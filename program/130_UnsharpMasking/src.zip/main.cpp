//--------------------------------------------------------------------------------------
// File: main.cpp
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"
#include "resource.h"
#include "rendertarget.h"

#undef FAST_RENDERING
//#define FAST_RENDERING

//#define DEBUG_VS   // Uncomment this line to debug vertex shaders 
//#define DEBUG_PS   // Uncomment this line to debug pixel shaders 

#define ORIGINAL_WIDTH   1024.0f
#define ORIGINAL_HEIGHT  1024.0f

#define SCREEN_WIDTH   512.0f
#define SCREEN_HEIGHT  512.0f
//#define SCREEN_WIDTH   1024.0f
//#define SCREEN_HEIGHT  1024.0f
//#define SCREEN_WIDTH  1280.0f
//#define SCREEN_HEIGHT  720.0f

#define SCREEN_FORMAT 	RTF_RGBA
//#define SCREEN_FORMAT 	RTF_RGBA16F

#define DEPTH_FORMAT 	RTF_RGBA
//#define DEPTH_FORMAT 	RTF_R16F

#define Z_NEAR 0.5f
#define Z_FAR  10.0f
//--------------------------------------------------------------------------------------
// Vertex format
//--------------------------------------------------------------------------------------
struct VERTEX 
{
    D3DXVECTOR4 pos;
    D3DXVECTOR2 tex1;

    static const DWORD FVF;
};
const DWORD VERTEX::FVF = D3DFVF_XYZRHW | D3DFVF_TEX1;


typedef struct {
	FLOAT       p[4];
	FLOAT       tu, tv;
} TVERTEX;



//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN     1
#define IDC_TOGGLEREF            2
#define IDC_CHANGEDEVICE         3
#define IDC_CHANGE_SCENE         4
#define IDC_PAUSE                10
#define IDC_INTENSITY_STATIC     11
#define IDC_INTENSITY            12
#define IDC_RADIUS_STATIC        13
#define IDC_RADIUS               14

//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
HWND g_hWnd;
ID3DXFont*              g_pFont = NULL;         // Font for drawing text
ID3DXSprite*            g_pTextSprite = NULL;   // Sprite for batching draw text calls
CFirstPersonCamera      g_Camera;               // A model viewing camera
bool                    g_bShowHelp = true;     // If true, it renders the UI control text
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg         g_SettingsDlg;          // Device settings dialog
CDXUTDialog             g_HUD;                  // dialog for standard controls
CDXUTDialog             g_SampleUI;             // dialog for sample specific controls
bool                    g_bPause = false;
//bool                    g_bPause = true;
float                   g_fPhase = D3DX_PI * 0.8f;

VERTEX                  g_Vertex[4];

// Render target
CRenderTarget          *g_pRT_FullScreen=0;
D3DVIEWPORT9            g_ViewportFB;
CRenderTarget          *g_pRT_Depth=0;
CRenderTarget          *g_pRT_GaussX=0;
CRenderTarget          *g_pRT_Blur=0;

// BG object
bool                    g_bObj = true;
LPD3DXMESH              g_pObjMesh=0;
LPDIRECT3DTEXTURE9      g_pObjMeshTexture=0;
D3DXMATRIXA16           g_matObjWorld;

// Map object
bool                    g_bMap = true;
LPD3DXMESH              g_pMapMesh=0;
LPDIRECT3DTEXTURE9      g_pMapMeshTexture=0;
D3DXMATRIXA16           g_matMapWorld;

// Scene management
DWORD                   g_dwBackgroundColor;


// Effect system
LPD3DXEFFECT            g_pEffect;
D3DXHANDLE              g_hWorld = NULL;
D3DXHANDLE              g_hWorldView = NULL;
D3DXHANDLE              g_hWorldViewProjection = NULL;

D3DXHANDLE              g_hMeshTexture = NULL;

D3DXHANDLE              g_hTechScene           = NULL;
D3DXHANDLE              g_hTechFinal           = NULL;
float                   g_fGaussRadius = 4.0f;
float                   g_fIntensity = 20.0f;

//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
bool    CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext );
bool    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext );
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
void    CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void    CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void    CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void    CALLBACK OnLostDevice( void* pUserContext );
void    CALLBACK OnDestroyDevice( void* pUserContext );

void    InitApp();
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh );
void    RenderText(bool bFast);
void    SetupQuad( const D3DSURFACE_DESC* pBackBufferSurfaceDesc );


void SetGaussWeight()
{
//	 const float dispersion = 0.3f;
	 const float dispersion = 1.f;
	 const unsigned int WEIGHT_MUN = 4;
	 float tbl[WEIGHT_MUN];
     DWORD i;
 
     FLOAT total=0;
     for( i=0; i<WEIGHT_MUN; i++ ){
         tbl[i] = expf(-0.5f*(FLOAT)(i*i)/dispersion);
         if(0==i){
             total += tbl[i];
         }else{
             // ���S�ȊO�́A�Q�񓯂��W�����g���̂łQ�{
             total += 2.0f*tbl[i];
         }
     }
     // �K�i��
     for( i=0; i<WEIGHT_MUN; i++ ) tbl[i] /= total;
 
     if(g_pEffect) g_pEffect->SetFloatArray("weight", tbl, WEIGHT_MUN);
 
}

void SetGaussRadius()
{
	float range = g_fGaussRadius;
	
    D3DXVECTOR4  width(2.0f*range/ORIGINAL_WIDTH, 4.0f*range/ORIGINAL_WIDTH, 6.0f*range/ORIGINAL_WIDTH, 8.0f*range/ORIGINAL_WIDTH);
    D3DXVECTOR4 height(2.0f*range/ORIGINAL_WIDTH, 4.0f*range/ORIGINAL_WIDTH, 6.0f*range/ORIGINAL_WIDTH, 8.0f*range/ORIGINAL_WIDTH);
    
    if(g_pEffect) g_pEffect->SetVector("vBias",  &width);
    if(g_pEffect) g_pEffect->SetVector("hBias", &height);
}

//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // Set the callback functions. These functions allow DXUT to notify
    // the application about device changes, user input, and windows messages.  The 
    // callbacks are optional so you need only set callbacks for events you're interested 
    // in. However, if you don't handle the device reset/lost callbacks then the sample 
    // framework won't be able to reset your device since the application must first 
    // release all device resources before resetting.  Likewise, if you don't handle the 
    // device created/destroyed callbacks then DXUT won't be able to 
    // recreate your device resources.
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( KeyboardProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Show the cursor and clip it when in full screen
    DXUTSetCursorSettings( true, true );

    InitApp();

    // Initialize DXUT and create the desired Win32 window and Direct3D 
    // device for the application. Calling each of these functions is optional, but they
    // allow you to set several options which control the behavior of the framework.
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTCreateWindow( L"Unsharp Masking" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, (DWORD)SCREEN_WIDTH, (DWORD)SCREEN_HEIGHT, IsDeviceAcceptable, ModifyDeviceSettings );
//    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 640, 480, IsDeviceAcceptable, ModifyDeviceSettings );

    // Pass control to DXUT for handling the message pump and 
    // dispatching render calls. DXUT will call your FrameMove 
    // and FrameRender callback when there is idle time between handling window messages.
    DXUTMainLoop();

    // Perform any application-level cleanup here. Direct3D device resources are released within the
    // appropriate callback functions and therefore don't require any cleanup code here.

    return DXUTGetExitCode();
}


//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    g_pFont = NULL;

    g_pEffect = NULL;

    g_bShowHelp = TRUE;
    g_dwBackgroundColor = 0x00003F3F;

	// Initialize dialogs
    g_SettingsDlg.Init( &g_DialogResourceManager );
    g_HUD.Init( &g_DialogResourceManager );
    g_SampleUI.Init( &g_DialogResourceManager );

    g_HUD.SetCallback( OnGUIEvent ); int iY = 10; 
    g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
    g_HUD.AddButton( IDC_TOGGLEREF, L"Toggle REF (F3)", 35, iY += 24, 125, 22 );
    g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device (F2)", 35, iY += 24, 125, 22, VK_F2 );

    g_SampleUI.SetCallback( OnGUIEvent ); iY = 100; 

    WCHAR sz[100];

    g_SampleUI.AddCheckBox( IDC_PAUSE, L"PAUSE", 50, iY += 24, 145, 22, g_bPause );
//    iY += 24;
	StringCchPrintf( sz, 100, L"Intensity: %0.2f", g_fIntensity ); 
    g_SampleUI.AddStatic( IDC_INTENSITY_STATIC, sz, 35, iY += 24, 125, 22 );
    g_SampleUI.AddSlider( IDC_INTENSITY, 50, iY += 24, 100, 22, 0, 10000, (int) (100.0f*g_fIntensity) );

	StringCchPrintf( sz, 100, L"Radius: %0.2f", g_fGaussRadius ); 
    g_SampleUI.AddStatic( IDC_RADIUS_STATIC, sz, 35, iY += 24, 125, 22 );
    g_SampleUI.AddSlider( IDC_RADIUS, 50, iY += 24, 100, 22, 0, 1000, (int) (100.0f*g_fGaussRadius) );

}


//--------------------------------------------------------------------------------------
// Called during device initialization, this code checks the device for some 
// minimum set of capabilities, and rejects those that don't pass by returning false.
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    // Skip backbuffer formats that don't support alpha blending
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

    // Must support pixel shader 1.1
    if( pCaps->PixelShaderVersion < D3DPS_VERSION( 2, 0 ) )
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// This callback function is called immediately before a device is created to allow the 
// application to modify the device settings. The supplied pDeviceSettings parameter 
// contains the settings that the framework has selected for the new device, and the 
// application can make any desired changes directly to this structure.  Note however that 
// DXUT will not correct invalid device settings so care must be taken 
// to return valid device settings, otherwise IDirect3D9::CreateDevice() will fail.  
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps, void* pUserContext )
{
    // If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
    // then switch to SWVP.
    if( (pCaps->DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT) == 0 ||
         pCaps->VertexShaderVersion < D3DVS_VERSION(2,0) )
    {
        pDeviceSettings->BehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }

    // Debugging vertex shaders requires either REF or software vertex processing 
    // and debugging pixel shaders requires REF.  
#ifdef DEBUG_VS
    if( pDeviceSettings->DeviceType != D3DDEVTYPE_REF )
    {
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_HARDWARE_VERTEXPROCESSING;
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_PUREDEVICE;                            
        pDeviceSettings->BehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }
#endif
#ifdef DEBUG_PS
    pDeviceSettings->DeviceType = D3DDEVTYPE_REF;
#endif

    // For the first device created if its a REF device, optionally display a warning dialog box
    static bool s_bFirstTime = true;
    if( s_bFirstTime )
    {
        s_bFirstTime = false;
        if( pDeviceSettings->DeviceType == D3DDEVTYPE_REF )
            DXUTDisplaySwitchingToREFWarning();
    }

    return true;
}


//--------------------------------------------------------------------------------------
// This function loads the mesh and ensures the mesh has normals; it also optimizes the 
// mesh for the graphics card's vertex cache, which improves performance by organizing 
// the internal triangle list for less cache misses.
//--------------------------------------------------------------------------------------
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh )
{
    ID3DXMesh* pMesh = NULL;
    WCHAR str[MAX_PATH];
    HRESULT hr;

    // Load the mesh with D3DX and get back a ID3DXMesh*.  For this
    // sample we'll ignore the X file's embedded materials since we know 
    // exactly the model we're loading.  See the mesh samples such as
    // "OptimizedMesh" for a more generic mesh loading example.
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, strFileName ) );

    V_RETURN( D3DXLoadMeshFromX(str, D3DXMESH_MANAGED, pd3dDevice, NULL, NULL, NULL, NULL, &pMesh) );

    // Make sure there are normals which are required for lighting
    if( !(pMesh->GetFVF() & D3DFVF_NORMAL) )
    {
        ID3DXMesh* pTempMesh;
        V( pMesh->CloneMeshFVF( pMesh->GetOptions(), 
                                  pMesh->GetFVF() | D3DFVF_NORMAL, 
                                  pd3dDevice, &pTempMesh ) );
        V( D3DXComputeNormals( pTempMesh, NULL ) );

        SAFE_RELEASE( pMesh );
        pMesh = pTempMesh;
    }

    *ppMesh = pMesh;

    return S_OK;
}

HRESULT OptimizeMesh( IDirect3DDevice9* pd3dDevice, ID3DXMesh** ppMesh )
{
    ID3DXMesh* pMesh = *ppMesh;
    DWORD *rgdwAdjacency = NULL;
    HRESULT hr;

    // Optimize the mesh for this graphics card's vertex cache 
    // so when rendering the mesh's triangle list the vertices will 
    // cache hit more often so it won't have to re-execute the vertex shader 
    // on those vertices so it will improve perf.     
    rgdwAdjacency = new DWORD[pMesh->GetNumFaces() * 3];
    if( rgdwAdjacency == NULL )
        return E_OUTOFMEMORY;
    V( pMesh->GenerateAdjacency(1e-6f,rgdwAdjacency) );
    V( pMesh->OptimizeInplace(D3DXMESHOPT_VERTEXCACHE, rgdwAdjacency, NULL, NULL, NULL) );
    delete []rgdwAdjacency;

    *ppMesh = pMesh;

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// created, which will happen during application initialization and windowed/full screen 
// toggles. This is the best location to create D3DPOOL_MANAGED resources since these 
// resources need to be reloaded whenever the device is destroyed. Resources created  
// here should be released in the OnDestroyDevice callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    WCHAR str[MAX_PATH];
    HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnCreateDevice( pd3dDevice ) );
    V_RETURN( g_SettingsDlg.OnCreateDevice( pd3dDevice ) );

    // Initialize the font
    V_RETURN( D3DXCreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         L"Arial", &g_pFont ) );

    // Load meshs
    V_RETURN( LoadMesh( pd3dDevice, TEXT("t-pot.x"), &g_pObjMesh ) );
    V_RETURN( OptimizeMesh( pd3dDevice, &g_pObjMesh ) );
    V_RETURN( LoadMesh( pd3dDevice, TEXT("room.x"), &g_pMapMesh ) );
    V_RETURN( OptimizeMesh( pd3dDevice, &g_pMapMesh ) );

    // Load mesh textures
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"t-pot.bmp" ) );
    V_RETURN( D3DXCreateTextureFromFile( pd3dDevice, str, &g_pObjMeshTexture) );
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"room.bmp" ) );
    V_RETURN( D3DXCreateTextureFromFile( pd3dDevice, str, &g_pMapMeshTexture) );


	// Define DEBUG_VS and/or DEBUG_PS to debug vertex and/or pixel shaders with the 
    // shader debugger. Debugging vertex shaders requires either REF or software vertex 
    // processing, and debugging pixel shaders requires REF.  The 
    // D3DXSHADER_FORCE_*_SOFTWARE_NOOPT flag improves the debug experience in the 
    // shader debugger.  It enables source level debugging, prevents instruction 
    // reordering, prevents dead code elimination, and forces the compiler to compile 
    // against the next higher available software target, which ensures that the 
    // unoptimized shaders do not exceed the shader model limitations.  Setting these 
    // flags will cause slower rendering since the shaders will be unoptimized and 
    // forced into software.  See the DirectX documentation for more information about 
    // using the shader debugger.
    DWORD dwShaderFlags = D3DXFX_NOT_CLONEABLE;
    #ifdef DEBUG_VS
        dwShaderFlags |= D3DXSHADER_FORCE_VS_SOFTWARE_NOOPT;
    #endif
    #ifdef DEBUG_PS
        dwShaderFlags |= D3DXSHADER_FORCE_PS_SOFTWARE_NOOPT;
    #endif

    // Read the D3DX effect file
    // If this fails, there should be debug output as to 
    // they the .fx file failed to compile
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"main.fx" ) );
    V_RETURN( D3DXCreateEffectFromFile( pd3dDevice, str, NULL, NULL, dwShaderFlags, 
                                        NULL, &g_pEffect, NULL ) );

    return S_OK;
}



//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// been destroyed, which generally happens as a result of application termination or 
// windowed/full screen toggles. Resources created in the OnCreateDevice callback 
// should be released here, which generally includes all D3DPOOL_MANAGED resources. 
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice( void* pUserContext )
{
    g_DialogResourceManager.OnDestroyDevice();
    g_SettingsDlg.OnDestroyDevice();
    SAFE_RELEASE(g_pEffect);
    SAFE_RELEASE(g_pFont);

    SAFE_RELEASE(g_pMapMeshTexture);
    SAFE_RELEASE(g_pObjMeshTexture);
    SAFE_RELEASE(g_pMapMesh);
    SAFE_RELEASE(g_pObjMesh);
}



//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// reset, which will happen after a lost device scenario. This is the best location to 
// create D3DPOOL_DEFAULT resources since these resources need to be reloaded whenever 
// the device is lost. Resources created here should be released in the OnLostDevice 
// callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnResetDevice() );
    V_RETURN( g_SettingsDlg.OnResetDevice() );

    if( g_pFont )
        V_RETURN( g_pFont->OnResetDevice() );
    if( g_pEffect )
        V_RETURN( g_pEffect->OnResetDevice() );

	// Setup the camera with view & projection matrix
    D3DXVECTOR3 vecEye(0.0f, 0.0f, 4.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, 0.0f);
    g_Camera.SetViewParams( &vecEye, &vecAt );
    g_Camera.SetProjParams( D3DXToRadian(50.0f), 1.0f, Z_NEAR, Z_FAR );
    g_Camera.SetRotateButtons( TRUE, FALSE, FALSE, FALSE );// L M R �����Ȃ��瓮����


	pd3dDevice->GetViewport(&g_ViewportFB);

    // Create fullscreen renders target texture
	g_pRT_FullScreen = CRenderTarget::Create(pd3dDevice
									, (DWORD)ORIGINAL_WIDTH, (DWORD)ORIGINAL_HEIGHT
									, SCREEN_FORMAT);
	g_pRT_Depth      = CRenderTarget::Create(pd3dDevice
									, (DWORD)ORIGINAL_WIDTH, (DWORD)ORIGINAL_HEIGHT
									, DEPTH_FORMAT, RTF_NONE);
	g_pRT_GaussX = CRenderTarget::Create(pd3dDevice
									, (DWORD)ORIGINAL_WIDTH, (DWORD)ORIGINAL_HEIGHT
									, DEPTH_FORMAT, RTF_NONE);
	g_pRT_Blur = CRenderTarget::Create(pd3dDevice
									, (DWORD)ORIGINAL_WIDTH, (DWORD)ORIGINAL_HEIGHT
									, DEPTH_FORMAT, RTF_NONE);


	SetupQuad( pBackBufferSurfaceDesc );

	
    // Get D3DXHANDLEs to the parameters/techniques that are set every frame so 
    // D3DX doesn't spend time doing string compares.  Doing this likely won't affect
    // the perf of this simple sample but it should be done in complex engine.
    g_hWorld                    = g_pEffect->GetParameterByName( NULL, "mWorld" );
    g_hWorldView                = g_pEffect->GetParameterByName( NULL, "mWorldView" );
    g_hWorldViewProjection      = g_pEffect->GetParameterByName( NULL, "mWorldViewProjection" );
    g_hMeshTexture              = g_pEffect->GetParameterByName( NULL, "MeshTexture" );

	g_hTechScene                = g_pEffect->GetTechniqueByName("TechScene");
	g_hTechFinal                = g_pEffect->GetTechniqueByName("TechFinal");

	// Set the vars in the effect that doesn't change each frame
	V_RETURN( g_pEffect->SetTexture("RenderTargetTexture", g_pRT_FullScreen->GetTexture()) );
	V_RETURN( g_pEffect->SetTexture("DepthRenderTarget", g_pRT_Depth->GetTexture()) );

	V_RETURN( g_pEffect->SetFloat("z_min", Z_NEAR) );
	V_RETURN( g_pEffect->SetFloat("z_max", Z_FAR) );

	SetGaussWeight();
	SetGaussRadius();


	pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

	g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 0 );
    g_HUD.SetSize( 170, 170 );
    g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width-170, pBackBufferSurfaceDesc->Height-300 );
    g_SampleUI.SetSize( 170, 250 );

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// entered a lost state and before IDirect3DDevice9::Reset is called. Resources created
// in the OnResetDevice callback should be released here, which generally includes all 
// D3DPOOL_DEFAULT resources. See the "Lost Devices" section of the documentation for 
// information about lost devices.
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice( void* pUserContext )
{
    g_DialogResourceManager.OnLostDevice();
    g_SettingsDlg.OnLostDevice();
    if( g_pFont )
        g_pFont->OnLostDevice();
    if( g_pEffect )
        g_pEffect->OnLostDevice();
    SAFE_RELEASE(g_pTextSprite);

    SAFE_RELEASE(g_pRT_Blur);
    SAFE_RELEASE(g_pRT_GaussX);
    SAFE_RELEASE(g_pRT_Depth);
    SAFE_RELEASE(g_pRT_FullScreen);
}


//--------------------------------------------------------------------------------------
// Sets up a quad to render the fullscreen render target to the backbuffer
// so it can run a fullscreen pixel shader pass that blurs based
// on the depth of the objects.  It set the texcoords based on the blur factor
//--------------------------------------------------------------------------------------
void SetupQuad( const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{
	FLOAT fWidth5  = pBackBufferSurfaceDesc->Width -0.5f;
	FLOAT fHeight5 = pBackBufferSurfaceDesc->Height-0.5f;

    FLOAT fTexWidth1  = 1.0f;
    FLOAT fTexHeight1 = 1.0f;

    g_Vertex[0].pos = D3DXVECTOR4(fWidth5, -0.5f, 0.0f, 1.0f);
    g_Vertex[0].tex1 = D3DXVECTOR2(fTexWidth1, 0.0f);

    g_Vertex[1].pos = D3DXVECTOR4(fWidth5, fHeight5, 0.0f, 1.0f);
    g_Vertex[1].tex1 = D3DXVECTOR2(fTexWidth1, fTexHeight1);

    g_Vertex[2].pos = D3DXVECTOR4(-0.5f, -0.5f, 0.0f, 1.0f);
    g_Vertex[2].tex1 = D3DXVECTOR2(0.0f, 0.0f);

    g_Vertex[3].pos = D3DXVECTOR4(-0.5f, fHeight5, 0.0f, 1.0f);
    g_Vertex[3].tex1 = D3DXVECTOR2(0.0f, fTexHeight1);
}

void RenderQuad(IDirect3DDevice9* pd3dDevice, D3DXHANDLE hTech)
{
    HRESULT hr;
	UINT cPasses, iPass;

	V( g_pEffect->SetTechnique(hTech) );

	V( pd3dDevice->SetFVF(VERTEX::FVF) );

	// Render the fullscreen quad on to the backbuffer
	V( g_pEffect->Begin(&cPasses, 0) );
	for (iPass = 0; iPass < cPasses; iPass++)
	{
		V( g_pEffect->BeginPass(iPass) );
		V( pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, g_Vertex, sizeof(VERTEX)) );
		V( g_pEffect->EndPass() );
	}
	V( g_pEffect->End() );
}

//--------------------------------------------------------------------------------------
// This callback function will be called once at the beginning of every frame. This is the
// best location for your application to handle updates to the scene, but is not 
// intended to contain actual rendering calls, which should instead be placed in the 
// OnFrameRender callback.  
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );

	if(!DXUTIsTimePaused())
	{
		if(!g_bPause)
		{
			g_fPhase += 2.0f * fElapsedTime;
			if(2.0f * D3DX_PI < g_fPhase) g_fPhase -= 2.0f * D3DX_PI;
		}
	}


    D3DXMATRIXA16 matTrans, matRot, matScale;
	D3DXMatrixScaling(&matScale, 1.0f, 1.0f, 1.0f);
    D3DXMatrixTranslation( &matTrans, 0.0f,+0.0f, -0.5f );
	D3DXMatrixRotationY(&matRot, g_fPhase);
	g_matObjWorld = matScale * matRot * matTrans;

	D3DXMatrixRotationY(&matRot, -D3DX_PI * 0.5f);
	D3DXMatrixScaling(&matScale, 3.5f, 3.5f, 3.5f);
	g_matMapWorld = matScale * matRot;
}

// render map
void RenderBG(IDirect3DDevice9* pd3dDevice)
{
	HRESULT hr;
	UINT iPass, cPasses;
    D3DXMATRIXA16 matView = *g_Camera.GetViewMatrix();
    D3DXMATRIXA16 matProj = *g_Camera.GetProjMatrix();
    D3DXMATRIXA16 matViewProj = matView * matProj;

    // Set world render technique
    V( g_pEffect->SetTechnique( g_hTechScene ) );
	
    // Update effect vars
    D3DXMATRIXA16 matWorldView;
    D3DXMATRIXA16 matWorldViewProj;

	if(g_bObj)
	{
		matWorldView     = g_matObjWorld * matView;
		matWorldViewProj = g_matObjWorld * matViewProj;

		V( g_pEffect->SetMatrix( g_hWorld, &g_matObjWorld) );
		V( g_pEffect->SetMatrix( g_hWorldView, &matWorldView) );
		V( g_pEffect->SetMatrix( g_hWorldViewProjection, &matWorldViewProj) );

		// Set the mesh texture 
		V( g_pEffect->SetTexture( g_hMeshTexture, g_pObjMeshTexture) );

		// Draw the mesh on the rendertarget
		V( g_pEffect->Begin(&cPasses, 0) );
		for (iPass = 0; iPass < cPasses; iPass++)
		{
			V( g_pEffect->BeginPass(iPass) );
			V( g_pObjMesh->DrawSubset(0) );
			V( g_pEffect->EndPass() );
		}
		V( g_pEffect->End() );
	}


	if(g_bMap)
	{
		matWorldView     = g_matMapWorld * matView;
		matWorldViewProj = g_matMapWorld * matViewProj;
		V( g_pEffect->SetMatrix( g_hWorld, &g_matMapWorld) );
		V( g_pEffect->SetMatrix( g_hWorldView, &matWorldView) );
		V( g_pEffect->SetMatrix( g_hWorldViewProjection, &matWorldViewProj) );

		// Set the mesh texture 
		V( g_pEffect->SetTexture( g_hMeshTexture, g_pMapMeshTexture) );

		// Draw the mesh on the rendertarget
		V( g_pEffect->Begin(&cPasses, 0) );
		for (iPass = 0; iPass < cPasses; iPass++)
		{
			V( g_pEffect->BeginPass(iPass) );
			V( g_pMapMesh->DrawSubset(0) );
			V( g_pEffect->EndPass() );
		}
		V( g_pEffect->End() );
	}
}



void RenderScene(IDirect3DDevice9* pd3dDevice)
{
	if( SUCCEEDED( g_pRT_Depth->Begin(1,RT_FLAG_NOT_SET_ZBUFFER) ) )
	if( SUCCEEDED( g_pRT_FullScreen->Begin(0) ) )
	{
		HRESULT hr;

		V( pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, g_dwBackgroundColor, 1.0f, 0) );

		RenderBG(pd3dDevice);

		g_pRT_FullScreen->End();
		g_pRT_Depth->End();
	}
}

void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	UINT iPass, cPasses;
    HRESULT hr;

    // If the settings dialog is being shown, then
    // render it instead of rendering the app's scene
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.OnRender( fElapsedTime );
        return;
    }


	LPDIRECT3DSURFACE9 pOriginalZbuffer = 0;
	V( pd3dDevice->GetDepthStencilSurface( &pOriginalZbuffer ) );

	// First render the world on the rendertarget
	RenderScene(pd3dDevice);

	if( SUCCEEDED( g_pRT_GaussX->Begin() ) )
	{
		static TVERTEX Vertex[4] = {
			//    x                             y         z rhw tu tv
			{-0.5,                             -0.5, 0, 1, 0, 0,},
			{ORIGINAL_WIDTH-0.5,               -0.5, 0, 1, 1, 0,},
			{ORIGINAL_WIDTH-0.5, ORIGINAL_HEIGHT-0.5, 0, 1, 1, 1,},
			{-0.5,               ORIGINAL_HEIGHT-0.5, 0, 1, 0, 1,},
		};
		pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		V( g_pEffect->SetTexture(g_hMeshTexture, g_pRT_Depth->GetTexture()) );
		V( g_pEffect->SetTechnique("TechGaussX") );

		V( g_pEffect->Begin(&cPasses, 0) );
		for (iPass = 0; iPass < cPasses; iPass++)
		{
			V( g_pEffect->BeginPass(iPass) );
			pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			V( g_pEffect->EndPass() );
		}
		V( g_pEffect->End() );

		g_pRT_GaussX->End();
	}

	if( SUCCEEDED( g_pRT_Blur->Begin() ) )
	{
		static TVERTEX Vertex[4] = {
			//    x                             y         z rhw tu tv
			{-0.5,                             -0.5, 0, 1, 0, 0,},
			{ORIGINAL_WIDTH-0.5,               -0.5, 0, 1, 1, 0,},
			{ORIGINAL_WIDTH-0.5, ORIGINAL_HEIGHT-0.5, 0, 1, 1, 1,},
			{-0.5,               ORIGINAL_HEIGHT-0.5, 0, 1, 0, 1,},
		};
		pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		V( g_pEffect->SetTexture(g_hMeshTexture, g_pRT_GaussX->GetTexture()) );
		V( g_pEffect->SetTechnique("TechGaussY") );

		V( g_pEffect->Begin(&cPasses, 0) );
		for (iPass = 0; iPass < cPasses; iPass++)
		{
			V( g_pEffect->BeginPass(iPass) );
			pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			V( g_pEffect->EndPass() );
		}
		V( g_pEffect->End() );

		g_pRT_Blur->End();
	}

	V( pd3dDevice->SetDepthStencilSurface( pOriginalZbuffer ) );
	SAFE_RELEASE( pOriginalZbuffer );

	// Clear the backbuffer 
//    V( pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET, 0x00000000, 1.0f, 0L ) );

    // Begin the scene, rendering to the backbuffer
    if( SUCCEEDED( pd3dDevice->BeginScene() ) )
    {
        pd3dDevice->SetViewport(&g_ViewportFB);

		g_pEffect->SetFloat("fIntensity", g_fIntensity);
		V( g_pEffect->SetTexture( g_hMeshTexture,  g_pRT_Blur->GetTexture()) );
		RenderQuad(pd3dDevice, g_hTechFinal);

#ifdef FAST_RENDERING
		BOOL bFastRendering = true;
#else // FAST_RENDERING
		BOOL bFastRendering = false;
#endif // FAST_RENDERING

		if(bFastRendering)
		{
			RenderText(true);
		}else{
#if 1
#ifdef _DEBUG // Display textures when debugging, (�f�o�b�O�p�Ƀe�N�X�`����\������)
			{
			pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
			pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
			pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
			pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
			pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
			pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			float scale = 64.0f;
			LPDIRECT3DTEXTURE9 texture_tbl[] = 
			{
				g_pRT_FullScreen->GetTexture(),
				g_pRT_Depth->GetTexture(),
				g_pRT_GaussX->GetTexture(),
				g_pRT_Blur->GetTexture(),
				NULL,
			};
			for(DWORD i=0; texture_tbl[i]; i++){
				TVERTEX Vertex[4] = {
					//    x                             y         z rhw tu tv
					{(i+0)*scale, (FLOAT)g_ViewportFB.Height-scale, 0, 1, 0, 0,},
					{(i+1)*scale, (FLOAT)g_ViewportFB.Height-scale, 0, 1, 1, 0,},
					{(i+1)*scale, (FLOAT)g_ViewportFB.Height-    0, 0, 1, 1, 1,},
					{(i+0)*scale, (FLOAT)g_ViewportFB.Height-    0, 0, 1, 0, 1,},
				};
				pd3dDevice->SetTexture( 0, texture_tbl[i] );
				pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			}
			}
#endif		
#endif
			V( g_HUD.OnRender( fElapsedTime ) );
			V( g_SampleUI.OnRender( fElapsedTime ) );

			// Render the text
			RenderText(false);

		}

		// End the scene.
        pd3dDevice->EndScene();
    }
}

//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText(bool bFast)
{
	if(bFast)
	{
		// �Ȃ�ׂ����ׂ����������Ȃ��Ƃ��ɂ́A
		// FPS ���X�V���ꂽ�Ƃ������E�B���h�E�̃^�C�g����ύX����V�X�e���ɂ���
		wchar_t buf[256];
		static float s_fFPS_Last = -1.0f;
		float fFps = DXUTGetFPS();
		if(fFps != s_fFPS_Last)
		{
			swprintf_s(  buf, 256, TEXT("%0.4f"), fFps );
			SetWindowText(g_hWnd, buf );
			s_fFPS_Last = fFps;
		}

		return;
	}

    // The helper object simply helps keep track of text position, and color
    // and then it calls pFont->DrawText( g_pSprite, strMsg, -1, &rc, DT_NOCLIP, g_clr );
    // If NULL is passed in as the sprite object, then it will work however the 
    // pFont->DrawText() will not be batched together.  Batching calls will improves performance.
    CDXUTTextHelper txtHelper( g_pFont, g_pTextSprite, 15 );

    // Output statistics
    txtHelper.Begin();
    txtHelper.SetInsertionPos( 5, 5 );
    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    txtHelper.DrawTextLine( DXUTGetFrameStats() );
    txtHelper.DrawTextLine( DXUTGetDeviceStats() );

    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
    txtHelper.DrawFormattedTextLine( L"FPS: %0.4f", DXUTGetFPS() );

#if 0
    // Draw help
    if( g_bShowHelp )
    {
        const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetBackBufferSurfaceDesc();
        txtHelper.SetInsertionPos( 2, pd3dsdBackBuffer->Height-15*6 );
        txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 0.75f, 0.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Controls (F1 to hide):" );

        txtHelper.SetInsertionPos( 20, pd3dsdBackBuffer->Height-15*5 );
        txtHelper.DrawTextLine( L"Look: Left drag mouse\n"
                                L"Move: A,W,S,D or Arrow Keys\n"
                                L"Move up/down: Q,E or PgUp,PgDn\n"
                                L"Reset camera: Home\n" );
    }
    else
    {
        txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Press F1 for help" );
    }
#endif
    txtHelper.End();
}


//--------------------------------------------------------------------------------------
// Before handling window messages, DXUT passes incoming windows 
// messages to the application through this callback function. If the application sets 
// *pbNoFurtherProcessing to TRUE, then DXUT will not process this message.
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
	g_hWnd = hWnd;

    // Always allow dialog resource manager calls to handle global messages
    // so GUI state is updated correctly
    *pbNoFurtherProcessing = g_DialogResourceManager.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
        return 0;
    }

    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;
    *pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// As a convenience, DXUT inspects the incoming windows messages for
// keystroke messages and decodes the message parameters to pass relevant keyboard
// messages to the application.  The framework does not remove the underlying keystroke 
// messages, which are still passed to the application's MsgProc callback.
//--------------------------------------------------------------------------------------
void CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{
    if( bKeyDown )
    {
        switch( nChar )
        {
            case VK_F1: g_bShowHelp = !g_bShowHelp; break;
        }
    }
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
    switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:        DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:     g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive() ); break;

		case IDC_PAUSE:
            g_bPause = g_SampleUI.GetCheckBox( IDC_PAUSE )->GetChecked(); 
			break;

		case IDC_INTENSITY: {
			g_fIntensity = 0.01f*(float) (g_SampleUI.GetSlider( IDC_INTENSITY )->GetValue());

            WCHAR sz[100];
			StringCchPrintf( sz, 100, L"Intensity: %0.2f", g_fIntensity ); 
			g_SampleUI.GetStatic( IDC_INTENSITY_STATIC )->SetText( sz );
			}break;

		case IDC_RADIUS: {
			g_fGaussRadius = 0.01f*(float) (g_SampleUI.GetSlider( IDC_RADIUS )->GetValue());

            WCHAR sz[100];
			StringCchPrintf( sz, 100, L"Radius: %0.2f", g_fGaussRadius ); 
			g_SampleUI.GetStatic( IDC_RADIUS_STATIC )->SetText( sz );
			SetGaussRadius();
			}break;

		default:
			break;
	}
}


