//-------------------------------------------------------------
// File: main.cpp
//
// Desc: ascii art
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_WIDTH	512
#define MAP_HEIGHT	512
const int COLOR_MAP[] = {MAP_WIDTH/8, MAP_WIDTH/32};


// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	DWORD i, j;

	m_pMesh						= new CD3DMesh();
	m_pMeshBg					= new CD3DMesh();

	m_pMapZ						= NULL;
	m_pOriginalMap				= NULL;
	m_pOriginalMapSurf			= NULL;
	m_pFinalMap					= NULL;
	m_pFinalMapSurf				= NULL;
	m_pPostMap					= NULL;
	m_pPostMapSurf				= NULL;
	m_pAsciiMap					= NULL;
	m_pAsciiCoeffMap			= NULL;

	for( i=0;i<2;i++ )
	{
		m_pColorMap[i]			= NULL;
		m_pColorMapSurf[i]		= NULL;
	}
	for( i=0;i<2;i++ )
	for( j=0;j<4;j++ )
	{
		m_pCoeffMap[i][j]		= NULL;
		m_pCoeffMapSurf[i][j]		= NULL;
	}
	for( j=0;j<4;j++ )
	{
		m_pWaveletMap[j]		= NULL;
	}
	for( i=0;i<13;i++ )
	{
		m_pDiffMap[i]			= NULL;
		m_pDiffMapSurf[i]		= NULL;
	}
	m_pIndex0Map			= NULL;
	m_pValue0Map			= NULL;
	m_pIndex0MapSurf		= NULL;
	m_pValue0MapSurf		= NULL;
	m_pIndex1Map			= NULL;
	m_pIndex1MapSurf		= NULL;


	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_htSrcMap					= NULL;

	m_fWorldRotX                = -0.195;
    m_fWorldRotY                = 3.14159265f;
	m_fViewZoom				    = 7.0f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}

// ----------------------------------------------------------------------------
// �e�N�X�`���[���쐬
// ----------------------------------------------------------------------------
float GetHaarWavelet( int n, int m, float x, float y )
{
	switch(n)
	{
	case 0:
		return 1;
		break;
	case 1:
		switch(m)
		{
		case 0: return (y<0.5) ? -1 : 1;
		case 1: return (x<0.5) ? -1 : 1;
		case 2: return ((x<0.5)^(y<0.5)) ? -1 : 1;
		}
		break;
	case 2:
		if(1==((m/3)&1)) x -= 0.5f;
		if(1==((m/3)/2)) y -= 0.5f;

		if( 0.0<=x && x<0.5 && 0.0<=y && y<0.5 )
		{
			switch(m%3)
			{
			case 0: return (x<0.25) ? -1 : 1;
			case 1: return (y<0.25) ? -1 : 1;
			case 2: return ((x<0.25)^(y<0.25)) ? -1 : 1;
			}
			break;
		}
	}

	return 0;
}


// ----------------------------------------------------------------------------
// �e�N�X�`���[���쐬
// ----------------------------------------------------------------------------
VOID WINAPI FillTextureHaarWavelet(D3DXVECTOR4* pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	float o[4] = {0.0, 0.0, 0.0, 0.0};
	int idx = (int)pData;

	switch(idx)
	{
	case 0:
		o[0] = GetHaarWavelet( 1, 0, pTexCoord->x, pTexCoord->y );
		o[1] = GetHaarWavelet( 1, 1, pTexCoord->x, pTexCoord->y );
		o[2] = GetHaarWavelet( 1, 2, pTexCoord->x, pTexCoord->y );
		o[3] = GetHaarWavelet( 0, 0, pTexCoord->x, pTexCoord->y );
		break;
	case 1:
		o[0] = GetHaarWavelet( 2, 0, pTexCoord->x, pTexCoord->y );
		o[1] = GetHaarWavelet( 2, 1, pTexCoord->x, pTexCoord->y );
		o[2] = GetHaarWavelet( 2, 2, pTexCoord->x, pTexCoord->y );
		o[3] = GetHaarWavelet( 2, 9, pTexCoord->x, pTexCoord->y );
		break;
	case 2:
		o[0] = GetHaarWavelet( 2, 3, pTexCoord->x, pTexCoord->y );
		o[1] = GetHaarWavelet( 2, 4, pTexCoord->x, pTexCoord->y );
		o[2] = GetHaarWavelet( 2, 5, pTexCoord->x, pTexCoord->y );
		o[3] = GetHaarWavelet( 2,10, pTexCoord->x, pTexCoord->y );
		break;
	case 3:
		o[0] = GetHaarWavelet( 2, 6, pTexCoord->x, pTexCoord->y );
		o[1] = GetHaarWavelet( 2, 7, pTexCoord->x, pTexCoord->y );
		o[2] = GetHaarWavelet( 2, 8, pTexCoord->x, pTexCoord->y );
		o[3] = GetHaarWavelet( 2,11, pTexCoord->x, pTexCoord->y );
		break;
	}
	pOut->x = 0.5f * o[0] + 0.5f;
	pOut->y = 0.5f * o[1] + 0.5f;
	pOut->z = 0.5f * o[2] + 0.5f;
	pOut->w = 0.5f * o[3] + 0.5f;
}

// ----------------------------------------------------------------------------
// �e�N�X�`���[���쐬
// ----------------------------------------------------------------------------
VOID WINAPI FillTextureAsciiCoeff(D3DXVECTOR4* pOut, CONST D3DXVECTOR2 *pTexCoord, CONST D3DXVECTOR2 *pTexelSize, LPVOID pData)
{
	CMyD3DApplication *pApp = (CMyD3DApplication*)pData;
	DWORD i, j;
	int ascii = 52.0 * pTexCoord->x;
	int idx   =  4.0 * pTexCoord->y;
	int n[4];
	int m[4];
	float o[4] = {0,0,0,0};

	switch(idx)
	{
	case 0:
		n[0] = 1; m[0] = 0;
		n[1] = 1; m[1] = 1;
		n[2] = 1; m[2] = 2;
		n[3] = 0; m[3] = 0;
		break;
	case 1:
		n[0] = 2; m[0] = 0;
		n[1] = 2; m[1] = 1;
		n[2] = 2; m[2] = 2;
		n[3] = 2; m[3] = 9;
		break;
	case 2:
		n[0] = 2; m[0] = 3;
		n[1] = 2; m[1] = 4;
		n[2] = 2; m[2] = 5;
		n[3] = 2; m[3] =10;
		break;
	case 3:
		n[0] = 2; m[0] = 6;
		n[1] = 2; m[1] = 7;
		n[2] = 2; m[2] = 8;
		n[3] = 2; m[3] =11;
		break;
	}
	for( i=0;i<24;i++ )
	for( j=0;j<24;j++ )
	{
		float x = (1.0f/24.0f) * (float)i;
		float y = (1.0f/24.0f) * (float)j;
		float tex = (2.0f/255.0f) * (float) pApp->m_iTex[ascii][j][i] - 1.0f;

		o[0] += GetHaarWavelet( n[0], m[0], x, y ) * tex;
		o[1] += GetHaarWavelet( n[1], m[1], x, y ) * tex;
		o[2] += GetHaarWavelet( n[2], m[2], x, y ) * tex;
		o[3] += GetHaarWavelet( n[3], m[3], x, y ) * tex;
	}
	o[0] /= (24.0*24.0);
	o[1] /= (24.0*24.0);
	o[2] /= (24.0*24.0);
	o[3] /= (24.0*24.0);

	pOut->x = 0.5f * o[0] + 0.5f;
	pOut->y = 0.5f * o[1] + 0.5f;
	pOut->z = 0.5f * o[2] + 0.5f;
	pOut->w = 0.5f * o[3] + 0.5f;
}




void CMyD3DApplication::CreateTextureArray( LPDIRECT3DTEXTURE9 pTex )
{
	D3DLOCKED_RECT d3dlr;

	pTex->LockRect(0,&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N
	
    unsigned char *p = (unsigned char *)d3dlr.pBits;
    for( int y = 0; y < ASCII_HEIGHT; y++ )
	{
		for( int x = 0; x < ASCII_MAX * ASCII_WIDTH; x++ )
		{
			int idx = x/ASCII_WIDTH;
			m_iTex[idx][y][x%ASCII_WIDTH] = p[ 32 * d3dlr.Pitch * y / ASCII_HEIGHT
											+ d3dlr.Pitch * x / (ASCII_MAX * ASCII_WIDTH) ];
		}
    }

	pTex->UnlockRect(0);
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

#ifdef DX9C
	// UFO�̓ǂݍ���
	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, (LPCWSTR)("t-pot.x"))))
        return DXTRACE_ERR( "LoadCar", hr );
	// �n�ʂ̓ǂݍ���
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, (LPCWSTR)("map.x"))))
        return DXTRACE_ERR( "Load BG", hr );
#else // DX9C
	// UFO�̓ǂݍ���
	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, _T("t-pot.x"))))
        return DXTRACE_ERR( "LoadCar", hr );
	// �n�ʂ̓ǂݍ���
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load BG", hr );
#endif // DX9C
	m_pMesh->UseMeshMaterials(false);
	m_pMeshBg->UseMeshMaterials(false);
        
	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_htSrcMap  = m_pEffect->GetParameterByName( NULL, "SrcMap" );

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );
    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i, j;

	// ���b�V��
	m_pMesh  ->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );

    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );


    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ALPHATESTENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
    TSS( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	// �e�N�X�`��
	D3DXCreateTextureFromFileEx(m_pd3dDevice, "abc.bmp", 0,0,1,
		0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, D3DX_FILTER_POINT, D3DX_DEFAULT,0, NULL,NULL,
		&m_pAsciiMap);
	CreateTextureArray( m_pAsciiMap );

	for( i=0;i<4;i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture( 4, 4, 1, 
			0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, m_pWaveletMap+i, NULL)))
			return E_FAIL;
	}

	D3DXCreateTexture( m_pd3dDevice, 52, 4, 1, 
			0, D3DFMT_A32B32G32R32F, D3DPOOL_MANAGED, &m_pAsciiCoeffMap);

	// �V���h�E�}�b�v�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_WIDTH, MAP_HEIGHT, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_WIDTH, MAP_HEIGHT, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pOriginalMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pOriginalMap->GetSurfaceLevel(0, &m_pOriginalMapSurf)))
		return E_FAIL;
	// ���m�g�[��
	if (FAILED(m_pd3dDevice->CreateTexture(
						COLOR_MAP[0], COLOR_MAP[0], 1,
						D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,
						D3DPOOL_DEFAULT, &m_pPostMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pPostMap->GetSurfaceLevel(0, &m_pPostMapSurf)))
		return E_FAIL;
	// �ŏI�摜
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_WIDTH, MAP_HEIGHT, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pFinalMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pFinalMap->GetSurfaceLevel(0, &m_pFinalMapSurf)))
		return E_FAIL;

	// �e�N�X�`��
	for( i=0;i<2;i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[i], COLOR_MAP[i], 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pColorMap[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pColorMap[i]->GetSurfaceLevel(0, &m_pColorMapSurf[i])))
			return E_FAIL;
	}

	for( i=0;i<2;i++ )
	for( j=0;j<4;j++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[i], COLOR_MAP[i], 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pCoeffMap[i][j], NULL)))
			return E_FAIL;
		if (FAILED(m_pCoeffMap[i][j]->GetSurfaceLevel(0, &m_pCoeffMapSurf[i][j])))
			return E_FAIL;
	}

	for( i=0;i<13;i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[1], COLOR_MAP[1], 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pDiffMap[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pDiffMap[i]->GetSurfaceLevel(0, &m_pDiffMapSurf[i])))
			return E_FAIL;
	}

	if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[1], COLOR_MAP[1], 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pValue0Map, NULL)))
		return E_FAIL;
	if (FAILED(m_pValue0Map->GetSurfaceLevel(0, &m_pValue0MapSurf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[1], COLOR_MAP[1], 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pIndex0Map, NULL)))
		return E_FAIL;
	if (FAILED(m_pIndex0Map->GetSurfaceLevel(0, &m_pIndex0MapSurf)))
		return E_FAIL;

	if (FAILED(m_pd3dDevice->CreateTexture( COLOR_MAP[1], COLOR_MAP[1], 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pIndex1Map, NULL)))
		return E_FAIL;
	if (FAILED(m_pIndex1Map->GetSurfaceLevel(0, &m_pIndex1MapSurf)))
		return E_FAIL;

	// Fill textures
	D3DXFillTexture( m_pAsciiCoeffMap, (LPD3DXFILL2D)FillTextureAsciiCoeff, (LPVOID)this );
	for( i=0;i<4;i++ )
	{
		D3DXFillTexture( m_pWaveletMap[i], (LPD3DXFILL2D)FillTextureHaarWavelet, (LPVOID)i );
	}

	m_pEffect->OnResetDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else
    if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else
    if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
	D3DXVECTOR4 v;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	DWORD i, j;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ύX
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pOriginalMapSurf);
			m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);

			// �r���[�|�[�g�̕ύX
			D3DVIEWPORT9 viewport = {0,0      // ����̍��W
							, MAP_WIDTH  // ��
							, MAP_HEIGHT // ����
							, 0.0f,1.0f};     // �O�ʁA���
			m_pd3dDevice->SetViewport(&viewport);

			// �}�b�v�̃N���A
			m_pd3dDevice->Clear(0L, NULL
							, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
							, 0x003040, 1.0f, 0L);

			//-------------------------------------------------
			// 1�p�X:�e�N�X�`���Ƀ����_�����O�̍쐬
			//-------------------------------------------------
			m_pEffect->SetTechnique( "SimpleTech" );
			m_pEffect->Begin( NULL, 0 );

			mW = m_mWorld;
			m_pEffect->SetMatrix( "mWorldIT", &mW );
			m = mW * m_mView * m_mProj;
			m_pEffect->SetMatrix( "mWorldViewProjection", &m);
			v = D3DXVECTOR4(1,1,1,0);
			m_pEffect->SetVector( "MaterialAmbientColor", &v);
			v = D3DXVECTOR4(0,0,0,0);
			m_pEffect->SetVector( "MaterialDiffuseColor", &v);

			m_pEffect->SetTexture( "SrcMap", m_pMeshBg->m_pTextures[0] );

			BEGIN_PASS(0);
			m_pMeshBg->Render( m_pd3dDevice );
			END_PASS();

			// ��s���f���̕`��
			D3DXMatrixTranslation( &m, 1.0f, 0.0f ,0.0f );
			D3DXMatrixRotationY( &mR,  fmod( 2.0f * m_fTime, 2.0f*3.14159265f) );
			D3DXMatrixTranslation( &mT, 0.0f, 1.0f ,1.0f );
			mW = m * mR * mT * m_mWorld;
			m_pEffect->SetMatrix( "mWorldIT", &mW);
			m = mW * m_mView * m_mProj;
			m_pEffect->SetMatrix( "mWorldViewProjection", &m);
			v = D3DXVECTOR4(0.3,0.3,0.3,0);
			m_pEffect->SetVector( "MaterialAmbientColor", &v);
			v = D3DXVECTOR4(0.7,0.7,0.7,0);
			m_pEffect->SetVector( "MaterialDiffuseColor", &v);
			m_pEffect->SetTexture( "SrcMap", m_pMesh->m_pTextures[0] );

			BEGIN_PASS(0);
			m_pMesh  ->Render( m_pd3dDevice );
			END_PASS();

			m_pEffect->End();


			//-------------------------------------------------
			// �k���o�b�t�@�ɃR�s�[
			//-------------------------------------------------
			RS( D3DRS_ZENABLE, FALSE );
			m_pEffect->SetTechnique( "SmallTech" );
			m_pEffect->Begin( NULL, 0 );
			
			for( i=0;i<2;i++ )
			{
				m_pd3dDevice->SetRenderTarget(0, m_pColorMapSurf[i]);

				static const float Vertex1[4][5] = {
					// x      y     z      tu    tv
					{-1.0f, -1.0f, 0.5f,   0, 0,},
					{+1.0f, -1.0f, 0.5f,   1, 0,},
					{+1.0f, +1.0f, 0.5f,   1, 1,},
					{-1.0f, +1.0f, 0.5f,   0, 1,},
				};
				m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
				if(0==i)
				{
					m_pEffect->SetTexture( "SrcMap", m_pOriginalMap );
					m_pEffect->SetFloat( "INV_TEXSIZE", 1.0 / 512.0 );
				}else{
					m_pEffect->SetTexture( "SrcMap", m_pColorMap[i-1]);
					m_pEffect->SetFloat( "INV_TEXSIZE", 1.0f/(FLOAT)COLOR_MAP[i-1]);
				}
				
				BEGIN_PASS(0);
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex1, 5*sizeof( float ) );
				END_PASS();
			}
			m_pEffect->End();

			//-------------------------------------------------
			// ���m�g�[����
			//-------------------------------------------------
			m_pEffect->SetTechnique( "TShader" );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pPostMapSurf);

			TVERTEX Vertex1[4] = {
				//   x         y         z     w       tu    tv
				{        0.0f-0.5,         0.0f-0.5, 0.1f, 1.0f,   0, 0,},
				{COLOR_MAP[0]-0.5,         0.0f-0.5, 0.1f, 1.0f,   1, 0,},
				{COLOR_MAP[0]-0.5, COLOR_MAP[0]-0.5, 0.1f, 1.0f,   1, 1,},
				{        0.0f-0.5, COLOR_MAP[0]-0.5, 0.1f, 1.0f,   0, 1,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcMap, m_pColorMap[0] );

			BEGIN_PASS(0);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();

			//-------------------------------------------------
			// Wavelet�W���̌v�Z
			//-------------------------------------------------
			m_pEffect->SetTechnique( "WaveletTech" );
			m_pEffect->Begin( NULL, 0 );

			m_pEffect->SetFloat( "INV_TEXSIZE", 1.0f/(FLOAT)COLOR_MAP[0]);
			m_pEffect->SetTexture( "PointMap", m_pPostMap );
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

			for( i=0;i<4;i++ )
			{
				m_pd3dDevice->SetRenderTarget(0, m_pCoeffMapSurf[0][i]);

				static float Vertex[4][5] = {
					// x      y     z     tu tv
					{-1.0f, -1.0f, 0.5f,   0, 0,},
					{+1.0f, -1.0f, 0.5f,   1, 0,},
					{+1.0f, +1.0f, 0.5f,   1, 1,},
					{-1.0f, +1.0f, 0.5f,   0, 1,},
				};
				m_pEffect->SetTexture( "WaveletTexture", m_pWaveletMap[i] );
				BEGIN_PASS(0);
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex, 5*sizeof( float ) );
				END_PASS();
			}

			m_pEffect->End();



			//-------------------------------------------------
			// Wavelet�W���̏k����
			//-------------------------------------------------
			m_pEffect->SetTechnique( "SmallTech4" );
			m_pEffect->Begin( NULL, 0 );
			
			for( i=0;i<4;i++ )
			{
				m_pd3dDevice->SetRenderTarget(0, m_pCoeffMapSurf[1][i]);

				float Vertex1[4][5] = {
					// x      y     z      tu    tv
					{-1.0f, -1.0f, 0.5f,   0, 0,},
					{+1.0f, -1.0f, 0.5f,   1, 0,},
					{+1.0f, +1.0f, 0.5f,   1, 1,},
					{-1.0f, +1.0f, 0.5f,   0, 1,},
				};
				m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
				m_pEffect->SetTexture( "SrcMap", m_pCoeffMap[0][i]);
				m_pEffect->SetFloat( "INV_TEXSIZE", 1.0f/(FLOAT)COLOR_MAP[0]);
				BEGIN_PASS(0);
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex1, 5*sizeof( float ) );
				END_PASS();

			}
			m_pEffect->End();

			//-------------------------------------------------
			// �e�����Ƃ̌W���̔�r������
			//-------------------------------------------------
			{
			m_pEffect->SetTechnique( "DiffTech" );
			m_pEffect->Begin( NULL, 0 );
			
			m_pEffect->SetTexture( "PointMap", m_pAsciiCoeffMap );
			m_pEffect->SetTexture( "SrcMap0", m_pCoeffMap[1][0]);
			m_pEffect->SetTexture( "SrcMap1", m_pCoeffMap[1][1]);
			m_pEffect->SetTexture( "SrcMap2", m_pCoeffMap[1][2]);
			m_pEffect->SetTexture( "SrcMap3", m_pCoeffMap[1][3]);

			static const TVERTEX Vertex[4] = {
				//        x                 y         z     w     tu tv
				{        0.0f-0.5,         0.0f-0.5, 0.1f, 1.0f,   0, 0,},
				{COLOR_MAP[1]-0.5,         0.0f-0.5, 0.1f, 1.0f,   1, 0,},
				{COLOR_MAP[1]-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   1, 1,},
				{        0.0f-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   0, 1,},
			};

			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );

			for( i=0;i<13;i++ )
			{
				m_pd3dDevice->SetRenderTarget( 0, m_pDiffMapSurf[i] );

				for(j=0;j<4;j++)
				{
					m_pEffect->SetFloat( "INV_TEXSIZE", (1.0/13.0)*(float)i + (1.0/52.0)*(float)j );
					if(0==j) m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_RED ); else
					if(1==j) m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_GREEN ); else
					if(2==j) m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE,  D3DCOLORWRITEENABLE_BLUE); else
					if(3==j) m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_ALPHA );

					BEGIN_PASS(0);
					m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
										, 2, Vertex, sizeof( TVERTEX ) );
					END_PASS();
				}
			}
			m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, 0xf );
			m_pEffect->End();
			}

			//-------------------------------------------------
			// �W�����r(52��13)
			//-------------------------------------------------
			{
			m_pEffect->SetTechnique( "CompareTech" );
			m_pEffect->Begin( NULL, 0 );
			
			static const TVERTEX Vertex[4] = {
				//   x         y         z     w       tu    tv
				{        0.0f-0.5,         0.0f-0.5, 0.1f, 1.0f,   0, 0,},
				{COLOR_MAP[1]-0.5,         0.0f-0.5, 0.1f, 1.0f,   1, 0,},
				{COLOR_MAP[1]-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   1, 1,},
				{        0.0f-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   0, 1,},
			};

			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			m_pd3dDevice->SetRenderTarget( 0, m_pValue0MapSurf );
			m_pd3dDevice->SetRenderTarget( 1, m_pIndex0MapSurf );

			for( i=0;i<4;i++ )
			{
				switch(i)
				{
				case 0:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE,D3DCOLORWRITEENABLE_RED );
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE1,D3DCOLORWRITEENABLE_RED );
					break;
				case 1:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE,D3DCOLORWRITEENABLE_GREEN);
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE1,D3DCOLORWRITEENABLE_GREEN);
					break;
				case 2:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE,D3DCOLORWRITEENABLE_BLUE);
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE1,D3DCOLORWRITEENABLE_BLUE);
					break;
				case 3:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE,D3DCOLORWRITEENABLE_ALPHA);
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE1,D3DCOLORWRITEENABLE_ALPHA);
					break;
				}

				if( 3!=i )
				{
					m_pEffect->SetTexture( "SrcMap0", m_pDiffMap[i*4+0]);
					m_pEffect->SetTexture( "SrcMap1", m_pDiffMap[i*4+1]);
					m_pEffect->SetTexture( "SrcMap2", m_pDiffMap[i*4+2]);
					m_pEffect->SetTexture( "SrcMap3", m_pDiffMap[i*4+3]);
				}else{
					m_pEffect->SetTexture( "SrcMap0", m_pDiffMap[i*4+0]);
					m_pEffect->SetTexture( "SrcMap1", m_pDiffMap[i*4+0]);
					m_pEffect->SetTexture( "SrcMap2", m_pDiffMap[i*4+0]);
					m_pEffect->SetTexture( "SrcMap3", m_pDiffMap[i*4+0]);
				}

				m_pEffect->SetFloat( "INV_TEXSIZE", (16.0/52.0)*(float)i );

				BEGIN_PASS(0);
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex, sizeof( TVERTEX ) );
				END_PASS();
			}
			m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE, 0xf );
			m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE1, 0xf );
			m_pd3dDevice->SetRenderTarget( 1, NULL );
			m_pEffect->End();
			}
			//-------------------------------------------------
			// �W�����r(13��1)
			//-------------------------------------------------
			{
			m_pEffect->SetTechnique( "Compare2Tech" );
			m_pEffect->Begin( NULL, 0 );
			
			static const TVERTEX Vertex[4] = {
				//        x                 y         z     w     tu tv
				{        0.0f-0.5,         0.0f-0.5, 0.1f, 1.0f,   0, 0,},
				{COLOR_MAP[1]-0.5,         0.0f-0.5, 0.1f, 1.0f,   1, 0,},
				{COLOR_MAP[1]-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   1, 1,},
				{        0.0f-0.5, COLOR_MAP[1]-0.5, 0.1f, 1.0f,   0, 1,},
			};

			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );

			m_pd3dDevice->SetRenderTarget( 0, m_pIndex1MapSurf );
			
			m_pEffect->SetTexture( "SrcMap0",  m_pValue0Map );
			m_pEffect->SetTexture( "IndexMap", m_pIndex0Map);

			BEGIN_PASS(0);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
			}

			//-------------------------------------------------
			// �ŏI����
			//-------------------------------------------------
			{
			m_pEffect->SetTechnique( "FinalTech" );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pFinalMapSurf);

			static const TVERTEX Vertex[4] = {
				//      x               y         z     w     tu tv
				{      0.0f-0.5,       0.0f-0.5, 0.1f, 1.0f,   0, 0,},
				{ MAP_WIDTH-0.5,       0.0f-0.5, 0.1f, 1.0f,   1, 0,},
				{ MAP_WIDTH-0.5, MAP_HEIGHT-0.5, 0.1f, 1.0f,   1, 1,},
				{      0.0f-0.5, MAP_HEIGHT-0.5, 0.1f, 1.0f,   0, 1,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcMap, m_pAsciiMap );
			m_pEffect->SetTexture( "PointMap", m_pColorMap[1] );
			m_pEffect->SetTexture( "SrcMap0",  m_pIndex1Map );
			
			BEGIN_PASS(0);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
			}


		}

		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		//-----------------------------------------------------
		// ���̂܂ܒ���
		//-----------------------------------------------------
		FLOAT w = (FLOAT)oldViewport.Width;
		FLOAT h = (FLOAT)oldViewport.Height;
		TSS(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		TSS(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		TSS(1,D3DTSS_COLOROP,   D3DTOP_DISABLE);
			
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
#if 0
		TVERTEX Vertex1[4] = {
			//x  y   z    rhw  tu tv
			{ 0 - 0.5f, 0 - 0.5f, 0.1f, 1.0f, 0, 0,},
			{ w - 0.5f, 0 - 0.5f, 0.1f, 1.0f, 1, 0,},
			{ w - 0.5f, h - 0.5f, 0.1f, 1.0f, 1, 1,},
			{ 0 - 0.5f, h - 0.5f, 0.1f, 1.0f, 0, 1,},
		};
		m_pd3dDevice->SetTexture(0, m_pOriginalMap);
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
#endif
		//-----------------------------------------------------
		// �ϊ��������̂𒣂�
		//-----------------------------------------------------

		TVERTEX Vertex2[4] = {
			//   x    y   z    rhw    tu    tv
#if 0
			{ 0.0f - 0.5f,   0 - 0.5f, 0.1f, 1.0f, 0.0f, 0.0f,},
			{ 0.5f*w - 0.5f, 0 - 0.5f, 0.1f, 1.0f, 0.5f, 0.0f,},
			{ 0.5f*w - 0.5f, h - 0.5f, 0.1f, 1.0f, 0.5f, 1.0f,},
			{ 0.0f - 0.5f,   h - 0.5f, 0.1f, 1.0f, 0.0f, 1.0f,},
#else
			{ 0.0f - 0.5f, 0 - 0.5f, 0.1f, 1.0f, 0.0f, 0.0f,},
			{    w - 0.5f, 0 - 0.5f, 0.1f, 1.0f, 1.0f, 0.0f,},
			{    w - 0.5f, h - 0.5f, 0.1f, 1.0f, 1.0f, 1.0f,},
			{ 0.0f - 0.5f, h - 0.5f, 0.1f, 1.0f, 0.0f, 1.0f,},
#endif
		};
		m_pd3dDevice->SetTexture(0, m_pFinalMap );
//		m_pd3dDevice->SetTexture(0, m_pColorMap[1] );
//		m_pd3dDevice->SetTexture(0, m_pPostMap);
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex2, sizeof( TVERTEX ) );

		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 64.0f;
#ifdef _DEBUG// �f�o�b�O�p�Ƀe�N�X�`����\������
		for(DWORD i=0; i<8; i++){
#else
		for(DWORD i=0; i<1; i++){
#endif
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pOriginalMap );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pPostMap );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pAsciiCoeffMap );
			if(3==i) m_pd3dDevice->SetTexture( 0, m_pColorMap[1] );

			if(4==i) m_pd3dDevice->SetTexture( 0, m_pValue0Map );
			if(5==i) m_pd3dDevice->SetTexture( 0, m_pIndex0Map );
			if(6==i) m_pd3dDevice->SetTexture( 0, m_pIndex1Map );
			if(4==i) m_pd3dDevice->SetTexture( 0, m_pDiffMap[0] );
			if(5==i) m_pd3dDevice->SetTexture( 0, m_pDiffMap[1] );
			if(6==i) m_pd3dDevice->SetTexture( 0, m_pDiffMap[2] );
			if(7==i) m_pd3dDevice->SetTexture( 0, m_pDiffMap[3] );
//			if(4==i) m_pd3dDevice->SetTexture( 0, m_pCoeffMap[1][0] );
//			if(5==i) m_pd3dDevice->SetTexture( 0, m_pCoeffMap[1][1] );
//			if(6==i) m_pd3dDevice->SetTexture( 0, m_pCoeffMap[1][2] );
//			if(7==i) m_pd3dDevice->SetTexture( 0, m_pCoeffMap[1][3] );
//			if(4==i) m_pd3dDevice->SetTexture( 0, m_pWaveletMap[0] );
//			if(5==i) m_pd3dDevice->SetTexture( 0, m_pWaveletMap[1] );
//			if(6==i) m_pd3dDevice->SetTexture( 0, m_pWaveletMap[2] );
//			if(7==i) m_pd3dDevice->SetTexture( 0, m_pWaveletMap[3] );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}

        // �w���v�̕\��
        RenderText();

		RS( D3DRS_ZENABLE, TRUE );

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
//    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
//    fNextLine -= 20.0f;
//    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
#ifndef _DEBUG
	fNextLine = (FLOAT) 2; 
    m_pFont->DrawText( m_d3dsdBackBuffer.Width-80+2, fNextLine+2, 0xff000000, TEXT("t-pot.com") );
    m_pFont->DrawText( m_d3dsdBackBuffer.Width-80+0, fNextLine,   0xffff8040, TEXT("t-pot.com") );
#endif //! _DEBUG

	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	DWORD i, j;

	// �e�N�X�`��
	SAFE_RELEASE(m_pFinalMapSurf);
	SAFE_RELEASE(m_pFinalMap);
	SAFE_RELEASE(m_pPostMapSurf);
	SAFE_RELEASE(m_pPostMap);
	SAFE_RELEASE(m_pOriginalMapSurf);
	SAFE_RELEASE(m_pOriginalMap);
	SAFE_RELEASE(m_pMapZ);

	SAFE_RELEASE(m_pIndex1MapSurf);
	SAFE_RELEASE(m_pIndex1Map);
	SAFE_RELEASE(m_pValue0MapSurf);
	SAFE_RELEASE(m_pValue0Map);
	SAFE_RELEASE(m_pIndex0MapSurf);
	SAFE_RELEASE(m_pIndex0Map);

	for( i=0;i<13;i++ )
	{
		SAFE_RELEASE(m_pDiffMapSurf[i]);
		SAFE_RELEASE(m_pDiffMap[i]);
	}

	for( i=0;i<2;i++ )
	{
		SAFE_RELEASE(m_pColorMapSurf[i]);
		SAFE_RELEASE(m_pColorMap[i]);
	}

	// �e�N�X�`��
	for( i=0;i<2;i++ )
	for( j=0;j<4;j++ )
	{
		SAFE_RELEASE(m_pCoeffMapSurf[i][j]);
		SAFE_RELEASE(m_pCoeffMap[i][j]);
	}

	// �e�N�X�`��
	SAFE_RELEASE(m_pAsciiCoeffMap);
	SAFE_RELEASE(m_pAsciiMap);
	for( i=0;i<4;i++ )
	{
		SAFE_RELEASE(m_pWaveletMap[i]);
	}

	m_pMesh  ->InvalidateDeviceObjects(); // ���b�V��
	m_pMeshBg->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// �V�F�[�_
	SAFE_RELEASE( m_pEffect );

	// ���b�V��
	m_pMesh  ->Destroy();
	m_pMeshBg->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pMeshBg ); // ���b�V��
	SAFE_DELETE( m_pMesh );

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




