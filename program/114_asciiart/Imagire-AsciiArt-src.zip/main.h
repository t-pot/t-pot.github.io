//-------------------------------------------------------------
// File: main.h
//
// Desc: ascii art
//-------------------------------------------------------------
#pragma once

#ifdef DX9C
	#define BEGIN_PASS(n) m_pEffect->BeginPass(n)
	#define END_PASS()    m_pEffect->EndPass()
#else// DX9C
	#define BEGIN_PASS(n) m_pEffect->Pass(n)
	#define END_PASS()
#endif // DX9C

//-------------------------------------------------------------
// ��`��萔
//-------------------------------------------------------------
// abc.bmp �̏��
#define ASCII_MAX    52
#define ASCII_WIDTH  24
#define ASCII_HEIGHT 24

// ���݂̓��̓f�[�^��ۑ�����\����
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
    BOOL bZoomIn;
    BOOL bZoomOut;
};




//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: �A�v���P�[�V�����̃N���X
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	CD3DMesh				*m_pMesh;
	CD3DMesh				*m_pMeshBg;
			
	// �V�F�[�_
	LPD3DXEFFECT		    m_pEffect;		// �G�t�F�N�g
	D3DXHANDLE				m_hTechnique;	// �e�N�j�b�N
	D3DXHANDLE				m_hafWeight;	// �d�݂̔z��
	D3DXHANDLE				m_htSrcMap;		// �e�N�X�`��

	// �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pMapZ;			// �[�x�o�b�t�@
	LPDIRECT3DTEXTURE9		m_pOriginalMap;		// �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pOriginalMapSurf;	// �T�[�t�F�X
	LPDIRECT3DTEXTURE9		m_pPostMap;		// �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pPostMapSurf;	// �T�[�t�F�X
	LPDIRECT3DTEXTURE9		m_pWaveletMap[4];	// Haar wavelet
	LPDIRECT3DTEXTURE9		m_pCoeffMap[2][4];
	LPDIRECT3DSURFACE9		m_pCoeffMapSurf[2][4];	// �T�[�t�F�X
	LPDIRECT3DTEXTURE9		m_pColorMap[2];		// �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pColorMapSurf[2];	// �T�[�t�F�X
	LPDIRECT3DTEXTURE9		m_pFinalMap;		// �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pFinalMapSurf;	// �T�[�t�F�X
	LPDIRECT3DTEXTURE9		m_pAsciiMap;
	LPDIRECT3DTEXTURE9		m_pAsciiCoeffMap;
	LPDIRECT3DTEXTURE9		m_pDiffMap[13];
	LPDIRECT3DSURFACE9		m_pDiffMapSurf[13];
	LPDIRECT3DTEXTURE9		m_pValue0Map;
	LPDIRECT3DTEXTURE9		m_pIndex0Map;
	LPDIRECT3DSURFACE9		m_pValue0MapSurf;
	LPDIRECT3DSURFACE9		m_pIndex0MapSurf;
	LPDIRECT3DTEXTURE9		m_pIndex1Map;
	LPDIRECT3DSURFACE9		m_pIndex1MapSurf;

	// �ʏ�̍��W�ϊ��s��
	D3DXMATRIX				m_mWorld;
	D3DXMATRIX				m_mView;
	D3DXMATRIX				m_mProj;

	BOOL					m_bLoadingApp;	// ���[�h���H
    CD3DFont*				m_pFont;		// �t�H���g
    UserInput				m_UserInput;	// ���̓f�[�^

    FLOAT                   m_fWorldRotX;   // �w����]
    FLOAT                   m_fWorldRotY;   // �x����]
    FLOAT                   m_fViewZoom;    // ���_�̋���

public:
	unsigned char           m_iTex[ASCII_MAX][ASCII_WIDTH][ASCII_HEIGHT];

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
	void	CreateTextureArray( LPDIRECT3DTEXTURE9 pTex );

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();

};

