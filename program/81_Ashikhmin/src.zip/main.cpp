//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Ashikhmin���f��
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE	256

// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

// ���_�錾
D3DVERTEXELEMENT9 decl[] =
{
	{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0},
	{0, 24, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_BINORMAL, 0},
	{0, 36, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TANGENT,  0},
	D3DDECL_END()
};
typedef struct  {
	D3DXVECTOR3 p;
	D3DXVECTOR3 n, b, t;
} MESH_VERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: Diffuse()
// Desc: Diffuse �e�N�X�`���̍쐬
//-------------------------------------------------------------
VOID WINAPI Diffuse (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
	FLOAT u = pTexCoord->x;
	FLOAT v = pTexCoord->y;
	
	u = 1-powf(1-u/2, 5);
	v = 1-powf(1-v/2, 5);

	pOut->x = pOut->y = pOut->z = u*v;
}

//-------------------------------------------------------------
// Name: gs()
// Desc: gs �e�N�X�`���̍쐬
//-------------------------------------------------------------
VOID WINAPI gs (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
	FLOAT u = pTexCoord->x;
	FLOAT v = pTexCoord->y;
	FLOAT g;

	if(1.0f-1.0f/256.0f<u){
		g = expf(-5.0f*5.0f*(v-0.5f)*(v-0.5f)/2.0f );
	}else{
		g = powf(u, 5.0f*5.0f*(v-0.5f)*(v-0.5f)/(1.0f-u*u));
	}
	pOut->x = pOut->y = pOut->z = g;
}

//-------------------------------------------------------------
// Name: Fresnel
// Desc: Fresnel���̌v�Z
//-------------------------------------------------------------
FLOAT Fresnel(FLOAT n)
{
	FLOAT Rs = 0.5f;// ���ʔ��˗�

	return Rs+(1-Rs)*(1-powf(n,5));
}

//-------------------------------------------------------------
// Name: gp()
// Desc: gp �e�N�X�`���̍쐬
//-------------------------------------------------------------
VOID WINAPI gp (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
	FLOAT u = pTexCoord->x;
	FLOAT v = pTexCoord->y;
	FLOAT g;
	
	g = Fresnel(u)/(1.0f/256.0f+u*v);

	pOut->x = pOut->y = pOut->z = g;
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pMesh						= new CD3DMesh();
	m_pTex[0]					= NULL;
	m_pTex[1]					= NULL;
	m_pTex[2]					= NULL;

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWVP						= NULL;
	m_hvCol						= NULL;
	m_hvLightPos				= NULL;
	m_hvCamPos					= NULL;
	m_pDecl						= NULL;

	m_fWorldRotX                = -0.41271535f;
    m_fWorldRotY                = 0.5f * D3DX_PI;
	m_fViewZoom				    = 2.5f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

	m_LightPos					= D3DXVECTOR4( 3.0f, 3.0f, -3.0f, 0.0f);
//	m_LightPos					= D3DXVECTOR4(-0.6f, 2.2f, -2.0f, 0.0f);

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    return S_OK;
}


// ---------------------------------------------------------------------------
// ����
// ---------------------------------------------------------------------------
HRESULT CreateMesh( LPDIRECT3DDEVICE9 pd3dDevice, CD3DMesh *pSrcMesh )
{
	HRESULT ret = S_OK;
	MESH_VERTEX* pVertices;
	LPD3DXMESH pMesh;
	DWORD i;

    if( FAILED( pSrcMesh->m_pSysMemMesh->CloneMesh(
						D3DXMESH_SYSTEMMEM,
						decl,
                        pd3dDevice, &pMesh ) ) )
        return E_FAIL;
	DWORD dwNumVertices    = pMesh->GetNumVertices();

	// �o�b�t�@���L
    pMesh->LockVertexBuffer( 0L, (LPVOID*)&pVertices );
	
	D3DXVECTOR3 up = D3DXVECTOR3(0,1,0);
	for(i=0;i<dwNumVertices;i++){
        D3DXVec3Cross( &pVertices[i].t, &pVertices[i].n, &up );
        D3DXVec3Normalize( &pVertices[i].t, &pVertices[i].t );
		D3DXVec3Cross( &pVertices[i].b, &pVertices[i].n, &pVertices[i].t );
        D3DXVec3Normalize( &pVertices[i].b, &pVertices[i].b );
	}
    
	// �o�b�t�@�̐�L������
    pMesh->UnlockVertexBuffer();
	
	SAFE_RELEASE( pSrcMesh->m_pSysMemMesh );
	pSrcMesh->m_pSysMemMesh = pMesh;

	return ret;
}

//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	D3DXVECTOR4 offset;

	// ���_�錾�̃I�u�W�F�N�g�̐���
	if( FAILED( hr = m_pd3dDevice->CreateVertexDeclaration( decl, &m_pDecl ) ) )
		return DXTRACE_ERR( "CreateVertexDeclaration", hr );
	
	// ���f���̓ǂݍ���
	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, _T("ball.x"))))
//	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, _T("dog.x"))))
        return DXTRACE_ERR( "LoadCar", hr );
    m_pMesh->UseMeshMaterials(FALSE);

	CreateMesh( m_pd3dDevice, m_pMesh );

	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWVP = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvCol  = m_pEffect->GetParameterByName( NULL, "vCol" );
	m_hvLightPos  = m_pEffect->GetParameterByName( NULL, "vLightPos" );
	m_hvCamPos  = m_pEffect->GetParameterByName( NULL, "vCamPos" );
	
	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	HRESULT hr;
	
	// �g�U���p
	if( FAILED(hr = m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_R16F
                          , D3DPOOL_DEFAULT, &m_pTex[0], NULL)))
		return hr;
	if( FAILED(hr = D3DXFillTexture(m_pTex[0], Diffuse, NULL)))
		return hr;
	m_pEffect->SetTexture( "tDiffuse", m_pTex[0] );
	
	// �ٕ���
	if( FAILED(hr = m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_R16F
                          , D3DPOOL_DEFAULT, &m_pTex[1], NULL)))
		return hr;
	if( FAILED(hr = D3DXFillTexture(m_pTex[1], gp, NULL)))
		return hr;
	m_pEffect->SetTexture( "tGp", m_pTex[1] );
	// �t���l���A�G�l���M�[�񑝕�
	if( FAILED(hr = m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_R16F
                          , D3DPOOL_DEFAULT, &m_pTex[2], NULL)))
		return hr;
	if( FAILED(hr = D3DXFillTexture(m_pTex[2], gs, NULL)))
		return hr;
	m_pEffect->SetTexture( "tGs", m_pTex[2] );


	// ���b�V��
    if( NULL == m_pMesh->m_pSysMemMesh )        return E_FAIL;
    if( FAILED( m_pMesh->m_pSysMemMesh->CloneMesh( 0L, decl,
                   m_pd3dDevice, &m_pMesh->m_pLocalMesh ) ) )
        return E_FAIL;

    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    RS( D3DRS_LIGHTING,       FALSE );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
    TSS( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	m_pEffect->OnResetDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else
    if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else
    if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mW;
	D3DXVECTOR4 v;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x404080, 1.0f, 0L);

		if(m_pEffect != NULL)
		{
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );
			
			D3DXMatrixTranslation ( &mW, 0, -0.0f, 0 );
//			D3DXMatrixTranslation ( &mW, 0, -0.5f, 0 );
			mW = mW * m_mWorld;
			m = mW * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			// ���C�g
			D3DXMatrixInverse( &m, NULL, &mW);
			D3DXVec4Transform( &v, &m_LightPos, &m );
			m_pEffect->SetVector( m_hvLightPos, &v );
			
			// ���_
			v = D3DXVECTOR4( 0.0f, 0.0f, -m_fViewZoom, 1.0f );
			D3DXVec4Transform( &v, &v, &m );
			m_pEffect->SetVector( m_hvCamPos, &v );
			
			TSS( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
			TSS( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE );

			//-------------------------------------------------
			// �`��
			//-------------------------------------------------
			m_pd3dDevice->SetVertexDeclaration(m_pDecl);

			D3DMATERIAL9 *pMtrl = m_pMesh->m_pMaterials;
			for( DWORD i=0; i<m_pMesh->m_dwNumMaterials; i++ ) {
				// ���b�V���̐F
				v.x = pMtrl->Diffuse.r;
				v.y = pMtrl->Diffuse.g;
				v.z = pMtrl->Diffuse.b;
				v.w = pMtrl->Diffuse.a;
				m_pEffect->SetVector( m_hvCol, &v );
				// �e�N�X�`��
				m_pMesh->m_pLocalMesh->DrawSubset( i ); // �`��
				pMtrl++;
			}

			m_pEffect->End();
		}

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(0);
	for(DWORD l = 0; l < 3; l++){
		const float scale =128.0f;
		typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;
		FLOAT X = (FLOAT)this->m_rcWindowClient.right;
		FLOAT Y = (FLOAT)this->m_rcWindowClient.bottom;
		TVERTEX Vertex[4] = {
			//  x       y    z rhw tu tv
			{X-(l+1)*scale,Y-scale,0, 1, 0.0f, 0.0f,},
			{X-(l+0)*scale,Y-scale,0, 1, 1.0f, 0.0f,},
			{X-(l+0)*scale,Y      ,0, 1, 1.0f, 1.0f,},
			{X-(l+1)*scale,Y      ,0, 1, 0.0f, 1.0f,},
		};
		switch(l){
		case 0: m_pd3dDevice->SetTexture( 0, m_pTex[0] ); break;
		case 1: m_pd3dDevice->SetTexture( 0, m_pTex[1] ); break;
		case 2: m_pd3dDevice->SetTexture( 0, m_pTex[2] ); break;
		}
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
	}
#endif      
        // �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	SAFE_RELEASE(m_pTex[2]);
	SAFE_RELEASE(m_pTex[1]);
	SAFE_RELEASE(m_pTex[0]);

	m_pMesh  ->InvalidateDeviceObjects(); // ���b�V��

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	SAFE_RELEASE( m_pDecl );
	
	// ���b�V��
	m_pMesh  ->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	SAFE_DELETE( m_pMesh );

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




