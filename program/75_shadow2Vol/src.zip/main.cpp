//-----------------------------------------------------------------------------
// File: main.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"


//-----------------------------------------------------------------------------
// �S��ʕ`��|���S��
//-----------------------------------------------------------------------------
const DWORD CBigSquare::FVF = D3DFVF_XYZRHW | D3DFVF_DIFFUSE;

//-----------------------------------------------------------------------------
CBigSquare::CBigSquare()
{
	m_pVB=NULL;
}
//-----------------------------------------------------------------------------
void CBigSquare::Destroy()
{
	SAFE_RELEASE( m_pVB );
}
//-----------------------------------------------------------------------------
void CBigSquare::Render( LPDIRECT3DDEVICE9 pd3dDevice )
{
	// Draw a big, gray square
	pd3dDevice->SetFVF( FVF );
	pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(SHADOWVERTEX));
	pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );
}
//-----------------------------------------------------------------------------
// �������m��
HRESULT CBigSquare::Create( LPDIRECT3DDEVICE9 pd3dDevice )
{
	if( FAILED( pd3dDevice->CreateVertexBuffer(
									4*sizeof(SHADOWVERTEX),
									D3DUSAGE_WRITEONLY,
									FVF,
									D3DPOOL_MANAGED,
									&m_pVB, NULL ) ) )
		return E_FAIL;

	return S_OK;
}
//-----------------------------------------------------------------------------
// �f�[�^����
void CBigSquare::RestoreDeviceObjects( FLOAT sx, FLOAT sy )
{
	SHADOWVERTEX* v;
	m_pVB->Lock( 0, 0, (void**)&v, 0 );
	v[0].p = D3DXVECTOR4(  0, sy, 0.0f, 1.0f );
	v[1].p = D3DXVECTOR4(  0,  0, 0.0f, 1.0f );
	v[2].p = D3DXVECTOR4( sx, sy, 0.0f, 1.0f );
	v[3].p = D3DXVECTOR4( sx,  0, 0.0f, 1.0f );
	v[0].color = D3DCOLOR_RGBA(0,0,0,0x7f);
	v[1].color = D3DCOLOR_RGBA(0,0,0,0x7f);
	v[2].color = D3DCOLOR_RGBA(0,0,0,0x7f);
	v[3].color = D3DCOLOR_RGBA(0,0,0,0x7f);
	m_pVB->Unlock();
}


//-----------------------------------------------------------------------------
// Global access to the app (needed for the global WndProc())
//-----------------------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_pBigSquare				= new CBigSquare();
	m_pMeshBG					= new CD3DMesh();				
	m_pMeshBox					= new CD3DMesh();
	m_pShadowBox				= new CShadowVolume();

	m_pFx						= NULL;
	m_hmWVP						= NULL;
	m_hvPos						= NULL;

	// �I�������V�[���̐ݒ�
    m_d3dEnumeration.AppUsesDepthBuffer = TRUE;
    m_d3dEnumeration.AppMinDepthBits = 15;
    m_d3dEnumeration.AppMinStencilBits = 1;

	m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    // Create a D3D font using d3dfont.cpp
    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = 0.0f;
    m_fWorldRotY                = 0.0f;
}




//-----------------------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//-----------------------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // TODO: perform one time initialization

    // Drawing loading status message until app finishes loading
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}









//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
D3DFORMAT adapterFormat, D3DFORMAT backBufferFormat )
{
	// �V�F�[�_�̃`�F�b�N
	if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) )
		if( (dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING ) == 0 )
			return E_FAIL;
	
	// ���ʃX�e���V���@�\�̊m�F
	if( !( pCaps->StencilCaps & D3DSTENCILCAPS_TWOSIDED ) ) return E_FAIL;
	
	// �X�e���V���@�\���T�|�[�g���Ă��邩�`�F�b�N
	if( FAILED( m_pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal
									, pCaps->DeviceType
									, adapterFormat
									, D3DUSAGE_RENDERTARGET
									| D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING
									, D3DRTYPE_SURFACE
									, backBufferFormat ) ) )
		return E_FAIL;

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	DWORD i;

    // Init the font
    m_pFont->InitDeviceObjects( m_pd3dDevice );

	if( FAILED( D3DXCreateEffectFromFile( m_pd3dDevice, "hlsl.fx", NULL, NULL, 
									0, NULL, &m_pFx, NULL ) ) ) return E_FAIL;
	m_hmWVP = m_pFx->GetParameterByName( NULL, "mWVP" );
	m_hvPos = m_pFx->GetParameterByName( NULL, "vLightPos" );

	// �S��ʕ`��|���S���̏�����
	if( FAILED( m_pBigSquare->Create( m_pd3dDevice ) )) return E_FAIL;

	// �w�i���b�V���̓ǂݍ���
	if( FAILED( hr = m_pMeshBG->Create( m_pd3dDevice, "CornellNoBox.x" ) ) )
		return DXTRACE_ERR( "Load Mesh", hr );
	for(i=0;i<m_pMeshBG->m_dwNumMaterials;i++){
		m_pMeshBG->m_pMaterials[i].Ambient.r = m_pMeshBG->m_pMaterials[i].Diffuse.r*=2;
		m_pMeshBG->m_pMaterials[i].Ambient.g = m_pMeshBG->m_pMaterials[i].Diffuse.g*=2;
		m_pMeshBG->m_pMaterials[i].Ambient.b = m_pMeshBG->m_pMaterials[i].Diffuse.b*=2;
	}
	// ��
	if( FAILED( hr = m_pMeshBox->Create( m_pd3dDevice, "box.x" ) ) )
		return DXTRACE_ERR( "Load Mesh", hr );
	for(i=0;i<m_pMeshBox->m_dwNumMaterials;i++){
		m_pMeshBox->m_pMaterials[i].Ambient.r = m_pMeshBox->m_pMaterials[i].Diffuse.r*=1.13f;
		m_pMeshBox->m_pMaterials[i].Ambient.g = m_pMeshBox->m_pMaterials[i].Diffuse.g*=0.93f;
		m_pMeshBox->m_pMaterials[i].Ambient.b = m_pMeshBox->m_pMaterials[i].Diffuse.b*=0.53f;
	}
	
	// �e�{�����[���̐���
	m_pShadowBox->Create( m_pd3dDevice, m_pMeshBox->GetSysMemMesh() );

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	m_LighPos = D3DXVECTOR3(0.0f, 5.488f, 2.770f);

    // Setup a material
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set up the textures
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

    // Set miscellaneous render states
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );

    // Set the world matrix
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // Set up our view matrix. A view matrix can be defined given an eye point,
    // a point to lookat, and a direction for which way is up. Here, we set the
    // eye five units back along the z-axis and up three units, look at the
    // origin, and define "up" to be in the y-direction.
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mView );

    // Set the projection matrix
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, 0.21f*D3DX_PI, fAspect, 1.0f, 100.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mProj );

    // Set up lighting states
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -0.0f, -1.0f, 0.2f );
    light.Diffuse.r   = 0.5f;
    light.Diffuse.g   = 0.5f;
    light.Diffuse.b   = 0.5f;
    light.Ambient.r   = 0.5f;
    light.Ambient.g   = 0.5f;
    light.Ambient.b   = 0.5f;
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // Restore the font
    m_pFont->RestoreDeviceObjects();

	m_pBigSquare->RestoreDeviceObjects( (FLOAT)m_d3dsdBackBuffer.Width,
										(FLOAT)m_d3dsdBackBuffer.Height );
	m_pMeshBG->RestoreDeviceObjects(m_pd3dDevice);
	m_pMeshBox->RestoreDeviceObjects(m_pd3dDevice);
	if( m_pFx != NULL ) m_pFx->OnResetDevice();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // Update user input state
    UpdateInput( &m_UserInput );

    // Update the world state according to user input
    D3DXMATRIX m;
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m, &matRotX, &matRotY );

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 2.73f, -8.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 2.73f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );
	m_mView = m * m_mView;
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mView );

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	D3DXMATRIX m, mW, mS, mR, mT;
	D3DXVECTOR4 v;

	
	//��ʂ̃N���A
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL,
                         0x000000ff, 1.0f, 0L );

    // �`��̊J�n
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) ) {

		// ----------------------------------------------------------
		// �������F�e�Ȃ������̕`��
		// ----------------------------------------------------------
		D3DXMatrixIdentity( &m );
		m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m );
		m_pMeshBG->Render( m_pd3dDevice );

		// ��������
		D3DXMatrixScaling( &mS, 1.82f,1.65f, 1.82f );
		D3DXMatrixRotationY( &mR, 0.59f*D3DX_PI );
		D3DXMatrixTranslation( &mT, 2.73f-1.85f, 0.f , 1.69f );
		m = mS * mR * mT;
		m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m );
		m_pMeshBox->Render( m_pd3dDevice );

		// �傫����
		D3DXMatrixScaling( &mS, 1.69f, 3.30f, 1.69f );
		D3DXMatrixRotationY( &mR, 0.91f*D3DX_PI );
		D3DXMatrixTranslation( &mT, 2.73f-3.685f, 0, 3.51f );
		m = mS * mR * mT;
		m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m );
		m_pMeshBox->Render( m_pd3dDevice );

		// ----------------------------------------------------------
		// �p�X1:�e�{�����[���̕`��
		// ----------------------------------------------------------
		// �[�x�o�b�t�@�ɏ������݂͂��Ȃ�
		m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE,  FALSE );
		// �����_�����O�^�[�Q�b�g�ɏ������݂͂��Ȃ�
		m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE,  FALSE );
		// �t���b�g�V�F�[�f�B���O����
		m_pd3dDevice->SetRenderState( D3DRS_SHADEMODE,	 D3DSHADE_FLAT );
		// ���ʕ`��
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE );

		// ���ʃX�e���V�����g�p����
		m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, TRUE );

		// �X�e���V���e�X�g�͏�ɍ��i����i���e�X�g���Ȃ��j
		m_pd3dDevice->SetRenderState( D3DRS_STENCILFUNC,  D3DCMP_ALWAYS );
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILFUNC,  D3DCMP_ALWAYS );
		// �X�e���V���o�b�t�@�̑�����1�ɐݒ肷��
		m_pd3dDevice->SetRenderState( D3DRS_STENCILREF,	   0x1 );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILMASK,	  0xffffffff );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILWRITEMASK, 0xffffffff );
		// �\�ʂ͐[�x�e�X�g�ɍ��i������X�e���V���o�b�t�@�̓��e��+1����
		m_pd3dDevice->SetRenderState( D3DRS_STENCILPASS,  D3DSTENCILOP_INCR );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILZFAIL, D3DSTENCILOP_KEEP );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILFAIL,  D3DSTENCILOP_KEEP );
		// ���ʂ͐[�x�e�X�g�ɍ��i������X�e���V���o�b�t�@�̓��e��-1����
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILPASS, D3DSTENCILOP_DECR );
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILZFAIL, D3DSTENCILOP_KEEP );
		m_pd3dDevice->SetRenderState( D3DRS_CCW_STENCILFAIL,  D3DSTENCILOP_KEEP );

		// �����_�����O����
		if( m_pFx != NULL ){
			D3DXHANDLE hTechnique = m_pFx->GetTechniqueByName( "TShader" );
			m_pFx->SetTechnique( hTechnique );
			m_pFx->Begin( NULL, 0 );
			m_pFx->Pass( 0 );

			// ��������
			D3DXMatrixScaling( &mS, 1.82f,1.65f, 1.82f );
			D3DXMatrixRotationY( &mR, 0.59f*D3DX_PI );
			D3DXMatrixTranslation( &mT, 2.73f-1.85f, 0.f , 1.69f );
			mW = mS * mR * mT;
			m = mW * m_mView * m_mProj;
			if( m_hmWVP != NULL ) m_pFx->SetMatrix( m_hmWVP, &m );
			D3DXMatrixInverse( &m, NULL, &mW);
			D3DXVec3Transform( &v, &m_LighPos, &m );
			if( m_hvPos != NULL ) m_pFx->SetVector( m_hvPos, &v );
			m_pShadowBox->Render( m_pd3dDevice );

			// �傫����
			D3DXMatrixScaling( &mS, 1.69f, 3.30f, 1.69f );
			D3DXMatrixRotationY( &mR, 0.91f*D3DX_PI );
			D3DXMatrixTranslation( &mT, 2.73f-3.685f, 0, 3.51f );
			mW = mS * mR * mT;
			m = mW * m_mView * m_mProj;
			if( m_hmWVP != NULL ) m_pFx->SetMatrix( m_hmWVP, &m );
			D3DXMatrixInverse( &m, NULL, &mW);
			D3DXVec3Transform( &v, &m_LighPos, &m );
			if( m_hvPos != NULL ) m_pFx->SetVector( m_hvPos, &v );
			m_pShadowBox->Render( m_pd3dDevice );

			m_pFx->End();
		}

		// ��Ԃ����ɖ߂�
		m_pd3dDevice->SetRenderState( D3DRS_SHADEMODE, D3DSHADE_GOURAUD );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW );
		m_pd3dDevice->SetRenderState( D3DRS_ZWRITEENABLE,	 TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_COLORWRITEENABLE,  0xf );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,	FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_TWOSIDEDSTENCILMODE, FALSE );

		// ----------------------------------------------------------
		// �p�X2:�e�̕`��
		// ----------------------------------------------------------
		// �[�x�e�X�g�͂��Ȃ�
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,		  FALSE );
		// �X�e���V���e�X�g�͂���
		m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,	TRUE );
		// �A���t�@�u�����f�B���O�͐��`�Ɋ|����
		m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
		m_pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
		// �|���S����`�悷��Ƃ��ɂ́A�e�N�X�`���ƒ��_�F�̗���������
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
		m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );

		// �X�e���V���o�b�t�@�̒l���P�ȏ�̂Ƃ��ɏ�������
		m_pd3dDevice->SetRenderState( D3DRS_STENCILREF,  0x1 );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILFUNC, D3DCMP_LESSEQUAL );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILPASS, D3DSTENCILOP_KEEP );
		
		m_pBigSquare->Render( m_pd3dDevice );

		// ��Ԃ����ɖ߂�
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,		  TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_STENCILENABLE,	FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE );

        // ��ԕ\���̕����̕`��  
        RenderText();

        // �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: Renders stats and help text to the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    // Output display stats
    FLOAT fNextLine = 40.0f; 

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    // Output statistics & help
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    wsprintf( szMsg, TEXT("Arrow keys: Up=%d Down=%d Left=%d Right=%d"), 
              m_UserInput.bRotateUp, m_UserInput.bRotateDown, m_UserInput.bRotateLeft, m_UserInput.bRotateRight );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("Use arrow keys to rotate object") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Draw on the window tell the user that the app is loading
                // TODO: change as needed
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	if( m_pFx != NULL ) m_pFx->OnLostDevice();
	m_pMeshBG->InvalidateDeviceObjects();
	m_pMeshBox->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	
	SAFE_RELEASE( m_pFx );

	m_pMeshBG->Destroy();
	m_pMeshBox->Destroy();
	m_pShadowBox->Destroy();

	m_pBigSquare->Destroy();
	
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	SAFE_DELETE( m_pShadowBox );
	SAFE_DELETE( m_pMeshBox );
	SAFE_DELETE( m_pMeshBG );
	SAFE_DELETE( m_pBigSquare );

    SAFE_DELETE( m_pFont );

    return S_OK;
}




