//-----------------------------------------------------------------------------
// File: main.h
//
// Desc: Phong �V�F�[�f�B���O.
//-----------------------------------------------------------------------------
#ifndef MAIN_H
#define MAIN_H

#include "GLApp.h"
#include "GLSL.h"

//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: �A�v���P�[�V�����̃N���X
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	GLhandleARB m_hProgramObject;
	GLint		m_locLightPos;

	BOOL					m_bLoadingApp;	// ���[�h���H
protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( void*, DWORD, void* );

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

#endif // !MAIN_H

