//-----------------------------------------------------------------------------
// File: GLApp.h
//
// Desc: Application class for the OpenGL samples framework library.
//-----------------------------------------------------------------------------
#ifndef GLAPP_H
#define GLAPP_H

#pragma warning(disable : 4136)     // X86

#include <GL/gl.h>
#include <GL/glu.h>


typedef struct _D3DSURFACE_DESC {
//    D3DFORMAT Format;
//    D3DRESOURCETYPE Type;
//    DWORD Usage;
//    D3DPOOL Pool;
//    D3DMULTISAMPLE_TYPE MultiSampleType;
//    DWORD MultiSampleQuality;
    UINT Width;
    UINT Height;
} MY_SURFACE_DESC;

//-------------------------------------------------------------
// Name: class CD3DApplication
// Desc: �A�v���P�[�V�����̊��N���X
//-------------------------------------------------------------

class CD3DApplication
{
    bool              m_bDeviceObjectsInited;
    bool              m_bDeviceObjectsRestored;
	HRESULT HandlePossibleSizeChange();// ��ʃT�C�Y�̍X�V
    HRESULT Reset3DEnvironment();
    HRESULT Initialize3DEnvironment();
	void    Cleanup3DEnvironment();
    HRESULT Render3DEnvironment();

protected:
    HWND              m_hWnd;              // The main app window
	BOOL			  m_bGL;
    MY_SURFACE_DESC   m_mysdBackBuffer;   // Surface desc of the backbuffer
    DWORD             m_dwWindowStyle;     // Saved window style for mode switches
    RECT              m_rcWindowBounds;    // Saved window bounds for mode switches
    RECT              m_rcWindowClient;    // Saved client area size for mode switches

	TCHAR*            m_strWindowTitle;    // Title for the app's window
    FLOAT             m_fTime;             // Current time in seconds
    FLOAT             m_fElapsedTime;      // Time elapsed since last frame
    DWORD             m_dwCreationWidth;   // Width used to create window
    DWORD             m_dwCreationHeight;  // Height used to create window

    // Overridable functions for the 3D scene created by the app
    virtual HRESULT ConfirmDevice(void*,DWORD,void*)   { return S_OK; }
    virtual HRESULT OneTimeSceneInit()                         { return S_OK; }
    virtual HRESULT InitDeviceObjects()                        { return S_OK; }
    virtual HRESULT RestoreDeviceObjects()                     { return S_OK; }
    virtual HRESULT FrameMove()                                { return S_OK; }
    virtual HRESULT Render()                                   { return S_OK; }
    virtual HRESULT InvalidateDeviceObjects()                  { return S_OK; }
    virtual HRESULT DeleteDeviceObjects()                      { return S_OK; }
    virtual HRESULT FinalCleanup()                             { return S_OK; }
public:
	HRESULT Create( HINSTANCE hInst, int nCmdShow );
	INT Run();
    virtual LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

	CD3DApplication();
};

#endif // !GLAPP_H

