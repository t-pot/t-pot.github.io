//-----------------------------------------------------------------------------
// File: GLSL.h
//
// Desc: Library for the OpenGL Shading Language.
//-----------------------------------------------------------------------------
#ifndef GLSL_H
#define GLSL_H

#include <GL/gl.h>
#include <GL/glu.h>
#include "gl3dlabs.h"

//-----------------------------------------------------------------------------
//
// OpenGL Shading Language �֐�
//
//-----------------------------------------------------------------------------
extern PFNGLCREATEPROGRAMOBJECTARBPROC glCreateProgramObjectARB;
extern PFNGLCREATESHADEROBJECTARBPROC glCreateShaderObjectARB;
extern PFNGLDELETEOBJECTARBPROC glDeleteObjectARB;
extern PFNGLDETACHOBJECTARBPROC glDetachObjectARB;
extern PFNGLATTACHOBJECTARBPROC glAttachObjectARB;

extern PFNGLSHADERSOURCEARBPROC glShaderSourceARB;
extern PFNGLCOMPILESHADERARBPROC glCompileShaderARB;
extern PFNGLLINKPROGRAMARBPROC glLinkProgramARB;
extern PFNGLGETINFOLOGARBPROC glGetInfoLogARB;
extern PFNGLUSEPROGRAMOBJECTARBPROC glUseProgramObjectARB;

extern PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB;
extern PFNGLGETOBJECTPARAMETERFVARBPROC glGetObjectParameterfvARB;
extern PFNGLGETUNIFORMLOCATIONARBPROC glGetUniformLocationARB;

extern PFNGLUNIFORM1FARBPROC glUniform1fARB;
extern PFNGLUNIFORM2FARBPROC glUniform2fARB;
extern PFNGLUNIFORM3FARBPROC glUniform3fARB;
extern PFNGLUNIFORM4FARBPROC glUniform4fARB;

extern PFNGLUNIFORM1IARBPROC glUniform1iARB;
extern PFNGLUNIFORM2IARBPROC glUniform2iARB;
extern PFNGLUNIFORM3IARBPROC glUniform3iARB;
extern PFNGLUNIFORM4IARBPROC glUniform4iARB;

extern PFNGLUNIFORM1FVARBPROC glUniform1fvARB;
extern PFNGLUNIFORM2FVARBPROC glUniform2fvARB;
extern PFNGLUNIFORM3FVARBPROC glUniform3fvARB;
extern PFNGLUNIFORM4FVARBPROC glUniform4fvARB;

extern PFNGLUNIFORM1IVARBPROC glUniform1ivARB;
extern PFNGLUNIFORM2IVARBPROC glUniform2ivARB;
extern PFNGLUNIFORM3IVARBPROC glUniform3ivARB;
extern PFNGLUNIFORM4IVARBPROC glUniform4ivARB;




//-------------------------------------------------------------
// Name: class CD3DApplication
// Desc: �V�F�[�_�փA�N�Z�X���邽�߂̃C���^�[�t�F�C�X
//-------------------------------------------------------------
class GLSL
{
	// �t�@�C����ǂݍ���
	static HRESULT ReadShader(char *fileName, GLubyte *shaderText, int size);
	// �V�F�[�_�̃t�@�C���̃T�C�Y�𒲂ׂ�
	static int GetShaderSize(char *fileName);
	// �V�F�[�_�v���O������ǂݍ���
	static HRESULT readShaderSource(char *fileName, GLubyte **vertexShader, GLubyte **fragmentShader);
	// �V�F�[�_�� OpenGL �փZ�b�g�A�b�v����
	static HRESULT handShadersToOpenGL(GLhandleARB Program, GLubyte *vertexShader,  GLubyte *fragmentShader);
public:
	// ������
	static HRESULT Init();
	// �V�F�[�_�̓ǂݍ���
	static HRESULT CreateShaderFromFile(char *fileName, GLhandleARB *pProgram);
};


#endif // !GLSL_H

