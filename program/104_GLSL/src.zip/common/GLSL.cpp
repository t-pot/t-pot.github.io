//-----------------------------------------------------------------------------
// File: GLSL.cpp
//
// Desc: Application class for the imagire's OprnGL samples framework library.
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <tchar.h>
#include <mmsystem.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>

#include "GLSL.h"

//-----------------------------------------------------------------------------
//
// OpenGL Shading Language �֐�
//
//-----------------------------------------------------------------------------
PFNGLCREATEPROGRAMOBJECTARBPROC glCreateProgramObjectARB;
PFNGLCREATESHADEROBJECTARBPROC glCreateShaderObjectARB;
PFNGLDELETEOBJECTARBPROC glDeleteObjectARB;
PFNGLDETACHOBJECTARBPROC glDetachObjectARB;
PFNGLATTACHOBJECTARBPROC glAttachObjectARB;

PFNGLSHADERSOURCEARBPROC glShaderSourceARB;
PFNGLCOMPILESHADERARBPROC glCompileShaderARB;
PFNGLLINKPROGRAMARBPROC glLinkProgramARB;
PFNGLGETINFOLOGARBPROC glGetInfoLogARB;
PFNGLUSEPROGRAMOBJECTARBPROC glUseProgramObjectARB;

PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB;
PFNGLGETOBJECTPARAMETERFVARBPROC glGetObjectParameterfvARB;
PFNGLGETUNIFORMLOCATIONARBPROC glGetUniformLocationARB;

PFNGLUNIFORM1FARBPROC glUniform1fARB;
PFNGLUNIFORM2FARBPROC glUniform2fARB;
PFNGLUNIFORM3FARBPROC glUniform3fARB;
PFNGLUNIFORM4FARBPROC glUniform4fARB;

PFNGLUNIFORM1IARBPROC glUniform1iARB;
PFNGLUNIFORM2IARBPROC glUniform2iARB;
PFNGLUNIFORM3IARBPROC glUniform3iARB;
PFNGLUNIFORM4IARBPROC glUniform4iARB;

PFNGLUNIFORM1FVARBPROC glUniform1fvARB;
PFNGLUNIFORM2FVARBPROC glUniform2fvARB;
PFNGLUNIFORM3FVARBPROC glUniform3fvARB;
PFNGLUNIFORM4FVARBPROC glUniform4fvARB;

PFNGLUNIFORM1IVARBPROC glUniform1ivARB;
PFNGLUNIFORM2IVARBPROC glUniform2ivARB;
PFNGLUNIFORM3IVARBPROC glUniform3ivARB;
PFNGLUNIFORM4IVARBPROC glUniform4ivARB;





#define PADDR(functype,funcname) \
	((funcname = (functype) wglGetProcAddress( #funcname )) == NULL)

//-----------------------------------------------------------------------------
// Name: InitGLSL()
// Desc: GLSL �̏�����
//-----------------------------------------------------------------------------
HRESULT GLSL::Init( )
{
	int error;

	error |= PADDR(PFNGLCREATEPROGRAMOBJECTARBPROC, glCreateProgramObjectARB);
	error |= PADDR(PFNGLCREATESHADEROBJECTARBPROC, glCreateShaderObjectARB);
	error |= PADDR(PFNGLDELETEOBJECTARBPROC, glDeleteObjectARB);
	error |= PADDR(PFNGLDETACHOBJECTARBPROC, glDetachObjectARB);
	error |= PADDR(PFNGLATTACHOBJECTARBPROC, glAttachObjectARB);
	error |= PADDR(PFNGLSHADERSOURCEARBPROC, glShaderSourceARB);
	error |= PADDR(PFNGLCOMPILESHADERARBPROC, glCompileShaderARB);
	error |= PADDR(PFNGLLINKPROGRAMARBPROC, glLinkProgramARB);
	error |= PADDR(PFNGLGETINFOLOGARBPROC, glGetInfoLogARB);
	error |= PADDR(PFNGLUSEPROGRAMOBJECTARBPROC, glUseProgramObjectARB);
	error |= PADDR(PFNGLGETOBJECTPARAMETERIVARBPROC, glGetObjectParameterivARB);
	error |= PADDR(PFNGLGETOBJECTPARAMETERFVARBPROC, glGetObjectParameterfvARB);
	error |= PADDR(PFNGLGETUNIFORMLOCATIONARBPROC, glGetUniformLocationARB);
	error |= PADDR(PFNGLUNIFORM1FARBPROC, glUniform1fARB);
	error |= PADDR(PFNGLUNIFORM2FARBPROC, glUniform2fARB);
	error |= PADDR(PFNGLUNIFORM3FARBPROC, glUniform3fARB);
	error |= PADDR(PFNGLUNIFORM4FARBPROC, glUniform4fARB);
	error |= PADDR(PFNGLUNIFORM1IARBPROC, glUniform1iARB);
	error |= PADDR(PFNGLUNIFORM2IARBPROC, glUniform2iARB);
	error |= PADDR(PFNGLUNIFORM3IARBPROC, glUniform3iARB);
	error |= PADDR(PFNGLUNIFORM4IARBPROC, glUniform4iARB);
	error |= PADDR(PFNGLUNIFORM1FVARBPROC, glUniform1fvARB);
	error |= PADDR(PFNGLUNIFORM2FVARBPROC, glUniform2fvARB);
	error |= PADDR(PFNGLUNIFORM3FVARBPROC, glUniform3fvARB);
	error |= PADDR(PFNGLUNIFORM4FVARBPROC, glUniform4fvARB);
	error |= PADDR(PFNGLUNIFORM1IVARBPROC, glUniform1ivARB);
	error |= PADDR(PFNGLUNIFORM2IVARBPROC, glUniform2ivARB);
	error |= PADDR(PFNGLUNIFORM3IVARBPROC, glUniform3ivARB);
	error |= PADDR(PFNGLUNIFORM4IVARBPROC, glUniform4ivARB);
	if (error) {
		return FALSE;
	}

	return S_OK;
}


//-------------------------------------------------------------
// Name: GetShaderSize
// Desc: �t�@�C���̃T�C�Y�𒲂ׂ�
//-------------------------------------------------------------
int GLSL::GetShaderSize(char *fileName)
{
	int fp;
	int count;

	// �t�@�C�����J��
	fp = _open(fileName, _O_RDONLY);
	if (fp == -1) return -1;// Open ���s

	// �Ō�̈ʒu�𒲂ׂāA�T�C�Y�𓾂�
	count = _lseek(fp, 0, SEEK_END);

	// �t�@�C�������
	_close(fp);

	return count;
}


//-------------------------------------------------------------
// Name: ReadShader
// Desc: �t�@�C����ǂݍ���ŁAshaderText�Ɋi�[����
//-------------------------------------------------------------
HRESULT GLSL::ReadShader(char *fileName, GLubyte *shaderText, int size)
{
	FILE *fp;
	int count;

	// �t�@�C�����J��
	fp = fopen(fileName, "r");
	if (!fp) return FALSE;

	// �t�@�C����ǂݍ���
	fseek(fp, 0, SEEK_SET);
	count = fread(shaderText, 1, size, fp);
	shaderText[count] = '\0';

	if (ferror(fp)) return FALSE;

	// �t�@�C�������
	fclose(fp);

	return count;
}

//-------------------------------------------------------------
// Name: readShaderSource
// Desc: �V�F�[�_�v���O������ǂݍ���
//-------------------------------------------------------------
HRESULT GLSL::readShaderSource(char *fileName, GLubyte **vertShader, GLubyte **fragShader)
{
	// -------------------------------------------------------
	// �t�@�C���������߂�
	// -------------------------------------------------------
	char vert_fileName[256];// ���_�v���O�����̃t�@�C����
	char frag_fileName[256];// �t���O�����g�v���O�����̃t�@�C����

	strcpy(vert_fileName, fileName); strcat(vert_fileName, ".vert");
	strcpy(frag_fileName, fileName); strcat(frag_fileName, ".frag");

	// -------------------------------------------------------
	// �V�F�[�_�̂��߂̃������̊m��
	// -------------------------------------------------------
	int vertSize = GetShaderSize(vert_fileName);
	int fragSize = GetShaderSize(frag_fileName);

	if ((vertSize == -1) || (fragSize == -1)) {
		return FALSE;// �V�F�[�_�̃T�C�Y�����܂�Ȃ�����
	}

	*vertShader = (GLubyte *) malloc(vertSize);
	*fragShader = (GLubyte *) malloc(fragSize);

	// -------------------------------------------------------
	// �V�F�[�_�̃\�[�X�v���O������ǂݍ���
	// -------------------------------------------------------
	if (FAILED(ReadShader(vert_fileName, *vertShader, vertSize)))
		return FALSE;// �t�@�C����ǂ߂Ȃ�����

	if (FAILED(ReadShader(frag_fileName, *fragShader, fragSize)))
		return FALSE;// �t�@�C����ǂ߂Ȃ�����

	return S_OK;
}


//-------------------------------------------------------------
// Name: handShadersToOpenGL
// Desc: �V�F�[�_�� OpenGL �փZ�b�g�A�b�v����
//-------------------------------------------------------------
HRESULT GLSL::handShadersToOpenGL( GLhandleARB Program, GLubyte *vertShader,  GLubyte *fragShader )
{
	// -------------------------------------------------------
	// �V�F�[�_�Ɋւ���I�u�W�F�N�g�̐���
	// -------------------------------------------------------
	GLhandleARB hVertShaderObject = glCreateShaderObjectARB(GL_VERTEX_SHADER_ARB);
	GLhandleARB hFragShaderObject = glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

	// -------------------------------------------------------
	// OpenGL �V�X�e���Ƀv���O����������������n��
	// -------------------------------------------------------
	int vert_compiled = 0;
	int frag_compiled = 0;
	int linked = 0;
	GLint	  length;

	length = strlen((char*)vertShader);
	glShaderSourceARB(hVertShaderObject, 1, (const GLcharARB**)&vertShader, &length);

	length = strlen((char*)fragShader);
	glShaderSourceARB(hFragShaderObject, 1, (const GLcharARB**)&fragShader, &length);

	// -------------------------------------------------------
	// �s�K�v�ɂȂ������������J������
	// -------------------------------------------------------
	free(vertShader);
	free(fragShader);

	// -------------------------------------------------------
	// �V�F�[�_�v���O�������R���p�C������
	// -------------------------------------------------------
	glCompileShaderARB(hVertShaderObject);
	glGetObjectParameterivARB(hVertShaderObject,
			GL_OBJECT_COMPILE_STATUS_ARB, &vert_compiled);


	glCompileShaderARB(hFragShaderObject);
	glGetObjectParameterivARB(hFragShaderObject,
			GL_OBJECT_COMPILE_STATUS_ARB, &frag_compiled);

	if (!vert_compiled || !frag_compiled) return FALSE;

	// -------------------------------------------------------
	// Program �̃I�u�W�F�N�g�ɂ��ꂼ��̃V�F�[�_���֘A�t����
	// -------------------------------------------------------
	glAttachObjectARB(Program, hVertShaderObject);
	glAttachObjectARB(Program, hFragShaderObject);

	// -------------------------------------------------------
	// �s�K�v�ɂȂ����I�u�W�F�N�g���폜����
	// -------------------------------------------------------
	glDeleteObjectARB(hVertShaderObject);
	glDeleteObjectARB(hFragShaderObject);

	// -------------------------------------------------------
	// �S�Ă������N����
	// -------------------------------------------------------
	glLinkProgramARB(Program);
	glGetObjectParameterivARB(Program, GL_OBJECT_LINK_STATUS_ARB, &linked);

	if (!vert_compiled || !frag_compiled || !linked) return FALSE;

	return S_OK;
}


//-----------------------------------------------------------------------------
// Name: InitGLSL()
// Desc: GLSL �̏�����
//-----------------------------------------------------------------------------

HRESULT GLSL::CreateShaderFromFile(char *fileName, GLhandleARB *pProgram)
{
	GLubyte *vertexShader;
	GLubyte *fragmentShader;
	GLhandleARB prog;

	// ���s�����Ƃ��̂��߂ɏ�����
	*pProgram = 0;

	// �t�@�C����ǂݍ���
	if (FAILED(readShaderSource(fileName, &vertexShader, &fragmentShader))) return FALSE;

	// �V�F�[�_�𐶐�����
	prog = glCreateProgramObjectARB();

	// �V�F�[�_�� OpenGL �փZ�b�g�A�b�v����
	if (FAILED(handShadersToOpenGL( prog, vertexShader, fragmentShader))) return FALSE;

	*pProgram = prog;

	return S_OK;
}







