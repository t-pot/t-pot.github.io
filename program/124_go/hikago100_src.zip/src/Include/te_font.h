//--------------------------------------------------------------------------------------
// File: te_font.h
//
// �t�H���g�V�X�e��
//
// Copyright (c) 2004 Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#ifndef __TE_FONT_H__
#define __TE_FONT_H__

namespace Te
{
	//----------------------------------------------------------------------------------
	// �t�H���g���
	//----------------------------------------------------------------------------------
	typedef struct
	{
		signed char x, y;
		signed char w, h;
		signed char u, v;
	}FONT_INFO;

	//----------------------------------------------------------------------------------
	// ascii �t�H���g�N���X
	//----------------------------------------------------------------------------------
	class CFont
	{
		//------------------------------------------------------------------------------
		// �V�X�e������A�N�Z�X
		//------------------------------------------------------------------------------
	protected:
		unsigned int       m_iTexture;

	protected:
		//------------------------------------------------------------------------------
		// �A�v���P�[�V�����Ƃ̂����
		//------------------------------------------------------------------------------
		float   m_color[4];
		float   m_size[2];

	public:
		CFont();
		virtual ~CFont();
		
		// �������A�Еt��
		void Init( const void *p );
		virtual void Release();
		
		// �\��
		virtual int TextOut( const char *pStr, int x, int y );
		void SetColor( float r, float g, float b, float a = 1.0f );
		void SetSize( float w, float h );

		rect *GetSize( rect *dest, const char *pStr );
	};

	//----------------------------------------------------------------------------------
	// ���{��t�H���g�N���X
	//----------------------------------------------------------------------------------
	class CFontJ : public CFont
	{
		//------------------------------------------------------------------------------
		// �V�X�e������A�N�Z�X
		//------------------------------------------------------------------------------
	protected:
		const FONT_INFO   *m_pInfo;
		const FONT_INFO   *m_pInfoJ;
		unsigned int       m_iTextures[8];

	protected:

	public:
		CFontJ();
		~CFontJ();
		
		// �������A�Еt��
		void Init( void *p[9], const FONT_INFO *pInfo, const FONT_INFO *pInfoJ );
		void Release();
		
		// �\��
		int TextOut( const char *pStr, int x, int y );

		rect *GetSize( rect *dest, const char *pStr );
	};

} // namespace Te

#endif // !__TE_FONT_H__
