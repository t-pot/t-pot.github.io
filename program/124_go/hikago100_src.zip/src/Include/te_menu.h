//--------------------------------------------------------------------------------------
// File: te_menu.h
//
// ���j���[�V�X�e��
//
// Copyright (c) 2004 Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#ifndef __TE_MENU_H__
#define __TE_MENU_H__

namespace Te
{
	//----------------------------------------------------------------------------------
	// ���j���[�N���X
	//----------------------------------------------------------------------------------
	class CMenu
	{
		//------------------------------------------------------------------------------
		// �V�X�e������A�N�Z�X
		//------------------------------------------------------------------------------
	protected:
		unsigned int       m_iTexture;

	protected:
		//------------------------------------------------------------------------------
		// �A�v���P�[�V�����Ƃ̂����
		//------------------------------------------------------------------------------
		float   m_color[4]; // �F
		float   m_pos[2];   // �\���ʒu
		float   m_size[2];  // �g��`�����傫��
		float   m_waku[2];  // �g�T�C�Y

	public:
		 CMenu();
		 CMenu( const void *p );
		~CMenu();
		
		// �\��
		int  Render();
		void SetColor( float r, float g, float b, float a = 1.0f );
		void SetAlpha( float a );
		void SetPos ( float x, float y );
		void SetSize( float w, float h );
		void SetFrameWidth( float w, float h );
	};

} // namespace Te

#endif // !__TE_MENU_H__
