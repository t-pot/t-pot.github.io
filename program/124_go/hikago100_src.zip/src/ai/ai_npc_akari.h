// ----------------------------------------------------------------------------
//
// ai_npc.h - NPC�̊��N���X�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __AI_NPC_AKARI_H__
#define __AI_NPC_AKARI_H__

#include "go_common.h"
#include "ai_npc.h"

namespace Ai
{
	// -----------------------------------------------------------------------
	// �Ƃ肠����NPC
	// -----------------------------------------------------------------------
	class CNpcAkari : public CNpc
	{
	private:
		float _time;
	public:
		 CNpcAkari() : CNpc(),_time(0) {}
		~CNpcAkari(){;}
		
		
		void Init( Go::CBoard *p ){ CNpc::Init(p);}
		bool ThinkMove( Go::GOISHI_TYPE color, Go::BOARD_POINT dest, float dt );
	};
	
}// namespace ai

#endif // !__AI_NPC_H__
