// ----------------------------------------------------------------------------
//
// go_okiishi.h - �u��
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __GO_OKIISHI_H__
#define __GO_OKIISHI_H__

namespace Go
{
	enum
	{
		OKIISHI_MAX = 10,
	};
	
	bool GetOkiishi( unsigned char dest[2], unsigned char roban, unsigned char handicap, unsigned char no );
	
}// namespace go

#endif // !__GO_OKIISHI_H__
