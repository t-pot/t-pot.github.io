// ----------------------------------------------------------------------------
//
// ai_npc_akari.cpp - �Ƃ肠����NPC
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <stdlib.h>
#include "ai_npc_akari.h"

extern signed int jiai_board [Go::BOARD_SIZE][Go::BOARD_SIZE];

namespace Ai
{
	inline void SetValue( signed short board[][Go::BOARD_SIZE], int x, int y, int size )
	{
		if( x > 0 && x < (size+1) && y > 0 && y < (size+1) ){
			board[y][x]++;
		}
	}
/*------------------------------------------------------------------*/
/* �Ֆʂ̕]��                                                       */
/*------------------------------------------------------------------*/
	static int EvalBoard( Go::GOISHI_TYPE board[][Go::BOARD_SIZE], int size )
	{
		signed short blackBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  /* ���΂̉e���͈� */
		signed short whiteBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  /* ���΂̉e���͈� */
		signed short totalBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  /* �n */
		int x, y, value;

		/* ������ */
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				blackBoard[y][x] = 0;
				whiteBoard[y][x] = 0;
				totalBoard[y][x] = Go::SPACE;
			}
		}

		/* ����3�ȓ��Ȃ�n�Ƃ݂Ȃ� */
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				if( board[y][x] == Go::BLACK )
				{
					SetValue( blackBoard, x-3, y  , size );
					SetValue( blackBoard, x-2, y-1, size );
					SetValue( blackBoard, x-2, y  , size );
					SetValue( blackBoard, x-2, y+1, size );
					SetValue( blackBoard, x-1, y-2, size );
					SetValue( blackBoard, x-1, y-1, size );
					SetValue( blackBoard, x-1, y  , size );
					SetValue( blackBoard, x-1, y+1, size );
					SetValue( blackBoard, x-1, y+2, size );
					SetValue( blackBoard, x,   y-3, size );
					SetValue( blackBoard, x,   y-2, size );
					SetValue( blackBoard, x,   y-1, size );
					SetValue( blackBoard, x,   y  , size );
					SetValue( blackBoard, x,   y+1, size );
					SetValue( blackBoard, x,   y+2, size );
					SetValue( blackBoard, x,   y+3, size );
					SetValue( blackBoard, x+1, y-2, size );
					SetValue( blackBoard, x+1, y-1, size );
					SetValue( blackBoard, x+1, y  , size );
					SetValue( blackBoard, x+1, y+1, size );
					SetValue( blackBoard, x+1, y+2, size );
					SetValue( blackBoard, x+2, y-1, size );
					SetValue( blackBoard, x+2, y  , size );
					SetValue( blackBoard, x+2, y+1, size );
					SetValue( blackBoard, x+3, y  , size );
				}else if( board[y][x] == Go::WHITE ){
					SetValue( whiteBoard, x-3, y  , size );
					SetValue( whiteBoard, x-2, y-1, size );
					SetValue( whiteBoard, x-2, y  , size );
					SetValue( whiteBoard, x-2, y+1, size );
					SetValue( whiteBoard, x-1, y-2, size );
					SetValue( whiteBoard, x-1, y-1, size );
					SetValue( whiteBoard, x-1, y  , size );
					SetValue( whiteBoard, x-1, y+1, size );
					SetValue( whiteBoard, x-1, y+2, size );
					SetValue( whiteBoard, x,   y-3, size );
					SetValue( whiteBoard, x,   y-2, size );
					SetValue( whiteBoard, x,   y-1, size );
					SetValue( whiteBoard, x,   y  , size );
					SetValue( whiteBoard, x,   y+1, size );
					SetValue( whiteBoard, x,   y+2, size );
					SetValue( whiteBoard, x,   y+3, size );
					SetValue( whiteBoard, x+1, y-2, size );
					SetValue( whiteBoard, x+1, y-1, size );
					SetValue( whiteBoard, x+1, y  , size );
					SetValue( whiteBoard, x+1, y+1, size );
					SetValue( whiteBoard, x+1, y+2, size );
					SetValue( whiteBoard, x+2, y-1, size );
					SetValue( whiteBoard, x+2, y  , size );
					SetValue( whiteBoard, x+2, y+1, size );
					SetValue( whiteBoard, x+3, y  , size );
				}
			}
		}

		value = 0;
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				if( board[y][x] == Go::BLACK ){
					totalBoard[y][x] = Go::BLACK;
				}else if( board[y][x] == Go::WHITE ){
					totalBoard[y][x] = Go::WHITE;
				}else{
					if( blackBoard[y][x] > whiteBoard[y][x] ){
						/* ���n�Ƃ��ăJ�E���g */
						totalBoard[y][x] = Go::BLACK;
						value++;
					}else if( blackBoard[y][x] < whiteBoard[y][x] ){
						/* ���n�Ƃ��ăJ�E���g */
						totalBoard[y][x] = Go::WHITE;
						value--;
					}
				}
			}
		}

		return( value );
	}


	void EvalJiai( Go::GOISHI_TYPE board[][Go::BOARD_SIZE], int size )
	{
		signed short blackBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  /* ���΂̉e���͈� */
		signed short whiteBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  /* ���΂̉e���͈� */
		int x, y;

		/* ������ */
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				blackBoard[y][x] = 0;
				whiteBoard[y][x] = 0;
			}
		}

		/* ����3�ȓ��Ȃ�n�Ƃ݂Ȃ� */
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				if( board[y][x] == Go::BLACK )
				{
					SetValue( blackBoard, x-3, y  , size );
					SetValue( blackBoard, x-2, y-1, size );
					SetValue( blackBoard, x-2, y  , size );
					SetValue( blackBoard, x-2, y+1, size );
					SetValue( blackBoard, x-1, y-2, size );
					SetValue( blackBoard, x-1, y-1, size );
					SetValue( blackBoard, x-1, y  , size );
					SetValue( blackBoard, x-1, y+1, size );
					SetValue( blackBoard, x-1, y+2, size );
					SetValue( blackBoard, x,   y-3, size );
					SetValue( blackBoard, x,   y-2, size );
					SetValue( blackBoard, x,   y-1, size );
					SetValue( blackBoard, x,   y  , size );
					SetValue( blackBoard, x,   y+1, size );
					SetValue( blackBoard, x,   y+2, size );
					SetValue( blackBoard, x,   y+3, size );
					SetValue( blackBoard, x+1, y-2, size );
					SetValue( blackBoard, x+1, y-1, size );
					SetValue( blackBoard, x+1, y  , size );
					SetValue( blackBoard, x+1, y+1, size );
					SetValue( blackBoard, x+1, y+2, size );
					SetValue( blackBoard, x+2, y-1, size );
					SetValue( blackBoard, x+2, y  , size );
					SetValue( blackBoard, x+2, y+1, size );
					SetValue( blackBoard, x+3, y  , size );
				}else if( board[y][x] == Go::WHITE ){
					SetValue( whiteBoard, x-3, y  , size );
					SetValue( whiteBoard, x-2, y-1, size );
					SetValue( whiteBoard, x-2, y  , size );
					SetValue( whiteBoard, x-2, y+1, size );
					SetValue( whiteBoard, x-1, y-2, size );
					SetValue( whiteBoard, x-1, y-1, size );
					SetValue( whiteBoard, x-1, y  , size );
					SetValue( whiteBoard, x-1, y+1, size );
					SetValue( whiteBoard, x-1, y+2, size );
					SetValue( whiteBoard, x,   y-3, size );
					SetValue( whiteBoard, x,   y-2, size );
					SetValue( whiteBoard, x,   y-1, size );
					SetValue( whiteBoard, x,   y  , size );
					SetValue( whiteBoard, x,   y+1, size );
					SetValue( whiteBoard, x,   y+2, size );
					SetValue( whiteBoard, x,   y+3, size );
					SetValue( whiteBoard, x+1, y-2, size );
					SetValue( whiteBoard, x+1, y-1, size );
					SetValue( whiteBoard, x+1, y  , size );
					SetValue( whiteBoard, x+1, y+1, size );
					SetValue( whiteBoard, x+1, y+2, size );
					SetValue( whiteBoard, x+2, y-1, size );
					SetValue( whiteBoard, x+2, y  , size );
					SetValue( whiteBoard, x+2, y+1, size );
					SetValue( whiteBoard, x+3, y  , size );
				}
			}
		}

		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				jiai_board[y][x] = blackBoard[y][x]-whiteBoard[y][x];
			}
		}
	}


	// -----------------------------------------------------------------------
	// �l����
	// -----------------------------------------------------------------------
	bool CNpcAkari::ThinkMove( Go::GOISHI_TYPE color, Go::BOARD_POINT dest, float dt )
	{
		_time += dt;
		if( _time < 1 )
		{
			return false;// ������Ƒ҂�
		}else{
			_time = 0;
		}
	
		// 
		Go::GOISHI_TYPE tmpBoard[Go::BOARD_SIZE][Go::BOARD_SIZE];  // ���ʗp���
		int evalBoard[Go::BOARD_SIZE][Go::BOARD_SIZE]; // �]���l�i�[�p���

		auto int size = _pBoard->_iBoardSize - 2;
		auto int x, y;

		/* ������ */
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				evalBoard[y][x] = 0;
			}
		}

		// ���݂̌�Ղ̕]��
		auto int max_eval = EvalBoard( _pBoard->_iBoard, size );

		// ��Ղ𕡎�
		Go::CBoard::CopyBoard( tmpBoard, _pBoard->_iBoard );

		// ���������ɔՏ�ɑł��ĕ]��
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				// ����֎~�_�Ȃ玟�̓_��
				if( 0 != _pBoard->CheckLegal( color, x, y, tmpBoard )) continue;
				
				// ��Ղ𕡎� */
				Go::CBoard::CopyBoard( _pBoard->_iBoard, tmpBoard );

				// �����Տ�ɑł�
				_pBoard->_iBoard[y][x] = color;				/* ���W(x,y)�ɐ΂�u�� */
				if( 1 < y ){				/* �u�����΂̎��͂̑���̐΂�����ł���Ό�Ղ����菜�� */
					_pBoard->RemoveStone( color, x, y-1 );
				}
				if( 1 < x ){
					_pBoard->RemoveStone( color, x-1, y );
				}
				if( y < (size-1) ){
					_pBoard->RemoveStone( color, x, y+1 );
				}
				if( x < (size-1) ){
					_pBoard->RemoveStone( color, x+1, y );
				}
				
				/* ����O���ǂ̂��炢�ǂ��Ȃ邩��]���l�i�[�p��ՂɋL�^ */
				if( Go::BLACK == color )
				{
					evalBoard[y][x] = EvalBoard( _pBoard->_iBoard, size ) - max_eval;
				}else{
					evalBoard[y][x] = max_eval - EvalBoard( _pBoard->_iBoard, size );
				}
			}
		}

		Go::CBoard::CopyBoard( _pBoard->_iBoard, tmpBoard );

		// �]���l���ō��̂��̂�I��

		auto int xResult = 0;
		auto int yResult = 0;

		max_eval = 0;
		for( y=size; 0 < y; y-- )
		{
			for( x=size; 0 < x; x-- )
			{
				if( max_eval < evalBoard[y][x] ){
					max_eval = evalBoard[y][x];
					xResult = x;
					yResult = y;
				}
			}
		}

		dest[0] = xResult;
		dest[1] = yResult;
		return true;
	}
}// namespace ai

