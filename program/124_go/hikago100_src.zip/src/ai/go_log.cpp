// ----------------------------------------------------------------------------
//
// ai_log.cpp - �Q�[���̋L�^������
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include "go_common.h"
#include "go_log.h"

namespace Go
{
	// -----------------------------------------------------------------------
	// ���̋L�^
	// -----------------------------------------------------------------------
	void CLog::Record( GOISHI_TYPE color, BOARD_POINT pos )
	{
		if( m_iMax <= m_iMove )
		{
			TYPE_LOG *p = new TYPE_LOG[2*m_iMax];           // �{�̃T�C�Y���m�ۂ���
			memcpy( p, m_pData, m_iMax * sizeof(TYPE_LOG) );// �Â��f�[�^�̃R�s�[
			m_iMax *= 2;                                    // �T�C�Y�̍X�V
			delete[] m_pData;                               // �g��Ȃ��������̔j��
			m_pData = p;                                    // �����N���ς���
		}
		
		m_pData[m_iMove].color  = color;
		m_pData[m_iMove].pos[0] = pos[0];
		m_pData[m_iMove].pos[1] = pos[1];
		m_iMove++;
	}
	// -----------------------------------------------------------------------
	// �����̕ۑ�
	// -----------------------------------------------------------------------
	bool CLog::SaveSgf( const char *filename )
	{
		FILE *fp = fopen( filename, "wt" );
		if(NULL==fp) return false;
		
		// �w�b�_�̏o��
		fprintf( fp, "(;\n" );
		fprintf( fp, "GM[1]SZ[%d]\n",_iRoban );	// �T�C�Y
		
		// �΋�
		int n = 0;
		for( unsigned int i = 0; i < m_iMove; i++ )
		{
			if(!IS_RESIGN(m_pData[i].pos))
			{
				char sPos[3] = "tt";
				if(!IS_PASS(m_pData[i].pos)){
					const char *alphabet = "abcdefghijklmnopqrstuvwxyz";
					sPos[0] = alphabet[m_pData[i].pos[0]];
					sPos[1] = alphabet[m_pData[i].pos[1]];
				}
				if( BLACK == m_pData[i].color)
				{
					fprintf( fp, ";B[%s]", sPos );
				} else {
					fprintf( fp, ";W[%s]", sPos );
				}
				// �K���ɉ��s
				if(10<=++n)
				{
					n=0;
					fprintf( fp, "\n" );
				}
			}
		}
		
		// �t�b�^�̏o��
		if( 0 == n )
		{
			fprintf( fp, ")\n" );
		}else{
			fprintf( fp, "\n)\n" );
		}
		
		fclose(fp);
		
		return true;
	}
}// namespace ai
