// ----------------------------------------------------------------------------
//
// go_string.h - �A�A�����A�Q�̃I�u�W�F�N�g�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __GO_STRING_H__
#define __GO_STRING_H__

#include "go_common.h"

namespace Go
{
	enum
	{
		ALIVE = 1,
		DEAD,
		NEUTRAL,
	};
	
	// -----------------------------------------------------------------------
	// �A
	// -----------------------------------------------------------------------
	typedef struct _string {
		GOISHI_TYPE     color;     // �F (BLACK/WHITE)
		int             id;        // ���ʔԍ�
		int             size;      // �T�C�Y
		BOARD_POINT		*goishi;
	int             dame;      // �_����
	int             status;    // ���� (ALIVE/DEAD/NEUTRAL)
	int             offense_x; // ����̂w���W
	int             offense_y; // ����̂x���W
	int             defense_x; // �������̂w���W
	int             defense_y; // �������̂x���W
	struct _string *neighbors; // �אڂ���A
		struct _string *next;      // ���̘A
	}string;
	
	// -----------------------------------------------------------------------
	// �A���m�ۂ���Ƃ��̏��
	class CString
	{
	protected:
		int     _num;
		string *_root;
	public:
		int    _IdBoard[BOARD_SIZE][BOARD_SIZE];
		
		CString();
		virtual ~CString();
		
		void MakeString( GOISHI_TYPE board[][BOARD_SIZE], int size );
		int GetNum() const {return _num;}

		string *Begin()        {return _root;}
	};
	
	
	// -----------------------------------------------------------------------
	// ����
	// -----------------------------------------------------------------------
	typedef struct{
		string *string[2];
		int    status;
		GOISHI_TYPE     color;     // �F (BLACK/WHITE)
	}linkage;
	
	// -----------------------------------------------------------------------
	class CLinkage
	{
	protected:
		int     _num;
		string *_root;
	public:
		void MakeLinkage( CString * );
	};
	// -----------------------------------------------------------------------
	// �Q
	// -----------------------------------------------------------------------
	typedef struct{
	}group;
	
}// namespace go

#endif // !__GO_STRING_H__
