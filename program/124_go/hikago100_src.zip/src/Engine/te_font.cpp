//--------------------------------------------------------------------------------------
// File: graphics_font.cpp
//
// �t�H���g�V�X�e��
//
// Copyright (c) Takashi Imagire, 2004. All rights reserved.
//--------------------------------------------------------------------------------------

#include "te.h"
#include "te_font.h"
#include <GL/glut.h>

namespace Te
{


//--------------------------------------------------------------------------------------
// �R���X�g���N�^
//--------------------------------------------------------------------------------------
CFont::CFont( ) : m_iTexture( 0 )
{
	m_color[0] = 1.0;
	m_color[1] = 1.0;
	m_color[2] = 1.0;
	m_color[3] = 1.0;

	m_size[0] = 32.0f;
	m_size[1] = 32.0f;
}




//--------------------------------------------------------------------------------------
// �f�X�g���N�^
//--------------------------------------------------------------------------------------
CFont::~CFont( )
{
}




//--------------------------------------------------------------------------------------
// ������
//--------------------------------------------------------------------------------------
void CFont::Init( const void *p )
{
	m_iTexture = Te::SetupBitmap( p );
}




//--------------------------------------------------------------------------------------
// �Еt��
//--------------------------------------------------------------------------------------
void CFont::Release()
{
	DeleteBitmap( m_iTexture );

	delete this;
}




//--------------------------------------------------------------------------------------
// �\��
//--------------------------------------------------------------------------------------
int CFont::TextOut( const char *pStr, int x, int y )
{
	if( 0 == m_iTexture ) return -1;
	
	float fWidth  = m_size[0];
	float fHeight = m_size[1];
	float fx = (float)x - 0.5f;
	float fy = (float)y - 0.5f;
	float x_base = fx;

	// �s���ύX����
	rect screen;
	GetScreenRect( &screen );
	
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( screen.left, screen.right, screen.bottom, screen.top, 0.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); 
	glLoadIdentity();

	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, m_iTexture );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glEnable(GL_TEXTURE_2D);

	// �A���t�@�u�����f�B���O
	glEnable(GL_BLEND);
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	glBegin( GL_QUADS );
	
	glColor4f( m_color[0], m_color[1], m_color[2], m_color[3] );

	for( const char *p = pStr; *p; p++ )
	{
		if( *p==0x0a )
		{
			// ���s
			fy += fHeight;
			fx = x_base;
		} else if( *p < 0 ) {
			// ���{��Ƃ�
			p++;
			fx += fWidth;
		} else if( 0x20 <= *p ) {
			// ascii
			int no = *p - 0x20;
			float duv = (1.0f/16.0f);
			float u = 1-duv * (float)(no & 0xf) + 0.5f/512.0f;
			float v =   duv * (float)(no >> 4)  - 0.5f/512.0f;

			glTexCoord2d( u+  0, v+  0 );
			glVertex3d( fx       , fy        , 0 );
			glTexCoord2d( u+  0, v+duv );
			glVertex3d( fx       , fy+fHeight, 0 );
			glTexCoord2d( u-duv, v+duv );
			glVertex3d( fx+fWidth, fy+fHeight, 0 );
			glTexCoord2d( u-duv, v+  0 );
			glVertex3d( fx+fWidth, fy        , 0 );

			fx += fWidth;
		}
	}
	glEnd();

	// �s������ɖ߂�
	glPopMatrix(); 
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	glDisable(GL_TEXTURE_2D);

	return 0;
}

//------------------------------------------------------------------------
// �t�H���g�̃T�C�Y���v�Z����
//------------------------------------------------------------------------
rect *CFont::GetSize( rect *dest, const char *pStr )
{
	float fWidth  = m_size[0];
	float fHeight = m_size[1];
	float fx = 0.0f;
	float fy = 0.0f;
	float x_base = fx;
	float x_max = 0;
	bool  no_lf = false;

	for( const char *p = pStr; *p; p++ )
	{
		if( *p==0x0a )
		{
			// ���s
			fy += fHeight;
			if( x_max < fx ) x_max = fx;
			fx = x_base;
			no_lf = false;
		} else if( *p < 0 ) {
			// ���{��Ƃ�
			p++;
			fx += fWidth;
			no_lf = true;
		} else if( 0x20 <= *p ) {
			// ascii
			fx += fWidth;
			no_lf = true;
		}
	}
	
	if(no_lf) fy += fHeight; // ���s�ŏI���Ȃ������炻�̍s�̍�����ǉ�����

	if( x_max < fx ) x_max = fx;

	dest->top = dest->left = 0;
	dest->bottom = fy;
	dest->right = x_max;

	return dest;
}


//------------------------------------------------------------------------
// �F�ݒ�
//------------------------------------------------------------------------
void CFont::SetColor( float r, float g, float b, float a )
{
	m_color[0] = r;
	m_color[1] = g;
	m_color[2] = b;
	m_color[3] = a;
}
//------------------------------------------------------------------------
// �傫���ݒ�
//------------------------------------------------------------------------
void CFont::SetSize( float w, float h )
{
	m_size[0] = w;
	m_size[1] = h;
}




//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
// ���{��t�H���g
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------
// �R���X�g���N�^
//--------------------------------------------------------------------------------------
CFontJ::CFontJ( )
{
	CFont();

	m_iTextures[0] = 0;
	m_iTextures[1] = 0;
	m_iTextures[2] = 0;
	m_iTextures[3] = 0;
	m_iTextures[4] = 0;
	m_iTextures[5] = 0;
	m_iTextures[6] = 0;
	m_iTextures[7] = 0;
}




//--------------------------------------------------------------------------------------
// �f�X�g���N�^
//--------------------------------------------------------------------------------------
CFontJ::~CFontJ( )
{
}




//--------------------------------------------------------------------------------------
// ������
//--------------------------------------------------------------------------------------
void CFontJ::Init( void *p[9], const FONT_INFO *pInfo, const FONT_INFO *pInfoJ )
{
	m_pInfo  = pInfo;
	m_pInfoJ = pInfoJ;

	m_iTexture     = Te::SetupBitmap( p[0] );
	m_iTextures[0] = Te::SetupBitmap( p[1] );
	m_iTextures[1] = Te::SetupBitmap( p[2] );
	m_iTextures[2] = Te::SetupBitmap( p[3] );
	m_iTextures[3] = Te::SetupBitmap( p[4] );
	m_iTextures[4] = Te::SetupBitmap( p[5] );
	m_iTextures[5] = Te::SetupBitmap( p[6] );
	m_iTextures[6] = Te::SetupBitmap( p[7] );
	m_iTextures[7] = Te::SetupBitmap( p[8] );
}




//--------------------------------------------------------------------------------------
// �Еt��
//--------------------------------------------------------------------------------------
void CFontJ::Release()
{
	DeleteBitmap( m_iTextures[7] ); m_iTextures[7] = 0;
	DeleteBitmap( m_iTextures[6] ); m_iTextures[6] = 0;
	DeleteBitmap( m_iTextures[5] ); m_iTextures[5] = 0;
	DeleteBitmap( m_iTextures[4] ); m_iTextures[4] = 0;
	DeleteBitmap( m_iTextures[3] ); m_iTextures[3] = 0;
	DeleteBitmap( m_iTextures[2] ); m_iTextures[2] = 0;
	DeleteBitmap( m_iTextures[1] ); m_iTextures[1] = 0;
	DeleteBitmap( m_iTextures[0] ); m_iTextures[0] = 0;
	DeleteBitmap( m_iTexture     ); m_iTexture     = 0;

	delete this;
}




//--------------------------------------------------------------------------------------
// �\��
//--------------------------------------------------------------------------------------
int CFontJ::TextOut( const char *pStr, int x, int y )
{
	if( 0 == m_iTexture ) return -1;
	
	float fWidth  = m_size[0];
	float fHeight = m_size[1];
	float fx = (float)x - 0.5f;
	float fy = (float)y - 0.5f;
	float x_base = fx;
	
	unsigned int last_page = 100000;

	// �s���ύX����
	rect screen;
	GetScreenRect( &screen );
	
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( screen.left, screen.right, screen.bottom, screen.top, 0.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); 
	glLoadIdentity();

	// �A���t�@�u�����f�B���O
	glEnable(GL_BLEND);
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	// Z�e�X�g�Ȃ�
	glDisable(GL_DEPTH_TEST);

	for( const char *p = pStr; *p; p++ )
	{
		if( *p==0x0a )
		{
			// ���s
			fy += fHeight;
			fx = x_base;
		} else if( *p < 0 ) {
			unsigned int code = (((unsigned char*)p)[0] << 8)
								+ ((unsigned char*)p)[1];
			p++;
			if(((code & 0xc0) < 0x40)
			|| (code < 0x8140)
			|| (0xa000 < code && code < 0xe000)
			|| (0xef00 < code))
			{
				fx += fWidth;// ����������
			}else{
				if( 0xe000 < code ) code += 0xe000-0xa000;
				code -= 0x8100;
				unsigned int no = 192*(code>>8)+((code & 0xff)-0x40);
				unsigned int page = no / (32*32);
				unsigned int ix = no&31;
				unsigned int iy = (no/32)&31;
				float duv = (1.0f/32.0f);
				float u = 1-duv * (float)(ix) + 0.5f/1024.0f;
				float v =   duv * (float)(iy) - 0.5f/1024.0f;

				float px = fx + this->m_pInfoJ[no].x * fWidth  * (1.0f / 128.0f);
				float py = fy + this->m_pInfoJ[no].y * fHeight * (1.0f / 64.0f);
				
				if( last_page != page )
				{
					last_page = page;
					glBindTexture( GL_TEXTURE_2D, m_iTextures[page] );
					glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
					glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
					glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
					glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
					glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
					glEnable(GL_TEXTURE_2D);
				}
				glBegin( GL_QUADS );
				glColor4f( m_color[0], m_color[1], m_color[2], m_color[3] );
				glTexCoord2d( u+  0, v+  0 );
				glVertex3d( px       , py        , 0 );
				glTexCoord2d( u+  0, v+duv );
				glVertex3d( px       , py+fHeight, 0 );
				glTexCoord2d( u-duv, v+duv );
				glVertex3d( px+fWidth, py+fHeight, 0 );
				glTexCoord2d( u-duv, v+  0 );
				glVertex3d( px+fWidth, py        , 0 );
				glEnd();

				fx += fWidth * this->m_pInfoJ[no].u * (1.0f / 128.0f);
			}
		} else if( 0x20 <= *p ) {
			// ascii
			int no = *p - 0x20;
			float duv = (1.0f/16.0f);
			float u = 1-duv * (float)(no & 0xf) + 0.5f/512.0f;
			float v =   duv * (float)(no >>  4) - 0.5f/512.0f;

			if( last_page != ~0 )
			{
				last_page = ~0;
				glBindTexture( GL_TEXTURE_2D, m_iTexture );
				glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
				glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
				glEnable(GL_TEXTURE_2D);
			}

			float px = fx + this->m_pInfo[no].x * fWidth  * (0.5f / 128.0f);
			float py = fy + this->m_pInfo[no].y * fHeight * (1.0f / 64.0f);

			glBegin( GL_QUADS );
			glColor4f( m_color[0], m_color[1], m_color[2], m_color[3] );
			glTexCoord2d( u+  0, v+  0 );
			glVertex3d( px       , py        , 0 );
			glTexCoord2d( u+  0, v+duv );
			glVertex3d( px       , py+fHeight, 0 );
			glTexCoord2d( u-duv, v+duv );
			glVertex3d( px+fWidth*0.5, py+fHeight, 0 );
			glTexCoord2d( u-duv, v+  0 );
			glVertex3d( px+fWidth*0.5, py        , 0 );
			glEnd();

			fx += fWidth * this->m_pInfo[no].u * (0.5f / 128.0f);
		}
	}

	// �s������ɖ߂�
	glPopMatrix(); 
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	glDisable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);

	return 0;
}

//------------------------------------------------------------------------
// �t�H���g�̃T�C�Y���v�Z����
//------------------------------------------------------------------------
rect *CFontJ::GetSize( rect *dest, const char *pStr )
{
	float fWidth  = m_size[0];
	float fHeight = m_size[1];
	float fx = 0.0f;
	float fy = 0.0f;
	float x_base = fx;
	float x_max = 0;
	bool  no_lf = false;

	for( const char *p = pStr; *p; p++ )
	{
		if( *p==0x0a )
		{
			fy += fHeight;
			if( x_max < fx ) x_max = fx;
			fx = x_base;
			no_lf = false;
		} else if( *p < 0 ) {
			unsigned int code = (((unsigned char*)p)[0] << 8)
								+ ((unsigned char*)p)[1];
			p++;
			if(((code & 0xc0) < 0x40)
			|| (code < 0x8140)
			|| (0xa000 < code && code < 0xe000)
			|| (0xef00 < code))
			{
				fx += fWidth;// ����������
			}else{
				if( 0xe000 < code ) code += 0xe000-0xa000;
				code -= 0x8100;
				unsigned int no = 192*(code>>8)+((code & 0xff)-0x40);

				fx += fWidth * this->m_pInfoJ[no].u * (1.0f / 128.0f);
			}
			no_lf = true;
		} else if( 0x20 <= *p ) {
			int no = *p - 0x20;
			fx += fWidth * this->m_pInfo[no].u * (0.5f / 128.0f);
			no_lf = true;
		}
	}
	
	if(no_lf) fy += fHeight; // ���s�ŏI���Ȃ������炻�̍s�̍�����ǉ�����

	if( x_max < fx ) x_max = fx;

	dest->top = dest->left = 0;
	dest->bottom = fy;
	dest->right = x_max;

	return dest;
}



}// namespace Te
