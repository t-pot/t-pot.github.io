// te_teb.cpp
//

//#include "stdafx.h"
#include <map>
#include <windows.h>
#include <malloc.h>
#include "te_teb.h"

//----------------------------------------------------------------------------
// FILE_INFO �z�񂩂�TEB�t�@�C�������
//----------------------------------------------------------------------------
unsigned int CreateTeb( void* *pdest, std::map <unsigned int, INPUT_FILE> &src )
{
	int n = src.size();
	unsigned int size = sizeof(TEB_HEADER) + n * sizeof(TEB_INDEX);
	unsigned int image_offset; // �f�[�^���̎n�܂�ʒu
	std::map< unsigned int , INPUT_FILE >::iterator it;
	
	//------------------------------------------------------------------------
	// �T�C�Y�v�Z
	//------------------------------------------------------------------------
	size = 16*((size+16-1)/16); // 16 �o�C�g�A���C�����g
	image_offset = size;
	for (it = src.begin() ; it != src.end() ; it++ )
	{
		size += it->second.size;
		size = 16*((size+16-1)/16); // 16 �o�C�g�A���C�����g
	}

	//------------------------------------------------------------------------
	// �������m��
	//------------------------------------------------------------------------
	*pdest = malloc(size);

	//------------------------------------------------------------------------
	// �w�b�_�̍쐬
	//------------------------------------------------------------------------
	TEB_HEADER *pHeader = (TEB_HEADER *)(*pdest);
	pHeader->id[0] = 'T';
	pHeader->id[1] = 'E';
	pHeader->id[2] = 'B';
	pHeader->id[3] = '\0';
	pHeader->num = n;
	pHeader->reserved[0] = pHeader->reserved[1] = 0;

	//------------------------------------------------------------------------
	// �C���f�b�N�X�̍쐬
	//------------------------------------------------------------------------
	TEB_INDEX *pIndex = (TEB_INDEX *)(pHeader+1);
	for (it = src.begin() ; it != src.end() ; it++ )
	{
		pIndex->id   = it->second.id;
		pIndex->addr = image_offset;
		image_offset += 16*((it->second.size+16-1)/16);
		pIndex++;
	}
	// 16 �o�C�g�A���C�����g
	if( n&1 ) pIndex++;

	//------------------------------------------------------------------------
	// �f�[�^�̍쐬
	//------------------------------------------------------------------------
	void *pData = (void *)pIndex;
	for (it = src.begin() ; it != src.end() ; it++ )
	{
		memcpy( pData, it->second.addr, it->second.size );
		pData = (void*)((unsigned int)pData + (16*((it->second.size+16-1)/16)));
	}

	return size;
}
//----------------------------------------------------------------------------
// 
//----------------------------------------------------------------------------
void DeleteTeb( void *p )
{
	free( p );
}

