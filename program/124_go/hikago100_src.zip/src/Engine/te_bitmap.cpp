
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <GL/glut.h>
#include "te_bitmap.h"

namespace Te
{


// ---------------------------------------------------------------------------
// Bitmap�w�b�_�`�F�b�N
// ---------------------------------------------------------------------------
int Bitmap::_CheckHeaders (const BitmapHeader *pBH, const BitmapInfoHeader *pBIH)
{
	//�w�b�_��BM�̕���
	if( pBH->distinct1!='B' || pBH->distinct2!='M' )return 0;
	//���C���[�P
	if( pBIH->plane !=1 )return 0;
	//���k�Ȃ�
	if( pBIH->compression !=0 ) return 0;
	//�F����Ԃ�
	if( pBIH->bits ==24 || pBIH->bits ==32 || pBIH->bits ==8 ) return pBIH->bits;
	
	return 0;
}
// ---------------------------------------------------------------------------
// �r�b�g�}�b�v�t�@�C���̃T�C�Y�`�F�b�N
// ---------------------------------------------------------------------------
int Bitmap::_CheckSize(unsigned int pict_size)
{
	unsigned int i=2;
	const unsigned int TEX_SIZE = 1024;
	unsigned int max_texture = TEX_SIZE*TEX_SIZE;
	
	//�T�C�Y�`�F�b�N
	for(i=2;i<=max_texture;i*=2){
		if( i == pict_size){
			return 1;
		}
	}
	return 0;
};

// ---------------------------------------------------------------------------
// 24bits�e�N�X�`���̓ǂݍ���
// ---------------------------------------------------------------------------
unsigned int Bitmap::_Analize24bit( const BitmapInfoHeader *pBIH, const void *p )
{
	unsigned int tex_id = 0;
	const unsigned char *src = (const unsigned char *)p;
	unsigned char *dst;
	int i, j, no;
	
	//dst�m��
	dst = (unsigned char*)malloc(3*pBIH->width*pBIH->height*sizeof(unsigned char));
	//�ǂݍ���
	no = 0;
	for(j=(pBIH->height-1);j>=0;j--){
		for(i=(pBIH->width-1);i>=0;i--){
			dst[3*(j*pBIH->width+i)+2] = src[no++];
			dst[3*(j*pBIH->width+i)+1] = src[no++];
			dst[3*(j*pBIH->width+i)+0] = src[no++];
		}
	}
	//�e�N�X�`���쐬
	glGenTextures(1, &tex_id);
	glBindTexture(GL_TEXTURE_2D, tex_id);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, pBIH->width, pBIH->height,
				0, GL_RGB, GL_UNSIGNED_BYTE, dst );
	
	//�������J��
	free(dst);
	
	return tex_id;
}
// ---------------------------------------------------------------------------
// 32bits�e�N�X�`���̓ǂݍ���
// ---------------------------------------------------------------------------
unsigned int Bitmap::_Analize32bit( const BitmapInfoHeader *pBIH, const void *p )
{
	unsigned int tex_id = 0;
	const unsigned char *src = (const unsigned char *)p;
	unsigned char *dst;
	int i, j, no;
	
	//�������m��
	dst = (unsigned char*)malloc(4*pBIH->width*pBIH->height*sizeof(unsigned char));
	//�ǂݍ���
	no = 0;
	for(j=(pBIH->height-1);j>=0;j--){
		for(i=(pBIH->width-1);i>=0;i--){
			dst[4*(j*pBIH->width+i)+2] = src[no++];
			dst[4*(j*pBIH->width+i)+1] = src[no++]; 
			dst[4*(j*pBIH->width+i)+0] = src[no++];
			dst[4*(j*pBIH->width+i)+3] = src[no++];
		}
	}
	//�e�N�X�`���쐬
	glGenTextures( 1, &tex_id );
	glBindTexture( GL_TEXTURE_2D, tex_id );
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, pBIH->width, pBIH->height,
				0, GL_RGBA, GL_UNSIGNED_BYTE, dst );
	
	//�������J��
	free(dst);
	
	return tex_id;
}


// ---------------------------------------------------------------------------
// �e�N�X�`���̓ǂݍ���
// ---------------------------------------------------------------------------
unsigned int Bitmap::Load(const char *filename)
{
	unsigned int tex_id = 0;

	char *p;

	int hFile = _open( filename, _O_BINARY | _O_RDONLY );
	if( -1 != hFile )                             // �t�@�C�������݂��Ȃ�������
	{
		long size = _filelength( hFile );	      // �f�[�^�̒����̏���
		p = new char[size];	                      // �������̊m��
		_read( hFile, p, size );	          // �ǂݍ���
		_close( hFile );
	}
	
	tex_id = Setup( (void*)p );
	delete[] p;

	return tex_id;
}

// ---------------------------------------------------------------------------
// �e�N�X�`���̐ݒ�
// ---------------------------------------------------------------------------
unsigned int Bitmap::Setup( const void *p )
{
	unsigned int tex_id = 0;
	//�r�b�g�}�b�v�w�b�_
	BitmapHeader     *pHeader;
	BitmapInfoHeader *pInfo;
	void             *pData;
	//�F��
	unsigned int color_bit;
	
	// �f�[�^�i�[
	pHeader = (BitmapHeader*)p;
	pInfo   = (BitmapInfoHeader*)(pHeader+1);
	pData   = (void*)(pInfo+1);
	
	//�w�b�_�`�F�b�N
	if( !(color_bit = _CheckHeaders( pHeader, pInfo ))) return tex_id;
	
	//�r�b�g�}�b�v�t�@�C���T�C�Y�`�F�b�N
	if( !_CheckSize( pInfo->width * pInfo->height) ) return tex_id;
	
	//�J���[�r�b�g���ŏ����𕪂���
	switch(color_bit){
	case 24:
		tex_id = _Analize24bit( pInfo, pData );
		break;
	case 32:
		tex_id = _Analize32bit( pInfo, pData );
		break;
	}
	
	return tex_id;
}

unsigned int BitmapLoad( const char *filename )
{
	return Bitmap::Load(filename);
}

unsigned int SetupBitmap( const void *p )
{
	return Bitmap::Setup( p );
}

void DeleteBitmap( unsigned int tex_id )
{
	glDeleteTextures(1, &tex_id);
}

}// namespace Te
