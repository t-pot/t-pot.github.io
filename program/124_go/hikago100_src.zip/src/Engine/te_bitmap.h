#ifndef _GRAPHICS_BITMAP_H_
#define _GRAPHICS_BITMAP_H_

#include <stdio.h>

namespace Te
{

///////////////////////////////////////////////////////////////////////////////
//Bitmap�t�@�C��
//BitmapHeader�\����
#pragma pack(push, 2)
typedef struct _BitmapHeader{
	char	distinct1;
	char	distinct2;
	int		filesize;
	short	reserve1;
	short	reserve2;
	int		offset;
}BitmapHeader;
#pragma pack(pop)

//BitmapInfoHeader�\����
typedef struct _BitmapInfoHeader{
	int		header;
	int		width;
	int		height;
	short	plane;
	short	bits;
	int		compression;
	int		comp_image_size;
	int		x_resolution;
	int		y_resolution;
	int		pallet_num;
	int		important_pallet_num;
}BitmapInfoHeader;


class Bitmap{
private:
	static int _CheckHeaders (const BitmapHeader *pBH, const BitmapInfoHeader *pBIH );
	static int _CheckSize(unsigned int pict_size);
	
	static unsigned int _Analize24bit( const BitmapInfoHeader *pBIH, const void *pData );
	static unsigned int _Analize32bit( const BitmapInfoHeader *pBIH, const void *pData );
public:
	static unsigned int Load ( const char *filename );
	static unsigned int Setup( const void *p );
};



}// namespace Te

#endif _GRAPHICS_BITMAP_H_
