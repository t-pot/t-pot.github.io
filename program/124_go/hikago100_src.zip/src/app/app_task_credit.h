// ----------------------------------------------------------------------------
//
// app_task_credit.h - [t-pot PRESENTS]�\���^�X�N�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_CREDIT_H__
#define __APP_TASK_CREDIT_H__

#include "app_task.h"

namespace Application
{
	class CTaskCredit : public CTask
	{
	private:
		float _time;
		float _a;
		unsigned int _tex_id;
	public:
		 CTaskCredit();
		~CTaskCredit();
		
		int  FrameMove( float dt );
		void Render();
		
	};

}// namespace Application


#endif // !__APP_TASK_CREDIT_H__
