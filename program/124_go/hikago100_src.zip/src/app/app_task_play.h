// ----------------------------------------------------------------------------
//
// app_task_play.h - �Q�[���^�X�N�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_PLAY_H__
#define __APP_TASK_PLAY_H__

#include "ai/go_common.h"
#include "app_task.h"

namespace Application
{
	class CTaskPlay : public CTask
	{
	private:
		typedef enum
		{
			STATE_READY = 0,
			STATE_THINK,
			AFTER_PLAY,
		}PLAY_STATE;

		enum
		{
			BOARD_MAX = 20,
		};

		unsigned char disp_board [BOARD_MAX][BOARD_MAX]; // �\���p
		float         board_count[BOARD_MAX][BOARD_MAX];// ��������


		void InitDispBoard();
		void UpdateDispBoard( );
		void FrameMoveDispBoard( float dt );
		void RenderDispBoard( float scale, float bias );

	public:
		float _time;
		PLAY_STATE _iState;
		bool       _bShowJiai;

		 CTaskPlay();
		~CTaskPlay();
		
		int  FrameMove( float dt );
		void Render();
		
	};

}// namespace Application


#endif // !__APP_TASK_PLAY_H__
