// ----------------------------------------------------------------------------
//
// app_task_title.cpp - �^�C�g���^�X�N
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <GL/glut.h>
#include "../main.h"
#include "te.h"
#include "app_task_tbl.h"
#include "app_task_title.h"
#include "file_tbl.h"

// ===========================================================================
// �ϐ�
// ===========================================================================
extern Te::CFontJ *g_pFont;

static void *pTeb = 0;

namespace Application
{
static const char *pMsg   = "CLICK LEFT BUTTON";
static int msg_x;
static int msg_y;


// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskTitle::CTaskTitle() : CTask()
{
	_time = 0.0f;
	_a = 0;
	_state = 0;
	
#ifdef USE_IMAGE_DATA
	pTeb = Te::File::SetupTeb( IMG_DATA2 );
#endif // USE_IMAGE_DATA
	void *pBitmap = Te::File::GetData( FILE_DATA2_TITLE_BMP, pTeb );
	_tex_id = Te::SetupBitmap( pBitmap );
	Te::File::DeleteData( pBitmap, pTeb );

	// �w�i�F�̕ύX
	Te::SetClearColor( Te::fColor( 0.0, 0.0, 0.0, 0.0 ) );
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskTitle::~CTaskTitle( )
{
	Te::DeleteBitmap( _tex_id );
	Te::File::DeleteTeb( pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskTitle::FrameMove( float dt )
{
	// ���b�Z�[�W�̈ʒu�̎Z�o(�Z���^�����O)
	Te::rect sr, mr;
	Te::GetScreenRect( &sr );
	g_pFont->GetSize( &mr, pMsg );
	msg_x = (sr.right+sr.left - mr.right )/2;
	msg_y = (sr.top+sr.bottom - mr.bottom)/2 + 96;

	switch( _state )
	{
	case 0:
		_time += dt;
		_a = _time / 0.5f;
		if( 0.5f < _time ) {_a = 1.0; _state++;}
		break;
	case 1:
		_a = 1.0;
		if( Te::GetMouseInfo()->trg & Te::MOUSE_L ) _state++;
		break;
	case 2:
		_time -= dt;
		_a = _time / 0.5f;

		if( _time < 0 )
		{
			_a = 0;
			return TASK_ID_SETTING;
		}
		break;
	}

	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskTitle::Render()
{
	Te::BeginRender();

	// ��ʂ̃N���A
	Te::Clear();

	// �ˉe�s���ύX����
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( -2.0, 2.0, -1.5, 1.5, -1.0, 1.0);

	// �r���[�s��̐ݒ�
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, _tex_id );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glEnable(GL_TEXTURE_2D);

	glBegin(GL_TRIANGLE_STRIP);		// �X�g���b�v�ݒ�
	glColor3d( _a, _a, _a);
	
	glTexCoord2d( 1, 1 );
	glVertex3d( -1,  0, 0 );
	glTexCoord2d( 1, 0 );
	glVertex3d( -1,  1, 0 );
	glTexCoord2d( 0, 1 );
	glVertex3d(  1,  0, 0 );
	glTexCoord2d( 0, 0 );
	glVertex3d(  1,  1, 0 );

	glEnd();						// �|���S���̕`��I��

	glDisable(GL_TEXTURE_2D);
	
	// �ˉe�s������ɖ߂�
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	g_pFont->SetColor( 1,1,1,_a);
	g_pFont->TextOut( pMsg, msg_x, msg_y );

	Te::EndRender();
}

}// namespace Application
