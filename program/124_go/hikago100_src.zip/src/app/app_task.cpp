// ----------------------------------------------------------------------------
//
// app_task.cpp - �^�X�N�Ǘ��̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include "app_task.h"
#include "app_task_tbl.h"
#include "app_task_credit.h"
#include "app_task_title.h"
#include "app_task_setting.h"
#include "app_task_play.h"

namespace Application
{
// ===========================================================================
// �O���[�o���ϐ�
// ===========================================================================

// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// �^�X�N����
// ---------------------------------------------------------------------------
CTask *CTaskMgr::CreateTask( int task_id )
{
	switch( task_id )
	{
	case TASK_ID_CREDIT:  return new CTaskCredit();
	case TASK_ID_TITLE:   return new CTaskTitle();
	case TASK_ID_SETTING: return new CTaskSetting();
	case TASK_ID_PLAY:    return new CTaskPlay();
	}

	return 0;
}

// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskMgr::CTaskMgr( int task_id )
{
	_pCurrent = 0;
	_next = task_id;
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskMgr::~CTaskMgr( )
{
	if( _pCurrent ) delete _pCurrent; _pCurrent = 0;
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
void CTaskMgr::Update( float dt )
{
	if( CTask::INVALID_ID != _next )
	{
		if( _pCurrent ) delete _pCurrent;
		_pCurrent = CreateTask( _next );
	}
	
	if( _pCurrent )
	{
		_next = _pCurrent->FrameMove( dt );
		_pCurrent->Render();
	}
}

}// namespace Application
