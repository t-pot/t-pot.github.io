// ----------------------------------------------------------------------------
//
// app_task_tbl.h - �^�X�N�Ǘ��̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_TBL_H__
#define __APP_TASK_TBL_H__

namespace Application
{
	enum
	{
		TASK_ID_CREDIT = 0,
		TASK_ID_TITLE,
		TASK_ID_SETTING,
		TASK_ID_PLAY,
	};

}// namespace Application


#endif // !__APP_TASK_TBL_H__
