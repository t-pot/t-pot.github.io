// ----------------------------------------------------------------------------
//
// app_task_play.cpp - �Q�[���v���C�̃^�X�N
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <stdio.h>
#include <GL/glut.h>
#include "ai/go_log.h"
#include "ai/go_string.h"
#include "ai/ai_npc.h"
#include "main.h"
#include "te.h"
#include "app_task_tbl.h"
#include "app_task_play.h"
#include "file_tbl.h"

// ===========================================================================
// �ϐ�
// ===========================================================================
extern Te::CFontJ *g_pFont;

signed int jiai_board [Go::BOARD_SIZE][Go::BOARD_SIZE]; // �n���p
namespace Ai
{
extern void EvalJiai( Go::GOISHI_TYPE board[][Go::BOARD_SIZE], int size );
}


// ===========================================================================
// �J�[�\�������̃O���[�o���ϐ�
// ===========================================================================
float current_pos[2] = {0,0};
int current_index[2] = {0,0};

void GetCursolBoard( Go::BOARD_POINT dest )
{
	dest[0] = current_index[0];
	dest[1] = current_index[1];
}
// ---------------------------------------------------------------------------
// �X�N���[�����W���烏�[���h���W�̏���
// ---------------------------------------------------------------------------
static void  GetWorldPos(float x, float y, float depth, 
             double &wx, double &wy, double &wz )
{
    GLdouble mModelView[16], mProj[16];
    GLint viewport[4];

    glGetIntegerv( GL_VIEWPORT, viewport );
    glGetDoublev ( GL_MODELVIEW_MATRIX, mModelView );
    glGetDoublev ( GL_PROJECTION_MATRIX, mProj );

    gluUnProject( x, (double)viewport[3]-y,depth,
            mModelView,  mProj, viewport,
            &wx, &wy, &wz);
}
// ---------------------------------------------------------------------------
// �X�N���[����񂩂�J�[�\������Ղ̂����ʒu�𒲂ׂ�
// ---------------------------------------------------------------------------
static void update_current_pos()
{
	double v[3];
	double n[3];
	GetWorldPos( Te::GetMouseInfo()->pos[0], Te::GetMouseInfo()->pos[1], 0,
				 v[0], v[1], v[2]);
	GetWorldPos( Te::GetMouseInfo()->pos[0], Te::GetMouseInfo()->pos[1], 1,
				 n[0], n[1], n[2]);
	
	n[0] -= v[0];
	n[1] -= v[1];
	n[2] -= v[2];

	// ���ʂƂ̌��������߂�
	// n0.(v+tn-p0)=0 (p0={0,0,0},n0={0,1,0})�����藧�_����_�ŁA
	// p0,n0�𕪂��������̂Ƃ���ƁA
	// v[1]+t n[1]=0, t=-v[1]/n[1]�ŁAx=v+t*n �Ō�_�����߂�
	double t = -v[1]/n[1];
	current_pos[0] = v[0] + t * n[0];
	current_pos[1] = v[2] + t * n[2];
}


namespace Application
{
// ===========================================================================
// �O���[�o���ϐ�
// ===========================================================================
static unsigned int tex_id=0;
static unsigned int button_tex_id=0;

Go::CBoard *pBoard = 0;
int player = Go::PLAYER_BLACK;
Ai::CNpc   *pPlayer[2] = {NULL,NULL};
Go::CLog   *pLog = 0;
char       _msg[1024] = "";
Go::GOISHI_TYPE _current_color;

static void *pTeb = 0;


#define DISP_FLAG_SHOW (1<<6) // �΂��ł��ꂽ
#define DISP_FLAG_HIDE (1<<7) // �΂���菜���ꂽ

Go::SETTING_DATA g_current_setting =
{
	{
		6, // 19/13/9/6�H
		0,  // �u��:0�`36�q
		0,  // ����Aplayer0���ԁAplayer1����
		13, // �R�~�F�Q�{�����l(6�ڔ��Ȃ�13)
	},{
		{"PLAYER0", Ai::NPC_PLAYER},
//		{"PLAYER1", Ai::NPC_AKARI},
		{"PLAYER1", Ai::NPC_AKARI},
	},
};

// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
void UpdateJiaiBoard( )
{
	// string ���v�Z
	Go::CString *pString = new Go::CString();
	pString->MakeString( pBoard->_iBoard, pBoard->_iBoardSize-2 );

	// linkage ���v�Z
	// �͂܂��ꏊ���v�Z
}

// ---------------------------------------------------------------------------
void CTaskPlay::InitDispBoard()
{
	// �\���p�ϐ��̏�����
	for( int y = 0; y < BOARD_MAX; y++ )
	{
		for( int x = 0; x < BOARD_MAX; x++ )
		{
			disp_board[y][x] = pBoard->_iBoard[y][x];
			board_count[y][x] = 0.0f;

			jiai_board[y][x] = 0;
		}
	}
}
// ---------------------------------------------------------------------------
void CTaskPlay::UpdateDispBoard( )
{
	for( int y = 0; y < BOARD_MAX; y++ )
	{
		for( int x = 0; x < BOARD_MAX; x++ )
		{
			if( (disp_board[y][x] & 3) != pBoard->_iBoard[y][x] )
			{
				if( pBoard->_iBoard[y][x] == Go::SPACE )
				{
					// �΂���菜���ꂽ
					disp_board[y][x] |= DISP_FLAG_HIDE;
					board_count[y][x] = 1.0f;
				}else{
					// �΂��ł��ꂽ
					disp_board[y][x] = pBoard->_iBoard[y][x] | DISP_FLAG_SHOW;
					board_count[y][x] = 1.0f;
				}
			}
		}
	}
}


// ---------------------------------------------------------------------------
void CTaskPlay::FrameMoveDispBoard( float dt )
{
	for( int y = 0; y < BOARD_MAX; y++ )
	{
		for( int x = 0; x < BOARD_MAX; x++ )
		{
			// �΂�ł�����̉��o
			if( disp_board[y][x] & DISP_FLAG_SHOW )
			{
				board_count[y][x] -= 5.0f*dt;
				if( board_count[y][x] < 0 )
				{
					disp_board[y][x] &= ~DISP_FLAG_SHOW;// �t���O�𗎂Ƃ�
				}
			}
			
			// �΂���菜������̉��o
			if( disp_board[y][x] & DISP_FLAG_HIDE )
			{
				board_count[y][x] -= 2.0f * dt;
				if( board_count[y][x] < 0 )
				{
					disp_board[y][x] = Go::SPACE;
				}
			}
		}
	}
}
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
void CTaskPlay::RenderDispBoard( float scale, float bias )
{
	// �J�[�\���̐΂�\������
	bool bDispCurrent = false;
	Go::BOARD_POINT pos = { current_index[0], current_index[1] };
	if( (Go::BLACK == _current_color || Go::WHITE == _current_color )
	 && 0 == pBoard->CheckLegal( _current_color, pos[0], pos[1], pBoard->_iBoard ))
	{
		bDispCurrent = true;
	}


	for( int y = 1; y <= pBoard->_iBoardSize-2; y++ )
	{
		for( int x = 1; x <= pBoard->_iBoardSize-2; x++ )
		{
			unsigned char color = disp_board[y][x] & 0x3;
			
			// �ʒu�̐ݒ�
			float tx = (x-1) * scale + bias;
			float tz = (y-1) * scale + bias;
			float ty = 0.3;
			float sxz = 0.95 * 19/(pBoard->_iBoardSize-2);
			float sy = 0.3;

			if( Go::SPACE == color ) // ��
			{
				if( bDispCurrent &&  x == current_index[0] && y == current_index[1] )
				{
					// �J�[�\���̐F�ŕ\��
					glColor3d( 1.0, 0.2, 0.2 );
				}else{
					continue;
				}
			}else
			if( Go::OUT == color ) // �ՊO
			{
				continue;
			}else{
				// �ʒu�̐ݒ�
				if( disp_board[y][x] & DISP_FLAG_SHOW )
				{
					ty += 20.0f * board_count[y][x]; // �ォ�痎�Ƃ�
					
				}else
				if(disp_board[y][x] & DISP_FLAG_HIDE )
				{
					// �������Ȃ�
					sxz *= board_count[y][x];
					sy  *= board_count[y][x];
				}
				// �w�肳�ꂽ�F�ŕ\��
				if( Go::BLACK == color)
				{
					glColor3d( 0.0, 0.0, 0.0 );
				}else{
					glColor3d( 1.0, 1.0, 1.0 );
				}
			}

			glPushMatrix();
			glTranslatef( tx, ty, tz );
			glScalef( sxz, sy, sxz );
			glutSolidSphere( 1, 8, 8 );
			glPopMatrix();
		}
	}
}

// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskPlay::CTaskPlay() : CTask()
{
	_time = 0.0f;
	_iState = STATE_READY;
	_bShowJiai = false;

	Te::SetClearColor( Te::fColor( 0.0, 0.2, 0.3, 0.0 ) );// �w�i�F�̕ύX

	pBoard = new Go::CBoard();
	pBoard->Init( g_current_setting.common.roban );
	InitDispBoard();
	
	if ( 1 == g_current_setting.common.hadicap )
	{
		player = Go::PLAYER_BLACK;// ����
	}else if ( g_current_setting.common.hadicap )
	{
		unsigned char okiishi[2];
		int no = 0;
		while(Go::GetOkiishi( okiishi, g_current_setting.common.roban, g_current_setting.common.hadicap, no++ ))
		{
			pBoard->_iBoard[okiishi[1]][okiishi[0]] = Go::BLACK;
		}
		UpdateDispBoard( );
		UpdateJiaiBoard( );
		player = Go::PLAYER_WHITE;// ������
	}else{
		player = Go::PLAYER_BLACK;// �Ƃ肠�����B�{���͌ݐ�ŏ��Ԃ͂��łɌ��܂��Ă���B
	}

	pPlayer[0] = Ai::CNpc::CreateNPC( (Ai::NPC_TYPE)g_current_setting.player[0].npc );
	pPlayer[1] = Ai::CNpc::CreateNPC( (Ai::NPC_TYPE)g_current_setting.player[1].npc );
	pPlayer[0]->Init( pBoard );
	pPlayer[1]->Init( pBoard );

	pLog = new Go::CLog();
	pLog->SetSize( g_current_setting.common.roban );

#ifdef USE_IMAGE_DATA
	pTeb = Te::File::SetupTeb( IMG_DATA3 );
#endif // USE_IMAGE_DATA

	void *pBitmapButton = Te::File::GetData( FILE_DATA3_BUTTON_BMP, pTeb );
	button_tex_id = Te::SetupBitmap( pBitmapButton );

	void *pBitmap = 0;
	switch(pBoard->_iBoardSize-2)
	{
	case 6:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN6_BMP, pTeb );
		break;
	case 9:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN9_BMP, pTeb );
		break;
	case 13:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN13_BMP, pTeb );
		break;
	default:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN19_BMP, pTeb );
		break;
	}
	tex_id = Te::SetupBitmap( pBitmap );

	Te::File::DeleteData( pBitmap, pTeb );
	Te::File::DeleteData( pBitmapButton, pTeb );
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskPlay::~CTaskPlay( )
{
	if(pPlayer[1]) delete pPlayer[1]; pPlayer[1] = 0;
	if(pPlayer[0]) delete pPlayer[0]; pPlayer[0] = 0;
	if(pBoard) delete pBoard; pBoard = 0;

	Te::DeleteBitmap( tex_id );
	tex_id = 0;
	Te::DeleteBitmap( button_tex_id );
	button_tex_id = 0;

	g_pFont->SetSize( 32, 32 );

	Te::DeleteBitmap( tex_id );
	Te::DeleteBitmap( button_tex_id );
	Te::File::DeleteTeb( pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskPlay::FrameMove( float dt )
{
	Go::BOARD_POINT pos;

	_time += dt;

	update_current_pos();
	
	if(Te::GetMouseInfo()->trg & Te::MOUSE_R) _bShowJiai = !_bShowJiai;

	switch( _iState )
	{
	case STATE_READY: // ready go!
		sprintf( _msg, "Ready ?" );
		_current_color = Go::INVALID_COLOR;

		if( 1.0 < _time ) 
		{
			_iState = STATE_THINK;
		
			if( Go::PLAYER_BLACK == player )
			{
				_current_color = Go::BLACK;
			}else{
				_current_color = Go::WHITE;
			}
		}
		break;
	case STATE_THINK: // black
		if(Go::BLACK == _current_color)
		{
			sprintf( _msg, "TURN : BLACK" );
		}else{
			sprintf( _msg, "TURN : WHITE" );
		}
		
		// �ł����̂�҂�
		if( pPlayer[player]->ThinkMove( _current_color, pos, dt ) )
		{
			pBoard->_vLast[player][0] = pos[0];
			pBoard->_vLast[player][1] = pos[1];

			// ���������Ȃ瑊��̏���
			if( IS_RESIGN( pos ) )
			{
				if(Go::PLAYER_BLACK == player)
				{
					sprintf( _msg, "Black Resign. White Win." );
				}else{
					sprintf( _msg, "White Resign. Black Win." );
				}
				_iState = AFTER_PLAY;
				_time = 0;
				break;
			}
			
			if( IS_PASS( pBoard->_vLast[player] ))
			{
				/* �����Ƃ��Ƀp�X�Ȃ�n�𐔂��ď��҂�\�� */
				if( IS_PASS( pBoard->_vLast[1-player]) )
				{
					signed int score = pBoard->CountScore( g_current_setting.common.komi );
					if( score > 0 )
					{
						/* ����������΍��̏��� */
						sprintf( _msg, "Black Win" );
					}else if( score < 0 ){
						sprintf( _msg, "White Win" );
						/* �������Ȃ���Δ��̏��� */
					}else{
						/* �����Ȃ�Έ����� */
						sprintf( _msg, "Draw" );
					}
					pLog->Record( _current_color, pos );// �����ɂ͋L�^���Ƃ�
					_iState = AFTER_PLAY;
					_time = 0;
					break;
				}
			}else{
				// �����ԈႢ�Ȃ�Δ��̏���
				if(0!= pBoard->CheckLegal( player, pos[0], pos[1], pBoard->_iBoard ))
				{
					if(Go::PLAYER_BLACK == player)
					{
						sprintf( _msg, "White Win" );
					}else{
						sprintf( _msg, "Black Win" );
					}
					_iState = AFTER_PLAY;
					_time = 0;
					break;
				}
			}
			
			// ���W����Ղɐ΂�u��
			pBoard->SetStone( _current_color, pos[0], pos[1] );
			UpdateDispBoard( );
			UpdateJiaiBoard( );
Ai::EvalJiai( pBoard->_iBoard, pBoard->_iBoardSize - 2 );

			/* �����ɋL�^ */
			pLog->Record( _current_color, pos );

			/* �萔��1������ */
			pBoard->_iMove++;

			// ���ɐi��
			if( Go::PLAYER_BLACK == player )
			{
				_current_color = Go::WHITE;
				player = Go::PLAYER_WHITE;
			}else{
				_current_color = Go::BLACK;
				player = Go::PLAYER_BLACK;
			}
		}
		break;
	case AFTER_PLAY:
		_current_color = Go::INVALID_COLOR;
		if( 0.5 < _time )
		{
			if( Te::GetMouseInfo()->trg & Te::MOUSE_L )
			{
//				pLog->SaveSgf("hikago.sgf");
				return TASK_ID_CREDIT;
			}
		}
		break;
	}

	FrameMoveDispBoard(dt);

	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskPlay::Render()
{
	Te::BeginRender();

	// ��ʂ̃N���A
	Te::Clear();

	// �r���[�s��̐ݒ�
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
//	gluLookAt(	0.0, 80.0, 0.0,		// ���_
//				0.0, 0.0, 0.0,		// ���ړ_
//				0.0, 0.0, 1.0);		// �����
	gluLookAt(	0.0, 70.0, 30.0,		// ���_
				0.0, 0.0, 0.0,		// ���ړ_
				0.0, 1.0, 0.0);		// �����

	// -----------------------------------------------------------------------
	// ���`��
	// -----------------------------------------------------------------------
	const float bw = 42.0;
	const float bh = 42.0;
	const float bd = 27.0;
	glPushMatrix();					// �r���[�s�񂪑��̃|���S���ł��g����悤�ޔ�
	static const GLdouble vertex[][3] = {
		{ -0.5*bw, -bd, -0.5*bh },
		{  0.5*bw, -bd, -0.5*bh },
		{  0.5*bw,   0, -0.5*bh },
		{ -0.5*bw,   0, -0.5*bh },
		{ -0.5*bw, -bd,  0.5*bh },
		{  0.5*bw, -bd,  0.5*bh },
		{  0.5*bw,   0,  0.5*bh },
		{ -0.5*bw,   0,  0.5*bh }
	};
	static const GLdouble tex_coord[][2] = {
		{ 0.0, 0.0 },
		{ 1.0, 0.0 },
		{ 1.0, 0.0 },
		{ 0.0, 0.0 },
		{ 0.0, 1.0 },
		{ 1.0, 1.0 },
		{ 1.0, 1.0 },
		{ 0.0, 1.0 },
	};

	static const int edge[] = {
		0,1,3,2,7,6,4,5,0,1, 1,
		4,0,7,3, 3,
		1,5,2,6,-1
	};
	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, tex_id );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glEnable(GL_TEXTURE_2D);

	glBegin(GL_TRIANGLE_STRIP);		// �X�g���b�v�ݒ�
	for (int i = 0; 0 <= edge[i]; i++ )
	{
		glTexCoord2dv(tex_coord[edge[i]]);
		glVertex3dv(vertex[edge[i]]);
	}
	glEnd();						// �|���S���̕`��I��
	glDisable(GL_TEXTURE_2D);

	// ��������
	float lw = bw / 1.07f;// ���̈������傫��
	float lh = bh / 1.07f;
	int moku = pBoard->_iBoardSize-2;
	float inv_moku = 1.0/(float)(moku-1);
#if 0
	float half_lw = 0.5f * lw;
	float half_lh = 0.5f * lh;
	float dw = 0.003f * lw; // ���C���̑���
	float dh = 0.003f * lh;

	glColor3d( 0, 0, 0 ); // ��
	// ����
	for( int i = 1; i <= moku; i++ )
	{
		float h = (i-1) * lh * inv_moku - 0.5f * lh;
		glBegin(GL_TRIANGLE_STRIP);
		glVertex3d( -half_lw-dw, 0.001, h+dh );
		glVertex3d( +half_lw+dw, 0.001, h+dh );
		glVertex3d( -half_lw-dw, 0.001, h-dh );
		glVertex3d( +half_lw+dw, 0.001, h-dh );
		glEnd();
	}
	// �c��
	for( int i = 1; i <= moku; i++ )
	{
		float w = (i-1) * lw * inv_moku - 0.5f * lw;
		glBegin(GL_TRIANGLE_STRIP);
		glVertex3d( w+dw, 0.001, -half_lh-dh );
		glVertex3d( w+dw, 0.001, +half_lh+dh );
		glVertex3d( w-dw, 0.001, -half_lh-dh );
		glVertex3d( w-dw, 0.001, +half_lh+dh );
		glEnd();
	}
#endif
	glPopMatrix();					// �r���[�s��Ɍ��݂̍s���߂�
	
	current_index[0] = ((current_pos[0] + 0.5f * lw) / (lw*inv_moku) + 1.5);
	current_index[1] = ((current_pos[1] + 0.5f * lh) / (lh*inv_moku) + 1.5);
	if( current_index[0] <= 0 ) current_index[0] = 0;
	if( current_index[1] <= 0 ) current_index[1] = 0;
	if( pBoard->_iBoardSize-1 <= current_index[0] ) current_index[0] = pBoard->_iBoardSize-1;
	if( pBoard->_iBoardSize-1 <= current_index[1] ) current_index[1] = pBoard->_iBoardSize-1;
	
	// �΂̕\��
	RenderDispBoard( lw * inv_moku, - 0.5f * lw );
	
	// --------------------------------------------------------------------------
	// �n�����̕\��
	// --------------------------------------------------------------------------
	if(_bShowJiai)
	{
		glEnable(GL_BLEND);
		glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

		for( int y = 1; y <= pBoard->_iBoardSize-2; y++ )
		{
			for( int x = 1; x <= pBoard->_iBoardSize-2; x++ )
			{
				signed int color = jiai_board[y][x];
				
				if(0 != disp_board[y][x]) continue;

				if( 0 == color ) continue;

				// �ʒu�̐ݒ�
				float tx = (x-1) * lw * inv_moku - 0.5f * lw;
				float tz = (y-1) * lw * inv_moku - 0.5f * lw;
				float ty = 0.3;
				float s = 0.5*lw * inv_moku;

				// �w�肳�ꂽ�F�ŕ\��
				if( 0 < color )
				{
					float f = 0.2f * (float)color;
					if( 0.8 < f ) f = 0.8;
					glColor4d( 0.0, 0.0, 1.0, f );
				}else{
					float f = -0.2f * (float)color;
					if( 0.8 < f ) f = 0.8;
					glColor4d( 1.0, 0.0, 0.0, f );
				}

				glPushMatrix();
				glTranslatef( tx, ty, tz );
				glBegin(GL_TRIANGLE_STRIP);
				glVertex3d( +s, 0.001, +s );
				glVertex3d( -s, 0.001, +s );
				glVertex3d( +s, 0.001, -s );
				glVertex3d( -s, 0.001, -s );
				glEnd();
				glPopMatrix();
			}
		}
		glDisable(GL_BLEND);

	}
	// --------------------------------------------------------------------------
	// �{�^���̕\��
	// --------------------------------------------------------------------------
	// �ˉe�s���ύX����
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( -1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

	// �r���[�s��̐ݒ�
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); 
	glLoadIdentity();

	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, button_tex_id );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	glEnable(GL_TEXTURE_2D);

	// ����
	{
	float w = 0.2;
	float h = 0.1;
	float x = +1.0-w;
	float y = -1.0;
	glBegin(GL_TRIANGLE_STRIP);
	glTexCoord2d( 0, 0 );
	glVertex3d( x+w, y+h, 0 );
	glTexCoord2d( 1, 0 );
	glVertex3d( x+0, y+h, 0 );
	glTexCoord2d( 0, 0.5-0.5/256.0 );
	glVertex3d( x+w, y+0, 0 );
	glTexCoord2d( 1, 0.5-0.5/256.0 );
	glVertex3d( x+0,  y+0, 0 );
	glEnd();
	}

	// �p�X
	{
	float w = 0.2;
	float h = 0.1;
	float x = -1.0;
	float y = -1.0;
	glBegin(GL_TRIANGLE_STRIP);
	glTexCoord2d( 0, 0.5+0.5/256.0 );
	glVertex3d( x+w, y+h, 0 );
	glTexCoord2d( 1, 0.5+0.5/256.0 );
	glVertex3d( x+0, y+h, 0 );
	glTexCoord2d( 0, 1 );
	glVertex3d( x+w, y+0, 0 );
	glTexCoord2d( 1, 1 );
	glVertex3d( x+0, y+0, 0 );
	glEnd();
	}

	glDisable(GL_TEXTURE_2D);
	
	// �s������ɖ߂�
	glPopMatrix(); 
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	// --------------------------------------------------------------------------
	// ���b�Z�[�W
	// --------------------------------------------------------------------------
	Te::rect sr, mr;
	char buf[256];
	Te::GetScreenRect( &sr );
	g_pFont->SetSize( 32, 24 );
	g_pFont->SetColor( 1, 1, 1 );
	
	// �������b�Z�[�W
	g_pFont->GetSize( &mr, _msg );
	g_pFont->TextOut( _msg , (sr.right - mr.right)/ 2 , 8 );

	// ��,��
	g_pFont->TextOut( "BLACK",    4 , 4 );

	g_pFont->GetSize( &mr, "WHITE" );
	g_pFont->TextOut( "WHITE", sr.right - mr.right - 4 , 4 );

	// �A�Q�n�}
	g_pFont->SetColor( 1, 1, 1 );
	g_pFont->SetSize( 24, 24 );
	sprintf( buf, "�A�Q�n�} %d", pBoard->_nPrisoner[Go::PLAYER_BLACK] );
	g_pFont->TextOut( buf, 4 , 30 );
	sprintf( buf, "�A�Q�n�} %d", pBoard->_nPrisoner[Go::PLAYER_WHITE] );
	g_pFont->GetSize( &mr, buf );
	g_pFont->TextOut( buf, sr.right - mr.right - 4 , 30 );



	Te::EndRender();
}

}// namespace Application
