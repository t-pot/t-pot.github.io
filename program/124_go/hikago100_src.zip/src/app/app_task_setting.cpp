// ----------------------------------------------------------------------------
//
// app_task_setting.cpp - ���ڐݒ�
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <GL/glut.h>
#include "../main.h"
#include "te.h"
#include "ai/ai_npc.h"
#include "app_task_tbl.h"
#include "app_task_setting.h"
#include "file_tbl.h"

// ===========================================================================
// �ϐ�
// ===========================================================================
extern Te::CFontJ *g_pFont;
extern Te::CMenu  *g_pMenu;
extern Te::CMenu  *g_pBtn;
static void *pTeb = 0;

namespace Application
{
extern Go::SETTING_DATA g_current_setting;

static const char *pMsg  = "�΋ǐݒ�";
static int msg_x;
static int msg_y;

static const char *msg[] = 
{
	"�΋ǐݒ�",

	"�H��",
	"�u��",
	"�R�~",

	"�Z�H��",
	"��H��",
	"�\�O�H��",
	"�\��H��",
	
	"�܂�",
//	"�ݐ�",
	"���",
	"��q",
	"�O�q",
	"�l�q",
	"�܎q",
	"�Z�q",
	"���q",
	"���q",
	"��q",

	"�@����",
	"�P�ڔ�",
	"�Q�ڔ�",
	"�R�ڔ�",
	"�S�ڔ�",
	"�T�ڔ�",
	"�U�ڔ�",
	"�V�ڔ�",
	"�W�ڔ�",
	"�X�ڔ�",

	"�΋ǊJ�n",
	"�߂�",
};

#define MSG_SETTING_TITLE         0
#define MSG_SETTING_TITLE_ROBAN   1
#define MSG_SETTING_TITLE_HANDI   2
#define MSG_SETTING_TITLE_KOMI    3
#define MSG_SETTING_TITLE_ROBAN0  4
#define MSG_SETTING_TITLE_ROBAN1  5
#define MSG_SETTING_TITLE_ROBAN2  6
#define MSG_SETTING_TITLE_ROBAN3  7
#define MSG_SETTING_TITLE_HANDI0  8
#define MSG_SETTING_TITLE_HANDI1  9
#define MSG_SETTING_TITLE_HANDI2 10
#define MSG_SETTING_TITLE_HANDI3 11
#define MSG_SETTING_TITLE_HANDI4 12
#define MSG_SETTING_TITLE_HANDI5 13
#define MSG_SETTING_TITLE_HANDI6 14
#define MSG_SETTING_TITLE_HANDI7 15
#define MSG_SETTING_TITLE_HANDI8 16
#define MSG_SETTING_TITLE_HANDI9 17
#define MSG_SETTING_TITLE_KOMI0  18
#define MSG_SETTING_TITLE_KOMI1  19
#define MSG_SETTING_TITLE_KOMI2  20
#define MSG_SETTING_TITLE_KOMI3  21
#define MSG_SETTING_TITLE_KOMI4  22
#define MSG_SETTING_TITLE_KOMI5  23
#define MSG_SETTING_TITLE_KOMI6  24
#define MSG_SETTING_TITLE_KOMI7  25
#define MSG_SETTING_TITLE_KOMI8  26
#define MSG_SETTING_TITLE_KOMI9  27
#define MSG_SETTING_TITLE_START  28
#define MSG_SETTING_TITLE_BACK   29

typedef struct MSG_PLACEMENT
{
	unsigned int id;
	float        size;
	float        x;
	float        y;
} *PMSG_PLACEMENT;

MSG_PLACEMENT msg_tbl[] = {
	//    id                     size   x     y
	{ MSG_SETTING_TITLE        , 0.07, 0.36, 0.09},
	{ MSG_SETTING_TITLE_ROBAN  , 0.05, 0.10, 0.20},
	{ MSG_SETTING_TITLE_HANDI  , 0.05, 0.10, 0.30},
	{ MSG_SETTING_TITLE_KOMI   , 0.05, 0.10, 0.50},
	{ MSG_SETTING_TITLE_ROBAN0 , 0.04, 0.25, 0.21},
	{ MSG_SETTING_TITLE_ROBAN1 , 0.04, 0.40, 0.21},
	{ MSG_SETTING_TITLE_ROBAN2 , 0.04, 0.55, 0.21},
	{ MSG_SETTING_TITLE_ROBAN3 , 0.04, 0.75, 0.21},
	{ MSG_SETTING_TITLE_HANDI0 , 0.05, 0.25, 0.30},
	{ MSG_SETTING_TITLE_HANDI1 , 0.05, 0.38, 0.30},
	{ MSG_SETTING_TITLE_HANDI2 , 0.05, 0.51, 0.30},
	{ MSG_SETTING_TITLE_HANDI3 , 0.05, 0.64, 0.30},
	{ MSG_SETTING_TITLE_HANDI4 , 0.05, 0.77, 0.30},
	{ MSG_SETTING_TITLE_HANDI5 , 0.05, 0.25, 0.40},
	{ MSG_SETTING_TITLE_HANDI6 , 0.05, 0.38, 0.40},
	{ MSG_SETTING_TITLE_HANDI7 , 0.05, 0.51, 0.40},
	{ MSG_SETTING_TITLE_HANDI8 , 0.05, 0.64, 0.40},
	{ MSG_SETTING_TITLE_HANDI9 , 0.05, 0.77, 0.40},
	{ MSG_SETTING_TITLE_KOMI0  , 0.04, 0.25, 0.51},
	{ MSG_SETTING_TITLE_KOMI1  , 0.04, 0.39, 0.51},
	{ MSG_SETTING_TITLE_KOMI2  , 0.04, 0.53, 0.51},
	{ MSG_SETTING_TITLE_KOMI3  , 0.04, 0.67, 0.51},
	{ MSG_SETTING_TITLE_KOMI4  , 0.04, 0.81, 0.51},
	{ MSG_SETTING_TITLE_KOMI5  , 0.04, 0.25, 0.61},
	{ MSG_SETTING_TITLE_KOMI6  , 0.04, 0.39, 0.61},
	{ MSG_SETTING_TITLE_KOMI7  , 0.04, 0.53, 0.61},
	{ MSG_SETTING_TITLE_KOMI8  , 0.04, 0.67, 0.61},
	{ MSG_SETTING_TITLE_KOMI9  , 0.04, 0.81, 0.61},
	{ MSG_SETTING_TITLE_START  , 0.06, 0.25, 0.85},
	{ MSG_SETTING_TITLE_BACK   , 0.06, 0.60, 0.85},
	{~0},
};

#define BTN_SETTING_TITLE_ROBAN0 0
#define BTN_SETTING_TITLE_ROBAN1 1
#define BTN_SETTING_TITLE_ROBAN2 2
#define BTN_SETTING_TITLE_ROBAN3 3
#define BTN_SETTING_TITLE_HANDI0 4
#define BTN_SETTING_TITLE_HANDI1 5
#define BTN_SETTING_TITLE_HANDI2 6
#define BTN_SETTING_TITLE_HANDI3 7
#define BTN_SETTING_TITLE_HANDI4 8
#define BTN_SETTING_TITLE_HANDI5 9
#define BTN_SETTING_TITLE_HANDI6 10
#define BTN_SETTING_TITLE_HANDI7 11
#define BTN_SETTING_TITLE_HANDI8 12
#define BTN_SETTING_TITLE_HANDI9 13
#define BTN_SETTING_TITLE_KOMI0  14
#define BTN_SETTING_TITLE_KOMI1  15
#define BTN_SETTING_TITLE_KOMI2  16
#define BTN_SETTING_TITLE_KOMI3  17
#define BTN_SETTING_TITLE_KOMI4  18
#define BTN_SETTING_TITLE_KOMI5  19
#define BTN_SETTING_TITLE_KOMI6  20
#define BTN_SETTING_TITLE_KOMI7  21
#define BTN_SETTING_TITLE_KOMI8  22
#define BTN_SETTING_TITLE_KOMI9  23
#define BTN_SETTING_TITLE_START  24
#define BTN_SETTING_TITLE_BACK   25

BTN_PLACEMENT btn_tbl[] = {
	//    id                     x     y       w         h
	{ BTN_SETTING_TITLE_ROBAN0 , 0.25, 0.21, 3.0*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_ROBAN1 , 0.40, 0.21, 3.0*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_ROBAN2 , 0.55, 0.21, 4.0*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_ROBAN3 , 0.75, 0.21, 4.0*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_HANDI0 , 0.25, 0.30, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI1 , 0.38, 0.30, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI2 , 0.51, 0.30, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI3 , 0.64, 0.30, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI4 , 0.77, 0.30, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI5 , 0.25, 0.40, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI6 , 0.38, 0.40, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI7 , 0.51, 0.40, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI8 , 0.64, 0.40, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_HANDI9 , 0.77, 0.40, 2.0*0.05, 1.0*0.05},
	{ BTN_SETTING_TITLE_KOMI0  , 0.25, 0.51, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI1  , 0.39, 0.51, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI2  , 0.53, 0.51, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI3  , 0.67, 0.51, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI4  , 0.81, 0.51, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI5  , 0.25, 0.61, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI6  , 0.39, 0.61, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI7  , 0.53, 0.61, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI8  , 0.67, 0.61, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_KOMI9  , 0.81, 0.61, 2.7*0.04, 1.0*0.04},
	{ BTN_SETTING_TITLE_START  , 0.25, 0.85, 4.0*0.06, 1.0*0.06},
	{ BTN_SETTING_TITLE_BACK   , 0.60, 0.85, 2.0*0.06, 1.0*0.06},
	{~0},
};

// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskSetting::CTaskSetting() : CTask()
{
	_time = 0.0f;
	_a = 0;
	_state = 0;
	
#ifdef USE_IMAGE_DATA
	pTeb = Te::File::SetupTeb( IMG_DATA2 );
#endif // USE_IMAGE_DATA

	// �w�i�F�̕ύX
	Te::SetClearColor( Te::fColor( 0.0, 0.0, 0.0, 0.0 ) );

	// �{�^���̏�����
	for( PBTN_PLACEMENT pbtn = &btn_tbl[0]; ~0 != pbtn->id ; pbtn++ )
	{
		pbtn->state = BTN_OFF;
	}

	// �v���C��
	_play_setting.common.roban   = 19;
	_play_setting.common.hadicap = 1;
	_play_setting.common.teban   = 0;
	_play_setting.common.komi    = 13;
	_play_setting.player[0].npc = Ai::NPC_PLAYER;
	_play_setting.player[1].npc = Ai::NPC_AKARI;

	btn_tbl[BTN_SETTING_TITLE_ROBAN3].state = BTN_ON;
	btn_tbl[BTN_SETTING_TITLE_HANDI1].state = BTN_ON;
	btn_tbl[BTN_SETTING_TITLE_KOMI6 ].state = BTN_ON;
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskSetting::~CTaskSetting( )
{
	Te::File::DeleteTeb( pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskSetting::FrameMove( float dt )
{
	// ���b�Z�[�W�̈ʒu�̎Z�o(�Z���^�����O)
	Te::rect sr, mr;
	Te::GetScreenRect( &sr );
	g_pFont->SetSize( 64, 64 );
	g_pFont->GetSize( &mr, pMsg );

	float sw = sr.right -sr.left;
	float sh = sr.bottom-sr.top;
	float mx = (float)Te::GetMouseInfo()->pos[0] / sw;
	float my = (float)Te::GetMouseInfo()->pos[1] / sh;

	msg_x = (sr.right+sr.left - mr.right )/2;
	msg_y = (sr.top+sr.bottom - mr.bottom)*0.1;
	
	switch( _state )
	{
	case 0:
		_time += dt;
		_a = _time / 0.5f;
		if( 0.5f < _time ) {_a = 1.0; _state++;}
		break;
	case 1:// �I��
		_a = 1.0;

		for( PBTN_PLACEMENT pbtn = &btn_tbl[0]; ~0 != pbtn->id ; pbtn++ )
		{
			if( pbtn->x <= mx && mx <= pbtn->x + pbtn->w
			&&  pbtn->y <= my && my <= pbtn->y + pbtn->h )
			{
				// �J�[�\�����{�^���̏�ɂ���
				if( BTN_OFF == pbtn->state )
				{
					pbtn->state = BTN_SELECTED;
				}
				if( BTN_ON != pbtn->state && Te::GetMouseInfo()->trg & Te::MOUSE_L )
				{
					switch(pbtn->id)
					{
					case BTN_SETTING_TITLE_ROBAN0:
						_play_setting.common.roban   = 6;
						btn_tbl[BTN_SETTING_TITLE_ROBAN0].state = BTN_ON;
						btn_tbl[BTN_SETTING_TITLE_ROBAN1].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN2].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN3].state = BTN_OFF;
						break;
					case BTN_SETTING_TITLE_ROBAN1:
						_play_setting.common.roban   = 9;
						btn_tbl[BTN_SETTING_TITLE_ROBAN0].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN1].state = BTN_ON;
						btn_tbl[BTN_SETTING_TITLE_ROBAN2].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN3].state = BTN_OFF;
						break;
					case BTN_SETTING_TITLE_ROBAN2:
						_play_setting.common.roban   = 13;
						btn_tbl[BTN_SETTING_TITLE_ROBAN0].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN1].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN2].state = BTN_ON;
						btn_tbl[BTN_SETTING_TITLE_ROBAN3].state = BTN_OFF;
						break;
					case BTN_SETTING_TITLE_ROBAN3:
						_play_setting.common.roban   = 19;
						btn_tbl[BTN_SETTING_TITLE_ROBAN0].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN1].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN2].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_ROBAN3].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI0:
						_play_setting.common.hadicap = 0;
						_play_setting.common.teban = 0;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI0].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI1:
						_play_setting.common.hadicap = 1;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI1].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI2:
						_play_setting.common.hadicap = 2;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI2].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI3:
						_play_setting.common.hadicap = 3;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI3].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI4:
						_play_setting.common.hadicap = 4;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI4].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI5:
						_play_setting.common.hadicap = 5;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI5].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI6:
						_play_setting.common.hadicap = 6;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI6].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI7:
						_play_setting.common.hadicap = 7;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI7].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI8:
						_play_setting.common.hadicap = 8;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI8].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_HANDI9:
						_play_setting.common.hadicap = 9;
						_play_setting.common.teban = 1;
						for( int i = BTN_SETTING_TITLE_HANDI0; i < BTN_SETTING_TITLE_HANDI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_HANDI9].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI0:
						_play_setting.common.komi = 1;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI0].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI1:
						_play_setting.common.komi = 3;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI1].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI2:
						_play_setting.common.komi = 5;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI2].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI3:
						_play_setting.common.komi = 7;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI3].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI4:
						_play_setting.common.komi = 9;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI4].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI5:
						_play_setting.common.komi = 11;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI5].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI6:
						_play_setting.common.komi = 13;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI6].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI7:
						_play_setting.common.komi = 15;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI7].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI8:
						_play_setting.common.komi = 17;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI8].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_KOMI9:
						_play_setting.common.komi = 19;
						for( int i = BTN_SETTING_TITLE_KOMI0; i < BTN_SETTING_TITLE_KOMI9; i++ )
							btn_tbl[i].state = BTN_OFF;
						btn_tbl[BTN_SETTING_TITLE_KOMI9].state = BTN_ON;
						break;
					case BTN_SETTING_TITLE_START : _state++; break;
					case BTN_SETTING_TITLE_BACK  : _state=-1; break;
					}
				}
			}else{
				// �J�[�\�����{�^���̏�ɂȂ�
				if( BTN_SELECTED == pbtn->state )
				{
					pbtn->state = BTN_OFF;
				}
			}
		}

//		if( Te::GetMouseInfo()->trg & Te::MOUSE_L ) _state++;
		break;
	case 2:// �i��
		_time -= dt;
		_a = _time / 0.5f;

		if( _time < 0 )
		{
			_a = 0;
			g_current_setting = _play_setting;// �Q�[���ݒ�̔��f
			return TASK_ID_PLAY;
		}
		break;
	case -1:// �L�����Z���Ŗ߂�
		_time -= dt;
		_a = _time / 0.5f;

		if( _time < 0 )
		{
			_a = 0;
			return TASK_ID_TITLE;
		}
		break;
	}

	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskSetting::Render()
{
	Te::BeginRender();

	// ��ʂ̃N���A
	Te::Clear();

	// ��ʃT�C�Y�̏���
	Te::rect screen;
	GetScreenRect( &screen );
	float sw = screen.right-screen.left;
	float sh = screen.bottom-screen.top;

	// window
	g_pMenu->SetColor( 1,1,1,_a );
	g_pMenu->SetFrameWidth( 0.05 * sw, 0.05 * sh );
	g_pMenu->SetSize( 0.8*sw, 0.8*sh );
	g_pMenu->SetPos ( 0.1*sw, 0.1*sh );
	g_pMenu->Render();

	// �{�^��
	g_pBtn->SetFrameWidth( 0.01 * sw, 0.01 * sh );
	for( PBTN_PLACEMENT pbtn = &btn_tbl[0]; ~0 != pbtn->id ; pbtn++ )
	{
		if( BTN_OFF == pbtn->state ) continue;// OFF �Ȃ�Ђ傤�����Ȃ�

		switch(pbtn->state)
		{
		case BTN_OFF:      continue;	break;
		case BTN_ON:       g_pBtn->SetColor( 1.0,0.5,0.5,_a);	break;
		case BTN_SELECTED: g_pBtn->SetColor( 1.0,1.0,1.0,_a);	break;
		}

		g_pBtn->SetSize( pbtn->w * sw, pbtn->h * sh );
		g_pBtn->SetPos ( pbtn->x * sw, pbtn->y * sh );
		g_pBtn->Render();
	}
	

	// �e�핶��
	g_pFont->SetColor( 0.2,0.7,1.0,_a);

	for( PMSG_PLACEMENT pmsg = &msg_tbl[0]; ~0 != pmsg->id ; pmsg++ )
	{
		g_pFont->SetSize( pmsg->size * sw, pmsg->size * sh );
		g_pFont->TextOut( msg[pmsg->id], pmsg->x * sw, pmsg->y * sh );
	}



	Te::EndRender();
}

}// namespace Application
