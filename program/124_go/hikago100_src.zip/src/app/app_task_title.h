// ----------------------------------------------------------------------------
//
// app_task_title.h - �^�C�g���^�X�N�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_TITLE_H__
#define __APP_TASK_TITLE_H__

#include "app_task.h"

namespace Application
{
	class CTaskTitle : public CTask
	{
	private:
		float _time;
		float _a;
		int _state;
		unsigned int _tex_id;
	public:
		 CTaskTitle();
		~CTaskTitle();
		
		int  FrameMove( float dt );
		void Render();
		
	};

}// namespace Application


#endif // !__APP_TASK_TITLE_H__
