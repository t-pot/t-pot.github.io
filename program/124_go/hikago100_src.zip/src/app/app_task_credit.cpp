// ----------------------------------------------------------------------------
//
// app_task_credit.cpp - [t-pot PRESENTS]�\���^�X�N
// 
// Copyright (c) 2004 �����t �� (imagire@nify.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <GL/glut.h>
#include "te.h"
#include "app_task_tbl.h"
#include "app_task_credit.h"
#include "file_tbl.h"

namespace Application
{
// ===========================================================================
// �O���[�o���ϐ�
// ===========================================================================
static void *pTeb = 0;


// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskCredit::CTaskCredit() : CTask()
{
	_time = 0.0f;
	_a = 0;
	
#ifdef USE_IMAGE_DATA
	pTeb = Te::File::SetupTeb( IMG_DATA1 );
#endif // USE_IMAGE_DATA
	
	void *pBitmap = Te::File::GetData( FILE_DATA1_T_POT_BMP, pTeb );
	_tex_id = Te::SetupBitmap( pBitmap );
	Te::File::DeleteData( pBitmap, pTeb );

	Te::SetClearColor( Te::fColor( 0.0, 0.0, 0.0, 0.0 ) );// �w�i�F�̕ύX
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskCredit::~CTaskCredit( )
{
	Te::DeleteBitmap( _tex_id );
	Te::File::DeleteTeb( pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskCredit::FrameMove( float dt )
{
	_time += dt;
	
	if( _time < 0.5f )
	{
		_a = _time / 0.5f;
	}else if( 3.0f - 1.0f < _time ){
		_a = (3.0f-_time) / 1.0f;
	}else{
		_a = 1.0f;
	}

	if( 3.0f < _time )
	{
		return TASK_ID_TITLE;
	}
	
	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskCredit::Render()
{
	Te::BeginRender();

	// ��ʂ̃N���A
	Te::Clear();

	// �ˉe�s���ύX����
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( -2.0, 2.0, -1.5, 1.5, -1.0, 1.0);

	// �r���[�s��̐ݒ�
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();


	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, _tex_id );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glEnable(GL_TEXTURE_2D);

	glBegin(GL_TRIANGLE_STRIP);		// �X�g���b�v�ݒ�
	glColor3d( _a*211.0/255.0, _a*173.0/255.0, _a*124.0/255.0);
	
	glTexCoord2d( 1, 1 );
	glVertex3d( -1, -1, 0 );
	glTexCoord2d( 1, 0 );
	glVertex3d( -1,  1, 0 );
	glTexCoord2d( 0, 1 );
	glVertex3d(  1, -1, 0 );
	glTexCoord2d( 0, 0 );
	glVertex3d(  1,  1, 0 );

	glEnd();						// �|���S���̕`��I��

	glDisable(GL_TEXTURE_2D);
	
	// �ˉe�s������ɖ߂�
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	Te::EndRender();
}

}// namespace Application
