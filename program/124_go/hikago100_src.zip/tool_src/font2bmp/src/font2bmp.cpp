// font2bmp.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "font2bmp.h"

// ---------------------------------------------------------------------------
// �萔
// ---------------------------------------------------------------------------
_TCHAR *CMyApplication::m_sVersion = TEXT("1.00");
_TCHAR *CMyApplication::m_sData    = TEXT("2004 Oct. 2");

// ---------------------------------------------------------------------------
// �O���[�o���ϐ�
// ---------------------------------------------------------------------------
CMyApplication *g_pApp = NULL;

// ---------------------------------------------------------------------------
// ���C���֐�
// ---------------------------------------------------------------------------
int _tmain(int argc, _TCHAR* argv[])
{
	g_pApp = new CMyApplication();
	
	if( g_pApp )
	{
		// ������ǂݍ���
		g_pApp->ImportArgument( argc, argv );
		
		// ����\������
		g_pApp->ShowInfo();

		if( g_pApp->IsShowHelp() )
		{
			// �w���v��\������Ȃ炷��
			g_pApp->ShowHelp();
		}else{
			g_pApp->SaveBitMap();
		}

		delete g_pApp;
	}

	return 0;
}




// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CMyApplication::CMyApplication() : m_pOutput( NULL ), m_pFontName( NULL )
, m_pSrcName( NULL ), m_Flag( 0 ), m_bShowHelp( FALSE )
{
}


// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CMyApplication::~CMyApplication()
{
}


// ---------------------------------------------------------------------------
// �����̉��
// ---------------------------------------------------------------------------
void CMyApplication::ImportArgument( int argc, _TCHAR* argv[] )
{
	for( int n = 1; n < argc; n++ )
	{
		if('-'==argv[n][0])
		{
			// �ǂ�ȃI�v�V���������ׂ�
			_TCHAR type = argv[n][1];

			switch(type){
			case 'o':
				if(argc<=++n) break; // ���̃f�[�^�����邩����
				m_pOutput = argv[n];
				break;
			case 't':
				if(argc<=++n) break; // ���̃f�[�^�����邩����
				m_pFontName = argv[n];
				break;
			case 's':
				if(argc<=++n) break; // ���̃f�[�^�����邩����
				m_pSrcName = argv[n];
				break;
			case 'h':
				m_bShowHelp = TRUE;
				break;
			default:
				if( !_tcscmp( argv[n], _T("-ascii") ) )
				{
					m_Flag |= FLAG_OUTPUT_ASCII;
				}
				break;
			}
		}else{
		}
	}
}


// ---------------------------------------------------------------------------
// ����\������
// ---------------------------------------------------------------------------
void CMyApplication::ShowInfo( ) const
{
	_tprintf( _T(
		"\n"
		"  font2bmp : �t�H���g�`�悵���r�b�g�}�b�v���o�͂���\n"
		"\n"
		"            author  : �����t �� (IMAGIRE Takashi)\n"
		"            vestion : %s\n"
		"            date    : %s\n"
		)
		, CMyApplication::m_sVersion
		, CMyApplication::m_sData
		);
}


// ---------------------------------------------------------------------------
// �w���v��\������
// ---------------------------------------------------------------------------
void CMyApplication::ShowHelp( )
{
	_tprintf( _T(
		"\n"
		"  �g���� : font2bmp [-o filename] -t fontname [-ascii] [-h]\n"
		"         -o : �o�̓t�@�C�������w�肷��\n"
		"         -t : �t�H���g�����w�肷��\n"
		"     -ascii : �����R�[�h 0x20�`0x7f �̕�����\������\n"
		"         -h : �w���v��\������\n"
		));
}


// ---------------------------------------------------------------------------
// �C���[�W�̕ۑ�
// ---------------------------------------------------------------------------
void CMyApplication::SaveBitMap( ) const
{
	SAVE_BITMAP sInfo;
	
	sInfo.iBitCount = 32;

	// �A�X�L�[�f�[�^�̏o��
	if( m_Flag & FLAG_OUTPUT_ASCII )
	{
		// �������m��
		sInfo.iWidth    = 16*32;
		sInfo.iHeight   = 16*32;
	}else{
		sInfo.iWidth    = 32*32;
		sInfo.iHeight   = 32*32;
	}

	DWORD size = (sInfo.iBitCount/8) * sInfo.iWidth * sInfo.iHeight;
	sInfo.pData     = new BYTE[size];
	memset( sInfo.pData, 0xff, size );               // RGB �����͔�

	// ������
	memset( sInfo.pData, 0xff, size );               // RGB �����͔�
	for( DWORD x = 0; x < sInfo.iWidth; x ++ )
	{
		for( DWORD y = 0; y < sInfo.iHeight; y++ )
		{
			sInfo.pData[4*(sInfo.iWidth*y+x)+3] = 0; // A������0
		}
	}

	FONT_INFO *info = new FONT_INFO[32*32*8];
	memset( info, 0x0, (32*32*8)*sizeof(FONT_INFO) );
	
	if(m_Flag & FLAG_OUTPUT_ASCII)
	{
		char    str[0x80-0x20+1];

		int pos = 0;
		for( int i = 0x20; i < 0x80; i++ )
		{
			str[pos++] = i;
		}
		str[pos++] = '\0';

		CMyApplication::FillArray( sInfo.pData, str, m_pFontName, true, info );
		
		sInfo.pFileName = m_pOutput;
		CMyApplication::SaveBitMap( sInfo );

		if(m_pSrcName) CMyApplication::SaveSrc( m_pSrcName, info, 16*16, true );
	}else{
		// SJIS �f�[�^�̏o��
		char name[1024];
		char    str[2*32*32+1];
		str[2*32*32] = '\0';

		unsigned int pos = 0x8140;
		
		for( int no = 0; no < 8; no++ )
		{
			// ������
			for( DWORD x = 0; x < sInfo.iWidth; x ++ )
			{
				for( DWORD y = 0; y < sInfo.iHeight; y++ )
				{
					sInfo.pData[4*(sInfo.iWidth*y+x)+3] = 0; // A������0
				}
			}
			
			for( int i = 0; i < 32*32; i++ )
			{
				str[2*i+0] = pos >> 8;
				str[2*i+1] = pos & 0xff;
				pos++;
				if( 0xa000 == pos ) pos = 0xe000;
				if( 0 == (pos & 0xff) ) pos += 0x40;// ���Q���� 0x40�`0xff
			}
			
			CMyApplication::FillArray( sInfo.pData, str, m_pFontName, false, &info[no*32*32] );

			sprintf( name, "%d%s", no, m_pOutput );
			sInfo.pFileName = name;
			CMyApplication::SaveBitMap( sInfo );

			if(m_pSrcName) CMyApplication::SaveSrc( m_pSrcName, info, 8*32*32, false );

		}
	}
	delete[] info;
	delete[] sInfo.pData;
}


// ---------------------------------------------------------------------------
// �C���[�W�̕ۑ�
// ---------------------------------------------------------------------------
void CMyApplication::FillArray( BYTE *pDest, const _TCHAR *pStr, _TCHAR *pFontName, bool ascii, FONT_INFO *pInfo )
{
	const static MAT2 mat = {{0,1}, {0,0}, {0,0}, {0,1}}; // �s��

	DWORD w = 0;
	DWORD h = 0;

	// HDC �̏���
	HDC hdc = GetDC(HWND_DESKTOP);
	
	// �t�H���g�̍쐬
    LOGFONT lf;
	if(ascii)
	{
		lf.lfWidth          = 128-1;
	}else{
		lf.lfWidth          = 64-1;
	}
	lf.lfHeight         = 64-1;
	lf.lfEscapement     = 0;
	lf.lfOrientation    = 0;
	lf.lfWeight         = FW_DONTCARE;
	lf.lfItalic         = 0;
	lf.lfUnderline      = 0;
	lf.lfStrikeOut      = 0;
	lf.lfCharSet        = SHIFTJIS_CHARSET;
	lf.lfOutPrecision   = OUT_DEFAULT_PRECIS;
	lf.lfClipPrecision  = CLIP_DEFAULT_PRECIS;
	lf.lfQuality        = ANTIALIASED_QUALITY;
	lf.lfPitchAndFamily = DEFAULT_PITCH;
	_tcscpy( lf.lfFaceName, pFontName );
    HFONT font = CreateFontIndirect( &lf );
    HFONT hOldFont = (HFONT)SelectObject( hdc, font );

	// �t�H���g�̊􉽂�����
	unsigned int no = 0;
	for( const _TCHAR *p = pStr; *p; p++ )
	{
		GLYPHMETRICS gm;
		TEXTMETRIC  tm;
		UINT uChar = *p;
		
		// �����΍�
		if( 0x80 <= uChar )
		{
			uChar = (((unsigned char*)p)[0] << 8)
								+ ((unsigned char*)p)[1];
			p++;
		}

		// �����̃o�b�t�@�T�C�Y�̏���
		DWORD    size = GetGlyphOutline( hdc, uChar, GGO_GRAY8_BITMAP, &gm, 0, NULL, &mat ); 
		LPBYTE   pData = NULL;
		
		// �����̐���
		if( 0 < size )
		{
			pData = (LPBYTE)GlobalAlloc(GPTR, size);
			GetGlyphOutline( hdc, uChar, GGO_GRAY8_BITMAP, &gm, size, pData, &mat ); 
			GetTextMetrics( hdc, &tm );
		}else{
			pData = 0;
			gm.gmBlackBoxX = gm.gmBlackBoxY = 0; 
			tm.tmAscent = 0;
		}
		
		// �􉽏��̐���
		if(NULL!=pInfo)
		{
			signed int x =  gm.gmptGlyphOrigin.x;
			signed int y = tm.tmAscent - gm.gmptGlyphOrigin.y;
			signed int w = gm.gmBlackBoxX;
			signed int h = gm.gmBlackBoxY;
			signed int u = gm.gmCellIncX;
			signed int v = gm.gmCellIncY;
			if( x < -128 )
			{
				x = -128;
			}
			if( +127 < x )
			{
				x = +127;
			}
			if( y < -128 )
			{
				y = -128;
			}
			if( +127 < y )
			{
				y = +127;
			}
			if( w < -128 )
			{
				w = -128;
			}
			if( +127 < w )
			{
				w = +127;
			}
			if( h < -128 )
			{
				h = -128;
			}
			if( +127 < h )
			{
				h = +127;
			}
			if( u < -128 )
			{
				u = -128;
			}
			if( +127 < u )
			{
				u = +127;
			}
			if( v < -128 )
			{
				v = -128;
			}
			if( +127 < v )
			{
				v = +127;
			}
			pInfo[no].x = x;
			pInfo[no].y = y;
			pInfo[no].w = w;
			pInfo[no].h = h;
			pInfo[no].u = u;
			pInfo[no].v = v;

		}
		no++;

		for( DWORD x = 0; x < 32; x++ )
		{
			for( DWORD y = 0; y < 32; y++ )
			{
				LONG dx;
				LONG dy;
//				if(ascii)
//				{
//					dx = 2*x - gm.gmptGlyphOrigin.x; 
//					dy = 2*y - (tm.tmAscent - gm.gmptGlyphOrigin.y);
//				}else{
					dx = 4*x;
					dy = 2*y;
//				}
				DWORD isx = ( gm.gmBlackBoxX + 3 ) & 0xfffc;

				// GetGlyphOutline �̒l��0�`128�Ȃ̂ŁA���ӂS�̃e�N�Z���̕��ς����
				BYTE val = 0;
				DWORD dv = 0;
				for( DWORD sy = 0; sy < 2; sy++ )
				{
					for( DWORD sx = 0; sx < 4; sx++ )
					{
						if( 0<= dx+sx && (DWORD)dx+sx < gm.gmBlackBoxX 
				 		&& 0<= dy+sy && (DWORD)dy+sy < gm.gmBlackBoxY )
						{
							dv += pData[ (dy+sy) * isx + dx+sx ];
						}
					}
				}
				dv/=2;
				// �I�[�o�[�t���[�̐��������ďo��
				if( 0xff < dv ) dv = 0xff;
				val = dv;

				// 0�̘g������
				if( x==32-1 || y == 32-1 ) val = 0;

				DWORD tx = 32 * w + x;
				DWORD ty = 32 * h + y;
				DWORD texel;
				if(ascii)
				{
					texel = 32*16*(32*16-1 - ty) + tx;
				}else{
					texel = 32*32*(32*32-1 - ty) + tx;
				}
				pDest[4*(texel)+0] = 
				pDest[4*(texel)+1] = 
				pDest[4*(texel)+2] = 0xff;

				pDest[4*(texel)+3] = val;
			}
		}
		
		// �o�b�t�@���J��
		if( pData ) GlobalFree( pData );

		// ���̈ʒu���v�Z����
		++w;
		if((ascii && 16<=w) || (!ascii && 32<=w))
		{
			h++;
			w = 0;
		}
	}
	SelectObject( hdc, hOldFont );
	DeleteObject( font );

	ReleaseDC( HWND_DESKTOP, hdc );
}


// ---------------------------------------------------------------------------
// �C���[�W�̕ۑ�
// ---------------------------------------------------------------------------
void CMyApplication::SaveBitMap( SAVE_BITMAP &sInfo )
{
	BITMAPFILEHEADER  bmfh;
	BITMAPINFOHEADER  bmih;
    DWORD tmp;

	// BITMAPINFOHEADER �̐���
	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth  = sInfo.iWidth;
	bmih.biHeight = sInfo.iHeight;
	bmih.biPlanes = 1;
	bmih.biBitCount = sInfo.iBitCount;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = bmih.biWidth * bmih.biHeight * (bmih.biBitCount / 8);
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	// BITMAPFILEHEADER �̐���
	bmfh.bfType = 0x4D42; // 'BM'
	bmfh.bfReserved1 = bmfh.bfReserved2 = 0;
	bmfh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);// �f�[�^�̃I�t�Z�b�g
	bmfh.bfSize = bmfh.bfOffBits + bmih.biSizeImage;// �T�C�Y

	// �t�@�C���̐���
	HANDLE hfile;
	hfile = CreateFile( sInfo.pFileName, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, 0, NULL);
	
	// BITMAPFILEHEADER �̏�������
    WriteFile(hfile, &bmfh, sizeof(bmfh), &tmp, NULL);
	// BITMAPINFOHEADER �̏�������
    WriteFile(hfile, &bmih, sizeof(bmih), &tmp, NULL);
	// �f�[�^�̏�������
    SetFilePointer( hfile, bmfh.bfOffBits, NULL, FILE_BEGIN ); // �������݈ʒu�̈ړ�
    GdiFlush();
    WriteFile( hfile, sInfo.pData, bmih.biSizeImage, &tmp, NULL );
    
	// ����
	CloseHandle(hfile);
}


// ---------------------------------------------------------------------------
// �\�[�X�t�@�C���̏o��
// ---------------------------------------------------------------------------
void CMyApplication::SaveSrc( _TCHAR *filename, FONT_INFO *pInfo, unsigned int num, bool ascii )
{
	FILE *fp;

	fp = fopen( filename, "wt" );

	if( NULL == fp ) return;
	
	if(ascii)
	{
		fprintf( fp, "#include \"te.h\"\n\nTe::FONT_INFO font_info[] = {\n");
	}else{
		fprintf( fp, "#include \"te.h\"\n\nTe::FONT_INFO font_info_j[] = {\n");
	}

	for( unsigned int i = 0; i < num; i++ )
	{
		fprintf( fp, "\t{%d,%d,%d,%d,%d,%d},\n", pInfo[i].x, pInfo[i].y, pInfo[i].w, pInfo[i].h, pInfo[i].u, pInfo[i].v);
	}
	fprintf( fp, "};\n");

	fclose(fp);
}
