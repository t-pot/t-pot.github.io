//-------------------------------------------------------------
// File: main.cpp
//
// Desc: �o�R���t�B���^
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

typedef struct {
    FLOAT       p[4];
    FLOAT       tu0, tv0;
    FLOAT       tu1, tv1;
    FLOAT       tu2, tv2;
    FLOAT       tu3, tv3;
    FLOAT       tu4, tv4;
    FLOAT       tu5, tv5;
    FLOAT       tu6, tv6;
    FLOAT       tu7, tv7;
} TVERTEX8;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;



//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pTex						= NULL;

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;

	m_dwCreationWidth           = 5 * (3 * 64 + 6 * 2);
    m_dwCreationHeight          = 5 * (32 + 2 + 2);
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    return S_OK;
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	LPDIRECT3DSURFACE9		pSurf;
	D3DSURFACE_DESC			desc;

	// �e�N�X�`���̓ǂݍ���
	D3DXCreateTextureFromFile(m_pd3dDevice, "src.bmp"
							, &m_pTex);
	m_pTex->GetSurfaceLevel(0,&pSurf);
	pSurf->GetDesc(&desc);
	m_TexWidth  = (FLOAT)desc.Width;
	m_TexHeight = (FLOAT)desc.Height;
    SAFE_RELEASE(pSurf);

	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	D3DXVECTOR4 size = D3DXVECTOR4( (FLOAT)m_TexWidth, (FLOAT)m_TexHeight, 0,0);
	D3DXVECTOR4 d2u  = D3DXVECTOR4( 2.0f/size[0], 0,0,0);
    m_pEffect->SetVector( "vSize", &size );
    m_pEffect->SetVector( "d2u",   &d2u );

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	m_pEffect->OnResetDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mView, mProj;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		// �N���A
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff0080ff, 1.0f, 0L);

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetTexture( 0, m_pTex );
		m_pd3dDevice->SetPixelShader(0);

		for ( int i = 0; i < 3; i++)
		{
			float x = 5 * (i * 64 + (2 * i + 1)*2);
			float y = 5 * (2);
			float w = 5 * 64;
			float h = 5 * 32;

			TVERTEX Vertex[4] = {
				// x      y    z rhw tu tv
				{x + 0, y + 0, 0, 1, 0, 0,},
				{x + w, y + 0, 0, 1, 1, 0,},
				{x + w, y + h, 0, 1, 1, 1,},
				{x + 0, y + h, 0, 1, 0, 1,},
			};
			
			float du = 1.0f/m_TexWidth;
			float dv = 1.0f/m_TexHeight;
			TVERTEX8 Vertex8[4] = {
				// x      y    z rhw  uv0
				{x + 0, y + 0, 0, 1, 0-1.5f*du, 0-1.5f*dv,  0-1.5f*du, 0-0.5f*dv,  0-1.5f*du, 0+0.5f*dv,  0-1.5f*du, 0+1.5f*dv
									,0-0.5f*du, 0-1.5f*dv,  0-0.5f*du, 0-0.5f*dv,  0-0.5f*du, 0+0.5f*dv,  0-0.5f*du, 0+1.5f*dv},
				{x + w, y + 0, 0, 1, 1-1.5f*du, 0-1.5f*dv,  1-1.5f*du, 0-0.5f*dv,  1-1.5f*du, 0+0.5f*dv,  1-1.5f*du, 0+1.5f*dv
									,1-0.5f*du, 0-1.5f*dv,  1-0.5f*du, 0-0.5f*dv,  1-0.5f*du, 0+0.5f*dv,  1-0.5f*du, 0+1.5f*dv},
				{x + w, y + h, 0, 1, 1-1.5f*du, 1-1.5f*dv,  1-1.5f*du, 1-0.5f*dv,  1-1.5f*du, 1+0.5f*dv,  1-1.5f*du, 1+1.5f*dv
									,1-0.5f*du, 1-1.5f*dv,  1-0.5f*du, 1-0.5f*dv,  1-0.5f*du, 1+0.5f*dv,  1-0.5f*du, 1+1.5f*dv},
				{x + 0, y + h, 0, 1, 0-1.5f*du, 1-1.5f*dv,  0-1.5f*du, 1-0.5f*dv,  0-1.5f*du, 1+0.5f*dv,  0-1.5f*du, 1+1.5f*dv
									,0-0.5f*du, 1-1.5f*dv,  0-0.5f*du, 1-0.5f*dv,  0-0.5f*du, 1+0.5f*dv,  0-0.5f*du, 1+1.5f*dv},
			};

			switch(i)
			{
			case 0:// point sampling
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
				m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
				break;
			case 1:// Bi-linear
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
				m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
				break;
			case 2:// Bicubic
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
				m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX8 );
				if( m_pEffect != NULL ) {
					m_pEffect->SetTechnique( m_hTechnique );
					m_pEffect->Begin( NULL, 0 );
					m_pEffect->Pass( 0 );
					m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex8, sizeof( TVERTEX8 ) );
					m_pEffect->End();
				}
				break;
			}

		}

        // �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,128,64);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = 0;
    lstrcpy( szMsg, TEXT("POINT") );
    m_pFont->DrawText( 140, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("BILINEAR") );
    m_pFont->DrawText( 470, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("BICUBLC") );
    m_pFont->DrawText( 810, fNextLine, fontColor, szMsg );
	
	return S_OK;
}



//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pTex );

    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	
    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




