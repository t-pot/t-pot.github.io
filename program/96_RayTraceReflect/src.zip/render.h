
#include <d3d9.h>
#include <d3dx9.h>


#ifndef _RENDER_H_
#define _RENDER_H_

namespace Render {

#if 0
	enum{
		RENDER_WIDTH  = 64,
		RENDER_HEIGHT = 64,
	};
#else
#if 1
	enum{
		RENDER_WIDTH  = 256,
		RENDER_HEIGHT = 256,
	};
#else
	enum{
		RENDER_WIDTH  = 512,
		RENDER_HEIGHT = 512,
	};
#endif

#endif

void Init();
void Delete();
void Begin();
int  Render();
char *GetDataPointer();

};// namespace Render

#endif // !_RENDER_H_