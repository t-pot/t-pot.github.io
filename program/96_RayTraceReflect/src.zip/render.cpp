#include "stdafx.h"
#include "math.h"
#include "prim.h"
#include "render.h"

namespace Render {

D3DXVECTOR3 BG_COLOR = D3DXVECTOR3(0.25f, 0.4f, 0.5f);

class CCamera
{
private:
	D3DXMATRIX  m_mView;
	D3DXMATRIX  m_mProj;
	D3DXMATRIX  m_mVP;
	D3DXMATRIX  m_mVP_Inv;

	D3DXVECTOR3 m_vFrom;
	D3DXVECTOR3 m_vLookat;
	D3DXVECTOR3 m_vUp;

	float	m_fFovy;
	float	m_fAspect;
	float   m_fNear;
	float   m_fFar;

public:

	void Update();
	void SetFrom  (const D3DXVECTOR3 *p){m_vFrom  =*p;}
	void SetLookAt(const D3DXVECTOR3 *p){m_vLookat=*p;}
	void SetUp    (const D3DXVECTOR3 *p){m_vUp    =*p;}
	void SetFovY  (float val){m_fFovy   = val;}
	void SetAspect(float val){m_fAspect = val;}
	void SetNear  (float val){m_fNear   = val;}
	void SetFar   (float val){m_fFar    = val;}

	inline const D3DXMATRIX *GetViewProjInverse() const {return &m_mVP_Inv;}
	inline D3DXVECTOR3 *GetFrom( D3DXVECTOR3 *dest){*dest = m_vFrom;return dest;}
};

// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
char s_data[4*RENDER_WIDTH*RENDER_HEIGHT];// ���z�t���[���o�b�t�@
CCamera camera;

CMesh *pRoom       = NULL;
CMesh *pBlockSmall = NULL;
CMesh *pBlockTall  = NULL;
CMesh *pShpereS    = NULL;
CMesh *pShpereT    = NULL;

static int s_x = 0;
static int s_y = 0;
static int s_state = 0;
enum{
	STATE_IDLE=0,
	STATE_RENDER,
};

// ---------------------------------------------------------------------------
// ��
OBJ_DATA sphere_data[] = {
{// �������̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.01f, 0.05f, 0.02f },
		{0.01f, 0.05f, 0.02f },
		{0.10f, 0.10f, 0.10f },
		16.0f,
		0.2f, 0.8f, 0.0f,
	},{{0,0,0},{0,0,0},{0,0,0}},{
		{185.5, 165+100,169},
		100.0f,
	}
},{// �傫���̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.00f, 0.00f, 0.00f},
		{0.00f, 0.00f, 0.00f},
		{0.10f, 0.10f, 0.10f },
		64.0f,
		0.90f, 0.00f, 0.10f,
	},{{0,0,0},{0,0,0},{0,0,0}},{
		{368.5, 330+100,351},
		100.0f,
	}
}};
// ---------------------------------------------------------------------------
// ����
OBJ_DATA room_data[12] = {
{// ���C�g�P
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f, 100.0f, 100.0f},
		{  0.0f,   0.0f,   0.0f},
		{  0.0f,   0.0f,   0.0f},
		0.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{213.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 227.0},
	}
},{// ���C�g�Q
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f, 100.0f, 100.0f},
		{  0.0f,   0.0f,   0.0f},
		{  0.0f,   0.0f,   0.0f},
		0.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{343.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 332.0},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.01f, 0.01f},
		{0.05f, 0.01f, 0.01f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{552.8f,   0.0f,   0.0f},
		{556.0f, 548.8f,   0.0f},
		{549.6f,   0.0f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.01f, 0.01f},
		{0.05f, 0.01f, 0.01f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f,   0.0f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �E�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.01f, 0.01f, 0.05f},
		{0.01f, 0.01f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{0.0f,   0.0f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f,   0.0f},
	}

},{// �E�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.01f, 0.01f, 0.05f},
		{0.01f, 0.01f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{0.0f, 548.8f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f, 559.2f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f,   0.0f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{  0.0f, 548.8f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �V��P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f, 548.8f,   0.0f},
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// �V��Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f, 0.0f,   0.0f},
		{552.8f, 0.0f,   0.0f},
		{  0.0f, 0.0f, 559.2f},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{  0.0f, 0.0f, 559.2f},
		{552.8f, 0.0f,   0.0f},
		{549.6f, 0.0f, 559.2f},
	}
}};

// ---------------------------------------------------------------------------
// �Ⴂ��
OBJ_DATA Short_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{ 82.0f, 165.0f, 225.0f},
		{130.0f, 165.0f,  65.0f},
		{240.0f, 165.0f, 272.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{290.0, 165.0, 114.0},
		{240.0, 165.0, 272.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{290.0, 165.0, 114.0},
		{290.0,   0.0, 114.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{240.0, 165.0, 272.0},
		{290.0,   0.0, 114.0},
		{240.0,   0.0, 272.0},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{290.0,   0.0, 114.0},
		{290.0, 165.0, 114.0},
		{130.0,   0.0,  65.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{130.0,   0.0,  65.0},
		{290.0, 165.0, 114.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0, 165.0,  65.0},
		{ 82.0, 165.0, 225.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0,   0.0,  65.0},
		{130.0, 165.0,  65.0},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0, 165.0, 225.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0,   0.0, 225.0},
		{ 82.0, 165.0, 225.0},
	}
}};

// ---------------------------------------------------------------------------
// ������
OBJ_DATA Tall_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{314.0f, 330.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f, 330.0f, 406.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{423.0f,   0.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{423.0f, 330.0f, 247.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{472.0f, 330.0f, 406.0f},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{314.0f, 330.0f, 456.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{314.0f, 330.0f, 456.0f},
		{472.0f, 330.0f, 406.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f,   0.0f, 296.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{265.0f,   0.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
		0.0f, 0.0f, 1.0f,
	},{
		{265.0f, 330.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{423.0f, 330.0f, 247.0f},
	}
}};

// ---------------------------------------------------------------------------
// �֐��錾
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y);


// ---------------------------------------------------------------------------
// �J�����N���X
// ---------------------------------------------------------------------------
void CCamera::Update()
{
    D3DXMatrixLookAtLH( &m_mView, &m_vFrom, &m_vLookat, &m_vUp );
    D3DXMatrixPerspectiveFovLH( &m_mProj, m_fFovy, m_fAspect, m_fNear, m_fFar );
	m_mVP = m_mView * m_mProj;

	D3DXMatrixInverse( &m_mVP_Inv, NULL, &m_mVP);
}
// ---------------------------------------------------------------------------
char *GetDataPointer()
{
	return s_data;
}

// ---------------------------------------------------------------------------
void Init()
{
	camera.SetFrom  (&D3DXVECTOR3(278,273,-800));
	camera.SetLookAt(&D3DXVECTOR3(278,273,0));
	camera.SetUp    (&D3DXVECTOR3(0,1,0));
	camera.SetFovY  (D3DX_PI/4);
	camera.SetAspect(1.0f);
	camera.SetNear  (0.01f);
	camera.SetFar   (100.0f);
	camera.Update();

	pRoom = new CMesh();
	pRoom->Init( room_data, 12 );
	
	pBlockSmall = new CMesh();
	pBlockSmall->Init( Short_block, 10);

	pBlockTall = new CMesh();
	pBlockTall->Init( Tall_block, 10);
	
	pShpereS = new CMesh();
	pShpereS->Init( sphere_data, 1);
	
	pShpereT = new CMesh();
	pShpereT->Init( sphere_data+1,1);

	Begin();// �t���[���o�b�t�@���̏�����
}
// ---------------------------------------------------------------------------
void Delete()
{
	if(pShpereT){delete pShpereT;pShpereT=NULL;}
	if(pShpereS){delete pShpereS;pShpereS=NULL;}
	if(pBlockTall){delete pBlockTall;pBlockTall=NULL;}
	if(pBlockSmall){delete pBlockSmall;pBlockSmall=NULL;}
	if(pRoom){delete pRoom; pRoom=NULL;}
}
// ---------------------------------------------------------------------------
void Begin()
{
	s_state = STATE_RENDER;
	
	s_x = 0;
	s_y = 0;

	// �t���[���o�b�t�@�̏�����
	for(int j=0; j<RENDER_HEIGHT; j++){
	for(int i=0; i<RENDER_WIDTH ; i++){
		s_data[4*(j*RENDER_WIDTH+i)+0]=(char)255;// R
		s_data[4*(j*RENDER_WIDTH+i)+1]=(char)(i*256/RENDER_WIDTH );// G
		s_data[4*(j*RENDER_WIDTH+i)+2]=(char)(j*256/RENDER_HEIGHT);// B
	}
	}
}
// ---------------------------------------------------------------------------
int Render()
{
	if(STATE_IDLE == s_state) return 0;
	
	// (s_x, s_y) �̃s�N�Z���������_�����O
	D3DXVECTOR3 col;
	GetColor(&col, ((float)s_x+0.5f)/(float)RENDER_WIDTH
				 , ((float)s_y+0.5f)/(float)RENDER_HEIGHT);
	s_data[4*(s_y*RENDER_WIDTH+s_x)+0]=(char)(255.9*min(1,col.x));// R
	s_data[4*(s_y*RENDER_WIDTH+s_x)+1]=(char)(255.9*min(1,col.y));// G
	s_data[4*(s_y*RENDER_WIDTH+s_x)+2]=(char)(255.9*min(1,col.z));// B
	
	// ���̃s�N�Z���Ɉړ�
	if(RENDER_WIDTH<=++s_x){
		// �s��ς���
		s_x = 0;
		if(RENDER_HEIGHT<=++s_y){
			s_state = STATE_IDLE;// �I��
			return 0;
		}
	}

	return -1;
}

// ---------------------------------------------------------------------------
bool GetColor(D3DXVECTOR3 *dest, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v, int depth)
{
	// -----------------------------------------------------------------------
	// �ċA���������ꍇ�͌����͂��Ă��Ȃ����̂ƍl����
	// -----------------------------------------------------------------------
	const int DEPTH_MAX = 3;
	if(DEPTH_MAX <= depth) {*dest = D3DXVECTOR3(0,0,0); return FALSE;}

	// -----------------------------------------------------------------------
	// ���������_�����߂�
	// -----------------------------------------------------------------------
	float t = CPrimitive::INFINTY_DIST;
	CPrimitive *pObj = NULL;
	D3DXVECTOR4 p, n;// ��_�̈ʒu�Ɩ@��

	t = pShpereS   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pShpereT   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pRoom      ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pBlockSmall->IsAcross(t, &n, &p, &pObj, x, v);
	t = pBlockTall ->IsAcross(t, &n, &p, &pObj, x, v);

	if( NULL == pObj ){
		// �����̓I�u�W�F�N�g����O�ꂽ�I
		*dest = BG_COLOR;
		return TRUE;
	}

	// -----------------------------------------------------------------------
	// �g�U�����Z�o����
	// -----------------------------------------------------------------------
	float cd = pObj->m_material.diffuse;
	D3DXVECTOR3 diffuse_color;

	if(0.0f<cd){
		D3DXVECTOR4 light_pos = D3DXVECTOR4(278.f, 548.8f, 279.5f,1);
		D3DXVECTOR4 l = light_pos-p;
		float L2 = D3DXVec3Length((D3DXVECTOR3 *)&l);
		D3DXVec3Normalize((D3DXVECTOR3 *)&l, (D3DXVECTOR3 *)&l);

		D3DXVECTOR3 dir, H;
		// �����̌v�Z
		camera.GetFrom(&dir);
		dir = dir - *(D3DXVECTOR3 *)&p;
		D3DXVec3Normalize(&dir, &dir);
		// �n�[�t�x�N�g��
		H = dir+*(D3DXVECTOR3 *)&l;
		D3DXVec3Normalize((D3DXVECTOR3 *)&H, (D3DXVECTOR3 *)&H);

		float LN = D3DXVec3Dot((D3DXVECTOR3 *)&l, (D3DXVECTOR3 *)&n);
		float HN = D3DXVec3Dot((D3DXVECTOR3 *)&H, (D3DXVECTOR3 *)&n);
		if(HN<0) HN=0;
		if(0<LN){
			// ---------------------------------------------------------------
			// ���������Ƃ��납��A�����������邩�𔻒�
			// ---------------------------------------------------------------
			// �����Ȃ���΁A�Â�����
			bool bShadow = FALSE;
			if(!bShadow) bShadow = pShpereS   ->IsAcross(L2, &p, &l);
			if(!bShadow) bShadow = pShpereT   ->IsAcross(L2, &p, &l);
			if(!bShadow) bShadow = pRoom      ->IsAcross(L2, &p, &l);
			if(!bShadow) bShadow = pBlockSmall->IsAcross(L2, &p, &l);
			if(!bShadow) bShadow = pBlockTall ->IsAcross(L2, &p, &l);
			if(bShadow) LN*=0.0f;// difuse�����Ȃ���
		}else{
			LN=0;
		}

		pObj->GetColor(&diffuse_color, LN, HN);
		
		// �����̐F�̔��f
		D3DXVECTOR3 light_color = D3DXVECTOR3(10.f,9.0f,5.0f);
		diffuse_color.x *= light_color.x;
		diffuse_color.y *= light_color.y;
		diffuse_color.z *= light_color.z;
		
		// ���̋����̓K���ȕ␳
		diffuse_color *= min(1.5f, 500000.0f/(10000.0f+L2)); // �����ɂ��␳
		diffuse_color *= min(1, l.y+0.1f);					// ���̌�����cos�Ƃ̊֐��ɂ���	
	}else{
		diffuse_color = D3DXVECTOR3(0,0,0);
	}

	// -----------------------------------------------------------------------
	// �ċA�I�Ɍ������΂��āA��荂���̔��˂��l���ɓ����
	// -----------------------------------------------------------------------
	// ����
	float cr = pObj->m_material.reflection;
	D3DXVECTOR3 reflect_color;
	if(0.0f<cr){
		// ���˃x�N�g��
		D3DXVECTOR4 r = *v - 2.0f*D3DXVec3Dot((D3DXVECTOR3 *)&n, (D3DXVECTOR3 *)v) * n;
		D3DXVECTOR4 pos = p + 0.01f*n;// ������ƕ�����
		if(!GetColor( &reflect_color, &pos, &r, depth+1)){
			cr = 0;
		}
	}else{
		reflect_color=D3DXVECTOR3(0,0,0);
	}

	// ����
	float cn = pObj->m_material.refraction;
	D3DXVECTOR3 refract_color=D3DXVECTOR3(0,0,0);
	if(0.0f<cn){
		// ���܃x�N�g��
		D3DXVECTOR4 t, pos;
		float VN = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&n);
		float eta = 1.5f;
		if(VN<0){
			// ����
			float D = 1-(1+VN)*(1+VN)/(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = (-VN/eta-sqrtf(D))*n+(1/eta)*(*v);
			pos = p - 0.01f*n;// ������ƕ�����
		}else{
			// �o�čs��
			float D = 1-(1-VN)*(1-VN)*(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = -(VN*eta-sqrtf(D))*n+eta*(*v);
			pos = p + 0.01f*n;// ������ƕ�����
		}
		D3DXVec3Normalize( (D3DXVECTOR3 *)&t, (D3DXVECTOR3 *)&t );
		if(!GetColor( &refract_color, &pos, &t, depth+1)){
			cn = 0;
		}
	}
no_refract:

	*dest = cd * diffuse_color + cr * reflect_color + cn * refract_color;

	return TRUE;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y)
{
	D3DXVECTOR4 ray_start_proj = D3DXVECTOR4(-2*x+1, -2*y+1, 0, 1);
	D3DXVECTOR4 ray_start_far  = D3DXVECTOR4(-2*x+1, -2*y+1, 1, 1);
	D3DXVECTOR4 ray_start;
	D3DXVECTOR4 ray_to;
	D3DXVECTOR4 ray_dir   = D3DXVECTOR4(0,0,-1,0);
	D3DXMATRIX mInv;
	
	D3DXVec4Transform( &ray_start, &ray_start_proj, camera.GetViewProjInverse() );
	D3DXVec4Transform( &ray_to,    &ray_start_far,  camera.GetViewProjInverse() );
	D3DXVec4Scale( &ray_start, &ray_start, 1.0f/ray_start.w);
	D3DXVec4Scale( &ray_to,    &ray_to,    1.0f/ray_to.w);
	ray_dir = ray_to - ray_start;
	D3DXVec4Normalize(&ray_dir, &ray_dir);
	
	GetColor(dest, &ray_start, &ray_dir, 0);

	return dest;
}

};// namespace Render
