//-------------------------------------------------------------
// File: main.h
//
// Desc: �����[�t�e�N�X�`��
//-------------------------------------------------------------
#pragma once




//-------------------------------------------------------------
// ��`��萔
//-------------------------------------------------------------
// ���݂̓��̓f�[�^��ۑ�����\����
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
};


//-------------------------------------------------------------
// Name: class CWave
// Desc: ���ʃ|���S���̃I�u�W�F�N�g
//-------------------------------------------------------------
class CPlane {
	typedef struct {
		FLOAT		p[3];
		FLOAT		n[3];
		FLOAT       tu, tv;
	}Vertex;
	static const DWORD FVF;
	static D3DVERTEXELEMENT9 CPlane::decl[];

	LPDIRECT3DVERTEXDECLARATION9	m_pDecl;
	LPDIRECT3DVERTEXBUFFER9			m_pVB;
	LPDIRECT3DINDEXBUFFER9			m_pIB;
	DWORD							m_dwNumVertices;
	DWORD							m_dwNumFaces;

public:
	CPlane();
	~CPlane();
	
	HRESULT Create ( LPDIRECT3DDEVICE9 lpD3DDev );
	HRESULT Render ( LPDIRECT3DDEVICE9 lpD3DDev );
	HRESULT DeleteDeviceObjects ();
};


//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: �A�v���P�[�V�����̃N���X
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	CPlane							*m_pPlane;
	LPDIRECT3DTEXTURE9				m_pTexDepth;
	LPDIRECT3DTEXTURE9				m_pTexColor;


	LPDIRECT3DVERTEXDECLARATION9	m_pDecl;	// ���_�錾
	LPD3DXEFFECT					m_pEffect;	// �V�F�[�_
	D3DXHANDLE						m_hmWVP;	// ���[���h�`�ˉe�s��
	D3DXHANDLE						m_hvEye;	// ���_

	D3DXMATRIX						m_mWorld;	// ���[���h�s��
	D3DXMATRIX						m_mView;	// �r���[�s��
	D3DXMATRIX						m_mProj;	// �ˉe�s��
	D3DXVECTOR3						m_Eye;		// ���_

    FLOAT						m_fWorldRotX;	// �w����]
    FLOAT						m_fWorldRotY;	// �x����]

	BOOL						m_bLoadingApp;	// ���[�h���H
    CD3DFont*					m_pFont;		// �t�H���g
    UserInput					m_UserInput;	// ���̓f�[�^
	
protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice(D3DCAPS9*, DWORD, D3DFORMAT);

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
public:
    LRESULT MsgProc( HWND hWnd, UINT msg
					, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};
