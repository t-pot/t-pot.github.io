//-------------------------------------------------------------
// File: main.cpp
//
// Desc: �����[�t�e�N�X�`��
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define frand() (((FLOAT)rand())/((FLOAT)RAND_MAX))

static const UINT MAP_SIZE = 256;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}


const DWORD CPlane::FVF = D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1;
// ���_�錾�̃I�u�W�F�N�g�̐���
D3DVERTEXELEMENT9 CPlane::decl[] =
{
	{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0},
	{0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	D3DDECL_END()
};


//-------------------------------------------------------------
// Name: CPlane()
// Desc: ���ʃ|���S���̃R���X�g���N�^
//-------------------------------------------------------------
CPlane::CPlane()
{
}
//-------------------------------------------------------------
// Name: ~CPlane()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CPlane::~CPlane()
{
}
//-------------------------------------------------------------
// Name: Create()
// Desc: �e��I�u�W�F�N�g�̏�����
//-------------------------------------------------------------
HRESULT CPlane::Create( LPDIRECT3DDEVICE9 lpD3DDev )
{
    HRESULT hr;

	m_dwNumVertices = 4;
	m_dwNumFaces = 2;

	// ���_�o�b�t�@�̐���
	Vertex *pDest;
    if(FAILED(hr=lpD3DDev->CreateVertexBuffer(
			m_dwNumVertices * sizeof(CPlane::Vertex),
			D3DUSAGE_WRITEONLY, CPlane::FVF,
			D3DPOOL_MANAGED, &m_pVB, NULL )))
		 return hr;

	// ���_�̐ݒ�
	Vertex	vertex[] = {
		// x  y  z  nx ny nz tu tv
		{ -1,-1, 0, 0, 0, 1,  0, 1},
		{  1,-1, 0, 0, 0, 1,  1, 1},
		{ -1, 1, 0, 0, 0, 1,  0, 0},
		{  1, 1, 0, 0, 0, 1,  1, 0},
	};
	m_pVB->Lock ( 0, 0, (void**)&pDest, 0 );
	memcpy(pDest, vertex, sizeof(vertex));
	m_pVB->Unlock ();

	// �C���f�b�N�X�o�b�t�@�̐ݒ�
    if(FAILED(hr=lpD3DDev->CreateIndexBuffer(
					3 * m_dwNumFaces * sizeof(WORD),
                    D3DUSAGE_WRITEONLY ,
                    D3DFMT_INDEX16, D3DPOOL_MANAGED,
                    &m_pIB, NULL )))
		 return hr;

	WORD	index[] = {
		2,1,0,
		1,2,3,
	};
	WORD *pIndex;
	m_pIB->Lock ( 0, 0, (void**)&pIndex, 0 );
	memcpy(pIndex, index, sizeof(index));
	m_pIB->Unlock ();

	// ���_�錾
	if( FAILED( hr = lpD3DDev->CreateVertexDeclaration(
										CPlane::decl, &m_pDecl )))
		return hr;

	return S_OK;
}
//-------------------------------------------------------------
// Name: Render()
// Desc: �`��
//-------------------------------------------------------------
HRESULT CPlane::Render( LPDIRECT3DDEVICE9 lpD3DDev )
{
//	lpD3DDev->SetVertexDeclaration( m_pDecl );
lpD3DDev->SetFVF( FVF );
	lpD3DDev->SetStreamSource( 0, m_pVB, 0, sizeof(Vertex) );
	lpD3DDev->SetIndices( m_pIB );
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0,
									0, m_dwNumVertices,
									0, m_dwNumFaces );
	return S_OK;
}
//-------------------------------------------------------------
// Name: Create()
// Desc: �������̊J��
//-------------------------------------------------------------
HRESULT CPlane::DeleteDeviceObjects()
{
    SAFE_RELEASE( m_pDecl );
    SAFE_RELEASE( m_pVB );
    SAFE_RELEASE( m_pIB );

	m_dwNumVertices = 0;
	m_dwNumFaces = 0;

	return S_OK;
}


//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	UINT i;

	m_pPlane					= new CPlane();
	for(i=0;i<6;i++){
		m_pTexDepth[i]				= NULL;
		m_pTexColor[i]				= NULL;
		m_pTexNormal[i]				= NULL;
	}

	m_pDecl						= NULL;
	m_pEffect					= NULL;
	m_hmWVP						= NULL;
	m_hvEye						= NULL;
	m_hvLight					= NULL;

    m_fWorldRotX                =-0.10f*D3DX_PI;
	m_fWorldRotY                = 0.25f*D3DX_PI;
	m_Eye   = D3DXVECTOR3( 0.0f, 0.0f, -4.0f );


	m_dwCreationWidth           = 750;
    m_dwCreationHeight          = 450;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
    
	ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps
						, DWORD dwBehavior, D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
	// �V�F�[�_�̃`�F�b�N
	if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) &&
	  !(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING ) )
		return E_FAIL;	// ���_�V�F�[�_
	
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;	// �s�N�Z���V�F�[�_

	return S_OK;
}


//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	UINT i;

	// �}�b�v�̓ǂݍ���
	const char *depth_map[6] = {
		"depth0.bmp",
		"depth1.bmp",
		"depth2.bmp",
		"depth3.bmp",
		"depth4.bmp",
		"depth5.bmp",
	};
	const char *color_map[6] = {
		"color0.bmp",
		"color1.bmp",
		"color2.bmp",
		"color3.bmp",
		"color4.bmp",
		"color5.bmp",
	};
	const char *normal_map[6] = {
		"normal0.bmp",
		"normal1.bmp",
		"normal2.bmp",
		"normal3.bmp",
		"normal4.bmp",
		"normal5.bmp",
	};
	for( i=0 ; i<6 ; i++ ){
		D3DXCreateTextureFromFileEx(m_pd3dDevice, depth_map[i], 0,0,0,0,D3DFMT_A8R8G8B8,
									D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
									0, NULL, NULL, &m_pTexDepth[i]);
		D3DXCreateTextureFromFileEx(m_pd3dDevice, color_map[i], 0,0,0,0,D3DFMT_A8R8G8B8,
									D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
									0, NULL, NULL, &m_pTexColor[i]);
		D3DXCreateTextureFromFileEx(m_pd3dDevice, normal_map[i], 0,0,0,0,D3DFMT_A8R8G8B8,
									D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
									0, NULL, NULL, &m_pTexNormal[i]);
	}
	// �������|���S���̐���
	m_pPlane->Create( m_pd3dDevice );

	// ���_�錾�̃I�u�W�F�N�g�̐���
	D3DVERTEXELEMENT9 decl[] =
	{
		{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
		{0, 12, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
		D3DDECL_END()
	};
	if( FAILED( hr = m_pd3dDevice->CreateVertexDeclaration(
										decl, &m_pDecl )))
		return DXTRACE_ERR ("CreateVertexDeclaration", hr);

	// �V�F�[�_�̓ǂݍ���
    if( FAILED( hr = D3DXCreateEffectFromFile(
						m_pd3dDevice, "hlsl.fx", NULL, NULL, 
						0, NULL, &m_pEffect, NULL ) ) )
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	m_hmWVP   = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvEye   = m_pEffect->GetParameterByName( NULL, "vEyePos" );
	m_hvLight = m_pEffect->GetParameterByName( NULL, "vLight" );

    m_pFont->InitDeviceObjects( m_pd3dDevice );// �t�H���g
    
	return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	// ��������Z�k�`������Ă݂�
	#define RS   m_pd3dDevice->SetRenderState

    // �����_�����O��Ԃ̐ݒ�
    RS  ( D3DRS_ZENABLE,        TRUE );
    RS  ( D3DRS_LIGHTING,       FALSE );

    // ���[���h�s��
    D3DXMatrixIdentity( &m_mWorld );

    // �r���[�s��
    D3DXVECTOR3 vLookat = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &m_Eye, &vLookat, &vUp );

    // �ˉe�s��̐ݒ�
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width )
				  / ((FLOAT)m_d3dsdBackBuffer.Height);
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect
								, 1.0f, 100.0f );

	
	if( m_pEffect!=NULL ) m_pEffect->OnResetDevice();// �V�F�[�_

    m_pFont->RestoreDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	UpdateInput( &m_UserInput ); // ���̓f�[�^�̍X�V

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;


	//---------------------------------------------------------
	// �s��̍X�V
	//---------------------------------------------------------
 	D3DXMATRIX matRotX, matRotY;
    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );

    return S_OK;
}




//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
}




//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXHANDLE hTechnique;
	D3DXMATRIX m, mL;
	D3DXVECTOR4 v;
	UINT i;

	if( SUCCEEDED( m_pd3dDevice->BeginScene()))	// �`��̊J�n
    {
		// ��ʂ��N���A����
		m_pd3dDevice->Clear( 0L, NULL,
							D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
							0x4004080, 1.0f, 0L );

		if(m_pEffect != NULL)
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
			m_pEffect->SetTechnique( hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );
			m_pd3dDevice->SetVertexDeclaration( m_pDecl );
			for( i=0 ; i<6 ; i++ ){
				//-------------------------------------------------
				// �V�F�[�_�萔�̐ݒ�
				//-------------------------------------------------
				// ���W�ϊ�
				switch(i){
				case 0:
					D3DXMatrixRotationY ( &m,+0.0f*D3DX_PI );
					break;
				case 1:
					D3DXMatrixRotationY ( &m,+1.0f*D3DX_PI );
					break;
				case 2:
					D3DXMatrixRotationY ( &m,+0.5f*D3DX_PI );
					break;
				case 3:
					D3DXMatrixRotationY ( &m,-0.5f*D3DX_PI );
					break;
				case 4:
					D3DXMatrixRotationX ( &m,-0.5f*D3DX_PI );
					break;
				case 5:
					D3DXMatrixRotationX ( &m,+0.5f*D3DX_PI );
					break;
				}
				D3DXMatrixTranslation ( &mL, 0.0f, 0.0f, -1.0 );
				mL = mL * m;
				m = mL * m_mWorld * m_mView * m_mProj;
				m_pEffect->SetMatrix( m_hmWVP, &m );

				// ���_
				m = mL * m_mWorld;
				D3DXMatrixInverse( &m, NULL, &m );
				D3DXVec3Transform( &v, &m_Eye, &m );
				m_pEffect->SetVector( m_hvEye, &v );
				
				// ��������
				v = D3DXVECTOR4(0.7, 0.7, -0.7, 1.0);
				m = m_mWorld;
				D3DXMatrixInverse( &m, NULL, &m );
				D3DXVec4Transform( &v, &v, &m );
				v.w = 0.3f;
				m_pEffect->SetVector( m_hvLight, &v );

				//-------------------------------------------------
				// �`��
				//-------------------------------------------------
				m_pEffect->SetTexture( "Depth",   m_pTexDepth [i] );
				m_pEffect->SetTexture( "Color",   m_pTexColor [i] );
				m_pEffect->SetTexture( "Normal",  m_pTexNormal[i] );
				m_pPlane->Render(m_pd3dDevice);
			}

			m_pEffect->End();
		}

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(0);
	for(DWORD loop = 0; loop < 3; loop++){
		const float scale = 128.0f;
		typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;

		TVERTEX Vertex[4] = {
			//       x        y   z rhw tu tv
			{    0,(loop  )*scale,0, 1, 0, 0,},
			{scale,(loop  )*scale,0, 1, 1, 0,},
			{scale,(loop+1)*scale,0, 1, 1, 1,},
			{    0,(loop+1)*scale,0, 1, 0, 1,},
		};
		switch(loop){
		case 0: m_pd3dDevice->SetTexture( 0, m_pTexDepth [0] ); break;
		case 1: m_pd3dDevice->SetTexture( 0, m_pTexColor [0] ); break;
		case 2: m_pd3dDevice->SetTexture( 0, m_pTexNormal[0] ); break;
		}
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
	}
#endif      

		RenderText();				// �w���v���̕\��

        m_pd3dDevice->EndScene();	// �`��̏I��
    }
	
    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; 

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, TEXT("Use arrow keys to rotate object") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    // �f�B�X�v���C�̏�Ԃ�\������
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd,
					UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct,
						DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    if(m_pEffect!=NULL) m_pEffect->OnLostDevice();	// �V�F�[�_

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	UINT i;

	m_pPlane->DeleteDeviceObjects();
	for( i=0 ; i<6 ; i++ ){
		SAFE_RELEASE( m_pTexNormal[i] );
		SAFE_RELEASE( m_pTexDepth [i] );
		SAFE_RELEASE( m_pTexColor [i] );
	}

	SAFE_RELEASE( m_pEffect );		// �V�F�[�_
	SAFE_RELEASE( m_pDecl );		// ���_�錾

    m_pFont->DeleteDeviceObjects();	// �t�H���g

	return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




