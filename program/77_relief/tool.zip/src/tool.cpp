//-----------------------------------------------------------------------------
// File: tool.cpp
//
// Desc: �����ȃ}�b�v�𐶐�����c�[��
//
// Copyright (c) IMAGIRE Takashi. All rights reserved.
//-----------------------------------------------------------------------------
#define STRICT
#include <Windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <tchar.h>
#include <stdio.h>
#include <d3dx9.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DUtil.h"
#include "resource.h"

#define MAP_SIZE 256

//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
    TCHAR               m_strMeshFilename[512];
    TCHAR               m_strSetDir[512];
    TCHAR               m_strInitialDir[512];


    LPD3DXMESH          m_pMeshSysMem;      // system memory version of mesh, lives through resize's
    LPD3DXMESH          m_pMeshEnhanced;    // vid mem version of mesh that is enhanced
    UINT                m_dwNumSegs;        // number of segments per edge (tesselation level)
    D3DXMATERIAL*       m_pMaterials;       // pointer to material info in m_pbufMaterials
    LPDIRECT3DTEXTURE9* m_ppTextures;       // array of textures, entries are NULL if no texture specified
    DWORD               m_dwNumMaterials;   // number of materials

	// �V�F�[�_
	LPD3DXEFFECT					m_pEffect;	// �V�F�[�_
	D3DXHANDLE						m_hmWVP;	// ���[���h�`�ˉe�s��
	D3DXHANDLE						m_hvCol;	// ���b�V���̐F
	LPDIRECT3DVERTEXDECLARATION9	m_pDecl;	// ���_�錾

	// �����_�����O�^�[�Q�b�g
	LPDIRECT3DSURFACE9				m_pMapZ;		// ���ʂy�o�b�t�@
	LPDIRECT3DTEXTURE9				m_pColorMap;	// �F
	LPDIRECT3DSURFACE9				m_pColorMapSurf;
	LPDIRECT3DTEXTURE9				m_pDepthMap;	// �[�x
	LPDIRECT3DSURFACE9				m_pDepthMapSurf;
	LPDIRECT3DTEXTURE9				m_pNormalMap;	// �@��
	LPDIRECT3DSURFACE9				m_pNormalMapSurf;

	UINT							m_Id;		// �ǂ̕������猩�邩
	D3DXMATRIX						m_mWorld;	// ���[���h�s��
	D3DXMATRIX						m_mView;	// �r���[�s��
	D3DXMATRIX						m_mProj;	// �ˉe�s��

	CD3DFont*           m_pFont;
    CD3DArcBall         m_ArcBall;          // mouse rotation utility
    D3DXVECTOR3         m_vObjectCenter;    // Center of bounding sphere of object
    FLOAT               m_fObjectRadius;    // Radius of bounding sphere of object

    LPD3DXBUFFER        m_pbufMaterials;    // contains both the materials data and the filename strings
    LPD3DXBUFFER        m_pbufAdjacency;    // Contains the adjacency info loaded with the mesh

    HRESULT GenerateEnhancedMesh(UINT cNewNumSegs);

protected:
    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior, 
		D3DFORMAT adapterFormat, D3DFORMAT backBufferFormat );
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();
	HRESULT RenderText();
    HRESULT FrameMove();
    HRESULT FinalCleanup();
    LRESULT MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

public:
    CMyD3DApplication();
};




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;
    return d3dApp.Run();
}




//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor. Sets attributes for the app.
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
    m_strWindowTitle    = _T("Map Creation tool");
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
    m_bShowCursorWhenFullscreen = TRUE;

	m_pEffect					= NULL;
	m_hmWVP						= NULL;
	m_hvCol						= NULL;
	m_pDecl						= NULL;

	m_pMapZ						= NULL;
	m_pColorMap					= NULL;
	m_pColorMapSurf				= NULL;
	m_pDepthMap					= NULL;
	m_pDepthMapSurf				= NULL;
	m_pNormalMap				= NULL;
	m_pNormalMapSurf			= NULL;

	m_Id						= 0;

	m_pMeshSysMem     = NULL;
    m_pMeshEnhanced   = NULL;
    m_pMaterials      = NULL;
    m_ppTextures      = NULL;
    m_dwNumMaterials  = NULL;
    m_pbufMaterials   = NULL;
    m_pbufAdjacency   = NULL;
    m_dwNumSegs       = 2;
    
    m_pFont           = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
	m_dwCreationWidth           = MAP_SIZE*3+2;
    m_dwCreationHeight          = 375;

	GetCurrentDirectory(sizeof(m_strInitialDir), m_strInitialDir);
    DXUtil_GetDXSDKMediaPathCb( m_strSetDir, sizeof(m_strSetDir) );
    _tcscpy( m_strMeshFilename, _T("tiger.x") );
}




//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Called during initial app startup, this function performs all the
//       permanent initialization.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // Set cursor to indicate that user can move the object with the mouse
#ifdef _WIN64
    SetClassLongPtr( m_hWnd, GCLP_HCURSOR, (LONG_PTR)LoadCursor( NULL, IDC_SIZEALL ) );
#else
    SetClassLong( m_hWnd, GCL_HCURSOR, HandleToLong( LoadCursor( NULL, IDC_SIZEALL ) ) );
#endif

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	//---------------------------------------------------------
	// �s��̍X�V
	//---------------------------------------------------------
    D3DXVECTOR3 vLookat = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vFrom;
    D3DXVECTOR3 vUp;

	switch( m_Id ){
	case 0:
		vFrom	= D3DXVECTOR3(-1.0f, 0.0f, 0.0f );
		vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		break;
	case 1:
		vFrom	= D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
		vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		break;
	case 2:
		vFrom	= D3DXVECTOR3( 0.0f,-1.0f, 0.0f );
		vUp     = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
		break;
	case 3:
		vFrom	= D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		vUp     = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		break;
	case 4:
		vFrom	= D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
		vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		break;
	case 5:
		vFrom	= D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
		vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
		break;
	}
	D3DXMatrixLookAtLH( &m_mView, &vFrom, &vLookat, &vUp );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
 	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DXHANDLE hTechnique;
	D3DXMATRIX m, mL;
	D3DXVECTOR4 v;
	DWORD i;
	// �ύX�p�r���[�|�[�g    x y   width   height  minz maxz
	D3DVIEWPORT9 viewport = {0,0, MAP_SIZE, MAP_SIZE,0.0f,1.0f};

	// Clear the backbuffer
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 
                         0x000000ff, 1.0f, 0L );

    // Begin the scene
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		if(m_pEffect != NULL)
		{
			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ۑ�
			//-------------------------------------------------
			m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
			m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
			m_pd3dDevice->GetViewport(&oldViewport);

			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ύX
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pColorMapSurf);
			m_pd3dDevice->SetRenderTarget(1, m_pDepthMapSurf);
			m_pd3dDevice->SetRenderTarget(2, m_pNormalMapSurf);
			m_pd3dDevice->SetViewport(&viewport);
			m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);

			// �����_�����O�^�[�Q�b�g�̃N���A
			m_pd3dDevice->Clear(0L, NULL,
							D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
							0x000000, 1.0f, 0L);

			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
			m_pEffect->SetTechnique( hTechnique );
			m_pEffect->Begin( NULL, 0 );
			
			//-------------------------------------------------
			// �V�F�[�_�萔�̐ݒ�
			//-------------------------------------------------
			// ���W�ϊ�
			D3DXMatrixScaling( &mL
								, 1.0f/m_fObjectRadius
								, 1.0f/m_fObjectRadius
								, 1.0f/m_fObjectRadius
								);
			m = mL * m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			//-------------------------------------------------
			// �`��
			//-------------------------------------------------
			m_pd3dDevice->SetFVF(m_pMeshEnhanced->GetFVF());
			for( i = 0; i < m_dwNumMaterials; i++ )
			{
				// ���b�V���̐F
				v.x = m_pMaterials[i].MatD3D.Diffuse.r;
				v.y = m_pMaterials[i].MatD3D.Diffuse.g;
				v.z = m_pMaterials[i].MatD3D.Diffuse.b;
				v.w = m_pMaterials[i].MatD3D.Diffuse.a;
				m_pEffect->SetVector( m_hvCol, &v );
				// �e�N�X�`��
				if(m_ppTextures[i]){
					m_pEffect->SetTexture("DecaleMap", m_ppTextures[i]);
					m_pEffect->Pass( 0 );
				}else{
					m_pEffect->Pass( 1 );
				}
				m_pMeshEnhanced->DrawSubset( i );
			}
			m_pEffect->End();
			m_pd3dDevice->SetRenderTarget( 1, NULL );
			m_pd3dDevice->SetRenderTarget( 2, NULL );

			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�����ɖ߂�
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
			m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
			m_pd3dDevice->SetViewport(&oldViewport);
			pOldBackBuffer->Release();
			pOldZBuffer->Release();
		}

		// �o�b�t�@�̃N���A
		m_pd3dDevice->Clear( 0L, NULL,
						D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
						0x00404080, 1.0f, 0L );

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetPixelShader(0);
		for(DWORD loop = 0; loop < 3; loop++){
			const float scale = 256.0f;
			typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;

			TVERTEX Vertex[4] = {
				//       x        y   z rhw tu tv
				{(loop  )*(scale+1),    0,0, 1, 0, 0,},
				{(loop+1)*(scale+1)-1,    0,0, 1,  1, 0,},
				{(loop+1)*(scale+1)-1,scale,0, 1,  1,  1,},
				{(loop  )*(scale+1),scale,0, 1, 0,  1,},
			};
			switch(loop){
			case 0: m_pd3dDevice->SetTexture( 0, m_pColorMap ); break;
			case 1: m_pd3dDevice->SetTexture( 0, m_pDepthMap ); break;
			case 2: m_pd3dDevice->SetTexture( 0, m_pNormalMap); break;
			}
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}

		RenderText();				// �w���v���̕\��

        // End the scene.
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}

//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine; 

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
	sprintf( szMsg, "ID: %d", m_Id );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("Use arrow keys to change view") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    // �f�B�X�v���C�̏�Ԃ�\������
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    
	return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: This creates all device-dependent managed objects, such as managed
//       textures and managed vertex buffers.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    LPDIRECT3DVERTEXBUFFER9 pVB = NULL;
    void*      pVertices = NULL;
    LPD3DXMESH pTempMesh;
    TCHAR      strMeshPath[512];
    HRESULT    hr;

    // Initialize the font's internal textures
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    // Load the mesh from the specified file
    DXUtil_FindMediaFileCb( strMeshPath, sizeof(strMeshPath), m_strMeshFilename );

    hr = D3DXLoadMeshFromX( strMeshPath, D3DXMESH_SYSTEMMEM, m_pd3dDevice, 
                            &m_pbufAdjacency, &m_pbufMaterials, NULL, &m_dwNumMaterials, 
                            &m_pMeshSysMem );
    if( FAILED(hr) )
        // hide error so that we can display a blue screen
        return S_OK;

    // Lock the vertex buffer, to generate a simple bounding sphere
    hr = m_pMeshSysMem->GetVertexBuffer( &pVB );
    if( FAILED(hr) )
        return hr;

    hr = pVB->Lock( 0, 0, &pVertices, 0 );
    if( FAILED(hr) )
    {
        SAFE_RELEASE( pVB );
        return hr;
    }

    hr = D3DXComputeBoundingSphere( (D3DXVECTOR3*)pVertices, m_pMeshSysMem->GetNumVertices(), 
                                    D3DXGetFVFVertexSize(m_pMeshSysMem->GetFVF()), &m_vObjectCenter, 
                                    &m_fObjectRadius );
    if( FAILED(hr) )
    {
        pVB->Unlock();
        SAFE_RELEASE( pVB );
        return hr;
    }

    if( 0 == m_dwNumMaterials )
    {
        pVB->Unlock();
        SAFE_RELEASE( pVB );
        return E_INVALIDARG;
    }

    // Get the array of materials out of the returned buffer, allocate a
    // texture array, and load the textures
    m_pMaterials = (D3DXMATERIAL*)m_pbufMaterials->GetBufferPointer();
    m_ppTextures = new LPDIRECT3DTEXTURE9[m_dwNumMaterials];

    for( UINT i=0; i<m_dwNumMaterials; i++ )
    {
        TCHAR strTexturePath[512] = _T("");
        DXUtil_FindMediaFileCb( strTexturePath, sizeof(strTexturePath), m_pMaterials[i].pTextureFilename );
        if( FAILED( D3DXCreateTextureFromFile( m_pd3dDevice, strTexturePath, 
                                               &m_ppTextures[i] ) ) )
            m_ppTextures[i] = NULL;
    }

    pVB->Unlock();
    SAFE_RELEASE( pVB );

    // Make sure there are normals, which are required for the tesselation
    // enhancement
    if( !(m_pMeshSysMem->GetFVF() & D3DFVF_NORMAL) )
    {
        hr = m_pMeshSysMem->CloneMeshFVF( m_pMeshSysMem->GetOptions(), 
                                          m_pMeshSysMem->GetFVF() | D3DFVF_NORMAL, 
                                          m_pd3dDevice, &pTempMesh );
        if( FAILED(hr) )
            return hr;

        D3DXComputeNormals( pTempMesh, NULL );

        SAFE_RELEASE( m_pMeshSysMem );
        m_pMeshSysMem = pTempMesh;
    }

	// ���_�錾�̃I�u�W�F�N�g�̐���(�n�`�p)
	D3DVERTEXELEMENT9 decl[] =
	{
		{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
		{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,	0},
		{0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
		D3DDECL_END()
	};
	if( FAILED( hr = m_pd3dDevice->CreateVertexDeclaration( decl, &m_pDecl )))
		return hr;

	// �V�F�[�_�̓ǂݍ���
    TCHAR strPath[MAX_PATH];
	SetCurrentDirectory( m_strInitialDir );
    if( FAILED( hr = DXUtil_FindMediaFileCch( strPath, MAX_PATH,
                                                TEXT("hlsl.fx") ) ) )
		return hr;
	if( FAILED( hr = D3DXCreateEffectFromFile(
						m_pd3dDevice, strPath, NULL, NULL, 
						0, NULL, &m_pEffect, NULL ) ) )
		return hr;
	m_hmWVP  = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvCol  = m_pEffect->GetParameterByName( NULL, "vCol" );
	
	SetCurrentDirectory( m_strSetDir );

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: GenerateEnhancedMesh()
// Desc: 
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::GenerateEnhancedMesh( UINT dwNewNumSegs )
{
    LPD3DXMESH pMeshEnhancedSysMem = NULL;
    LPD3DXMESH pMeshTemp;
    HRESULT    hr;

    if (m_pMeshSysMem == NULL)
        return S_OK;

    {
        // Create an enhanced version of the mesh, will be in sysmem since source is
        hr = D3DXTessellateNPatches( m_pMeshSysMem, (DWORD*)m_pbufAdjacency->GetBufferPointer(), 
                                     (float)dwNewNumSegs, FALSE, &pMeshEnhancedSysMem, NULL );
        if( FAILED(hr) )
        {
            // If the tessellate failed, there might have been more triangles or vertices 
            // than can fit into a 16bit mesh, so try cloning to 32bit before tessellation

            hr = m_pMeshSysMem->CloneMeshFVF( D3DXMESH_SYSTEMMEM | D3DXMESH_32BIT, 
                m_pMeshSysMem->GetFVF(), m_pd3dDevice, &pMeshTemp );
            if (FAILED(hr))
                return hr;

            hr = D3DXTessellateNPatches( pMeshTemp, (DWORD*)m_pbufAdjacency->GetBufferPointer(), 
                                         (float)dwNewNumSegs, FALSE, &pMeshEnhancedSysMem, NULL );
            if( FAILED(hr) )
            {
                pMeshTemp->Release();
                return hr;
            }

            pMeshTemp->Release();
        }

        // Make a vid mem version of the mesh  
        // Only set WRITEONLY if it doesn't use 32bit indices, because those 
        // often need to be emulated, which means that D3DX needs read-access.
        DWORD dwMeshEnhancedFlags = pMeshEnhancedSysMem->GetOptions() & D3DXMESH_32BIT;
        if( (dwMeshEnhancedFlags & D3DXMESH_32BIT) == 0)
            dwMeshEnhancedFlags |= D3DXMESH_WRITEONLY;
        hr = pMeshEnhancedSysMem->CloneMeshFVF( dwMeshEnhancedFlags, m_pMeshSysMem->GetFVF(),
                                                m_pd3dDevice, &pMeshTemp );
        if( FAILED(hr) )
        {
            SAFE_RELEASE( pMeshEnhancedSysMem );
            return hr;
        }

        // Latch in the enhanced mesh
        SAFE_RELEASE( pMeshEnhancedSysMem );
    }

    SAFE_RELEASE( m_pMeshEnhanced );
    m_pMeshEnhanced = pMeshTemp;
    m_dwNumSegs     = dwNewNumSegs;

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Restore device-memory objects and state after a device is created or
//       resized.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    HRESULT hr;

    hr = GenerateEnhancedMesh( m_dwNumSegs );
    if( FAILED(hr) )
        return hr;

	// �����_�����O�^�[�Q�b�g�[�x�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// �J���[�o�b�t�@
	if (FAILED(m_pd3dDevice->CreateTexture( MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pColorMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pColorMap->GetSurfaceLevel(0, &m_pColorMapSurf)))
		return E_FAIL;
	// �[�x�o�b�t�@
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pDepthMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pDepthMap->GetSurfaceLevel(0, &m_pDepthMapSurf)))
		return E_FAIL;
	// �@���o�b�t�@
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pNormalMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pNormalMap->GetSurfaceLevel(0, &m_pNormalMapSurf)))
		return E_FAIL;

	// Setup render state
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,     TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,      TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,      0x33333333 );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );

    // Setup the light
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, 0.0f,-1.0f, 1.0f );
    m_pd3dDevice->SetLight(0, &light );
    m_pd3dDevice->LightEnable(0, TRUE );

    // Setup the arcball parameters
    m_ArcBall.SetWindow( m_d3dsdBackBuffer.Width, m_d3dsdBackBuffer.Height, 0.85f );
    m_ArcBall.SetRadius( 1.0f );

    // ���[���h�s��
    D3DXMatrixIdentity( &m_mWorld );

    // �r���[�s��
    D3DXVECTOR3 vFrom   = D3DXVECTOR3(-1.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vLookat = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFrom, &vLookat, &vUp );

	// �ˉe�s��̐ݒ�
    D3DXMatrixOrthoLH( &m_mProj, 2.0, 2.0, 0.0f, 2.0f);

    // Restore the font
    m_pFont->RestoreDeviceObjects();

	if( m_pEffect!=NULL ) m_pEffect->OnResetDevice();// �V�F�[�_

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Called when the device-dependent objects are about to be lost.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    m_pFont->InvalidateDeviceObjects();

    SAFE_RELEASE( m_pMeshEnhanced );

	// �����_�����O�^�[�Q�b�g
	SAFE_RELEASE(m_pNormalMapSurf);
	SAFE_RELEASE(m_pNormalMap);
	SAFE_RELEASE(m_pDepthMapSurf);
	SAFE_RELEASE(m_pDepthMap);
	SAFE_RELEASE(m_pColorMapSurf);
	SAFE_RELEASE(m_pColorMap);
	SAFE_RELEASE(m_pMapZ);

    if(m_pEffect!=NULL) m_pEffect->OnLostDevice();	// �V�F�[�_

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	SAFE_RELEASE( m_pEffect );		// �V�F�[�_
	SAFE_RELEASE( m_pDecl );		// ���_�錾

	m_pFont->DeleteDeviceObjects();

    for( UINT i = 0; i < m_dwNumMaterials; i++ )
        SAFE_RELEASE( m_ppTextures[i] );
    SAFE_DELETE_ARRAY( m_ppTextures );
    SAFE_RELEASE( m_pMeshSysMem );
    SAFE_RELEASE( m_pbufMaterials );
    SAFE_RELEASE( m_pbufAdjacency );
    m_dwNumMaterials = 0L;

    return S_OK;
}





//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Called during initial app startup, this function performs all the
//       permanent initialization.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Message proc function to handle key and menu input
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam,
                                    LPARAM lParam )
{
    // Pass mouse messages to the ArcBall so it can build internal matrices
    m_ArcBall.HandleMouseMessages( hWnd, uMsg, wParam, lParam );

    // Trap context menu
    if( WM_CONTEXTMENU == uMsg )
        return 0;

    // Handle key presses
    if( WM_KEYDOWN == uMsg )
    {
#if 0
		if( VK_UP == (int)wParam )
            GenerateEnhancedMesh( m_dwNumSegs + 1 );
        
        if( VK_DOWN == (int)wParam )
            GenerateEnhancedMesh( max( 1, m_dwNumSegs - 1 ) );
#endif

        if( VK_LEFT  == (int)wParam )
			m_Id = (m_Id-1+6)%6;
        if( VK_RIGHT == (int)wParam )
	        m_Id = (m_Id+1)  %6;

	}
    else if( uMsg == WM_COMMAND )
    {
            // Handle the open file command
        if( LOWORD(wParam) == IDM_OPENFILE )
        {
            TCHAR g_strFilename[512]   = _T("");

            // Display the OpenFileName dialog. Then, try to load the specified file
            OPENFILENAME ofn = { sizeof(OPENFILENAME), NULL, NULL,
                                _T(".X Files (.x)\0*.x\0\0"), 
                                NULL, 0, 1, m_strMeshFilename, 512, g_strFilename, 512, 
                                m_strSetDir, _T("Open Mesh File"), 
                                OFN_FILEMUSTEXIST, 0, 1, NULL, 0, NULL, NULL };

            if( TRUE == GetOpenFileName( &ofn ) )
            {
                _tcscpy( m_strSetDir, m_strMeshFilename );
                TCHAR* pLastSlash =  _tcsrchr( m_strSetDir, _T('\\') );
                if( pLastSlash )
                    *pLastSlash = 0;
                SetCurrentDirectory( m_strSetDir );
				
				// Destroy and recreate everything
				InvalidateDeviceObjects();
				DeleteDeviceObjects();
				InitDeviceObjects();
				RestoreDeviceObjects();
            }
        }
    }


    // Pass remaining messages to default handler
    return CD3DApplication::MsgProc( hWnd, uMsg, wParam, lParam );
}

//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice (D3DCAPS9* pCaps, DWORD dwBehavior, 
                                          D3DFORMAT adapterFormat, D3DFORMAT backBufferFormat )
{
	// �V�F�[�_�̃`�F�b�N
	if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) &&
	  !(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING ) )
		return E_FAIL;	// ���_�V�F�[�_
	
	if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0))
		return E_FAIL;	// �s�N�Z���V�F�[�_

	// MRT ���Q���g��
	if(pCaps->NumSimultaneousRTs < 3) return E_FAIL;

	return S_OK;
}




