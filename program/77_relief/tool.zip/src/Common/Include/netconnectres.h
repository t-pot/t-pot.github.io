
#define IDD_MULTIPLAYER_CONNECT         10001
#define IDD_MULTIPLAYER_GAMES           10002
#define IDD_MULTIPLAYER_CREATE          10003
#define IDD_LOBBY_WAIT_STATUS           10004
#define IDD_MULTIPLAYER_ADDRESS         10005
#define IDC_RETURN                      11001
#define IDC_PLAYER_NAME_EDIT            11002
#define IDC_GAMES_LIST                  11003
#define IDC_JOIN                        11004
#define IDC_CREATE                      11005
#define IDC_CONNECTION_LIST             11006
#define IDC_BACK                        11007
#define IDC_EDIT_SESSION_NAME           11009
#define IDC_SEARCH_CHECK                11010
#define IDC_LOBBYCONNECTCANCEL          11011
#define IDC_WAIT_TEXT                   11012
#define IDC_MIGRATE_HOST                11013 
#define IDI_MAIN                        11014
#define IDC_IP_ADDRESS                  11015
#define IDC_SIGNING_FAST                11016
#define IDC_SIGNING_FULL                11017
#define IDC_LOCAL_PORT                  11018
#define IDC_LOCAL_PORT_TEXT             11019
#define IDC_USE_DPNSVR                  11020
#define IDC_REMOTE_PORT                 11021
#define IDC_REMOTE_HOSTNAME             11022                  

