//-------------------------------------------------------------
// File: main.cpp
//
// Desc: PRT
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE		256// PRT�e�N�X�`���̃T�C�Y�B���̐�����傫������ƍׂ����Ȃ�
#define DIFFUSE_SIZE	64


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_iState = -1;
	m_Shader = 0;

	m_pMeshBg					= new CD3DMesh();

	m_pMapZ						= NULL;
	m_pPosTex					= NULL;
	m_pPosSurf					= NULL;
	m_pPosLockTex				= NULL;
	m_pPosLockSurf				= NULL;
	m_pNormalTex				= NULL;
	m_pNormalSurf				= NULL;
	m_pNormalLockTex			= NULL;
	m_pNormalLockSurf			= NULL;

	for(int i=0;i<TEX_MAX;i++){
		m_pFinalTex[i]			= NULL;
		m_pFinalSurf[i]			= NULL;
	}
	for(int j=0;j<REDUCTION_MAPS;j++){
		m_pReductionTex[i]		= NULL;
		m_pReductionSurf[i]		= NULL;
	}

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWVP						= NULL;
	m_htSrcTex					= NULL;

	m_fWorldRotX                = -0.5f;
    m_fWorldRotY                = 0.0f;
	m_fViewZoom				    = 13.0f;

    m_fLightRotX                = -0.80116916f;
    m_fLightRotY                = 1.4874420f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}


//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �n�ʂ̓ǂݍ���
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMeshBg->UseMeshMaterials(FALSE);// �����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�
        
	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWVP		 = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// �^�񒆂������G�����
//-------------------------------------------------------------
VOID WINAPI FillTex (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexelSize );
    UNREFERENCED_PARAMETER( pData );

	FLOAT x = 2.0f*(pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(pTexCoord->y-0.5f);
    FLOAT col = (x*x+y*y<(1.0f-1.0f/DIFFUSE_SIZE)*(1.0f-1.0f/DIFFUSE_SIZE))
				? 1.0f : 0.0f;
	
	pOut->x = pOut->y = pOut->z = pOut->w = col;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	m_iState = -1;
	m_iChangeState = TRUE;

	DWORD i;

	// ���b�V��
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );

    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );


    // �����_�����O��Ԃ̐ݒ�
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
    
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	// �����_�����O�^�[�Q�b�g�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// �ʒu�}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &m_pPosTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pPosTex->GetSurfaceLevel(0, &m_pPosSurf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		0, D3DFMT_A32B32G32R32F, D3DPOOL_SYSTEMMEM , &m_pPosLockTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pPosLockTex->GetSurfaceLevel(0, &m_pPosLockSurf)))
		return E_FAIL;
	// �@���}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &m_pNormalTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pNormalTex->GetSurfaceLevel(0, &m_pNormalSurf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		0, D3DFMT_A32B32G32R32F, D3DPOOL_SYSTEMMEM , &m_pNormalLockTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pNormalLockTex->GetSurfaceLevel(0, &m_pNormalLockSurf)))
		return E_FAIL;
	// �g�U�}�b�v
	for(i=0;i<TEX_MAX;i++){
		if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pFinalTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pFinalTex[i]->GetSurfaceLevel(0, &m_pFinalSurf[i])))
			return E_FAIL;
	}

	// �k���o�b�t�@
	for(i=0;i<REDUCTION_MAPS;i++){
		int size = 1<<(3*(REDUCTION_MAPS-i));
		if (FAILED(m_pd3dDevice->CreateTexture(size, size, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pReductionTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pReductionTex[i]->GetSurfaceLevel(0, &m_pReductionSurf[i])))
			return E_FAIL;
	}

	// �}�X�N�p�̃e�N�X�`���̐���
    if( FAILED(m_pd3dDevice->CreateTexture(DIFFUSE_SIZE, DIFFUSE_SIZE, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
                          , D3DPOOL_DEFAULT, &m_pMaskTex, NULL)))
        return E_FAIL;
    if( FAILED(D3DXFillTexture(m_pMaskTex, FillTex, NULL)))
        return E_FAIL;

	m_pEffect->OnResetDevice();

	return S_OK;
}


//-------------------------------------------------------------
// Name: FrameMoveCreateMap()
// Desc: �ʒu�A�@���}�b�v���쐬����B
//-------------------------------------------------------------
int CMyD3DApplication::FrameMoveCreateMap()
{
	// �Q��ڂ̈ȍ~�͎��̏����Ɉڂ�
	if(1<m_iCount) return 1;

	return 0;
}
//-------------------------------------------------------------
// Name: RenderCreateMap()
// Desc: �ʒu�A�@���}�b�v���쐬����B
//-------------------------------------------------------------
void CMyD3DApplication::RenderCreateMap()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;

    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ύX
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pPosSurf);
		m_pd3dDevice->SetRenderTarget(1, m_pNormalSurf);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		D3DVIEWPORT9 viewport_height = {0,0      // ����̍��W
						, MAP_SIZE  // ��
						, MAP_SIZE // ����
						, 0.0f,1.0f};     // �O�ʁA���
		m_pd3dDevice->SetViewport(&viewport_height);

		//-------------------------------------------------
		// �t���[���o�b�t�@�̃N���A
		//-------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET
						, 0x00000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );

			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

			//-------------------------------------------------
			// �w�i�̕`��
			//-------------------------------------------------
			m_pMeshBg->Render(m_pd3dDevice);

			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

			m_pEffect->End();
		}

		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		//-----------------------------------------------------
		// ���܂����̉��
		//-----------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		m_pd3dDevice->EndScene();
	}
}


//-------------------------------------------------------------
// Name: FrameMoveCreateMap()
// Desc: �ʒu�A�@���}�b�v���쐬����B
//-------------------------------------------------------------
static int itex=0;
static int ix=0;
static int iy=0;
static float pos[MAP_SIZE][MAP_SIZE][3];
static float normal[MAP_SIZE][MAP_SIZE][3];
int CMyD3DApplication::FrameMoveFinalGathering()
{
	itex = this->m_iCount / (MAP_SIZE*MAP_SIZE);
	ix = this->m_iCount % MAP_SIZE;
	iy = (this->m_iCount / MAP_SIZE) % MAP_SIZE;
	
	if(0==this->m_iCount){
		D3DLOCKED_RECT d3dlr;
		float *p;
		m_pd3dDevice->GetRenderTargetData(m_pPosSurf,m_pPosLockSurf);
		m_pPosLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;
		for(int y=0;y<MAP_SIZE;y++){
		for(int x=0;x<MAP_SIZE;x++){
			pos[x][y][0]=p[0];
			pos[x][y][1]=p[1];
			pos[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pPosLockSurf->UnlockRect();

		m_pd3dDevice->GetRenderTargetData(m_pNormalSurf,m_pNormalLockSurf);
		m_pNormalLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;        
		for(int y=0;y<MAP_SIZE;y++){
		for(int x=0;x<MAP_SIZE;x++){
			normal[x][y][0]=p[0];
			normal[x][y][1]=p[1];
			normal[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pNormalLockSurf->UnlockRect();
	}

	// �I������
	if(MAP_SIZE-1==ix && MAP_SIZE-1==iy && TEX_MAX-1==itex) return 1;

	return 0;
}
//-------------------------------------------------------------
// Name: RenderFinalGathering()
// Desc: ���ꂼ��̈ʒu����̃��f�B�A���X���v�Z����B
//-------------------------------------------------------------
void CMyD3DApplication::RenderFinalGathering()
{
    int i;
	D3DXMATRIX m, mView;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DSURFACE_DESC d3dsd;

	D3DVIEWPORT9 viewport = {0,0      // ����̍��W
					, 1, 1  // ��,����
					, 0.0f,1.0f};     // �O�ʁA���

	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		//-------------------------------------------------
		// �e�_���猩�����f�B�A���X�̕`��
		//-------------------------------------------------
		//-------------------------------------------------

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ύX
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[0]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_pReductionSurf[0]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �d�݂��������̕��������`��
			//-------------------------------------------------
			float x[3] = {pos[ix][iy][0], pos[ix][iy][1], pos[ix][iy][2]};
			float n[3] = {normal[ix][iy][0], normal[ix][iy][1], normal[ix][iy][2]};
			D3DXVECTOR3 vFromPt   = D3DXVECTOR3( x[0], x[1], x[2] ) + 0.001f*D3DXVECTOR3( n[0], n[1], n[2] );
			D3DXVECTOR3 vLookatPt = D3DXVECTOR3( n[0], n[1], n[2] ) + vFromPt;
			D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			D3DXMatrixLookAtLH( &mView, &vFromPt, &vLookatPt, &vUpVec );
			m_pEffect->SetMatrix( "mWV", &mView );

			D3DXMatrixTranspose(&m, &mView);
			m_pEffect->SetMatrix( "mST", &m );

			// �V�F�[�_�̐ݒ�
			m_pEffect->SetTechnique( "TSphericalHarmonics" );
			m_pEffect->Begin( NULL, 0 );

			TVERTEX Vertex[4] = {
				// x  y  z tu tv
				{-1,-1,0,  0, 0,},
				{+1,-1,0,  1, 0,},
				{+1,+1,0,  1, 1,},
				{-1,+1,0,  0, 1,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture(m_htSrcTex, m_pMaskTex);

			for(i=0;i<4;i++){
				switch(i){
				case 0:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_RED );
					break;
				case 1:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_GREEN );
					break;
				case 2:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_BLUE );
					break;
				case 3:
					m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, D3DCOLORWRITEENABLE_ALPHA );
					break;
				}
				int no = 4*itex+i;
				m_pEffect->Pass( no );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			}
			m_pEffect->End();

			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( "TShader" );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 1 );
			
			m_pd3dDevice->SetRenderState(D3DRS_COLORWRITEENABLE, 0xf );

			//-------------------------------------------------
			// �w�i�̕`��
			//-------------------------------------------------
			m_pMeshBg->Render(m_pd3dDevice);

			m_pEffect->End();
		}
		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���~�b�v�}�b�v�̗v�̂ŏ���������
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[1]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_pReductionSurf[1]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 2 );

			m_pEffect->SetFloat("MAP_WIDTH",  DIFFUSE_SIZE);
			m_pEffect->SetFloat("MAP_HEIGHT", DIFFUSE_SIZE);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{-1.0f, +1.0f, 0.1f,  0, 0},
				{+1.0f, +1.0f, 0.1f,  1, 0},
				{+1.0f, -1.0f, 0.1f,  1, 1},
				{-1.0f, -1.0f, 0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture("ReductionMap", m_pReductionTex[0]);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );

			m_pEffect->End();
		}

		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���e�N�X�`���̑Ή�����ʒu�ɒ���
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pFinalSurf[itex]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_pFinalSurf[itex]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);
		
		// �ŏ��͊D�F�œh��Ԃ�
		if(0==ix&&0==iy)m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, 0x80808080, 1.0f, 0L);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 2 );

			m_pEffect->SetFloat("MAP_WIDTH",  8);
			m_pEffect->SetFloat("MAP_HEIGHT", 8);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			float x =  2.0f*((float)ix/(float)MAP_SIZE) - 1.0f;
			float y = -2.0f*((float)iy/(float)MAP_SIZE) + 1.0f;
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{x,                      y,                     0.1f,  0, 0},
				{x+2.0f/(float)MAP_SIZE, y,                     0.1f,  1, 0},
				{x+2.0f/(float)MAP_SIZE, y-2.0f/(float)MAP_SIZE,0.1f,  1, 1},
				{x,                      y-2.0f/(float)MAP_SIZE,0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture("ReductionMap", m_pReductionTex[1]);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );

			m_pEffect->End();
		}

		
		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

		//---------------------------------------------------------
		// ��ʂ̕\��
		//---------------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x00001020, 1.0f, 0L);

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 256.0f*2/3;
		for(DWORD i=0; i<3; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pFinalTex[itex] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[0] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[1] );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
		TCHAR szMsg[MAX_PATH] = TEXT("");

		sprintf( szMsg, TEXT("x:%4d\ny:%4d"), ix, iy);
		m_pFont->DrawText( 2, (FLOAT)m_d3dsdBackBuffer.Height-40, fontColor, szMsg );

		m_pd3dDevice->EndScene();
	}
}


//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	m_iCount++;
	
	if(m_iChangeState) {m_iState++;m_iCount=0;m_iChangeState=0;}

	switch(m_iState){
	case 0:
		m_iChangeState = this->FrameMoveCreateMap();
		return S_OK;
	case 1:
		m_iChangeState = this->FrameMoveFinalGathering();
		return S_OK;
	default:
		break;
	}


	// ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

	if(!m_UserInput.bShift){
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fWorldRotY += m_fElapsedTime;
		else
		if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fWorldRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fWorldRotX += m_fElapsedTime;
		else
		if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fWorldRotX -= m_fElapsedTime;
	}

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// ���C�g
	//---------------------------------------------------------
	if(m_UserInput.bShift){
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fLightRotY += m_fElapsedTime;
		else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fLightRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fLightRotX += m_fElapsedTime;
		else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fLightRotX -= m_fElapsedTime;
	}
	// ���C�g�̃x�N�g��
    D3DXMatrixRotationX( &matRotX, m_fLightRotX );
    D3DXMatrixRotationY( &matRotY, m_fLightRotY );
    D3DXMatrixMultiply( &m_mLight, &matRotX, &matRotY );

	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.3f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	//---------------------------------------------------------
	// �V�F�[�_�̕ύX
	//---------------------------------------------------------
    if( m_UserInput.bChangeShader ) m_Shader = (m_Shader + 1) % 3;

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
    
	pUserInput->bChangeShader= ( m_bActive && (GetAsyncKeyState( 'A'      ) & 0x8001) == 0x8001 );

	pUserInput->bShift = ((GetAsyncKeyState( VK_SHIFT )    & 0x8000) == 0x8000);
}



//-------------------------------------------------------------
static float P(int l, int m, float x)
{
	float pmm=1.0;

	if(0<m){
		float somx2 = sqrtf((1.0f-x)*(1.0f+x));
		float fact = 1.0;
		for(int i=1; i<=m; i++){
			pmm *= (-fact)*somx2;
			fact += 2.0f;
		}
	}
	if(l==m) return pmm;
	
	float pmmp1=x*(2.0f*m+1.0f) * pmm;
	if(l==m+1) return pmmp1;
	
	float pll = 0.0;
	
	for(int ll=m+2; ll<=l; ll++){
		pll = ((2.0f*ll-1.0f)*x*pmmp1-(ll+m-1.0f)*pmm) / (ll-m);
		pmm = pmmp1;
		pmmp1 = pll;
	}
	
	return pll;
}
//-------------------------------------------------------------
static float K(int l, int m)
{
	int i;
	float lpm=1;
	float lnm=1;

	if(m<0)m=-m;

	for(i=l-m;0<i;i--)lnm *= i;
	for(i=l+m;0<i;i--)lpm *= i;

	return ((2*l+1)*lnm)/(4*D3DX_PI*lpm);
//	return sqrt(((2*l+1)*lnm)/(4*D3DX_PI*lpm));
}
//-------------------------------------------------------------
static float SphericalHarmonics(int l, int m, float theta, float phi)
{
	float ret = K(l,m);

	if(0<m){
		ret *= 2.f * cosf( m*phi) * P(l,  m, cosf(theta));
//		ret *= sqrt(2) * cos( m*phi) * P(l,  m, cos(theta));
	}else if(m<0){
		ret *= 2.f * sinf(-m*phi) * P(l, -m, cosf(theta));
//		ret *= sqrt(2) * sin(-m*phi) * P(l, -m, cos(theta));
	}else{
		ret *= P(l, m, cosf(theta));
	}

	return ret;
}

//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	switch(m_iState){
	case 0:
		this->RenderCreateMap();
		return S_OK;
	case 1:
		this->RenderFinalGathering();
		return S_OK;
	default:
		break;
	}

    D3DXMATRIX m, mT, mR, mW, mView, mProj;
	DWORD i;
	D3DXVECTOR4 v;
	D3DMATERIAL9 *pMtrl;

	// ���C�g�̈ʒu
	m = m_mLight * m_mWorld;
	D3DXVECTOR4 LightPos = D3DXVECTOR4(0.0f, 0.0f, 5.0f, 0.0f);
	D3DXVec4Transform( &LightPos, &LightPos, &m );
	D3DXVECTOR4 LightDir = D3DXVECTOR4(0.0f, 0.0f, 1.0f, 0.0f);
	D3DXVec4Transform( &LightDir, &LightDir, &m_mLight );
	
	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		// �t���[���o�b�t�@�̃N���A
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 3+m_Shader );

			//-------------------------------------------------
			// �V�[���̕`��
			//-------------------------------------------------
			// �ϊ��s��
			m = m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			D3DXVECTOR4 vSH[TEX_MAX];
			
			float ref = 3.0f;
			
			float phi = atan2f(LightDir.z, LightDir.x);
			float theta = acosf(LightDir.y);

			for(int l=0; l<=L_MAX; l++){
				for(int m=-l; m<=l; m++){
					int n = l*(l+1) + m;
					((float*)&vSH[0])[n] = ref * SphericalHarmonics(l, m, theta, phi);
					// �e�N�X�`���̓W�J�̕␳�̂��߁A(2l-1)!! �̕␳������
					if(2==l){
						((float*)&vSH[0])[n] *= 3;
					}
					if(3==l){
						((float*)&vSH[0])[n] *= 15;
					}
				}
			}

			m_pEffect->SetVectorArray("vSH", vSH, (L_MAX+1)*(L_MAX+1)/4);

			// PRT �e�N�X�`���̐ݒ�
			for(int tex = 0; tex < TEX_MAX; tex++){
				char str[256];
				sprintf(str, "PrtTex%d", tex);
				m_pEffect->SetTexture(str, this->m_pFinalTex[tex] );
			}
			// �w�i�̕`��
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );	// �`��
				pMtrl++;
			}

			m_pEffect->End();
		}

		//---------------------------------------------------------
		// ���C�g�̈ʒu�̕\��
		//---------------------------------------------------------
		{
		m = m_mView * m_mProj;
		v = LightPos;
		v.w = 1;
		D3DXVec4Transform( &v, &v, &m );
		float x = (this->m_rcWindowClient.right-this->m_rcWindowClient.left)*( 0.5f*v.x/v.w+0.5f);
		float y = (this->m_rcWindowClient.bottom-this->m_rcWindowClient.top)*(-0.5f*v.y/v.w+0.5f);

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE );
		m_pd3dDevice->SetPixelShader(0);

		typedef struct {FLOAT p[4]; DWORD color;} LVERTEX;
		for(DWORD i=0; i<2; i++){
			LVERTEX Vertex[4] = {
				// x  y   z rhw tu tv
				{x-3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y+3, v.z/v.w, 1, 0xffffc0,},
				{x-3,y+3, v.z/v.w, 1, 0xffffc0,},
			};
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( LVERTEX ) );
		}
		}


		// �w���v�̕\��
        RenderText();

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 96.0f;
		for(DWORD i=0; i<2+TEX_MAX; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{(i+0)*scale,    0,0, 1, 0, 0,},
				{(i+1)*scale,    0,0, 1, 1, 0,},
				{(i+1)*scale,scale,0, 1, 1, 1,},
				{(i+0)*scale,scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pPosTex );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pNormalTex );
			if(2<=i) m_pd3dDevice->SetTexture( 0, m_pFinalTex[i-2] );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'A' to change shader") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// �����_�����O�^�[�Q�b�g
	SAFE_RELEASE(m_pMaskTex);
	for(int i=0;i<REDUCTION_MAPS;i++){
		SAFE_RELEASE(m_pReductionSurf[i]);
		SAFE_RELEASE(m_pReductionTex[i]);
	}
	for(int j=0;j<TEX_MAX;j++){
		SAFE_RELEASE(m_pFinalSurf[j]);
		SAFE_RELEASE(m_pFinalTex[j]);
	}
	SAFE_RELEASE(m_pNormalLockSurf);
	SAFE_RELEASE(m_pNormalLockTex);
	SAFE_RELEASE(m_pNormalSurf);
	SAFE_RELEASE(m_pNormalTex);
	SAFE_RELEASE(m_pPosLockSurf);
	SAFE_RELEASE(m_pPosLockTex);
	SAFE_RELEASE(m_pPosSurf);
	SAFE_RELEASE(m_pPosTex);
	SAFE_RELEASE(m_pMapZ);

	m_pMeshBg->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	
	// ���b�V��
	m_pMeshBg->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pMeshBg ); // ���b�V��

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




