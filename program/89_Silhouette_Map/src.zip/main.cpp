//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Silhouette Map Filtering
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE	5

// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: FillTex()
// Desc: �e�N�X�`���̍쐬
//-------------------------------------------------------------
VOID WINAPI FillTex (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
	FLOAT cx = 0.4f;
	FLOAT cy = 0.4f;
	FLOAT r  = 0.4f-0.0000001f;
		
	// �F���������߂�
	FLOAT x = pTexCoord->x-0.5f*pTexelSize->x - cx;
	FLOAT y = pTexCoord->y-0.5f*pTexelSize->y - cy;
	FLOAT col = (x*x+y*y<r*r) ? 0.0 : 1.0;
	
	// �V���G�b�g�}�b�v�����߂�
	FLOAT Dx = cx - pTexCoord->x;
	FLOAT Dy = cy - pTexCoord->y;
	FLOAT D0 = 2*r*r+2*Dx*Dy-Dx*Dx-Dy*Dy;// ���ʎ� y=+(x-px)+py
	FLOAT D1 = 2*r*r-2*Dx*Dy-Dx*Dx-Dy*Dy;// ���ʎ� y=-(x-px)+py

	FLOAT U = 0.5f;
	FLOAT V = 0.5f;
	int   hit0=FALSE;
	if(0<=D0){
		FLOAT tp = 0.5f*((Dx+Dy)+sqrt(D0));
		FLOAT tn = 0.5f*((Dx+Dy)-sqrt(D0));
		if(-0.5f/MAP_SIZE <= tp && tp <= +0.5f/MAP_SIZE){
			U=0.5f+MAP_SIZE*tp;
			V=0.5f+MAP_SIZE*tp;
			hit0=TRUE;
		}else
		if(-0.5f/MAP_SIZE <= tn && tn <= +0.5f/MAP_SIZE){
			U=0.5f+MAP_SIZE*tn;
			V=0.5f+MAP_SIZE*tn;
			hit0=TRUE;
		}
	}
	if(0<=D1){
		FLOAT tp = 0.5f*((Dx-Dy)+sqrt(D1));
		FLOAT tn = 0.5f*((Dx-Dy)-sqrt(D1));
		if(-0.5f/MAP_SIZE <= tp && tp <= +0.5f/MAP_SIZE){
			if(hit0){
				U=0.5f*(U + 0.5f+MAP_SIZE*tp);
				V=0.5f*(V + 0.5f-MAP_SIZE*tp);
			}else{
				U=0.5f+MAP_SIZE*tp;
				V=0.5f-MAP_SIZE*tp;
			}
		}else
		if(-0.5f/MAP_SIZE <= tn && tn <= +0.5f/MAP_SIZE){
			if(hit0){
				U=0.5f*(U + 0.5f+MAP_SIZE*tn);
				V=0.5f*(V + 0.5f-MAP_SIZE*tn);
			}else{
				U=0.5f+MAP_SIZE*tn;
				V=0.5f-MAP_SIZE*tn;
			}
		}
	}
//U = 0.5f;
//V = 0.5f;
	
	// �V���G�b�g�}�b�v���A���t�@�����Ɋi�[����
	int iu = 16.0f*U;
	int iv = 16.0f*V;
	int alpha = iv+iu*16;

	pOut->x = pOut->y = pOut->z = col;
	pOut->w = (1.0f/256.0f)*(FLOAT)alpha;
//pOut->x=U;
//pOut->y=V;
//pOut->z=0;
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pTex						= NULL;

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;

	m_dwCreationWidth           = 1024;
    m_dwCreationHeight          = 378;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    return S_OK;
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	D3DXVECTOR4 offset;

	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	
	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	HRESULT hr;

	if( FAILED(hr = m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
                          , D3DPOOL_DEFAULT, &m_pTex, NULL)))
		return hr;
	if( FAILED(hr = D3DXFillTexture(m_pTex, FillTex, NULL)))
		return hr;
	m_pEffect->SetTexture( "tSrc", m_pTex );


    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 0.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

	// ���C�g�̐ݒ�
	D3DLIGHT9 light;
	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -0.5f, -2.0f, 1.0f );
	m_pd3dDevice->SetLight( 0, &light );
	m_pd3dDevice->LightEnable( 0, FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
    TSS( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	m_pEffect->OnResetDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x202040, 1.0f, 0L);

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );

		for(DWORD loop = 0; loop < 3; loop++){
			const float scale =256.0f;
			typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;
			FLOAT X = loop*(scale+64.0f)+64.0f;
			FLOAT Y = 64.0f;
			TVERTEX Vertex[4] = {
				//  x       y    z rhw tu tv
				{X      ,Y      ,0, 1, 0.0f, 0.0f,},
				{X+scale,Y      ,0, 1, 1.0f, 0.0f,},
				{X+scale,Y+scale,0, 1, 1.0f, 1.0f,},
				{X      ,Y+scale,0, 1, 0.0f, 1.0f,},
			};
			switch(loop){
			case 0:
				m_pd3dDevice->SetTexture( 0, m_pTex );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
				break;
			case 1:
				m_pd3dDevice->SetTexture( 0, m_pTex );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
				m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
				break;
			case 2:
				if(m_pEffect != NULL)
				{
					m_pEffect->SetTechnique( m_hTechnique );
					m_pEffect->Begin( NULL, 0 );
					m_pEffect->Pass( 0 );
					m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
					m_pEffect->End();
				}
				break;
			}
		}


        // �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    lstrcpy( szMsg, TEXT("                          "
		                 "Linear Texture Filtering"
						 "                                  "
						 "Nearest-Point Sampling "
						 "                                  "
						 "Silhouette Map Filtering"
						 ) );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	// ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	SAFE_RELEASE(m_pTex);

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	
    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




