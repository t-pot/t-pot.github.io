//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
#include "rendertarget.h"
#include "dxstdafx.h"

LPDIRECT3DSURFACE9 CRenderTarget::g_apOriginalRenderTarget[4] = {0};
LPDIRECT3DSURFACE9 CRenderTarget::g_pOriginalZbuffer = 0;
D3DVIEWPORT9       CRenderTarget::g_aViewport[4];

CRenderTarget::CRenderTarget()
{
	m_pTexture = 0;
	m_pSurface = 0;
	m_pSurfaceZ = 0;
	m_iMrt = ~0;
	m_iFlag = 0;
	m_pd3dDevice = 0;
}

CRenderTarget::~CRenderTarget()
{
	m_pd3dDevice = 0;
	if(m_pSurfaceZ       ) m_pSurfaceZ       ->Release(); m_pSurfaceZ        = 0;
	if(m_pSurface        ) m_pSurface        ->Release(); m_pSurface         = 0;
	if(m_pTexture        ) m_pTexture        ->Release(); m_pTexture         = 0;
}

HRESULT CRenderTarget::SetUp(IDirect3DDevice9* pd3dDevice, DWORD width, DWORD height, RT_FORMAT rt_format, RT_FORMAT z_format, DWORD create_flag)
{
	HRESULT hr;

	D3DFORMAT format  = D3DFMT_A8R8G8B8;
	D3DFORMAT formatZ = D3DFMT_UNKNOWN;
	UINT uMip = 1;
	DWORD uUsage = D3DUSAGE_RENDERTARGET;

	switch(rt_format)
	{
	case RTF_RGBA:    format = D3DFMT_A8R8G8B8;      break;
	case RTF_RGBA16F: format = D3DFMT_A16B16G16R16F; break;
	case RTF_RGBA32F: format = D3DFMT_A32B32G32R32F; break;
	case RTF_R32F:    format = D3DFMT_R32F;          break;
	case RTF_R16F:    format = D3DFMT_R16F;          break;
	}

	// Mip level
	if(create_flag & RTCF_AUTOGENMIPMAP)
	{
		uMip = 0;
		uUsage |= D3DUSAGE_AUTOGENMIPMAP;
	}

    V_RETURN( D3DXCreateTexture( pd3dDevice, width, height,
                                 uMip, uUsage, format, 
                                 D3DPOOL_DEFAULT, &m_pTexture ) );
	V_RETURN( m_pTexture->GetSurfaceLevel(0, &m_pSurface ) );
	
	switch(z_format)
	{
	case RTF_D16:   formatZ = D3DFMT_D16;   break;
	case RTF_D24S8: formatZ = D3DFMT_D24S8; break;
	}

	if(D3DFMT_UNKNOWN == formatZ)
	{
		m_pSurfaceZ = 0;
	}else{
		V_RETURN( pd3dDevice->CreateDepthStencilSurface(width, height, formatZ,
					D3DMULTISAMPLE_NONE, 0, TRUE, &m_pSurfaceZ, 0));
	}

	m_Viewport.X = 0;
	m_Viewport.Y = 0;
	m_Viewport.Width  = width;
	m_Viewport.Height = height;
	m_Viewport.MinZ = 0.0f;
	m_Viewport.MaxZ = 1.0f;

	m_pd3dDevice = pd3dDevice;

	return S_OK;
}

CRenderTarget *CRenderTarget::Create(IDirect3DDevice9* pd3dDevice, DWORD width, DWORD height, RT_FORMAT format, RT_FORMAT z_format, DWORD create_flag)
{
	CRenderTarget *pRT = 0;

	pRT = new CRenderTarget();
	pRT->SetUp(pd3dDevice, width, height, format, z_format, create_flag);

	return pRT;
}

void CRenderTarget::Release()
{
	delete this;
}

LPDIRECT3DTEXTURE9 CRenderTarget::GetTexture()
{
	return m_pTexture;
}

HRESULT CRenderTarget::Begin(DWORD mrt, DWORD flag)
{
	HRESULT hr;

	m_iFlag = flag;

	PushBackBuffer(mrt);

	V_RETURN( m_pd3dDevice->SetRenderTarget( mrt, m_pSurface ) );
	if(0==mrt)
	{
		if(!(flag&RT_FLAG_NOT_SET_ZBUFFER))
		{
			V_RETURN( m_pd3dDevice->SetDepthStencilSurface( m_pSurfaceZ ) );
		}
		V_RETURN( m_pd3dDevice->BeginScene() );
		V_RETURN( m_pd3dDevice->SetViewport(&m_Viewport) );
	}

	m_iMrt = mrt;

	return S_OK;
}

void CRenderTarget::End()
{
	if(0==m_iMrt)
	{
		m_pd3dDevice->EndScene();
	}

	PopBackBuffer(m_iMrt);

	m_iMrt = ~0;
	m_iFlag = 0;
}

void CRenderTarget::PushBackBuffer(DWORD mrt)
{
	HRESULT hr;

	if(0==mrt)
	{
	    V( m_pd3dDevice->GetRenderTarget( mrt, &g_apOriginalRenderTarget[mrt] ) );
		if(!(m_iFlag&RT_FLAG_NOT_SET_ZBUFFER))
		{
		    V( m_pd3dDevice->GetDepthStencilSurface( &g_pOriginalZbuffer ) );
		}
		V( m_pd3dDevice->GetViewport(&g_aViewport[mrt]) );
	}
}
void CRenderTarget::PopBackBuffer(DWORD mrt)
{
	HRESULT hr;

	if(0==mrt)
	{
		V( m_pd3dDevice->SetRenderTarget( mrt, g_apOriginalRenderTarget[mrt] ) );
		if(!(m_iFlag&RT_FLAG_NOT_SET_ZBUFFER))
		{
			V( m_pd3dDevice->SetDepthStencilSurface( g_pOriginalZbuffer ) );
			SAFE_RELEASE( g_pOriginalZbuffer );
		}
		V( m_pd3dDevice->SetViewport(&g_aViewport[mrt]) );
		SAFE_RELEASE( g_apOriginalRenderTarget[mrt] );
	}else{
		V( m_pd3dDevice->SetRenderTarget( mrt, 0 ) );
	}
}

void CRenderTarget::SetZBuffer()
{
	HRESULT hr;

	SAFE_RELEASE( g_pOriginalZbuffer );
    V( m_pd3dDevice->GetDepthStencilSurface( &g_pOriginalZbuffer ) );

	if(m_pSurfaceZ)
	{
		V( m_pd3dDevice->SetDepthStencilSurface( m_pSurfaceZ ) );
	}
}

void CRenderTarget::ResetZBuffer()
{
	HRESULT hr;

	V( m_pd3dDevice->SetDepthStencilSurface( g_pOriginalZbuffer ) );
	SAFE_RELEASE( g_pOriginalZbuffer );
}
