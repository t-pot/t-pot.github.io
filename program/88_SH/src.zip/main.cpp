//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Ashikhmin���f��
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}

//-------------------------------------------------------------
static double P(int l, int m, double x)
{
	double pmm=1.0;

	if(0<m){
		double somx2 = sqrt((1.0-x)*(1.0+x));
		double fact = 1.0;
		for(int i=1; i<=m; i++){
			pmm *= (-fact)*somx2;
			fact += 2.0f;
		}
	}
	if(l==m) return pmm;
	
	double pmmp1=x*(2.0*m+1.0) * pmm;
	if(l==m+1) return pmmp1;
	
	double pll = 0.0;
	
	for(int ll=m+2; ll<=l; ll++){
		pll = ((2.0*ll-1.0)*x*pmmp1-(ll+m-1.0)*pmm) / (ll-m);
		pmm = pmmp1;
		pmmp1 = pll;
	}
	
	return pll;
}
//-------------------------------------------------------------
static float K(int l, int m)
{
	int i;
	float lpm=1;
	float lnm=1;

	if(m<0)m=-m;

	for(i=l-m;0<i;i--)lnm *= i;
	for(i=l+m;0<i;i--)lpm *= i;

	return sqrt(((2*l+1)*lnm)/(4*D3DX_PI*lpm));
}
//-------------------------------------------------------------
static float SphericalHarmonics(int l, int m, double theta, double phi)
{
	float ret = K(l,m);

	if(0<m){
		ret *= sqrt(2) * cos( m*phi) * P(l,  m, cos(theta));
	}else if(m<0){
		ret *= sqrt(2) * sin(-m*phi) * P(l, -m, cos(theta));
	}else{
		ret *= P(l, m, cos(theta));
	}

	return ret;
}
//-------------------------------------------------------------


const DWORD CMesh::FVF = D3DFVF_XYZ | D3DFVF_NORMAL;

//-------------------------------------------------------------
// Name: CMesh()
// Desc: �R���X�g���N�^
//-------------------------------------------------------------
CMesh::CMesh()
{
}
//-------------------------------------------------------------
// Name: ~CMesh()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMesh::~CMesh()
{
}
//-------------------------------------------------------------
// Name: Create()
// Desc: �e��I�u�W�F�N�g�̏�����
//-------------------------------------------------------------
HRESULT CMesh::Create(int l, int m,  LPDIRECT3DDEVICE9 lpD3DDev )
{
    HRESULT hr;
	DWORD i, j;
	const FLOAT r = 1.0f;
	const int x = 256;// �c�ɕ���
	const int y = 256;// ���ɕ���

	m_dwNumVertices  = ((x+1)*(y+1));
	m_dwNumFaces     = 2*x*y;
	DWORD dwNumIndex = 3*m_dwNumFaces;

	// ���_�o�b�t�@�̐���
	Vertex *pDest;
    lpD3DDev->CreateVertexBuffer( m_dwNumVertices * sizeof(CMesh::Vertex),
                                D3DUSAGE_WRITEONLY, CMesh::FVF, D3DPOOL_MANAGED,
                                &m_pVB, NULL );

    // ���_���Z�b�g�A�b�v
    m_pVB->Lock ( 0, 0, (VOID **)&pDest, 0 );
    for ( j = 0; j <= y; j++) {
    for ( i = 0; i <= x; i++) {
        float phi  = ((float)i)*2*D3DX_PI/x-D3DX_PI;
        float theta= ((float)j)*  D3DX_PI/y;
		float r = SphericalHarmonics(l, m, theta, phi);
		if(r<0)r=-r;
        pDest->x   = r * (float)sin(theta) * (float)cos(phi);
        pDest->z   = r * (float)sin(theta) * (float)sin(phi);
        pDest->y   = r * (float)cos(theta);
        pDest->n[0] = (float)sin(theta) * (float)cos(phi);
        pDest->n[2] = (float)sin(theta) * (float)sin(phi);
        pDest->n[1] = (float)cos(theta);
        pDest++;
    }
    }
    m_pVB->Unlock ();

    // �C���f�b�N�X���Z�b�g�A�b�v
    WORD *pIndex;
    lpD3DDev->CreateIndexBuffer( dwNumIndex * sizeof(WORD),
                               0,
                               D3DFMT_INDEX16, D3DPOOL_MANAGED,
                               &m_pIB, NULL );
    m_pIB->Lock ( 0, 0, (VOID**)&pIndex, 0 );
    for ( j = 0; j < y; j++) {
    for ( i = 0; i < x; i++) {
        *pIndex++ = (j+0)*(x+1)+i+0;
        *pIndex++ = (j+0)*(x+1)+i+1;
        *pIndex++ = (j+1)*(x+1)+i+0;
        *pIndex++ = (j+0)*(x+1)+i+1;
        *pIndex++ = (j+1)*(x+1)+i+1;
        *pIndex++ = (j+1)*(x+1)+i+0;
    }
    }
    m_pIB->Unlock ();

	return S_OK;
}
//-------------------------------------------------------------
// Name: Render()
// Desc: �`��
//-------------------------------------------------------------
HRESULT CMesh::Render( LPDIRECT3DDEVICE9 lpD3DDev )
{
	lpD3DDev->SetFVF( CMesh::FVF );
	lpD3DDev->SetStreamSource( 0, m_pVB, 0, sizeof(CMesh::Vertex) );
	lpD3DDev->SetIndices( m_pIB );
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0,
									0, m_dwNumVertices,
									0, m_dwNumFaces );
	return S_OK;
}
//-------------------------------------------------------------
// Name: Create()
// Desc: �������̊J��
//-------------------------------------------------------------
HRESULT CMesh::DeleteDeviceObjects()
{
    SAFE_RELEASE( m_pVB );
    SAFE_RELEASE( m_pIB );

	m_dwNumVertices = 0;
	m_dwNumFaces = 0;

	return S_OK;
}





//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pMesh						= new CMesh();

	m_fWorldRotX                = -0.41271535f;
    m_fWorldRotY                = 0.5f * D3DX_PI;
	m_fViewZoom				    = 3.0f;

	m_m = 0;
	m_l = 0;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

	m_LightPos					= D3DXVECTOR4( 3.0f, 3.0f, -3.0f, 0.0f);

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

    return S_OK;
}



//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	D3DXVECTOR4 offset;

	
	// ���f���̓ǂݍ���
	m_pMesh->Create(m_l, m_m, m_pd3dDevice);
	
	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	HRESULT hr;

    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    RS( D3DRS_LIGHTING,       TRUE );
    RS( D3DRS_CULLMODE,       D3DCULL_NONE  );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
    TSS( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // Set up lighting states
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // Setup a material
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

	// �t�H���g
    m_pFont->RestoreDeviceObjects();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else
    if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else
    if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );
	
	int l = m_l;
	int m = m_m;

	if( m_UserInput.bQ && !m_UserInput.bW ){
		m_l++;
	}else
	if( m_UserInput.bW && !m_UserInput.bQ ){
		m_l--;
	}
	if( m_UserInput.bA && !m_UserInput.bS ){
		m_m++;
	}else
	if( m_UserInput.bS && !m_UserInput.bA ){
		m_m--;
	}
	if(m_l<0) m_l=0;
	if(m_l< m_m)m_m= m_l;
	if(m_m<-m_l)m_m=-m_l;

	if(l != m_l || m != m_m){
		m_pMesh  ->DeleteDeviceObjects();
		m_pMesh->Create(m_l, m_m, m_pd3dDevice);
	}

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );

	pUserInput->bQ		     = ( m_bActive && (GetAsyncKeyState( 'Q'     )  & 0x0001) == 0x0001 );
    pUserInput->bW			 = ( m_bActive && (GetAsyncKeyState( 'W'      ) & 0x0001) == 0x0001 );
	pUserInput->bA		     = ( m_bActive && (GetAsyncKeyState( 'A'     )  & 0x0001) == 0x0001 );
    pUserInput->bS		     = ( m_bActive && (GetAsyncKeyState( 'S'      ) & 0x0001) == 0x0001 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mW;
	D3DXVECTOR4 v;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x404080, 1.0f, 0L);

		m_pd3dDevice->SetTransform( D3DTS_WORLD,  &m_mWorld);
		m_pd3dDevice->SetTransform( D3DTS_VIEW,  &m_mView );
		m_pd3dDevice->SetTransform( D3DTS_PROJECTION,  &m_mProj );

		TSS( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
		TSS( 0, D3DTSS_COLORARG1, D3DTA_DIFFUSE );

		//-------------------------------------------------
		// �`��
		//-------------------------------------------------
		m_pMesh->Render(m_pd3dDevice);

        // �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��


	// ����@��p�����[�^��\������
    fNextLine = (FLOAT) 0; 
    sprintf( szMsg, TEXT("l=%d [q/w]  m=%d [a/s]"), m_l, m_m );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	

	fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// ���b�V��
	m_pMesh  ->DeleteDeviceObjects();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	SAFE_DELETE( m_pMesh );

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




