//-------------------------------------------------------------
// File: main.h
//
// Desc: Ashikhmin���f��
//-------------------------------------------------------------
#pragma once



//-------------------------------------------------------------
// ��`��萔
//-------------------------------------------------------------
// ���݂̓��̓f�[�^��ۑ�����\����
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
    BOOL bZoomIn;
    BOOL bZoomOut;
    BOOL bQ;
    BOOL bW;
    BOOL bA;
    BOOL bS;
};


//-------------------------------------------------------------
// Name: class CMesh
// Desc: ���ʃ|���S���̃I�u�W�F�N�g
//-------------------------------------------------------------
class CMesh {
	typedef struct {
		FLOAT		x,y,z;
		FLOAT       n[3];
	}Vertex;
	static const DWORD FVF;

	LPDIRECT3DVERTEXBUFFER9			m_pVB;
	LPDIRECT3DINDEXBUFFER9			m_pIB;
	DWORD							m_dwNumVertices;
	DWORD							m_dwNumFaces;

public:
	CMesh();
	~CMesh();
	
	HRESULT Create ( int l, int m, LPDIRECT3DDEVICE9 lpD3DDev );
	HRESULT Render ( LPDIRECT3DDEVICE9 lpD3DDev );
	HRESULT DeleteDeviceObjects ();
};



//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: �A�v���P�[�V�����̃N���X
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	CMesh				*m_pMesh;
	
	int				m_m;
	int				m_l;

	// �ʏ�̍��W�ϊ��s��
	D3DXMATRIX				m_mWorld;
	D3DXMATRIX				m_mView;
	D3DXMATRIX				m_mProj;

	D3DXVECTOR4				m_LightPos;
	

	BOOL					m_bLoadingApp;	// ���[�h���H
    CD3DFont*				m_pFont;		// �t�H���g
    UserInput				m_UserInput;	// ���̓f�[�^

    FLOAT                   m_fWorldRotX;   // �w����]
    FLOAT                   m_fWorldRotY;   // �x����]
    FLOAT                   m_fViewZoom;    // ���_�̋���

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

