// ----------------------------------------------------------------------------
//
// load.h - �S�̓I�Ȓ�`
// 
// Copyright (c) 2001 IF (if@kun-desu.ne.jp)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _LOAD_H
#define	_LOAD_H

#include <d3d8.h>
#include <d3dx8.h>

// ----------------------------------------------------------------------------
// ���f��
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// ���_�̒�`
// ----------------------------------------------------------------------------
typedef struct {
	float x,y,z;
	float nx,ny,nz;
	float tu0,tv0;
//	float tu1,tv1;
}D3D_CUSTOMVERTEX;
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1/* | D3DFVF_TEX2*/)

extern DWORD dwDecl[];

class CMyMesh{
public:
	CMyMesh(){
		bActive = false;
		pVB = NULL;
		pIndex = NULL;
		pSubsetTable = NULL;
		pTextures = NULL;
		pMaterials = NULL;
		nFaces = nVertices = dwNumMaterials = 0;
		rot.x = rot.y = rot.z = 0;
	}
	bool					bActive;
	float					radius;		// �傫��
	D3DXVECTOR3				center;		// ���S�ʒu
	D3DXVECTOR3				rot;

	LPDIRECT3DVERTEXBUFFER8	pVB;
	LPDIRECT3DINDEXBUFFER8	pIndex;
	D3DXATTRIBUTERANGE		*pSubsetTable;
	DWORD					nFaces;
	DWORD					nVertices;
	D3DMATERIAL8			*pMaterials;		// ���b�V���̎���
	LPDIRECT3DTEXTURE8		*pTextures;		// ���b�V���̃e�N�X�`���[
	DWORD					dwNumMaterials;	// �}�e���A���̐�

	HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, char *filename);
	void Release();
};
// ----------------------------------------------------------------------------
// �e�N�X�`���[
// ----------------------------------------------------------------------------
class CTextureMgr{
public:
	static HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, LPDIRECT3DTEXTURE8 *ppTexture);
	static void Release(LPDIRECT3DTEXTURE8 pTexture);
};
// ----------------------------------------------------------------------------
// ���_�V�F�[�_�[
// ----------------------------------------------------------------------------
class CVertexShaderMgr{
public:
	static HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, DWORD *phVertexShader, const DWORD dwDecl[]);
	static void Release(LPDIRECT3DDEVICE8 lpD3DDev, DWORD *phVertexShader);
};
// ----------------------------------------------------------------------------
// �s�N�Z���V�F�[�_�[
// ----------------------------------------------------------------------------
class CPixelShaderMgr{
public:
	static HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, DWORD *phPixelShader);
	static void Release(LPDIRECT3DDEVICE8 lpD3DDev, DWORD *phPixelShader);
};


#endif /* !_LOAD_H */
