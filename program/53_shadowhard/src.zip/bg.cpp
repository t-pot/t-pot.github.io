// ----------------------------------------------------------------------------
//
// bg.cpp - �w�i
// 
// Copyright (c) 2001 if (if@edokko.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT


#include "main.h"
#include "load.h"
#include "draw.h"

// ��
#define NUM_Y		1	// �c�����ɉ��|���S���g����
#define NUM_CIRCLE	32	// ���艽�|���S����
#define NUM_VERTICES			((NUM_Y+1)*(NUM_CIRCLE+1))
#define NUM_INDICES_PERFACE		(3*2)
#define NUM_FACES				(NUM_Y*NUM_CIRCLE)
#define NUM_VERTICES_PERFACE	4

// ��
#define FLOOR_GRID   10
#define FLOOR_SIZE	(10.0f)
#define FLOOR_UV	(10.0f)		// �e�N�X�`���[�̌J��Ԃ���

// ----------------------------------------------------------------------------
// ��
LPDIRECT3DVERTEXBUFFER8		pCylinderVB;
LPDIRECT3DINDEXBUFFER8		pCylinderIB;
LPDIRECT3DTEXTURE8			pCylinderTex;
// ��
LPDIRECT3DVERTEXBUFFER8		pFloorVB;
LPDIRECT3DINDEXBUFFER8		pFloorIB;
LPDIRECT3DTEXTURE8			pFloorTex;

// ----------------------------------------------------------------------------
void InitBg(LPDIRECT3DDEVICE8 lpD3DDev)
{
	//
	// �~��
	//
	// ���_�o�b�t�@�̍쐬 
	D3DVERTEX *pDest;
    lpD3DDev->CreateVertexBuffer( NUM_VERTICES * sizeof(D3DVERTEX),
                                D3DUSAGE_WRITEONLY, 
								D3DFVF_VERTEX, D3DPOOL_MANAGED,
                                &pCylinderVB );

	// ���_���Z�b�g�A�b�v
	WORD k=0;
	pCylinderVB->Lock ( 0, 0, (BYTE**)&pDest, 0 );
	float r = 10.0f;
	float h = 10.0f;
	for (DWORD i = 0; i <= NUM_CIRCLE; i++) {
		float theta = (2*PI*(float)i)/(float)NUM_CIRCLE;
		for (DWORD j = 0; j <= NUM_Y; j++) {
			pDest->x = r * (float)cos(theta);
			pDest->z = r * (float)sin(theta);
			pDest->y = h*((float)j/(float)NUM_Y-0.0f);
			pDest->nx = 0;
			pDest->nz = 0;
			pDest->ny = 0;
			pDest->tu0 = (float)i / (float)NUM_CIRCLE;
			pDest->tv0 = 1.0f-(float)j / (float)NUM_Y;
			pDest += 1;
		}
	}		
	pCylinderVB->Unlock ();


	// �C���f�b�N�X���Z�b�g�A�b�v
	WORD *pIndex;
    lpD3DDev->CreateIndexBuffer( NUM_INDICES_PERFACE  * NUM_FACES * sizeof(WORD),
                                     0 ,
                                     D3DFMT_INDEX16, D3DPOOL_DEFAULT,
                                     &pCylinderIB );
	pCylinderIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
	{
	for (WORD i = 0; i < NUM_CIRCLE; i++) {
		for (WORD j = 0; j < NUM_Y; j++) {
			*pIndex++ = j + 0 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);

			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+1) * (NUM_Y+1);
		}
	}
	}
	pCylinderIB->Unlock ();

	CTextureMgr::Load(lpD3DDev, "sky.bmp", &pCylinderTex);
	
	//
	// ��
	//
	// ���_�o�b�t�@�̍쐬 
	D3DVERTEX *pFloorDest;
    lpD3DDev->CreateVertexBuffer( (FLOOR_GRID+1)*(FLOOR_GRID+1)*sizeof(D3DVERTEX),
                                D3DUSAGE_WRITEONLY, D3DFVF_VERTEX, D3DPOOL_MANAGED,
                                &pFloorVB );
	// ���_���Z�b�g�A�b�v
	{
	pFloorVB->Lock ( 0, 0, (BYTE**)&pFloorDest, 0 );
	float pos_z = -FLOOR_SIZE;
	for(DWORD z = 0; z <= FLOOR_GRID; z++){
		float pos_x = -FLOOR_SIZE;
		for(DWORD x = 0; x <= FLOOR_GRID; x++){
			pFloorDest->x   = pos_x;
			pFloorDest->z   = pos_z;
			pFloorDest->y   = 0.0f;
			pFloorDest->nx  = 0.0f;
			pFloorDest->nz  = 0.0f;
			pFloorDest->ny  = 1.0f;
			pFloorDest->tu0 = FLOOR_UV*(pos_x+FLOOR_SIZE)/(2.0f*FLOOR_SIZE);
			pFloorDest->tv0 = FLOOR_UV*(pos_z+FLOOR_SIZE)/(2.0f*FLOOR_SIZE);
			pFloorDest++;
			pos_x += 2*FLOOR_SIZE/FLOOR_GRID;
		}
		pos_z += 2*FLOOR_SIZE/FLOOR_GRID;
	}
	pFloorVB->Unlock ();
	}


	// �C���f�b�N�X���Z�b�g�A�b�v
    lpD3DDev->CreateIndexBuffer( 3*2*FLOOR_GRID*FLOOR_GRID * sizeof(WORD),
                               0,
                               D3DFMT_INDEX16, D3DPOOL_MANAGED,
                               &pFloorIB );
	pFloorIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
	{
	for (WORD i = 0; i < FLOOR_GRID; i++) {
		for (WORD j = 0; j < FLOOR_GRID; j++) {
			*pIndex++ = j + 0 + (i+0) * (FLOOR_GRID+1);
			*pIndex++ = j + 0 + (i+1) * (FLOOR_GRID+1);
			*pIndex++ = j + 1 + (i+0) * (FLOOR_GRID+1);

			*pIndex++ = j + 1 + (i+0) * (FLOOR_GRID+1);
			*pIndex++ = j + 0 + (i+1) * (FLOOR_GRID+1);
			*pIndex++ = j + 1 + (i+1) * (FLOOR_GRID+1);
		}
	}
	}

//	pIndex[0] = 0;	pIndex[1] = 1;	pIndex[2] = 2;
//	pIndex[3] = 1;	pIndex[4] = 3;	pIndex[5] = 2;
	pFloorIB->Unlock ();

	CTextureMgr::Load(lpD3DDev, "tile.bmp", &pFloorTex);
}
// ----------------------------------------------------------------------------
void DrawBg(LPDIRECT3DDEVICE8 lpD3DDev)
{
	lpD3DDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(0, D3DTSS_COLOROP,	D3DTOP_SELECTARG1);

	// ��
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_WRAP);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_WRAP);
	lpD3DDev->SetTexture(0,pFloorTex);

	lpD3DDev->SetStreamSource(0, pFloorVB, sizeof(D3DVERTEX));
	lpD3DDev->SetIndices(pFloorIB,0);
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,	0, (FLOOR_GRID+1)*(FLOOR_GRID+1), 0, 2*FLOOR_GRID*FLOOR_GRID );

	// ��
	lpD3DDev->SetPixelShader(0);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_WRAP);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTexture(0,pCylinderTex);
	lpD3DDev->SetStreamSource(0, pCylinderVB, sizeof(D3DVERTEX));
	lpD3DDev->SetIndices(pCylinderIB,0);
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,	0, NUM_VERTICES, 0 , NUM_FACES*2 );
}
// ----------------------------------------------------------------------------
void CleanBg(LPDIRECT3DDEVICE8 lpD3DDev)
{
	CTextureMgr::Release(pFloorTex);
	CTextureMgr::Release(pCylinderTex);
}