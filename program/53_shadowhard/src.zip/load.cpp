// ----------------------------------------------------------------------------
//
// load.cpp - �ǂݍ��ݕ���
// 
// Copyright (c) 2001 IF (if@kun-desu.ne.jp)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include "main.h"
#include "load.h"

// ----------------------------------------------------------------------------
// ���_�̒�`
// ----------------------------------------------------------------------------
// �����f��
typedef struct {
	float x,y,z;
	float nx,ny,nz;
	float tu0,tv0;
}D3DVERTEX;
#define D3DFVF_VERTEX 		(D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)

// D3D_CUSTOMVERTEX
DWORD dwDecl[] = {
	D3DVSD_STREAM(0),
	D3DVSD_REG(D3DVSDE_POSITION, D3DVSDT_FLOAT3 ),			//D3DVSDE_POSITION,  0
	D3DVSD_REG(D3DVSDE_NORMAL,   D3DVSDT_FLOAT3 ),          //D3DVSDE_NORMAL,    3
	D3DVSD_REG(D3DVSDE_TEXCOORD0,D3DVSDT_FLOAT2 ),		    //D3DVSDE_TEXCOORD0, 7  
//	D3DVSD_REG(D3DVSDE_TEXCOORD1,D3DVSDT_FLOAT2 ),		    //D3DVSDE_TEXCOORD1, 8  
	D3DVSD_END()
};

// ----------------------------------------------------------------------------
// ���f��
// ----------------------------------------------------------------------------
HRESULT CMyMesh::Load(LPDIRECT3DDEVICE8 lpD3DDev, char *filename)
{
	LPD3DXMESH pMesh, pMeshOpt;
	LPD3DXBUFFER pD3DXMtrlBuffer = NULL;
	DWORD i;
	HRESULT hr;
	
	this->Release();
	hr = D3DXLoadMeshFromX(filename, D3DXMESH_MANAGED,
								lpD3DDev, NULL,
								&pD3DXMtrlBuffer, &this->dwNumMaterials,
								&pMesh);
	if(FAILED(hr)) return E_FAIL;

	//���ёւ��Ă���
	pMesh->Optimize(D3DXMESHOPT_ATTRSORT, NULL, NULL, NULL, NULL, &pMeshOpt);
	RELEASE(pMesh);

	// �傫���𒲂ׂĂ���
	LPDIRECT3DVERTEXBUFFER8 pVB;
	BYTE* pVByte;
	pMeshOpt->GetVertexBuffer(&pVB);
	pVB->Lock(0,0,&pVByte,0);
	D3DXComputeBoundingSphere(pVByte, pMeshOpt->GetNumVertices(), pMeshOpt->GetFVF(), &this->center, &this->radius);
	pVB->Unlock();
	pVB->Release();

	//�A�g���r���[�g�e�[�u��
	pMeshOpt->GetAttributeTable(NULL,&this->dwNumMaterials);
	this->pSubsetTable = new D3DXATTRIBUTERANGE[this->dwNumMaterials];
	pMeshOpt->GetAttributeTable(this->pSubsetTable, &this->dwNumMaterials);

	// FVF�ϊ�
	hr = pMeshOpt->CloneMeshFVF(pMeshOpt->GetOptions(), D3DFVF_VERTEX, lpD3DDev, &pMesh);
	if(FAILED(hr)) return E_FAIL;
	RELEASE(pMeshOpt);
	D3DXComputeNormals(pMesh,NULL);

	//Vertex Buffer�ɃR�s�[����
	D3DVERTEX* pSrc;
	D3D_CUSTOMVERTEX* pDest;
	LPDIRECT3DINDEXBUFFER8 pSrcIndex;
	WORD* pISrc;
	WORD* pIDest;

	DWORD nMeshVertices = pMesh->GetNumVertices();
	DWORD nMeshFaces = pMesh->GetNumFaces();
	lpD3DDev->CreateVertexBuffer(nMeshVertices * sizeof(D3D_CUSTOMVERTEX),D3DUSAGE_WRITEONLY,D3DFVF_CUSTOMVERTEX,D3DPOOL_MANAGED,&this->pVB);
	lpD3DDev->CreateIndexBuffer(nMeshFaces * 3 * sizeof(WORD),0,D3DFMT_INDEX16,D3DPOOL_MANAGED,&this->pIndex);

//	LPDIRECT3DVERTEXBUFFER8 pVB;
	pMesh->GetVertexBuffer(&pVB);
	pVB->Lock(0,0,(BYTE**)&pSrc,0);
	this->pVB->Lock(0,0,(BYTE**)&pDest,0);
	for(i=0;i<nMeshVertices;i++){
		pDest->x = pSrc->x;
		pDest->y = pSrc->y;
		pDest->z = pSrc->z;
		pDest->nx = pSrc->nx;
		pDest->ny = pSrc->ny;
		pDest->nz = pSrc->nz;
		pDest->tu0 = pSrc->tu0;
		pDest->tv0 = pSrc->tv0;
//		pDest->tu1 = pSrc->tu0;
//		pDest->tv1 = pSrc->tv0;
		pSrc += 1;
		pDest += 1;
	}
	pVB->Unlock();
	pVB->Release();
	this->pVB->Unlock();

	//�C���f�b�N�X�̃R�s�[
	pMesh->GetIndexBuffer(&pSrcIndex);
	pSrcIndex->Lock(0,0,(BYTE**)&pISrc,0);
	this->pIndex->Lock(0,0,(BYTE**)&pIDest,0);
	CopyMemory(pIDest,pISrc,nMeshFaces * 3 * sizeof(WORD));
	pSrcIndex->Unlock();
	this->pIndex->Unlock();
	pSrcIndex->Release();

	// pD3DXMtrlBuffer ����A������e�N�X�`���[�̏���ǂݎ��
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	this->pTextures = new LPDIRECT3DTEXTURE8[this->dwNumMaterials];
	this->pMaterials = new D3DMATERIAL8[this->dwNumMaterials];

	for(i = 0; i < this->dwNumMaterials; i++){
		this->pMaterials[i] = d3dxMaterials[i].MatD3D;
		this->pMaterials[i].Ambient = this->pMaterials[i].Diffuse;
        hr = D3DXCreateTextureFromFile( lpD3DDev, 
                                        d3dxMaterials[i].pTextureFilename, 
                                        &this->pTextures[i] );
	    if(FAILED(hr)) this->pTextures[i] = NULL;
	}
	RELEASE(pD3DXMtrlBuffer);
	
	RELEASE(pMesh);
	
	this->bActive = true;		// �g����悤�ɂȂ�܂���
	
	return S_OK;
}
// ----------------------------------------------------------------------------
void CMyMesh::Release()
{
	DWORD i;

	if(this->pVB == NULL) return;

	for(i=0; i<this->dwNumMaterials; i++){
		RELEASE(this->pTextures[i]);
	}
	delete[] this->pTextures;
	delete[] this->pMaterials;
	delete[] this->pSubsetTable;

	RELEASE(this->pVB);
	RELEASE(this->pIndex);
	
	this->bActive = false;		// �����ł���悤�ɂȂ�܂ŁA�҂�
}
// ----------------------------------------------------------------------------
// �e�N�X�`���[
// ----------------------------------------------------------------------------
HRESULT CTextureMgr::Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, LPDIRECT3DTEXTURE8 *ppTexture)
{
//	HRESULT hr;
	D3DXCreateTextureFromFileEx(lpD3DDev, filename,0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, ppTexture);
	
	return S_OK;
}
// ----------------------------------------------------------------------------
void CTextureMgr::Release(LPDIRECT3DTEXTURE8 pTexture)
{
	RELEASE(pTexture);
}
// ----------------------------------------------------------------------------
// ���_�V�F�[�_�[
// ----------------------------------------------------------------------------
HRESULT CVertexShaderMgr::Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, DWORD *phVertexShader, const DWORD dwDecl[])
{
	HRESULT hr;
	LPD3DXBUFFER	pshader;
	
	hr = D3DXAssembleShaderFromFile(filename, 0,NULL, &pshader, NULL);
	if ( FAILED(hr) ) return hr;
	
	hr = lpD3DDev->CreateVertexShader( dwDecl, (DWORD*)pshader->GetBufferPointer(), phVertexShader, 0 );
	RELEASE(pshader);
	if ( FAILED(hr) ) return hr;
	
	return S_OK;
}
// ----------------------------------------------------------------------------
void CVertexShaderMgr::Release(LPDIRECT3DDEVICE8 lpD3DDev, DWORD *phVertexShader)
{
	if ( *phVertexShader != ~0 ){
		lpD3DDev->DeleteVertexShader( *phVertexShader );
		*phVertexShader = ~0;
	}
}
// ----------------------------------------------------------------------------
// �s�N�Z���V�F�[�_�[
// ----------------------------------------------------------------------------
HRESULT CPixelShaderMgr::Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, DWORD *phPixelShader)
{
	HRESULT hr;
	LPD3DXBUFFER	pshader;
	
	*phPixelShader = NULL;
	hr = D3DXAssembleShaderFromFile(filename, 0,NULL, &pshader, NULL);
	if ( FAILED(hr) ) return hr;
	
	hr = lpD3DDev->CreatePixelShader( (DWORD*)pshader->GetBufferPointer(), phPixelShader);
	RELEASE(pshader);
	if ( FAILED(hr) ) return hr;

	return S_OK;
}
// ----------------------------------------------------------------------------
void CPixelShaderMgr::Release(LPDIRECT3DDEVICE8 lpD3DDev, DWORD *phPixelShader)
{
	if ( *phPixelShader != ~0 ){
		lpD3DDev->DeleteVertexShader( *phPixelShader );
		*phPixelShader = ~0;
	}
}
