// ----------------------------------------------------------------------------
//
// draw.cpp - �`�敔��
// 
// Copyright (c) 2001 if (if@edokko.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include <windows.h>
#include "main.h"
#include "draw.h"
#include "load.h"

static const int SHADOWMAP_HEIGHT = 512;
static const int SHADOWMAP_WIDTH = 512;

LPDIRECT3DVERTEXBUFFER8	pMeshVB = NULL;
LPDIRECT3DINDEXBUFFER8	pMeshIndex = NULL;
D3DXATTRIBUTERANGE		*pSubsetTable = NULL;
DWORD					nMeshFaces = 0;
DWORD					nMeshVertices = 0;
D3DMATERIAL8			*pMeshMaterials = NULL;		// ���b�V���̎���
LPDIRECT3DTEXTURE8		*pMeshTextures  = NULL;		// ���b�V���̃e�N�X�`���[
DWORD					dwNumMaterials = 0L;		// �}�e���A���̐�
FLOAT					MeshRadius;					// ���b�V���̑傫��

DWORD					hVertexShader=~0;			// ���f���̕`��
DWORD					hPixelShader=~0;			// ���f���̕`��


// �e�����Ȃ���`��
LPDIRECT3DSURFACE8		pBackbuffer = NULL;
LPDIRECT3DSURFACE8		lpZbuffer = NULL;
LPDIRECT3DTEXTURE8		pMaskTexture = NULL;		// �}�X�N�p�e�N�X�`���[
DWORD					hShadowPixelShader=~0;
DWORD					hShadowNoTexPixelShader=~0;
DWORD					hShadowVertexShader=~0;
LPDIRECT3DVERTEXBUFFER8	pBlurVB = NULL;
LPDIRECT3DINDEXBUFFER8	pBlurIB = NULL;

LPDIRECT3DTEXTURE8		pTextureCol;
LPDIRECT3DTEXTURE8		pTextureZ;
LPDIRECT3DSURFACE8		pTextureSurfaceCol;
LPDIRECT3DSURFACE8		pTextureSurfaceZ;
LPDIRECT3DTEXTURE8		pLightTexture;
typedef struct {
	float x,y,z;
	float tu,tv;
}D3D_BLUR_VERTEX;
#define D3DFVF_BLUR_VERTEX 		(D3DFVF_XYZ | D3DFVF_TEX1)

DWORD dwBlurDecl[] = {
	D3DVSD_STREAM(0),
	D3DVSD_REG(D3DVSDE_POSITION, D3DVSDT_FLOAT3 ),			//D3DVSDE_POSITION,  0
	D3DVSD_REG(D3DVSDE_TEXCOORD0,D3DVSDT_FLOAT2 ),		    //D3DVSDE_TEXCOORD0, 7  
	D3DVSD_END()
};


// ----------------------------------------------------------------------------
// �O���֐�
void InitBg(LPDIRECT3DDEVICE8 lpD3DDev);
void DrawBg(LPDIRECT3DDEVICE8 lpD3DDev);
void CleanBg(LPDIRECT3DDEVICE8 lpD3DDev);



// ----------------------------------------------------------------------------
// Name: LoadXFile(char* filename, LPDIRECT3DDEVICE8 lpD3DDev)
// Desc: X-File�̓ǂݍ���
//-----------------------------------------------------------------------------
HRESULT LoadXFile(char* filename, LPDIRECT3DDEVICE8 lpD3DDev)
{
	LPD3DXMESH pMesh, pMeshOpt;
	LPD3DXBUFFER pD3DXMtrlBuffer = NULL;
	DWORD i;
	HRESULT hr;

	hr = D3DXLoadMeshFromX(filename, D3DXMESH_MANAGED,
								lpD3DDev, NULL,
								&pD3DXMtrlBuffer, &dwNumMaterials,
								&pMesh);
	if(FAILED(hr)) return E_FAIL;

	//���ёւ��Ă���
	pMesh->Optimize(D3DXMESHOPT_ATTRSORT, NULL, NULL, NULL, NULL, &pMeshOpt);
	RELEASE(pMesh);

	//�A�g���r���[�g�e�[�u��
	pMeshOpt->GetAttributeTable(NULL,&dwNumMaterials);
	pSubsetTable = new D3DXATTRIBUTERANGE[dwNumMaterials];
	pMeshOpt->GetAttributeTable(pSubsetTable, &dwNumMaterials);

	// FVF�ϊ�
	hr = pMeshOpt->CloneMeshFVF(pMeshOpt->GetOptions(), D3DFVF_VERTEX, lpD3DDev, &pMesh);
	if(FAILED(hr)) return E_FAIL;
	RELEASE(pMeshOpt);
	D3DXComputeNormals(pMesh, NULL);

	//Vertex Buffer�ɃR�s�[����
	D3DVERTEX* pSrc;
	D3D_CUSTOMVERTEX* pDest;
	LPDIRECT3DINDEXBUFFER8 pSrcIndex;
	WORD* pISrc;
	WORD* pIDest;

	DWORD nMeshVertices = pMesh->GetNumVertices();
	DWORD nMeshFaces = pMesh->GetNumFaces();
	lpD3DDev->CreateVertexBuffer(nMeshVertices * sizeof(D3D_CUSTOMVERTEX),0,D3DFVF_CUSTOMVERTEX,D3DPOOL_MANAGED,&pMeshVB);
	lpD3DDev->CreateIndexBuffer(nMeshFaces * 3 * sizeof(WORD),0,D3DFMT_INDEX16,D3DPOOL_MANAGED,&pMeshIndex);

	LPDIRECT3DVERTEXBUFFER8 pVB;
	pMesh->GetVertexBuffer(&pVB);
	pVB->Lock(0,0,(BYTE**)&pSrc,0);
	pMeshVB->Lock(0,0,(BYTE**)&pDest,0);
	MeshRadius = 0.0f;
	for(i=0;i<nMeshVertices;i++){
		pDest->x = pSrc->x;
		pDest->y = pSrc->y;
		pDest->z = pSrc->z;
		pDest->nx = pSrc->nx;
		pDest->ny = pSrc->ny;
		pDest->nz = pSrc->nz;
		pDest->tu0 = pSrc->tu0;
		pDest->tu0 = pSrc->tu0;
		// �T�C�Y�̌v�Z
		FLOAT radius = sqrtf( pSrc->x*pSrc->x + pSrc->y*pSrc->y + pSrc->z*pSrc->z );
        if (MeshRadius < radius) MeshRadius = radius;
		
		pSrc += 1;
		pDest += 1;
	}
	pVB->Unlock();
	pVB->Release();
	pMeshVB->Unlock();

	//�C���f�b�N�X�̃R�s�[
	pMesh->GetIndexBuffer(&pSrcIndex);
	pSrcIndex->Lock(0,0,(BYTE**)&pISrc,0);
	pMeshIndex->Lock(0,0,(BYTE**)&pIDest,0);
	CopyMemory(pIDest,pISrc,nMeshFaces * 3 * sizeof(WORD));
	pSrcIndex->Unlock();
	pMeshIndex->Unlock();
	pSrcIndex->Release();

	// pD3DXMtrlBuffer ����A������e�N�X�`���[�̏���ǂݎ��
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	pMeshTextures = new LPDIRECT3DTEXTURE8[dwNumMaterials];
	pMeshMaterials = new D3DMATERIAL8[dwNumMaterials];

	for(i = 0; i < dwNumMaterials; i++){
		pMeshMaterials[i] = d3dxMaterials[i].MatD3D;
		pMeshMaterials[i].Ambient = pMeshMaterials[i].Diffuse;
        hr = D3DXCreateTextureFromFile( lpD3DDev, 
                                        d3dxMaterials[i].pTextureFilename, 
                                        &pMeshTextures[i] );
	    if(FAILED(hr)) pMeshTextures[i] = NULL;
	}
	RELEASE(pD3DXMtrlBuffer);
	
	RELEASE(pMesh);

	return S_OK;
}
//-----------------------------------------------------------------------------
// Name: InitRenderTexture()
// Desc: �����_�����O�e�N�X�`���[�p�̉�����
//-----------------------------------------------------------------------------
HRESULT InitRenderTexture(LPDIRECT3DDEVICE8 lpD3DDev)
{
	HRESULT hr;
	DWORD i;
	
	// ���_�o�b�t�@�̍쐬 
	D3D_BLUR_VERTEX *pBlurDest;
	WORD *pIndex;
    lpD3DDev->CreateVertexBuffer( 4 * sizeof(D3D_BLUR_VERTEX),
                                D3DUSAGE_WRITEONLY, D3DFVF_BLUR_VERTEX, D3DPOOL_MANAGED,
                                &pBlurVB );
	// ���_���Z�b�g�A�b�v
	pBlurVB->Lock ( 0, 0, (BYTE**)&pBlurDest, 0 );
	for (i = 0; i < 4; i++) {
		pBlurDest->x   = (i == 0 || i == 1)?-1:(float)1;
		pBlurDest->y   = (i == 0 || i == 2)?-1:(float)1;
		pBlurDest->z   = 0.0f;
		pBlurDest->tu = (i == 2 || i == 3)?1:(float)0;
		pBlurDest->tv = (i == 0 || i == 2)?1:(float)0;
		pBlurDest++;
	}		
	pBlurVB->Unlock ();
	// �C���f�b�N�X���Z�b�g�A�b�v
    lpD3DDev->CreateIndexBuffer( 6 * sizeof(WORD),
                               0,
                               D3DFMT_INDEX16, D3DPOOL_MANAGED,
                               &pBlurIB );
	pBlurIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
	pIndex[0] = 0;	pIndex[1] = 1;	pIndex[2] = 2;
	pIndex[3] = 1;	pIndex[4] = 3;	pIndex[5] = 2;
	pBlurIB->Unlock ();


	// �`��p�e�N�X�`���[��p�ӂ���
	if( FAILED(hr = lpD3DDev->GetRenderTarget(&pBackbuffer))) return hr;
	if(FAILED(lpD3DDev->GetDepthStencilSurface(&lpZbuffer))) return hr;	// �ǉ�
	
	if(FAILED(hr = lpD3DDev->CreateTexture(SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, 1
						, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
						, D3DPOOL_DEFAULT, &pTextureCol)))
		return hr;
	if(FAILED(hr = lpD3DDev->CreateTexture(SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, 1
						, D3DUSAGE_DEPTHSTENCIL, D3DFMT_D24S8
						, D3DPOOL_DEFAULT, &pTextureZ)))
		return hr;

	if(FAILED(pTextureCol->GetSurfaceLevel(0, &pTextureSurfaceCol)))	return E_FAIL;
	if(FAILED(pTextureZ->GetSurfaceLevel(0, &pTextureSurfaceZ)))		return E_FAIL;

	
	if(FAILED(D3DXCreateTextureFromFileEx(lpD3DDev, 
										  "spotlight.bmp", 
										  SHADOWMAP_WIDTH,
										  SHADOWMAP_HEIGHT,
										  1,
										  D3DUSAGE_RENDERTARGET,
										  D3DFMT_A8R8G8B8,
										  D3DPOOL_DEFAULT,
										  D3DX_DEFAULT,
										  D3DX_DEFAULT,
										  0,
										  NULL,
										  NULL,
										  &pLightTexture))) return hr;


	// �V�F�|�_�[�̃��[�h
	if ( FAILED( CPixelShaderMgr::Load(lpD3DDev, "shadow_nocol.psh",    &hShadowPixelShader)) ) return hr;
	if ( FAILED( CPixelShaderMgr::Load(lpD3DDev, "shadow_notex.psh",    &hShadowNoTexPixelShader)) ) return hr;
	if ( FAILED(CVertexShaderMgr::Load(lpD3DDev, "shadow.vsh",    &hShadowVertexShader, dwDecl)) ) return hr;
	
	return S_OK;
}
//-----------------------------------------------------------------------------
// Name: InitRender()
// Desc: Load the mesh and build the material and texture arrays
//-----------------------------------------------------------------------------
HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	HRESULT hr;

	// ���f���̓ǂݍ���
	if ( FAILED(hr = LoadXFile("nsx.x", lpD3DDev)) ) return hr;
	
	// �}�X�N�p�e�N�X�`���[�̓ǂݍ���
	if ( FAILED(CTextureMgr::Load(lpD3DDev, "mask.bmp",     &pMaskTexture)) ) return hr;
	
	// �o�[�e�b�N�X�V�F�[�_�[���쐬����
	if ( FAILED(CVertexShaderMgr::Load(lpD3DDev, "vs.vsh",     &hVertexShader, dwDecl)) ) return hr;
	if ( FAILED( CPixelShaderMgr::Load(lpD3DDev, "ps.psh",      &hPixelShader)) ) return hr;
	
	// �����_�����O�e�N�X�`���[�p�̏�����
	InitRenderTexture(lpD3DDev);
	
	// �w�i�����̏�����
	InitBg(lpD3DDev);

	// �s�ςȃ��W�X�^�̐ݒ�
	lpD3DDev->SetRenderState( D3DRS_ZENABLE, TRUE );
    lpD3DDev->SetRenderState( D3DRS_LIGHTING,  FALSE );
	lpD3DDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	lpD3DDev->SetVertexShaderConstant(12, &D3DXVECTOR4(0.0f, 0.5f, 1.0f, 2.0f), 1);

	// �f�J�[��
	lpD3DDev->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_NONE);
	
	// �e�}�b�v
	lpD3DDev->SetTextureStageState(1, D3DTSS_ADDRESSU, D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(1, D3DTSS_ADDRESSV, D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(1, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(1, D3DTSS_MIPFILTER, D3DTEXF_NONE);

	// ���C�g�}�b�v
	lpD3DDev->SetTextureStageState(2, D3DTSS_ADDRESSU, D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(2, D3DTSS_ADDRESSV, D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(2, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(2, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	lpD3DDev->SetTextureStageState(2, D3DTSS_MIPFILTER, D3DTEXF_NONE);

	return S_OK;
}
//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
const float z_min =   1.0f;
const float z_max  = 70.0f;
D3DXVECTOR4 lightDir(1.0f, 1.0f, 0.5f, 0.0f);

VOID DrawModel(LPDIRECT3DDEVICE8 lpD3DDev, BOOL bShadowMap)
{
	D3DXMATRIX mVP,  mWorld, mView,  mProj;
	D3DXMATRIX mVPL, mLight, mViewL, mProjL;
	D3DXMATRIX	m;
	D3DXVECTOR4 vl;
	DWORD i;
	
	// 
	// �ʏ탌���_�����O�p�̍s����쐬
	// 
	// �r���[�s��
	D3DXVECTOR3 eye    = D3DXVECTOR3(0.0f,1.4f*MeshRadius,2.5f*MeshRadius);
	D3DXVECTOR3 lookAt = D3DXVECTOR3(0.0f,  0.0f,  0.0f);
	D3DXVECTOR3 up     = D3DXVECTOR3(0.0f,  1.0f,  0.0f);
	D3DXMatrixLookAtLH(&mView, &eye, &lookAt, &up);
	// �ˉe�s��
	D3DXMatrixPerspectiveFovLH(&mProj
		, D3DXToRadian(60.0f)						// ����p
		, (float)WIDTH/(float)HEIGHT				// �A�X�y�N�g��
		, z_min, z_max								// �ŋߐڋ���,�ŉ�������
		);
	
	mVP = mView * mProj;

	// 
	// ���C�g��������̃����_�����O�p�̍s����쐬
	// 
	// �r���[�s��
	D3DXVECTOR3 l_eye    = 30.0f*lightDir;
	D3DXVECTOR3 l_lookAt = D3DXVECTOR3(0.0f,  0.0f,  0.0f);
	D3DXVECTOR3 l_up     = D3DXVECTOR3(0.0f,  1.0f,  0.0f);
	D3DXMatrixLookAtLH(&mViewL, &l_eye, &l_lookAt, &l_up);
	// �ˉe�s��
	D3DXMatrixPerspectiveFovLH(&mProjL
		, D3DXToRadian(60.0f)							// ����p
		, (float)SHADOWMAP_WIDTH/(float)SHADOWMAP_HEIGHT// �A�X�y�N�g��
		, 1.0f, 70.0f									// �ŋߐڋ���,�ŉ�������
		);
	mVPL = mViewL * mProjL;

	// �ˉe��Ԃ���A�e�N�X�`���[�̋�Ԃɕϊ�����
	float fOffsetX = 0.5f + (0.5f / (float)SHADOWMAP_WIDTH);
	float fOffsetY = 0.5f + (0.5f / (float)SHADOWMAP_HEIGHT);
	unsigned int range = 0xFFFFFFFF >> (32 - 24);
	float fBias    = +0.000001f * (float)range;// �J�����O�𔽑΂ɂ���̂ŁA�ʏ�Ƃ͋t�̃I�t�Z�b�g
	D3DXMATRIX mScaleBias( 0.5f,     0.0f,     0.0f,         0.0f,
		                   0.0f,    -0.5f,     0.0f,         0.0f,
						   0.0f,     0.0f,     (float)range, 0.0f,
						   fOffsetX, fOffsetY, fBias,        1.0f );

	mLight = mVPL * mScaleBias;

	//
	// �����_�����O��Ԃ̐ݒ�
	// 
	if(bShadowMap){
		lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	}else{
		lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	}
	
	//
	// �O�����ł�`��
	//
	int t = timeGetTime()%314159;
	D3DXMatrixTranslation(&m, 1.5f*MeshRadius, 0,0);
	D3DXMatrixRotationY( &mWorld, t/1000.0f );
//D3DXMatrixRotationY( &mWorld, -0.2*PI/2 ); // �B�e�p�x
	mWorld = m * mWorld;
	
	if(bShadowMap){
		m = mWorld * mVPL;
	}else{
		m = mWorld * mLight;
		D3DXMatrixTranspose( &m ,  &m);
		lpD3DDev->SetVertexShaderConstant(4,&m, 4);

		m = mWorld * mVP;
	}
	D3DXMatrixTranspose( &m ,  &m);
	lpD3DDev->SetVertexShaderConstant(0,&m, 4);

	D3DXMatrixInverse( &m,  NULL, &mWorld);
	D3DXVec4Transform(&vl, &lightDir, &m);
	D3DXVec4Normalize(&vl, &vl);
	vl[3] = 0.1f;// w�����͊��F�̋���
	lpD3DDev->SetVertexShaderConstant(13, &vl, 1);
	
	lpD3DDev->SetStreamSource(0, pMeshVB, sizeof(D3D_CUSTOMVERTEX));
	lpD3DDev->SetIndices(pMeshIndex,0);
	
	for(i=0;i<dwNumMaterials;i++){
		//�F���Z�b�g
		D3DXVECTOR4 vl;
		vl.x = pMeshMaterials[i].Diffuse.r;
		vl.y = pMeshMaterials[i].Diffuse.g;
		vl.z = pMeshMaterials[i].Diffuse.b;
		lpD3DDev->SetVertexShaderConstant(14, &vl, 1);

		lpD3DDev->SetTexture(0,pMeshTextures[i]);
		lpD3DDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 
										pSubsetTable[i].VertexStart,
										pSubsetTable[i].VertexCount,
										pSubsetTable[i].FaceStart * 3,
										pSubsetTable[i].FaceCount);
	}
	//
	// ���f��2
	//
	D3DXMatrixRotationY( &mWorld, -t/3000.0f );
//D3DXMatrixRotationY( &mWorld, 1.4f*PI/2 ); // �B�e�p�x
	if(bShadowMap){
		m = mWorld * mVPL;
	}else{
		m = mWorld * mLight;
		D3DXMatrixTranspose( &m ,  &m);
		lpD3DDev->SetVertexShaderConstant(4,&m, 4);

		m = mWorld * mVP;
	}
	D3DXMatrixTranspose( &m ,  &m);
	lpD3DDev->SetVertexShaderConstant(0,&m, 4);

	D3DXMatrixInverse( &m,  NULL, &mWorld);
	D3DXVec4Transform(&vl, &lightDir, &m);
	D3DXVec4Normalize(&vl, &vl);
	vl[3] = 0.1f;// w�����͊��F�̋���
	lpD3DDev->SetVertexShaderConstant(13, &vl, 1);
	
	for(i=0;i<dwNumMaterials;i++){
		//�F���Z�b�g
		D3DXVECTOR4 vl;
		vl.x = pMeshMaterials[i].Diffuse.r;
		vl.y = pMeshMaterials[i].Diffuse.g;
		vl.z = pMeshMaterials[i].Diffuse.b;
		lpD3DDev->SetVertexShaderConstant(14, &vl, 1);

		lpD3DDev->SetTexture(0,pMeshTextures[i]);
		lpD3DDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 
										pSubsetTable[i].VertexStart,
										pSubsetTable[i].VertexCount,
										pSubsetTable[i].FaceStart * 3,
										pSubsetTable[i].FaceCount);
	}
	//
	// �w�i�`��
	// 
	if(!bShadowMap){// �V���h�E�}�b�v�쐬���͉e�ɂȂ�Ȃ����i�͕\�����Ȃ�
		lpD3DDev->SetPixelShader(hShadowPixelShader);
		D3DXMatrixScaling(&mWorld, 3.0f, 3.0f, 3.0f);
		
		if(bShadowMap){
			m = mWorld * mVPL;
		}else{
			m = mWorld * mLight;
			D3DXMatrixTranspose( &m ,  &m);
			lpD3DDev->SetVertexShaderConstant(4,&m, 4);

			m = mWorld * mVP;
		}
		D3DXMatrixTranspose( &m ,  &m);
		lpD3DDev->SetVertexShaderConstant(0,&m, 4);
		
		lpD3DDev->SetVertexShaderConstant(13, &D3DXVECTOR4(0.0f, 0.0f, 0.0f, 1.0f), 1);
		lpD3DDev->SetVertexShaderConstant(14, &D3DXVECTOR4(1.0f, 1.0f, 1.0f, 0.0f), 1);
		DrawBg(lpD3DDev);
	}
}
//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render(LPDIRECT3DDEVICE8 lpD3DDev)
{
	// ------------------------------------------------------------------------
	// �e�}�b�v�̍쐬
	// ------------------------------------------------------------------------
	// �e�N�X�`���[�Ƀ����_�����O����
	lpD3DDev->SetRenderTarget(pTextureSurfaceCol, pTextureSurfaceZ);
	// �r���[�|�[�g�̕ύX       x y         w                h      min_z max_z
	D3DVIEWPORT8 newViewport = {0,0,SHADOWMAP_WIDTH, SHADOWMAP_HEIGHT, 0, 1};
	D3DVIEWPORT8 oldViewport;
	lpD3DDev->GetViewport(&oldViewport);
	lpD3DDev->SetViewport(&newViewport);
	// �������̂��߂ɁA�[�x�����X�V����
	lpD3DDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0);
	// �[�x������������
	lpD3DDev->Clear(0, NULL, D3DCLEAR_ZBUFFER, 0x000000, 1.0f, 0L);

	// �V�F�[�_�[�̐ݒ�
	lpD3DDev->SetVertexShader(hVertexShader);
	lpD3DDev->SetPixelShader(hPixelShader);
	
	DrawModel(lpD3DDev, 1);

	// ------------------------------------------------------------------------
	// �V�[���̍쐬
	// ------------------------------------------------------------------------
	// �`���߂�
	lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );
	lpD3DDev->SetViewport(&oldViewport);
	lpD3DDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0x7);
	lpD3DDev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x000000, 1.0f, 0L);

	// �V�F�[�_�[�̐ݒ�
	lpD3DDev->SetVertexShader(hShadowVertexShader);	
	lpD3DDev->SetPixelShader(hShadowNoTexPixelShader);	

	lpD3DDev->SetTexture( 1, pTextureZ );					// �e�}�b�v
	lpD3DDev->SetTexture( 2, pLightTexture );				// ���C�g�e�N�X�`���[
	DrawModel(lpD3DDev, 0);
	
	// ���Ń����_�����O���Ă���肪�o�Ȃ��ݒ�ɂ���
	lpD3DDev->SetTexture( 0, NULL );
	lpD3DDev->SetTexture( 1, NULL );
	lpD3DDev->SetTexture( 2, NULL );
	lpD3DDev->SetPixelShader(0);
}
//-----------------------------------------------------------------------------
// ���b�V���I�u�W�F�N�g�폜
//-----------------------------------------------------------------------------
void DeleteMeshObject(void)
{
	DWORD i;

	if(pMeshVB == NULL) return;

	for(i=0; i<dwNumMaterials; i++){
		RELEASE(pMeshTextures[i]);
	}
	delete[] pMeshTextures;
	delete[] pMeshMaterials;
	delete[] pSubsetTable;

	RELEASE(pMeshVB);
	RELEASE(pMeshIndex);
}
//-----------------------------------------------------------------------------
// Name: CleanRender()
// Desc: ��n��
//-----------------------------------------------------------------------------
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	CleanBg(lpD3DDev);
	
	RELEASE(pTextureSurfaceZ);
	RELEASE(pTextureSurfaceCol);
	RELEASE(pTextureZ);
	RELEASE(pTextureCol);
	RELEASE(pLightTexture);
	
	RELEASE(pBackbuffer);
	
	CPixelShaderMgr::Release(lpD3DDev, &hShadowNoTexPixelShader);
	CPixelShaderMgr::Release(lpD3DDev, &hShadowPixelShader);
	CVertexShaderMgr::Release(lpD3DDev, &hShadowVertexShader);
	CPixelShaderMgr::Release(lpD3DDev, &hPixelShader);
	CVertexShaderMgr::Release(lpD3DDev, &hVertexShader);
	
	RELEASE(pMaskTexture);
	DeleteMeshObject();
}
