// ----------------------------------------------------------------------------
//
// draw.h - �S�̓I�Ȓ�`
// 
// Copyright (c) 2001 if (if@edokko.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _DRAW_H
#define	_DRAW_H

#include <d3d8.h>
#include <d3dx8.h>

HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDEV);	// ������
void Render(LPDIRECT3DDEVICE8 lpD3DDEV);		// �`��
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDEV);	// ��Еt��

// ----------------------------------------------------------------------------
// ���_�̒�`
typedef struct {
	float x,y,z;
	float nx,ny,nz;
	float tu0,tv0;
}D3DVERTEX;
#define D3DFVF_VERTEX 		(D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)



#endif /* !_DRAW_H */
