// --------------------------------------------------------------------------
//
//   src\file_tbl.cpp
//
// Copyright 2004 Takashi Imagire. All rights reserved.
// --------------------------------------------------------------------------

#include "engine.h"
#include "file_tbl.h"

	enum
	{
		// �e�f�[�^�ɉ��Ԃ̃t�@�C���������Ă��邩
		FILE_NO_DATA0_BEGIN = 0,
		FILE_NO_DATA0_END   = FILE_NO_DATA0_BEGIN + 11,
		FILE_NO_DATA1_BEGIN = 11,
		FILE_NO_DATA1_END   = FILE_NO_DATA1_BEGIN + 1,
		FILE_NO_DATA2_BEGIN = 12,
		FILE_NO_DATA2_END   = FILE_NO_DATA2_BEGIN + 1,
		FILE_NO_DATA3_BEGIN = 13,
		FILE_NO_DATA3_END   = FILE_NO_DATA3_BEGIN + 6,
	};
	
	const Te::File::IMAGE_DATA image_data[] =
	{
		// �ǂݍ��ރf�[�^�̏��
		{"data0", FILE_NO_DATA0_BEGIN, FILE_NO_DATA0_END },
		{"data1", FILE_NO_DATA1_BEGIN, FILE_NO_DATA1_END },
		{"data2", FILE_NO_DATA2_BEGIN, FILE_NO_DATA2_END },
		{"data3", FILE_NO_DATA3_BEGIN, FILE_NO_DATA3_END },
		{0},
	};
