// ----------------------------------------------------------------------------
//
// ai_npc_akari.cpp - �Ƃ肠����NPC
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <stdlib.h>
#include "ai_npc.h"
#include "ai_npc_akari.h"
#include "ai_npc_player.h"

namespace Ai
{
	// -----------------------------------------------------------------------
	// �v���C���[����������
	// -----------------------------------------------------------------------
	CNpc *CNpc::CreateNPC(NPC_TYPE type)
	{
		switch( type )
		{
		case NPC_PLAYER:
			return new CNpcPlayer();
			break;
		case NPC_GOD:
		default:
			return new CNpcAkari();
			break;
		case NPC_AKARI:
			return new CNpcAkari();
			break;
		}
	}
	
}// namespace ai

