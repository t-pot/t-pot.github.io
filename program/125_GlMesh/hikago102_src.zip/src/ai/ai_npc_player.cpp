// ----------------------------------------------------------------------------
//
// ai_npc_akari.cpp - �Ƃ肠����NPC
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <stdlib.h>
#include "TE/te.h"
#include "ai_npc_player.h"

void GetCursolBoard( Go::BOARD_POINT dest );

namespace Ai
{
	// -----------------------------------------------------------------------
	// �l����
	// -----------------------------------------------------------------------
	bool CNpcPlayer::ThinkMove( Go::GOISHI_TYPE color, Go::BOARD_POINT dest, float dt )
	{
		if( Te::GetMouseInfo()->trg & Te::MOUSE_L )
		{
			// ������
			
			// �p�X
			Te::rect sr;
			Te::GetScreenRect( &sr );
			int x = Te::GetMouseInfo()->pos[0];
			int y = Te::GetMouseInfo()->pos[1];
			if(  0                           < x && x < 0.10 * sr.right
			 && sr.bottom - 0.05 * sr.bottom < y && y <        sr.bottom )
			{
				dest[0] = dest[1] = Go::BOARD_PASS;
				return true;
			}
			// ����
			if( sr.right  - 0.10 * sr.right  < x && x < sr.right
			 && sr.bottom - 0.05 * sr.bottom < y && y < sr.bottom)
			{
				dest[0] = dest[1] = Go::BOARD_RESIGN;
				return true;
			}

			// �łĂ�ꏊ�H
			Go::BOARD_POINT cur;
			GetCursolBoard( cur );
			if( 0 == _pBoard->CheckLegal( color, cur[0], cur[1], _pBoard->_iBoard ))
			{
				dest[0] = cur[0];
				dest[1] = cur[1];
				
				return true;
			}
		}

		return false;
	}
}// namespace ai

