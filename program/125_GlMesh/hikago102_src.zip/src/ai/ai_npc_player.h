// ----------------------------------------------------------------------------
//
// ai_npc_player.h - NPC�̊��N���X����h�������v���C���[�̐���
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __AI_NPC_PLAYER_H__
#define __AI_NPC_PLAYER_H__

#include "go_common.h"
#include "ai_npc.h"

namespace Ai
{
	// -----------------------------------------------------------------------
	// ���N���X
	// -----------------------------------------------------------------------
	class CNpcPlayer  : public CNpc
	{
	protected:
		
	public:
		 CNpcPlayer() : CNpc() {}
		~CNpcPlayer(){;}
		
		void Init( Go::CBoard *p ){ CNpc::Init(p);}
		bool ThinkMove( Go::GOISHI_TYPE color, Go::BOARD_POINT dest, float dt );
	};
	
}// namespace ai

#endif // !__AI_NPC_H__
