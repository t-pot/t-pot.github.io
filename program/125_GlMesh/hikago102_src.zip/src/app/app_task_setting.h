// ----------------------------------------------------------------------------
//
// app_task_setting.h - ���ڐݒ�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_SETTING_H__
#define __APP_TASK_SETTING_H__

#include "app_task.h"
#include "ai/go_common.h"

namespace Application
{
	// ------------------------------------------------------------------------
	// �{�^���z�u�\����
	// ------------------------------------------------------------------------
	typedef enum
	{
		BTN_OFF,
		BTN_ON,
		BTN_SELECTED,
	}BTN_STATE;

	typedef struct BTN_PLACEMENT
	{
		unsigned int id;
		float        x;
		float        y;
		float        w;
		float        h;
		BTN_STATE    state; // ���I�ɕω�������
	} *PBTN_PLACEMENT;

	// ------------------------------------------------------------------------
	// �ݒ��ʃN���X
	// ------------------------------------------------------------------------
	class CTaskSetting : public CTask
	{
	private:
		float _time;
		float _a;
		int _state;
		Go::SETTING_DATA _play_setting;

	public:
		 CTaskSetting();
		~CTaskSetting();
		
		int  FrameMove( float dt );
		void Render();
		
	};

}// namespace Application


#endif // !__APP_TASK_SETTING_H__
