// ----------------------------------------------------------------------------
//
// app_task_demo.cpp - �f���v���C�̃^�X�N
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include <stdlib.h>
#include "TE/te.h"
#include "play/app_play_game.h"
#include "ai/ai_npc.h"
#include "app_task_tbl.h"
#include "app_task_demo.h"
#include "file_tbl.h"

// ===========================================================================
// �ϐ�
// ===========================================================================

namespace Application
{

// ===========================================================================
// �ϐ�
// ===========================================================================
static Go::SETTING_DATA s_demo_setting =
{
	{
		19, // 19/13/9/6�H
		0,  // �u��:0�`36�q
		0,  // ����Aplayer0���ԁAplayer1����
		13, // �R�~�F�Q�{�����l(6�ڔ��Ȃ�13)
	},{
		{"PLAYER0", Ai::NPC_AKARI},
		{"PLAYER1", Ai::NPC_AKARI},
	},
};


// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskDemo::CTaskDemo() : CTask()
{
	_iState = STATE_READY;
	_time = 0.0f;
	
	// -----------------------------------------------------------------------
	// �Q�[�������̏�����
	// -----------------------------------------------------------------------
	// �H�Րݒ�
	int rval = rand()/(RAND_MAX/4);
	switch(rval)
	{
	case 0:	s_demo_setting.common.roban =  6;break;
	case 1:	s_demo_setting.common.roban =  9;break;
	case 2:	s_demo_setting.common.roban = 13;break;
	default:s_demo_setting.common.roban = 19;break;
	}
	
	_pGame = new CGame( &s_demo_setting );
	_pGame->EnablePlayerControl( false );
	
	// -----------------------------------------------------------------------
	// �f�[�^�̓ǂݍ���
	// -----------------------------------------------------------------------
#ifdef USE_IMAGE_DATA
	_pTeb = Te::File::SetupTeb( IMG_DATA3 );
#else
	_pTeb = 0;
#endif // USE_IMAGE_DATA
	
	// ��Ղ̃e�N�X�`���̓ǂݍ���
	void *pBitmap = 0;
	switch(_pGame->GetGoban())
	{
	case 6:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN6_BMP, _pTeb );
		break;
	case 9:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN9_BMP, _pTeb );
		break;
	case 13:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN13_BMP, _pTeb );
		break;
	default:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN19_BMP, _pTeb );
		break;
	}
	_goban_tex_id = Te::SetupBitmap( pBitmap );
	_pGame->SetGobanTexture( _goban_tex_id );
	Te::File::DeleteData( pBitmap, _pTeb );

	// �{�^���̃e�N�X�`���̓ǂݍ���
	void *pBitmapButton = Te::File::GetData( FILE_DATA3_BUTTON_BMP, _pTeb );
	_button_tex_id = Te::SetupBitmap( pBitmapButton );
	_pGame->SetButtonTexture( _button_tex_id );
	Te::File::DeleteData( pBitmapButton, _pTeb );

	// ���f���̓ǂݍ���
	void *pMeshData = Te::File::GetData( FILE_DATA3_GOISHI_TMS, _pTeb );
	pMeshGoishi = Te::SetupTms( pMeshData );
	_pGame->SetGoishiMesh( pMeshGoishi );
}

// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskDemo::~CTaskDemo( )
{
	if( _pGame ) delete _pGame; _pGame = 0;
	
	// ���f��
	Te::ClenaTms( pMeshGoishi );

	Te::DeleteBitmap( _goban_tex_id );  _goban_tex_id  = 0;
	Te::DeleteBitmap( _button_tex_id ); _button_tex_id = 0;
	Te::File::DeleteTeb( _pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskDemo::FrameMove( float dt )
{
	switch(_iState)
	{
	case STATE_READY:// �΋ǑO
		_time += dt;
		_a = 1.0f - _time / 1.0f;
		if( 1.0f < _time )
		{
			_iState = STATE_PLAY;
			_a = 0.0f;
			_time = 0;
		}
		break;
	case STATE_PLAY:// �΋ǒ�
		_time += dt;
		if(_pGame->FrameMove( dt ) || 60.0f < _time )
		{
			_iState = STATE_OUT;
			_time = 0;
		}
		break;
	case STATE_OUT:// �I���
		_time += dt;
		_a = _time / 1.0f;
		if( 1.0f < _time )
		{
			_a = 1.0f;
			return TASK_ID_CREDIT;
		}
		break;
	}
	
	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskDemo::Render()
{
	Te::BeginRender();

	_pGame->Render();

	// ���t�F�[�h
	if( 0.00000001f < _a )
	{
		Te::FillSceneFilter( 0.0f, 0.0f, 0.0f, _a );
	}

	Te::EndRender();
}

}// namespace Application
