// ----------------------------------------------------------------------------
//
// app_task_play.cpp - �Q�[���v���C�̃^�X�N
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

//#include <stdio.h>
//#include <GL/glut.h>
//#include "ai/go_log.h"
//#include "ai/go_string.h"
//#include "ai/ai_npc.h"
//#include "main.h"
#include "TE/te.h"
#include "play/app_play_game.h"
#include "app_task_tbl.h"
#include "app_task_play.h"
#include "file_tbl.h"

// ===========================================================================
// �ϐ�
// ===========================================================================

namespace Application
{
// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTaskPlay::CTaskPlay() : CTask()
{
	_iState = STATE_READY;
	_time = 0.0f;
	_a = 1.0f;
	
#ifdef USE_IMAGE_DATA
	_pTeb = Te::File::SetupTeb( IMG_DATA3 );
#else
	_pTeb = 0;
#endif // USE_IMAGE_DATA
	
	// �Q�[�������̏�����
	_pGame = new CGame( 0 );
	
	// ��Ղ̃e�N�X�`���̓ǂݍ���
	void *pBitmap = 0;
	switch(_pGame->GetGoban())
	{
	case 6:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN6_BMP, _pTeb );
		break;
	case 9:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN9_BMP, _pTeb );
		break;
	case 13:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN13_BMP, _pTeb );
		break;
	default:
		pBitmap = Te::File::GetData( FILE_DATA3_GOBAN19_BMP, _pTeb );
		break;
	}
	_goban_tex_id = Te::SetupBitmap( pBitmap );
	_pGame->SetGobanTexture( _goban_tex_id );
	Te::File::DeleteData( pBitmap, _pTeb );

	// �{�^���̃e�N�X�`���̓ǂݍ���
	void *pBitmapButton = Te::File::GetData( FILE_DATA3_BUTTON_BMP, _pTeb );
	_button_tex_id = Te::SetupBitmap( pBitmapButton );
	_pGame->SetButtonTexture( _button_tex_id );
	Te::File::DeleteData( pBitmapButton, _pTeb );

	// ���f���̓ǂݍ���
	void *pMeshData = Te::File::GetData( FILE_DATA3_GOISHI_TMS, _pTeb );
	pMeshGoishi = Te::SetupTms( pMeshData );
	_pGame->SetGoishiMesh( pMeshGoishi );
}



// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTaskPlay::~CTaskPlay( )
{
	if( _pGame ) delete _pGame; _pGame = 0;
	
	// ���f��
	Te::ClenaTms( pMeshGoishi );

	Te::DeleteBitmap( _goban_tex_id );  _goban_tex_id  = 0;
	Te::DeleteBitmap( _button_tex_id ); _button_tex_id = 0;
	Te::File::DeleteTeb( _pTeb );
}

// ---------------------------------------------------------------------------
// �X�V�֐�
// ---------------------------------------------------------------------------
int CTaskPlay::FrameMove( float dt )
{
	switch(_iState)
	{
	case STATE_READY:// �΋ǑO
		_time += dt;
		_a = 1.0f - _time/1.0f;
		if( 1.0f < _time )
		{
			_a = 0.0f;
			_iState = STATE_PLAY;
		}
		break;
	case STATE_PLAY:// �΋ǒ�
		if(_pGame->FrameMove( dt ))
		{
			_iState = AFTER_PLAY;
		}
		break;
	case AFTER_PLAY:// �΋ǏI��
		if( Te::GetMouseInfo()->trg & Te::MOUSE_L )
		{
			_iState = STATE_OUT;
			_time = 0.0f;
		}
		break;
	case STATE_OUT:// �I���
		_time += dt;
		_a = _time/1.0f;
		if( 1.0f < _time )
		{
			_a = 1.0f;
			return TASK_ID_CREDIT;
		}
		break;
	}
	
	return INVALID_ID;
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTaskPlay::Render()
{
	Te::BeginRender();

	_pGame->Render();

	// ���t�F�[�h
	if( 0.00000001f < _a )
	{
		Te::FillSceneFilter( 0.0f, 0.0f, 0.0f, _a );
	}

	Te::EndRender();
}

}// namespace Application
