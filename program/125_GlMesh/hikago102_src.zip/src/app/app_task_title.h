// ----------------------------------------------------------------------------
//
// app_task_title.h - �^�C�g���^�X�N�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_TITLE_H__
#define __APP_TASK_TITLE_H__

#include "app_task.h"

namespace Application
{
	class CTaskTitle : public CTask
	{
	private:
		typedef enum
		{
			FADE_IN = 0,    // �t�F�[�h�C��
			WAIT,           // �L�[�҂�
			TO_PLAY,        // �΋ǂ�
			TO_DEMO,      // �f����
		}PLAY_STATE;

		float _time;
		float _a;
		PLAY_STATE _state;
		unsigned int _tex_id;
	public:
		 CTaskTitle();
		~CTaskTitle();
		
		int  FrameMove( float dt );
		void Render();
		
	};

}// namespace Application


#endif // !__APP_TASK_TITLE_H__
