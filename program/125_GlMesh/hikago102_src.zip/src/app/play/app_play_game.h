// ----------------------------------------------------------------------------
//
// app_play_game.h - �Q�[�����[�v�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_PLAY_GAME_H__
#define __APP_PLAY_GAME_H__

#include "ai/go_common.h"
#include "app_task.h"

namespace Application
{
	class CGame
	{
	private:

		typedef enum
		{
			STATE_READY = 0, // �΋ǑO
			STATE_THINK,     // �΋ǒ�
			AFTER_PLAY,      // �΋ǏI��
		}PLAY_STATE;

		enum
		{
			BOARD_MAX = 20,
		};
		
		Go::SETTING_DATA   _setting;
		unsigned char disp_board [BOARD_MAX][BOARD_MAX]; // �\���p
		float         board_count[BOARD_MAX][BOARD_MAX];// ��������
		
		// ���\�[�X
		unsigned int _goban_tex_id;
		unsigned int _button_tex_id;
		Te::PTMS     _pMeshGoishi;
		
		void InitDispBoard();
		void UpdateDispBoard( );
		void FrameMoveDispBoard( float dt );
		void RenderDispBoard( float scale, float bias );

		float _time;
		PLAY_STATE _iState;
		bool       _bShowJiai;
		bool       _bPlayerControl; // ���ꂪFALSE���ƁA�}�E�X������󂯕t���Ȃ�

	public:

		 CGame( const Go::SETTING_DATA *pSetting );
		~CGame();
		
		int  FrameMove( float dt );
		void Render();
		
		unsigned int GetGoban() const {return _setting.common.roban;}
		
		void SetGobanTexture (unsigned int tex_id) { _goban_tex_id = tex_id;}
		void SetButtonTexture(unsigned int tex_id) {_button_tex_id = tex_id;}
		void SetGoishiMesh( Te::PTMS mesh ) {_pMeshGoishi = mesh;}

		void EnablePlayerControl(bool b){_bPlayerControl = b;}
	};

}// namespace Application


#endif // !__APP_PLAY_GAME_H__
