// ----------------------------------------------------------------------------
//
// app_task_play.h - �Q�[���^�X�N�̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_PLAY_H__
#define __APP_TASK_PLAY_H__

#include "app_task.h"
#include "TE/te.h"

namespace Application
{
	// ------------------------------------------------------------------------
	// �N���X�錾
	// ------------------------------------------------------------------------
	class CGame;

	// ------------------------------------------------------------------------
	// �Q�[���v���C�^�X�N
	// ------------------------------------------------------------------------
	class CTaskPlay : public CTask
	{
	private:
		typedef enum
		{
			STATE_READY = 0, // �΋ǑO
			STATE_PLAY,      // �΋ǒ�
			AFTER_PLAY,      // �΋ǏI��
			STATE_OUT,       // �I���
		}PLAY_STATE;

		float _time;
		float _a;
		PLAY_STATE _iState;
		CGame *_pGame;
		
		void *_pTeb;
		unsigned int _goban_tex_id;
		unsigned int _button_tex_id;
		Te::PTMS pMeshGoishi;
		
	public:

		 CTaskPlay();
		~CTaskPlay();
		
		int  FrameMove( float dt );
		void Render();
	};

}// namespace Application


#endif // !__APP_TASK_PLAY_H__
