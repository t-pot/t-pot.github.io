// ----------------------------------------------------------------------------
//
// task.h - �^�X�N�Ǘ��̃w�b�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef __APP_TASK_H__
#define __APP_TASK_H__

namespace Application
{
	class CTask
	{
	public:
		enum
		{
			INVALID_ID = -1,
		};
		         CTask(){}
		virtual ~CTask(){}
		
		virtual int  FrameMove( float dt ){return INVALID_ID;}
		virtual void Render(){}
		
	};
	
	class CTaskMgr
	{
	protected:
		CTask *_pCurrent;
		int   _next;

		CTask *CreateTask( int task_id );
	public:
		 CTaskMgr( int task_id );
		~CTaskMgr();
		
		void Update( float dt );
	};
	
}// namespace Application


#endif // !__APP_TASK_H__
