// --------------------------------------------------------------------------
//
//   src\file_tbl.h
//
// Copyright 2004 Takashi Imagire. All rights reserved.
// --------------------------------------------------------------------------

#ifndef __FILE_TBL_H__
#define __FILE_TBL_H__


	// image �̃t�@�C����
	#define IMG_DATA0 "data0"
	#define IMG_DATA1 "data1"
	#define IMG_DATA2 "data2"
	#define IMG_DATA3 "data3"

#ifdef USE_IMAGE_DATA

	// �t�@�C���̃C���f�b�N�X
	#define FILE_DATA0_0FONT_BMP ((unsigned int)0) 
	#define FILE_DATA0_1FONT_BMP ((unsigned int)1) 
	#define FILE_DATA0_2FONT_BMP ((unsigned int)2) 
	#define FILE_DATA0_3FONT_BMP ((unsigned int)3) 
	#define FILE_DATA0_4FONT_BMP ((unsigned int)4) 
	#define FILE_DATA0_5FONT_BMP ((unsigned int)5) 
	#define FILE_DATA0_6FONT_BMP ((unsigned int)6) 
	#define FILE_DATA0_7FONT_BMP ((unsigned int)7) 
	#define FILE_DATA0_BUTTON_BMP ((unsigned int)8) 
	#define FILE_DATA0_FONT_BMP ((unsigned int)9) 
	#define FILE_DATA0_WINDOW_BMP ((unsigned int)10) 
	#define FILE_DATA1_T_POT_BMP ((unsigned int)11) 
	#define FILE_DATA2_TITLE_BMP ((unsigned int)12) 
	#define FILE_DATA3_BUTTON_BMP ((unsigned int)13) 
	#define FILE_DATA3_GOBAN13_BMP ((unsigned int)14) 
	#define FILE_DATA3_GOBAN19_BMP ((unsigned int)15) 
	#define FILE_DATA3_GOBAN6_BMP ((unsigned int)16) 
	#define FILE_DATA3_GOBAN9_BMP ((unsigned int)17) 
	#define FILE_DATA3_GOISHI_TMS ((unsigned int)18) 

#else // USE_IMAGE_DATA

	// �t�@�C���̖��O
	#define FILE_DATA0_0FONT_BMP "data0/0font.bmp"
	#define FILE_DATA0_1FONT_BMP "data0/1font.bmp"
	#define FILE_DATA0_2FONT_BMP "data0/2font.bmp"
	#define FILE_DATA0_3FONT_BMP "data0/3font.bmp"
	#define FILE_DATA0_4FONT_BMP "data0/4font.bmp"
	#define FILE_DATA0_5FONT_BMP "data0/5font.bmp"
	#define FILE_DATA0_6FONT_BMP "data0/6font.bmp"
	#define FILE_DATA0_7FONT_BMP "data0/7font.bmp"
	#define FILE_DATA0_BUTTON_BMP "data0/button.bmp"
	#define FILE_DATA0_FONT_BMP "data0/font.bmp"
	#define FILE_DATA0_WINDOW_BMP "data0/window.bmp"
	#define FILE_DATA1_T_POT_BMP "data1/t_pot.bmp"
	#define FILE_DATA2_TITLE_BMP "data2/title.bmp"
	#define FILE_DATA3_BUTTON_BMP "data3/button.bmp"
	#define FILE_DATA3_GOBAN13_BMP "data3/goban13.bmp"
	#define FILE_DATA3_GOBAN19_BMP "data3/goban19.bmp"
	#define FILE_DATA3_GOBAN6_BMP "data3/goban6.bmp"
	#define FILE_DATA3_GOBAN9_BMP "data3/goban9.bmp"
	#define FILE_DATA3_GOISHI_TMS "data3/goishi.tms"

#endif // USE_IMAGE_DATA

#endif // !__FILE_TBL_H__
