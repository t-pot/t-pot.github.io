// ---------------------------------------------------------------------------
// te_tem_struct.h
//      T-pot Engine Model data
// ---------------------------------------------------------------------------
#ifndef __TE_TEM_STRUCT_H__
#define __TE_TEM_STRUCT_H__

#include "TE/te_model.h"

namespace Te
{
	// -----------------------------------------------------------------------
	// ���b�V���f�[�^
	// -----------------------------------------------------------------------
	// +--------------------------+
	// |          header          |
	// +--------------------------+
	// |      position array      |
	// +--------------------------+
	// |       normal array       |
	// +--------------------------+
	// | texture coordinate array |
	// +--------------------------+
	//         �S�o�C�g�A���C�����g
	
	typedef struct TMS_HEADER
	{
		char         signiture[4];  // "TMS"
		char         version[2];    // version
		char         padding[2];
		unsigned int vertex_count;  // ���_��
	}*PTMS_HEADER;

}// namespace Te
#endif // !__TE_TEM_STRUCT_H__
