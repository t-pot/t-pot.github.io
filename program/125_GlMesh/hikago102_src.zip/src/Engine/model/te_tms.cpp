// ---------------------------------------------------------------------------
// tms.cpp
//      T-pot engine MeSh format
// ---------------------------------------------------------------------------

#include <windows.h>											// Header File For Windows
#include <GL/glut.h>
#include "te_tms.h"

#define DISPLAY_LIST// �f�B�X�v���C���X�g���g���ĕ\��
#define NO_VBOS     // VBO �̋���OFF

namespace Te
{
// glext.h ����� VBO Extension �̒�`
#define GL_ARRAY_BUFFER_ARB 0x8892
#define GL_STATIC_DRAW_ARB 0x88E4
typedef void (APIENTRY * PFNGLBINDBUFFERARBPROC)    (GLenum target, GLuint buffer);
typedef void (APIENTRY * PFNGLDELETEBUFFERSARBPROC) (GLsizei n, const GLuint *buffers);
typedef void (APIENTRY * PFNGLGENBUFFERSARBPROC)    (GLsizei n, GLuint *buffers);
typedef void (APIENTRY * PFNGLBUFFERDATAARBPROC)    (GLenum target, int size, const GLvoid *data, GLenum usage);

// VBO Extension �֐��̃|�C���^
PFNGLGENBUFFERSARBPROC glGenBuffersARB = NULL;					// VBO ���O����
PFNGLBINDBUFFERARBPROC glBindBufferARB = NULL;					// VBO ���т�
PFNGLBUFFERDATAARBPROC glBufferDataARB = NULL;					// VBO �f�[�^���[�h
PFNGLDELETEBUFFERSARBPROC glDeleteBuffersARB = NULL;			// VBO �폜

bool CTms::_fVBOSupported = FALSE;

// ===========================================================================
// ���J�֐�
// ===========================================================================


// ---------------------------------------------------------------------------
// TMS �̏�����
// ---------------------------------------------------------------------------
PTMS SetupTms( const PTMS_DATA data )
{
	CTms *pTms = new CTms( data );
	
	return (PTMS)pTms;
}

// ---------------------------------------------------------------------------
// TMS �̕Еt��
// ---------------------------------------------------------------------------
void ClenaTms( PTMS p )
{
	CTms *pTms = (CTms *)p;
	
	delete pTms;
}

// ---------------------------------------------------------------------------
// TMS �̕`��
// ---------------------------------------------------------------------------
void RenderTms( PTMS p )
{
	CTms *pTms = (CTms *)p;
	
	pTms->Render();
}


// ===========================================================================
// ���b�V���N���X
// ===========================================================================

// ---------------------------------------------------------------------------
// �V�X�e���̏�����
// ---------------------------------------------------------------------------
void CTms::Initialize()
{
	CheckDeviceAbility();
}


// ---------------------------------------------------------------------------
// �R���X�g���N�^
// ---------------------------------------------------------------------------
CTms::CTms( const PTMS_DATA p )
{
	const PTMS_HEADER pHeader = (const PTMS_HEADER)p;
	_nVertex = pHeader->vertex_count;
	
	// -----------------------------------------------------------------------
	// �f�[�^�z��̏���
	// -----------------------------------------------------------------------
	_pPosition = (const float *)(pHeader+1);
	_pNormal   = _pPosition + 3 * _nVertex;
	_pTexCoord = _pNormal   + 3 * _nVertex;

#ifdef DISPLAY_LIST
	_iDisplayList = glGenLists(1);
	glNewList( _iDisplayList, GL_COMPILE );

		glBegin( GL_TRIANGLES );
		// �f�B�X�v���C���X�g�̍쐬
		for( unsigned int i = 0; i < _nVertex; i++ )
		{
			glNormal3fv  (   _pNormal ); _pNormal   += 3;
			glTexCoord2fv( _pTexCoord ); _pTexCoord += 2;
			glVertex3fv  ( _pPosition ); _pPosition += 3;
		}
		glEnd();

	glEndList();
#else
#ifndef NO_VBOS
	// -----------------------------------------------------------------------
	// ���_�f�[�^���O���t�B�b�N�X�J�[�h�̃������Ɋi�[����B
	// -----------------------------------------------------------------------
	// �ʒu���W�o�b�t�@�𐶐����Č��т���
	glGenBuffersARB( 1, &_nVBOPosition );							// ID �𓾂�
	glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBOPosition );			// �o�b�t�@�����т���
	glBufferDataARB( GL_ARRAY_BUFFER_ARB, _nVertex*3*sizeof(float), _pPosition, GL_STATIC_DRAW_ARB );

	// �@���x�N�g���o�b�t�@�𐶐����Č��т���
	glGenBuffersARB( 1, &_nVBONormal );								// ID �𓾂�
	glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBONormal );			// �o�b�t�@�����т���
	glBufferDataARB( GL_ARRAY_BUFFER_ARB, _nVertex*3*sizeof(float), _pNormal, GL_STATIC_DRAW_ARB );

	// �e�N�X�`�����W�o�b�t�@�𐶐����Č��т���
	// Generate And Bind The Texture Coordinate Buffer
	glGenBuffersARB( 1, &_nVBOTexCoord );							// ID �𓾂�
	glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBOTexCoord );			// �o�b�t�@�����т���
	glBufferDataARB( GL_ARRAY_BUFFER_ARB, _nVertex*2*sizeof(float), _pTexCoord, GL_STATIC_DRAW_ARB );
#endif // !NO_VBOS
#endif // DISPLAY_LIST
}


// ---------------------------------------------------------------------------
// �f�X�g���N�^
// ---------------------------------------------------------------------------
CTms::~CTms( )
{
#ifdef DISPLAY_LIST
	glDeleteLists( _iDisplayList, 1 );
#endif // DISPLAY_LIST

	// VBO �̍폜
	if( _fVBOSupported )
	{
		unsigned int nBuffers[] = { _nVBOPosition, _nVBONormal, _nVBOTexCoord };
		glDeleteBuffersARB( 3, nBuffers );
	}

	_pTexCoord = 0;
	_pNormal = 0;
	_pPosition = 0;
	_nVertex = 0;
}

// ---------------------------------------------------------------------------
// �G�N�X�e���V�����̃T�|�[�g�𒲂ׂ�
// ---------------------------------------------------------------------------
static bool IsExtensionSupported( char* szTargetExtension )
{
	const unsigned char *pszExtensions = NULL;
	const unsigned char *pszStart;
	unsigned char *pszWhere, *pszTerminator;

	// Extension names should not have spaces
	pszWhere = (unsigned char *) strchr( szTargetExtension, ' ' );
	if( pszWhere || *szTargetExtension == '\0' )
		return false;

	// Get Extensions String
	pszExtensions = glGetString( GL_EXTENSIONS );

	// Search The Extensions String For An Exact Copy
	pszStart = pszExtensions;
	for(;;)
	{
		pszWhere = (unsigned char *) strstr( (const char *) pszStart, szTargetExtension );
		if( !pszWhere )
			break;
		pszTerminator = pszWhere + strlen( szTargetExtension );
		if( pszWhere == pszStart || *( pszWhere - 1 ) == ' ' )
			if( *pszTerminator == ' ' || *pszTerminator == '\0' )
				return true;
		pszStart = pszTerminator;
	}
	return false;
}

// ---------------------------------------------------------------------------
// �`��\�͂����؂���
// ---------------------------------------------------------------------------
void CTms::CheckDeviceAbility()
{
#ifdef DISPLAY_LIST
	_fVBOSupported = false;
	return;
#endif// DISPLAY_LIST

	// VBO �̃T�|�[�g���m�F����
#ifndef NO_VBOS
	_fVBOSupported = IsExtensionSupported( "GL_ARB_vertex_buffer_object" );
	if( _fVBOSupported )
	{
		// GL �֐��̃|�C���^����������
		glGenBuffersARB = (PFNGLGENBUFFERSARBPROC) wglGetProcAddress("glGenBuffersARB");
		glBindBufferARB = (PFNGLBINDBUFFERARBPROC) wglGetProcAddress("glBindBufferARB");
		glBufferDataARB = (PFNGLBUFFERDATAARBPROC) wglGetProcAddress("glBufferDataARB");
		glDeleteBuffersARB = (PFNGLDELETEBUFFERSARBPROC) wglGetProcAddress("glDeleteBuffersARB");
	}
#else /* NO_VBOS */
	_fVBOSupported = false;
#endif
}

// ---------------------------------------------------------------------------
// �`��
// ---------------------------------------------------------------------------
void CTms::Render( )
{
#ifdef DISPLAY_LIST
	glCallList( _iDisplayList );
#else // DISPLAY_LIST
	// �f�[�^�z���L���ɂ���
	glEnableClientState( GL_VERTEX_ARRAY );
	glEnableClientState( GL_NORMAL_ARRAY );
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );

	// �f�[�^���|�C���^�ɃZ�b�g����
	if( _fVBOSupported )
	{
		glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBOPosition );
		glVertexPointer( 3, GL_FLOAT, 0, (char *) NULL );
		glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBONormal );
		glNormalPointer( GL_FLOAT, 0, (char *) NULL );
		glBindBufferARB( GL_ARRAY_BUFFER_ARB, _nVBOTexCoord );
		glTexCoordPointer( 2, GL_FLOAT, 0, (char *) NULL );
	} else
	{
		glVertexPointer( 3, GL_FLOAT, 0, _pPosition );
		glNormalPointer( GL_FLOAT, 0, _pNormal );
		glTexCoordPointer( 2, GL_FLOAT, 0, _pTexCoord );
	}
	
	// �`��
	glDrawArrays( GL_TRIANGLES, 0, _nVertex );

	// �f�[�^�z��𖳌��ɂ���
	glDisableClientState( GL_VERTEX_ARRAY );
	glDisableClientState( GL_NORMAL_ARRAY );
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
#endif // DISPLAY_LIST
}

}// namespace Te
