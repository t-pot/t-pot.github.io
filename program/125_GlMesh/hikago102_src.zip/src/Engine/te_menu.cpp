//--------------------------------------------------------------------------------------
// File: te_menu.cpp
//
// ���j���[�V�X�e��
//
// Copyright (c) Takashi Imagire, 2004. All rights reserved.
//--------------------------------------------------------------------------------------

#include "TE/te.h"
#include "TE/te_menu.h"
#include <GL/glut.h>

namespace Te
{


//--------------------------------------------------------------------------------------
// �R���X�g���N�^
//--------------------------------------------------------------------------------------
CMenu::CMenu( ) : m_iTexture( 0 )
{
	m_color[0] = 1.0;
	m_color[1] = 1.0;
	m_color[2] = 1.0;
	m_color[3] = 1.0;

	m_pos[0] = 0.0f;
	m_pos[1] = 0.0f;
	m_size[0] = 32.0f;
	m_size[1] = 32.0f;
	m_waku[0] = 16.0f;
	m_waku[1] = 16.0f;
}


//--------------------------------------------------------------------------------------
//
//--------------------------------------------------------------------------------------
CMenu::CMenu( const void *p )
{
	CMenu();
	m_iTexture = Te::SetupBitmap( p );
}


//--------------------------------------------------------------------------------------
// �f�X�g���N�^
//--------------------------------------------------------------------------------------
CMenu::~CMenu( )
{
	DeleteBitmap( m_iTexture );
}




//--------------------------------------------------------------------------------------
// �\��
//--------------------------------------------------------------------------------------
int CMenu::Render( )
{
	if( 0 == m_iTexture ) return -1;
	
	float fw  = m_size[0];
	float fh = m_size[1];
	float fx = (float)m_pos[0] - 0.5f;
	float fy = (float)m_pos[1] - 0.5f;
	float w  = (float)m_waku[0];
	float h  = (float)m_waku[1];
	float x_base = fx;

	// �s���ύX����
	rect screen;
	GetScreenRect( &screen );
	
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); 
	glLoadIdentity();
	glOrtho( screen.left, screen.right, screen.bottom, screen.top, 0.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); 
	glLoadIdentity();

	// �e�N�X�`���̐ݒ�
	glBindTexture( GL_TEXTURE_2D, m_iTexture );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glEnable(GL_TEXTURE_2D);

	// �A���t�@�u�����f�B���O
	glEnable(GL_BLEND);
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	// Z�e�X�g�Ȃ�
	glDisable(GL_DEPTH_TEST);
	
	glColor4f( m_color[0], m_color[1], m_color[2], m_color[3] );

	glBegin( GL_TRIANGLE_STRIP );
	glTexCoord2d( 0.0, 0.0 );
	glVertex3d( fx-w     , fy-h      , 0 );
	glTexCoord2d( 0.0, 0.5 );
	glVertex3d( fx-w     , fy        , 0 );
	glTexCoord2d( 0.5, 0.0 );
	glVertex3d( fx       , fy-h      , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx       , fy        , 0 );
	glTexCoord2d( 0.5, 0.0 );
	glVertex3d( fx+fw    , fy-h      , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx+fw    , fy        , 0 );
	glTexCoord2d( 1.0, 0.0 );
	glVertex3d( fx+fw+w  , fy-h      , 0 );
	glTexCoord2d( 1.0, 0.5 );
	glVertex3d( fx+fw+w  , fy        , 0 );
	glVertex3d( fx+fw+w  , fy        , 0 );

	glTexCoord2d( 0.0, 0.5 );
	glVertex3d( fx-w     , fy        , 0 );
	glVertex3d( fx-w     , fy        , 0 );
	glTexCoord2d( 0.0, 0.5 );
	glVertex3d( fx-w     , fy+fh     , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx       , fy        , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx       , fy+fh     , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx+fw    , fy        , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx+fw    , fy+fh     , 0 );
	glTexCoord2d( 1.0, 0.5 );
	glVertex3d( fx+fw+w  , fy        , 0 );
	glTexCoord2d( 1.0, 0.5 );
	glVertex3d( fx+fw+w  , fy+fh     , 0 );
	glVertex3d( fx+fw+w  , fy+fh     , 0 );

	glTexCoord2d( 0.0, 0.5 );
	glVertex3d( fx-w     , fy+fh        , 0 );
	glVertex3d( fx-w     , fy+fh        , 0 );
	glTexCoord2d( 0.0, 1.0 );
	glVertex3d( fx-w     , fy+fh+h      , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx       , fy+fh        , 0 );
	glTexCoord2d( 0.5, 1.0 );
	glVertex3d( fx       , fy+fh+h      , 0 );
	glTexCoord2d( 0.5, 0.5 );
	glVertex3d( fx+fw    , fy+fh        , 0 );
	glTexCoord2d( 0.5, 1.0 );
	glVertex3d( fx+fw    , fy+fh+h      , 0 );
	glTexCoord2d( 1.0, 0.5 );
	glVertex3d( fx+fw+w  , fy+fh        , 0 );
	glTexCoord2d( 1.0, 1.0 );
	glVertex3d( fx+fw+w  , fy+fh+h      , 0 );

	glEnd();

	// �s������ɖ߂�
	glPopMatrix(); 
	glMatrixMode(GL_PROJECTION);
	glPopMatrix(); 

	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);

	return 0;
}

//------------------------------------------------------------------------
// �F�ݒ�
//------------------------------------------------------------------------
void CMenu::SetColor( float r, float g, float b, float a )
{
	m_color[0] = r;
	m_color[1] = g;
	m_color[2] = b;
	m_color[3] = a;
}
//------------------------------------------------------------------------
// �A���t�@�ݒ�
//------------------------------------------------------------------------
void CMenu::SetAlpha( float a )
{
	m_color[3] = a;
}
//------------------------------------------------------------------------
// �傫���ݒ�
//------------------------------------------------------------------------
void CMenu::SetSize( float w, float h )
{
	m_size[0] = w;
	m_size[1] = h;
}
//------------------------------------------------------------------------
// �傫���ݒ�
//------------------------------------------------------------------------
void CMenu::SetPos( float x, float y )
{
	m_pos[0] = x;
	m_pos[1] = y;
}
//------------------------------------------------------------------------
// �傫���ݒ�
//------------------------------------------------------------------------
void CMenu::SetFrameWidth( float w, float h )
{
	m_waku[0] = w;
	m_waku[1] = h;
}



}// namespace Te
