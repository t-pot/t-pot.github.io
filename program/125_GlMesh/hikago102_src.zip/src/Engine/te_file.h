//--------------------------------------------------------------------------------------
// File: te_file.h
//
// �t�@�C���V�X�e��
//
// Copyright (c) Takashi Imagire, 2004. All rights reserved.
//--------------------------------------------------------------------------------------

#ifndef _TE_FILE_H_
#define _TE_FILE_H_

#include "te_teb.h"

namespace Te
{
namespace File
{
	class CTeb
	{
	protected:
		void        *_pImage;
		TEB_HEADER  *_pHeader;
		TEB_INDEX   *_pIndex;
	public:
		 CTeb( const char *filename );
		~CTeb();
		
		void *GetData( unsigned int id );
	};
}// namespace File
}// namespace Te

#endif // !_TE_FILE_H_
