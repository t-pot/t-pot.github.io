// ----------------------------------------------------------------------------
//
// main.cpp - �X�^�[�g�n�_
// 
// Copyright (c) 2004 �����t �� (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------

#include "application.h"
#include "app/app_task_tbl.h"
#include "TE/te.h"
#include "main.h"
#include "file_tbl.h"

// �R���\�[���������Ȃ�
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )

// ===========================================================================
// �O���[�o���ϐ�
// ===========================================================================
extern Te::FONT_INFO font_info[];
extern Te::FONT_INFO font_info_j[];

static Application::CTaskMgr *g_pTaskMgr = 0;
static void *g_pFile = 0;
Te::CFontJ *g_pFont = 0;
Te::CMenu  *g_pMenu = 0;
Te::CMenu  *g_pBtn  = 0;

// ===========================================================================
// �֐�
// ===========================================================================

// ---------------------------------------------------------------------------
// �`��֐�
// ---------------------------------------------------------------------------
void Update(float dt)
{
	// �e�^�X�N�̎��s
	g_pTaskMgr->Update( dt );
}

// ---------------------------------------------------------------------------
// ���C���֐�
// ---------------------------------------------------------------------------
int main(int argc, char *argv[])
{
	Te::Init( argc, argv, 640, 480, "HIKAGO", &Update );
	
	g_pTaskMgr = new Application::CTaskMgr( Application::TASK_ID_CREDIT );

#ifdef USE_IMAGE_DATA
	g_pFile = Te::File::SetupTeb( IMG_DATA0 );
#endif // USE_IMAGE_DATA

	void *pFontDatas[] = {
		Te::File::GetData( FILE_DATA0_FONT_BMP,  g_pFile ),
		Te::File::GetData( FILE_DATA0_0FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_1FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_2FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_3FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_4FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_5FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_6FONT_BMP, g_pFile ),
		Te::File::GetData( FILE_DATA0_7FONT_BMP, g_pFile ),
	};
	g_pFont = new Te::CFontJ();
	g_pFont->Init( pFontDatas, font_info, font_info_j );
	
	Te::File::DeleteData( pFontDatas[8], g_pFile );
	Te::File::DeleteData( pFontDatas[7], g_pFile );
	Te::File::DeleteData( pFontDatas[6], g_pFile );
	Te::File::DeleteData( pFontDatas[5], g_pFile );
	Te::File::DeleteData( pFontDatas[4], g_pFile );
	Te::File::DeleteData( pFontDatas[3], g_pFile );
	Te::File::DeleteData( pFontDatas[2], g_pFile );
	Te::File::DeleteData( pFontDatas[1], g_pFile );
	Te::File::DeleteData( pFontDatas[0], g_pFile );
	
	void *pMenu;
	pMenu= Te::File::GetData( FILE_DATA0_WINDOW_BMP,  g_pFile );
	g_pMenu = new Te::CMenu( pMenu );
	Te::File::DeleteData( pMenu, g_pFile );
	pMenu = Te::File::GetData( FILE_DATA0_BUTTON_BMP,  g_pFile );
	g_pBtn  = new Te::CMenu( pMenu );
	Te::File::DeleteData( pMenu, g_pFile );

	// ���[�v
	Te::Execute();
	
	if(g_pBtn ) delete g_pBtn;  g_pBtn  = 0;
	if(g_pMenu) delete g_pMenu; g_pMenu = 0;
	if(g_pFont) g_pFont->Release(); g_pFont = 0;
	Te::File::DeleteTeb( g_pFile );
	delete g_pTaskMgr;

	return 0;
}