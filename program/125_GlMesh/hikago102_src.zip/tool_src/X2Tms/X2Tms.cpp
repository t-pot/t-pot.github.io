// Tga2Bmp.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include <d3d9.h>
#include <d3dx9.h>

#include "te_tem_struct.h"

//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
LPDIRECT3D9             g_pD3D       = NULL; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL; // Our rendering device

LPD3DXMESH              g_pMesh          = NULL; // Our mesh object in sysmem
D3DMATERIAL9*           g_pMeshMaterials = NULL; // Materials for our mesh
DWORD                   g_dwNumMaterials = 0L;   // Number of mesh materials


//-----------------------------------------------------------------------------
// �O���֐�
//-----------------------------------------------------------------------------
namespace Te
{
	unsigned int CreateTmsData( PTMS_DATA *addr, unsigned int nVertex, const D3DXVECTOR3 *pPosition, const D3DXVECTOR3 *pNormal, const D3DXVECTOR2 *pTexCoord );	// �z�񂩂�f�[�^�̍쐬
	void DeleteTmsData( PTMS_DATA p );	// �f�[�^�̔j��
}// namespace Te


//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;
        
    D3DPRESENT_PARAMETERS d3dpp; 
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;

    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
    if( g_pd3dDevice != NULL) g_pd3dDevice->Release();

    if( g_pD3D != NULL) g_pD3D->Release();
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    return DefWindowProc( hWnd, msg, wParam, lParam );
}




int _tmain(int argc, _TCHAR* argv[])
{
	// Register the window class
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L, 
                      GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
                      TEXT("X2Tms"), NULL };
    RegisterClassEx( &wc );

    // Create the application's window
    HWND hWnd = CreateWindow( TEXT("X2Tms"), TEXT("X2Tms"), 
                              WS_OVERLAPPEDWINDOW, 100, 100, 300, 300,
                              GetDesktopWindow(), NULL, wc.hInstance, NULL );


    // Initialize Direct3D
    if( SUCCEEDED( InitD3D( hWnd ) ) )
    { 
		// ���b�V���̓ǂݍ���
		LPD3DXBUFFER pD3DXMtrlBuffer;
		if( SUCCEEDED( D3DXLoadMeshFromX(argv[1], D3DXMESH_SYSTEMMEM, 
									g_pd3dDevice, NULL, 
									&pD3DXMtrlBuffer, NULL, &g_dwNumMaterials, 
									&g_pMesh ) ) )
		{
#if 0
			// ---------------------------------------------------------------
			// �}�e���A�����̏���
			// ---------------------------------------------------------------
			D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
			g_pMeshMaterials = new D3DMATERIAL9[g_dwNumMaterials];

			for( DWORD i=0; i<g_dwNumMaterials; i++ )
			{
				g_pMeshMaterials[i] = d3dxMaterials[i].MatD3D;
//				g_pMeshMaterials[i].Ambient = g_pMeshMaterials[i].Diffuse;
			}

			// Done with the material buffer
			pD3DXMtrlBuffer->Release();
#endif
			
			// ---------------------------------------------------------------
			// ���b�V�����č\�z
			// ---------------------------------------------------------------
			LPD3DXMESH pMesh;
			g_pMesh->CloneMeshFVF(	D3DXMESH_SYSTEMMEM, D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1, g_pd3dDevice, &pMesh );
			
			// ---------------------------------------------------------------
			// ���\�[�X�̊m��
			// ---------------------------------------------------------------
			struct MESH_VERTEX { D3DXVECTOR3 p, n; FLOAT u,v; };
			MESH_VERTEX* pVertices;
			WORD*       pIndices;
			DWORD dwNumFaces    = pMesh->GetNumFaces();
			pMesh->LockVertexBuffer( D3DLOCK_READONLY, (LPVOID*)&pVertices );
			pMesh->LockIndexBuffer ( D3DLOCK_READONLY, (LPVOID*)&pIndices );

			// ---------------------------------------------------------------
			// �V�������b�V���̍쐬
			// ---------------------------------------------------------------
			unsigned int nVertex = 3*dwNumFaces;
			D3DXVECTOR3 *pPosition = new D3DXVECTOR3[nVertex];
			D3DXVECTOR3 *pNormal   = new D3DXVECTOR3[nVertex];
			D3DXVECTOR2 *pTexCoord = new D3DXVECTOR2[nVertex];
    
			for( DWORD i=0; i<dwNumFaces; i++ )
			{
				D3DXVECTOR3 v0 = pVertices[pIndices[3*i+0]].p;
				D3DXVECTOR3 v1 = pVertices[pIndices[3*i+1]].p;
				D3DXVECTOR3 v2 = pVertices[pIndices[3*i+2]].p;
				D3DXVECTOR3 n0 = pVertices[pIndices[3*i+0]].n;
				D3DXVECTOR3 n1 = pVertices[pIndices[3*i+1]].n;
				D3DXVECTOR3 n2 = pVertices[pIndices[3*i+2]].n;

				pPosition[3*i+0]   = pVertices[pIndices[3*i+0]].p;
				pPosition[3*i+1]   = pVertices[pIndices[3*i+1]].p;
				pPosition[3*i+2]   = pVertices[pIndices[3*i+2]].p;
				pNormal[3*i+0]     = pVertices[pIndices[3*i+0]].n;
				pNormal[3*i+1]     = pVertices[pIndices[3*i+1]].n;
				pNormal[3*i+2]     = pVertices[pIndices[3*i+2]].n;
				pTexCoord[3*i+0].x = pVertices[pIndices[3*i+0]].u;
				pTexCoord[3*i+1].x = pVertices[pIndices[3*i+1]].u;
				pTexCoord[3*i+2].x = pVertices[pIndices[3*i+2]].u;
				pTexCoord[3*i+0].y = pVertices[pIndices[3*i+0]].v;
				pTexCoord[3*i+1].y = pVertices[pIndices[3*i+1]].v;
				pTexCoord[3*i+2].y = pVertices[pIndices[3*i+2]].v;
			}
			
			// ---------------------------------------------------------------
			// �ϊ�
			// ---------------------------------------------------------------
			Te::PTMS_DATA pdata;
			unsigned int size = Te::CreateTmsData( &pdata, nVertex, pPosition, pNormal, pTexCoord );
			
			// ---------------------------------------------------------------
			// �ۑ�
			// ---------------------------------------------------------------
			FILE *fp;
			char str[1024]; 
			DWORD dwLen = WideCharToMultiByte(CP_ACP,0,(LPCWSTR)argv[2],-1,NULL,0,NULL,NULL);
			int ret = WideCharToMultiByte(CP_ACP,0,(LPCWSTR)argv[2],-1,str,dwLen,NULL,NULL);
			str[dwLen] = '\0';
			fp= fopen( str, "wb" );
			if( 0 != fp ) {
				fwrite( pdata, sizeof(float), size/sizeof(float), fp );
				fclose( fp );
			}

			// ---------------------------------------------------------------
			// �g�������\�[�X�̊J��
			// ---------------------------------------------------------------
			
			Te::DeleteTmsData( pdata );
			
			delete[] pTexCoord;
			delete[] pNormal;
			delete[] pPosition;

			// �o�b�t�@�̐�L������
			pMesh->UnlockVertexBuffer();
			pMesh->UnlockIndexBuffer();
			pMesh->Release();


			// ���\�[�X�̍폜
			if( g_pMeshMaterials != NULL ) delete[] g_pMeshMaterials;
			if( g_pMesh != NULL ) g_pMesh->Release();
		    
		}
    }
	Cleanup();
	
    UnregisterClass( TEXT("Tga2Bmp"), wc.hInstance );

	return 0;
}

