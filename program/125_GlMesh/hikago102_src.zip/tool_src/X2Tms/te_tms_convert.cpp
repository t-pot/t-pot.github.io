// ---------------------------------------------------------------------------
// tms.cpp
//      T-pot engine MeSh format
// ---------------------------------------------------------------------------

#include "stdafx.h"
#include <d3d9.h>
#include <d3dx9.h>
#include "te_tem_struct.h"

namespace Te
{
	//-----------------------------------------------------------------------------
	// �z�񂩂�f�[�^�̍쐬
	//-----------------------------------------------------------------------------
	unsigned int CreateTmsData( PTMS_DATA *addr, unsigned int nVertex, const D3DXVECTOR3 *pPosition, const D3DXVECTOR3 *pNormal, const D3DXVECTOR2 *pTexCoord )
	{
		// �������̊m��
		unsigned int size = sizeof(TMS_HEADER) + nVertex * (3+3+2) * sizeof(float);
		PTMS_DATA p = (PTMS_DATA) new float[size/sizeof(float)];
		
		if( 0 == p ) return 0;
		
		// �w�b�_�[�̍쐬
		PTMS_HEADER pHeader = (PTMS_HEADER)p;
		memset( pHeader, 0, sizeof(TMS_HEADER) );
		pHeader->signiture[0] = 'T';
		pHeader->signiture[1] = 'M';
		pHeader->signiture[2] = 'S';
		pHeader->signiture[3] = '\0';
		pHeader->version[0] = 0;
		pHeader->version[1] = 0;
		pHeader->vertex_count = nVertex;
		
		// �������ݐ�̌���
		float *pDestPosition = (float *)(pHeader+1);
		float *pDestNormal   = pDestPosition + 3*nVertex;
		float *pDestTexCoord = pDestNormal   + 3*nVertex;
		
		// �f�[�^�̃R�s�[
		for( unsigned int i = 0; i < nVertex; i++ )
		{
			// �ʒu���W
			pDestPosition[0] = pPosition[i].x;
			pDestPosition[1] = pPosition[i].y;
			pDestPosition[2] = pPosition[i].z;
			pDestPosition += 3;
	
			// �@���x�N�g��
			pDestNormal[0] = pNormal[i].x;
			pDestNormal[1] = pNormal[i].y;
			pDestNormal[2] = pNormal[i].z;
			pDestNormal += 3;
	
			// �e�N�X�`�����W
			pDestTexCoord[0] = pTexCoord[i].x;
			pDestTexCoord[1] = pTexCoord[i].y;
			pDestTexCoord += 2;
		}
		
		*addr = p;
		
		return size;
	}
	
	//-----------------------------------------------------------------------------
	// �f�[�^�̔j��
	//-----------------------------------------------------------------------------
	void DeleteTmsData( PTMS_DATA p )
	{
		delete[] p;
	}
}// namespace Te
