//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Real-Time Global Illumination
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "hdr.h"
#include "main.h"

#define MAP_SIZE		128
#define DIFFUSE_SIZE	64


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

typedef struct {
    FLOAT       p[4];
    FLOAT       u0, v0;
    FLOAT       u1, v1;
} T2VERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	int i;

	m_Shader = 0;

	m_pos = D3DXVECTOR3(0,3,0);
	m_vel = D3DXVECTOR3(0,0,0);

	m_pMesh						= new CD3DMesh();
	m_pMeshBg					= new CD3DMesh();
	m_pMeshEnv					= new CD3DMesh();
	m_pEnvMap					= NULL;

	m_pMapZ						= NULL;
	m_pParaboloidTex[0]			= NULL;
	m_pParaboloidSurf[0]		= NULL;
	m_pParaboloidTex[1]			= NULL;
	m_pParaboloidSurf[1]		= NULL;
	for(i=0;i<1;i++){
		m_pJacobianTex[i][0]	= NULL;
		m_pJacobianTex[i][1]	= NULL;
	}
	m_pMaxNLTex[0]				= NULL;

	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		m_pReductionTex[i]		= NULL;
		m_pReductionSurf[i]		= NULL;
	}

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWVP						= NULL;
	m_htSrcTex					= NULL;

	m_pEffectHDR				= NULL;
	m_hTechniqueHDR				= NULL;
	m_hmWVP_HDR					= NULL;
	m_htTextureHDR				= NULL;

	m_fWorldRotX                = -0.5f;
    m_fWorldRotY                = 0.0f;
	m_fViewZoom				    = 10.0f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}


//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// ���f���̓ǂݍ���
	if(FAILED(hr=m_pMesh->Create( m_pd3dDevice, _T("ball.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMesh->UseMeshMaterials(FALSE);// �����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�
        
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMeshBg->UseMeshMaterials(FALSE);// �����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�
        
	if(FAILED(hr=m_pMeshEnv->Create( m_pd3dDevice, _T("room.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMeshEnv->UseMeshMaterials(FALSE);// �����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�
        
	hr = HDR::CreateTextureFromFile(m_pd3dDevice, "grace_cross.hdr", NULL, &m_pEnvMap);
	if(FAILED(hr)){
        MessageBox( NULL, NULL, "ERROR", MB_OK);
	}

	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWVP		 = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );

    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hdr.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffectHDR, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechniqueHDR = m_pEffectHDR->GetTechniqueByName( "TShader" );
	m_hmWVP_HDR	    = m_pEffectHDR->GetParameterByName( NULL, "mWVP" );
	m_htTextureHDR  = m_pEffectHDR->GetParameterByName( NULL, "Texture" );

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// �d�ݕt����
//-------------------------------------------------------------
typedef struct {
	int iRank;
	bool bFront;
}sParaboloidJacobian;

VOID WINAPI ParaboloidJacobian (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexelSize );

	sParaboloidJacobian *p = (sParaboloidJacobian *)pData;

	FLOAT x = 2.0f*( pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(-pTexCoord->y+0.5f);

	FLOAT r2 = x*x+y*y;
	FLOAT J = 0.5f*(1.0f+r2);

    FLOAT col = (r2<(1.0f-1.0f/MAP_SIZE)*(1.0f-1.0f/MAP_SIZE)) ? J : 0.0f;
	
	FLOAT nz = 0.5f * (1.0f-r2);
	FLOAT nx = x;
	FLOAT ny = y;
	FLOAT n = sqrtf(nx*nx+ny*ny+nz*nz);
	nx /= n;
	ny /= n;
	nz /= n;
	if(p->bFront) nz *= -1;

	pOut->x = 0.5f * col * nx + 0.5f;
	pOut->y = 0.5f * col * ny + 0.5f;
	pOut->z = 0.5f * col * nz + 0.5f;
	pOut->w = 0.5f * col + 0.5f;
}

//-------------------------------------------------------------
// shphere�}�b�v�̍��W�n��max(N.L, 0)��SH�W�J
VOID WINAPI SphereSH (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexelSize );
    UNREFERENCED_PARAMETER( pData );

	FLOAT u = 2.0f*( pTexCoord->x-0.5f);
    FLOAT v = 2.0f*(-pTexCoord->y+0.5f);

	FLOAT a = u*u+v*v;
	if(1<a) a = 1;
	FLOAT z = 1 - 2.0f * a;
	FLOAT m = 2*sqrtf(1-a);
	FLOAT x = m * u;
	FLOAT y = m * v;
	
	FLOAT col[4] = {0,0,0,0};

	FLOAT sum = 0;
	for( int theta = 0; theta < 32; theta++ )
	{
		FLOAT ct = cosf( D3DX_PI * theta / 32.0f );
		FLOAT st = sinf( D3DX_PI * theta / 32.0f );
		for( int phi = 0; phi < 32; phi++ )
		{
			FLOAT cp = cosf( D3DX_PI * (FLOAT)phi / 16.0f );
			FLOAT sp = sinf( D3DX_PI * (FLOAT)phi / 16.0f );
			float omega[3] = {st*cp, st*sp, ct};

			col[0] += st * max( 0, omega[0]*x + omega[1]*y + omega[2]*z );
			col[1] += st * max( 0, omega[0]*x + omega[1]*y + omega[2]*z ) * omega[0];
			col[2] += st * max( 0, omega[0]*x + omega[1]*y + omega[2]*z ) * omega[1];
			col[3] += st * max( 0, omega[0]*x + omega[1]*y + omega[2]*z ) * omega[2];
			sum += st;
		}
	}
	col[0] /= 0.5f * sum;
	col[1] /= 0.5f * sum;
	col[2] /= 0.5f * sum;
	col[3] /= 0.5f * sum;
	
	pOut->x = 0.5f * col[1] + 0.5f;
	pOut->y = 0.5f * col[2] + 0.5f;
	pOut->z = 0.5f * col[3] + 0.5f;
	pOut->w = 0.5f * col[0] + 0.5f;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i;

	// ���b�V��
	m_pMesh->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshEnv->RestoreDeviceObjects( m_pd3dDevice );

    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );


    // �����_�����O��Ԃ̐ݒ�
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
    
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	// �����_�����O�^�[�Q�b�g�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// �����}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[0], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[0]->GetSurfaceLevel(0, &m_pParaboloidSurf[0])))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[1], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[1]->GetSurfaceLevel(0, &m_pParaboloidSurf[1])))
		return E_FAIL;

	// �d�ݕt���̃e�N�X�`��
	sParaboloidJacobian data;
	for(i=0;i<1;i++){
		data.iRank = i;
		data.bFront = 0;
		if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
							, D3DPOOL_DEFAULT, &m_pJacobianTex[i][0], NULL)))
			return E_FAIL;
		if( FAILED(D3DXFillTexture(m_pJacobianTex[i][0], ParaboloidJacobian, &data)))
			return E_FAIL;

		data.bFront = 1;
		if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
							, D3DPOOL_DEFAULT, &m_pJacobianTex[i][1], NULL)))
			return E_FAIL;
		if( FAILED(D3DXFillTexture(m_pJacobianTex[i][1], ParaboloidJacobian, &data)))
			return E_FAIL;
	}

	// �k���o�b�t�@
	int size = 128;
	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture(size, size, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pReductionTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pReductionTex[i]->GetSurfaceLevel(0, &m_pReductionSurf[i])))
			return E_FAIL;
		size /= 8;
	}
	
	// max(N.L, 0)��SH�W�J
	if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
						, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
						, D3DPOOL_DEFAULT, &m_pMaxNLTex[0], NULL)))
		return E_FAIL;
	if( FAILED(D3DXFillTexture( m_pMaxNLTex[0], SphereSH, NULL )))
		return E_FAIL;

	m_pEffect->OnResetDevice();
	m_pEffectHDR->OnResetDevice();

	return S_OK;
}



//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	// ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

	if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
		m_fWorldRotY += m_fElapsedTime;
	else
	if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
		m_fWorldRotY -= m_fElapsedTime;

	if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
		m_fWorldRotX += m_fElapsedTime;
	else
	if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
		m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.3f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	//---------------------------------------------------------
	// �V�F�[�_�̕ύX
	//---------------------------------------------------------
    if( m_UserInput.bChangeShader ) m_Shader = (m_Shader + 1) % 3;


	//---------------------------------------------------------
	// �ʂ̈ړ�
	//---------------------------------------------------------
	if( m_UserInput.bLeft && !m_UserInput.bRight )
		m_pos.x -= m_fElapsedTime;
	else
	if( m_UserInput.bRight && !m_UserInput.bLeft )
		m_pos.x += m_fElapsedTime;

	if( m_UserInput.bUp && !m_UserInput.bDown )
		m_pos.z += m_fElapsedTime;
	else
	if( m_UserInput.bDown && !m_UserInput.bUp )
		m_pos.z -= m_fElapsedTime;

	m_pos += m_vel * this->m_fElapsedTime;
	m_vel.y -= 9.8f * this->m_fElapsedTime;
	
	if( m_pos.y < 0.3f )
	{
		m_pos.y = -(m_pos.y-0.3f) + 0.3f;
		m_vel.y *= -1;
	}
	if( 3 < m_pos.y )
	{
		m_pos.y = 3;
		m_vel.y = 0;
	}

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
    
	pUserInput->bChangeShader= ( m_bActive && (GetAsyncKeyState( 'A'      ) & 0x8001) == 0x8001 );

	pUserInput->bUp          = ( m_bActive && (GetAsyncKeyState( 'W'      ) & 0x8000) == 0x8000 );
	pUserInput->bDown        = ( m_bActive && (GetAsyncKeyState( 'S'      ) & 0x8000) == 0x8000 );
	pUserInput->bLeft        = ( m_bActive && (GetAsyncKeyState( 'Q'      ) & 0x8000) == 0x8000 );
	pUserInput->bRight       = ( m_bActive && (GetAsyncKeyState( 'E'      ) & 0x8000) == 0x8000 );
}




//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
void CMyD3DApplication::RenderParaboloidMap()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	int i, j, k;
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
    D3DXVECTOR3 vFrom;
    D3DXVECTOR3 vLookat;
    D3DXVECTOR3 vUpVec;

	D3DVIEWPORT9 viewport = {0, 0      // ����̍��W
					, 1, 1  // ��,����
					, 0.0f,1.0f};     // �O�ʁA���

	//-------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̕ۑ�
	//-------------------------------------------------
	m_pd3dDevice->GetRenderTarget( 0, &pOldBackBuffer );
	m_pd3dDevice->GetDepthStencilSurface( &pOldZBuffer );
	m_pd3dDevice->GetViewport( &oldViewport );
	
	for( i = 0; i < 2; i++ )
	{
		vFrom   = m_pos;

		m_pd3dDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_ALWAYS );
		m_pd3dDevice->SetRenderTarget( 0, m_pParaboloidSurf[i] );
		m_pd3dDevice->SetDepthStencilSurface( m_pMapZ );
		viewport.Width  = viewport.Height = MAP_SIZE;
		m_pd3dDevice->SetViewport( &viewport );

		switch(i)
		{
		case 0:
			vLookat = D3DXVECTOR3( 0.0f, 0.0f, 1.0f ) + vFrom;
			vUpVec  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			break;
		case 1:
			vLookat = D3DXVECTOR3( 0.0f, 0.0f,-1.0f ) + vFrom;
			vUpVec  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			break;
		}
	    D3DXMatrixLookAtLH( &mView, &vFrom, &vLookat, &vUpVec );

		if( m_pEffectHDR != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffectHDR->SetTechnique( m_hTechniqueHDR );
			m_pEffectHDR->Begin( NULL, 0 );
			m_pEffectHDR->Pass( 1 );

			//-------------------------------------------------
			// �V�[���̕`��
			//-------------------------------------------------
			// �ϊ��s��
			D3DXMatrixScaling ( &m, 100, 100, 100 );
			m = m * mView;
			m._41 = m._42 = m._43 = 0;
			m_pEffectHDR->SetMatrix( "mWV", &m );
			
			m_pEffectHDR->SetTexture( m_htTextureHDR, m_pEnvMap );

			m_pMeshEnv->Render( m_pd3dDevice );

			m_pEffectHDR->End();
		}
		m_pd3dDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );
		
		//-------------------------------------------------
		// �w�i�̕`��
		//-------------------------------------------------
		if( m_pEffect != NULL ) 
		{
			D3DMATERIAL9 *pMtrl;

			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 4 );

			m = mView;

//D3DXMatrixTranslation( &mT, 0, -4, 0 );
//D3DXMatrixRotationX( &m, 1.0*D3DX_PI );
//m = mT * m * mView;

			m_pEffect->SetMatrix( "mWV", &m );

			pMtrl = m_pMeshBg->m_pMaterials;
			for( unsigned int s=0; s<m_pMeshBg->m_dwNumMaterials; s++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[s] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( s );	// �`��
				pMtrl++;
			}

			m_pEffect->End();
		}
	}


	//-------------------------------------------------
	//-------------------------------------------------
	// �~�b�v�}�b�v�̗v�̂ŏ���������
	//-------------------------------------------------
	//-------------------------------------------------
	if( m_pEffect != NULL ) 
	{
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );

		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[0]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		viewport.Width  = viewport.Height = 128;
		m_pd3dDevice->SetViewport(&viewport);
		
		// �S����������ʂ�1/2�k�����ė��ʂ�SH�W���ō�������
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX2 );
		m_pEffect->SetTexture( "SrcTex0", m_pParaboloidTex[0] );
		m_pEffect->SetTexture( "SrcTex1", m_pParaboloidTex[1] );
		m_pEffect->SetTexture( "WeightTex0", m_pJacobianTex[0][0] );
		m_pEffect->SetTexture( "WeightTex1", m_pJacobianTex[0][1] );
		float scale = 64;
		int pass = 6;
		for( j = 0; j < 2; j++)
		{
		for( k = 0; k < 2; k++)
		{
			m_pEffect->Pass( pass++ );
			T2VERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{(j+0)*scale,(k+0)*scale,0, 1, 0+1/128, 0+1/128, 0+1/128, 0+1/128,},
				{(j+1)*scale,(k+0)*scale,0, 1, 1+1/128, 0+1/128, 1+1/128, 0+1/128,},
				{(j+1)*scale,(k+1)*scale,0, 1, 1+1/128, 1+1/128, 1+1/128, 1+1/128,},
				{(j+0)*scale,(k+1)*scale,0, 1, 0+1/128, 1+1/128, 0+1/128, 1+1/128,},
			};
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( T2VERTEX ) );
		}
		}

		// 2�i�K
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[1]);
		viewport.Width  = viewport.Height = 16;
		m_pd3dDevice->SetViewport(&viewport);
		m_pEffect->Pass( 3 );

		TVERTEX Vertex1[4] = {
			//   x    y     z    tu tv
			{-1.0f, +1.0f, 0.5f,  0, 0},
			{+1.0f, +1.0f, 0.5f,  1, 0},
			{+1.0f, -1.0f, 0.5f,  1, 1},
			{-1.0f, -1.0f, 0.5f,  0, 1},
		};
		m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

		m_pEffect->SetFloat( "MAP_WIDTH",  128 );
		m_pEffect->SetFloat( "MAP_HEIGHT", 128 );

		m_pEffect->SetTexture( "ReductionMap", m_pReductionTex[0] );
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, Vertex1, sizeof( TVERTEX ) );
		// 3�i�K
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[2]);
		viewport.Width  = viewport.Height = 2;
		m_pd3dDevice->SetViewport(&viewport);

		m_pEffect->SetFloat( "MAP_WIDTH",  16 );
		m_pEffect->SetFloat( "MAP_HEIGHT", 16 );

		m_pEffect->SetTexture("ReductionMap", m_pReductionTex[1]);
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, Vertex1, sizeof( TVERTEX ) );

		m_pEffect->End();
	}


	//-----------------------------------------------------
	// �����_�����O�^�[�Q�b�g�����ɖ߂�
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetRenderTarget(1, NULL);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	m_pd3dDevice->SetViewport(&oldViewport);
	pOldBackBuffer->Release();
	pOldZBuffer->Release();

}
//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
	DWORD i;
	D3DXVECTOR4 v;
	D3DMATERIAL9 *pMtrl;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		RenderParaboloidMap();

		// �t���[���o�b�t�@�̃N���A
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 5 );

			//-------------------------------------------------
			// �V�[���̕`��
			//-------------------------------------------------
			// �ϊ��s��
			m = m_mWorld * m_mView * m_mProj;
//D3DXMatrixTranslation( &mT, 0, -4, 0 );
//D3DXMatrixRotationX( &m, 1.0*D3DX_PI );
//m = mT * m * m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// �w�i�̕`��
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );	// �`��
				pMtrl++;
			}


			// ��
			m_pEffect->Pass( 0+m_Shader );

			D3DXMatrixTranslation( &mW, m_pos.x, m_pos.y, m_pos.z );
			m = mW * m_mWorld * m_mView;
			m_pEffect->SetMatrix( "mWV", &m );
			m = m * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			// ���[�J���ł̎��_
			m = m_mWorld * m_mView;
            D3DXMatrixInverse( &m, NULL, &m);
			v = D3DXVECTOR4( 0, 0, 0, 1 );
            D3DXVec4Transform( &v, &v, &m);
			m_pEffect->SetVector( "vEye", &v );

			m_pEffect->SetTexture( "ParaboloidFrontTex", m_pParaboloidTex[0] );
			m_pEffect->SetTexture( "ParaboloidBackTex",  m_pParaboloidTex[1] );
			m_pEffect->SetTexture( "ReductionMap", m_pReductionTex[2]);
			m_pEffect->SetTexture( "SHTex", m_pMaxNLTex[0]);

			m_pMesh->Render( m_pd3dDevice );

			m_pEffect->End();
		}


		if( m_pEffectHDR != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffectHDR->SetTechnique( m_hTechniqueHDR );
			m_pEffectHDR->Begin( NULL, 0 );
			m_pEffectHDR->Pass( 0 );

			//-------------------------------------------------
			// �V�[���̕`��
			//-------------------------------------------------
			// �ϊ��s��
			D3DXMatrixScaling ( &m, 100, 100, 100 );
			m = m * m_mWorld * m_mView;
			m._41 = m._42 = m._43 = 0;
			m = m * m_mProj;
			m_pEffectHDR->SetMatrix( m_hmWVP_HDR, &m );
			
			m_pEffectHDR->SetTexture( m_htTextureHDR, m_pEnvMap );

			m_pMeshEnv->Render( m_pd3dDevice );

			m_pEffectHDR->End();
		}

		// �w���v�̕\��
        RenderText();

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 64.0f;
		for(DWORD i=0; i<8; i++){
			TVERTEX Vertex[4] = {
				//    x                             y         z rhw tu tv
				{(i+0)*scale, m_d3dsdBackBuffer.Height-scale, 0, 1, 0, 0,},
				{(i+1)*scale, m_d3dsdBackBuffer.Height-scale, 0, 1, 1, 0,},
				{(i+1)*scale, m_d3dsdBackBuffer.Height-    0, 0, 1, 1, 1,},
				{(i+0)*scale, m_d3dsdBackBuffer.Height-    0, 0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[0] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[1] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pJacobianTex[0][0] );
			if(3==i) m_pd3dDevice->SetTexture( 0, m_pJacobianTex[0][1] );
			if(4==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[0] );
			if(5==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[1] );
			if(6==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[2] );
			if(7==i) m_pd3dDevice->SetTexture( 0, m_pMaxNLTex[0] );

			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = 0; 

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

    lstrcpy( szMsg, TEXT("Press 'A' to change shader") );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

    lstrcpy( szMsg, m_strDeviceStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	int i;

	// �����_�����O�^�[�Q�b�g
	SAFE_RELEASE(m_pMaxNLTex[0]);

	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		SAFE_RELEASE(m_pReductionSurf[i]);
		SAFE_RELEASE(m_pReductionTex[i]);
	}
	for( i = 0; i < 1; i++ )
	{
		SAFE_RELEASE(m_pJacobianTex[i][0]);
		SAFE_RELEASE(m_pJacobianTex[i][1]);
	}
	SAFE_RELEASE(m_pParaboloidSurf[1]);
	SAFE_RELEASE(m_pParaboloidTex[1]);
	SAFE_RELEASE(m_pParaboloidSurf[0]);
	SAFE_RELEASE(m_pParaboloidTex[0]);
	SAFE_RELEASE(m_pMapZ);

	m_pMeshEnv->InvalidateDeviceObjects();
	m_pMeshBg->InvalidateDeviceObjects();
	m_pMesh->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();
    if( m_pEffectHDR != NULL ) m_pEffectHDR->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	SAFE_RELEASE( m_pEnvMap );
	
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	SAFE_RELEASE( m_pEffectHDR );
	
	// ���b�V��
	m_pMeshEnv->Destroy();
	m_pMeshBg->Destroy();
	m_pMesh->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pMeshEnv ); // ���b�V��
    SAFE_DELETE( m_pMeshBg ); // ���b�V��
    SAFE_DELETE( m_pMesh ); // ���b�V��

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




