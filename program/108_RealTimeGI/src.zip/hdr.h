//-----------------------------------------------------------------------------
// File: hdr.h
//
// Desc: RADIANCE Picture File Format �̓ǂݍ���
// Copyright (c) 2003 IMAGIRE Takashi. All rights reserved.
//-----------------------------------------------------------------------------
#pragma once



#include <d3dx9.h>

namespace HDR{
	//-----------------------------------------------------------------------------
	// HDR �t�@�C���̓ǂݍ���
	//-----------------------------------------------------------------------------
	HRESULT CreateTextureFromFile(
		LPDIRECT3DDEVICE9 pDevice,
		LPCTSTR pSrcFile,
		LPCTSTR *pErr,
		LPDIRECT3DTEXTURE9 *pTexture);

}// namespace HDR
