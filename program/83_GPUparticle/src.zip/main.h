//-----------------------------------------------------------------------------
// File: main.h
//
// Desc: Header file main sample app
//-----------------------------------------------------------------------------
#pragma once

#define frand() ((FLOAT)rand()/(FLOAT)(RAND_MAX+1))

//-----------------------------------------------------------------------------
// ��`�ƒ萔
//-----------------------------------------------------------------------------


// ���̓f�[�^
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
    BOOL bZ;
    BOOL bX;
};

//-----------------------------------------------------------------------------
// ���_�錾
//-----------------------------------------------------------------------------
D3DVERTEXELEMENT9 decl[] =
{
	{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,	0},
	{0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	{0, 32, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_LOOKUP,  D3DDECLUSAGE_SAMPLE,	0},
	D3DDECL_END()
};



// ----------------------------------------------------------------------------
// �p�[�e�B�N��
// ----------------------------------------------------------------------------
#define PARTICLE_MAX 64	// �p�[�e�B�N�������ł��鐔

class CParticle{
private:
	int				id;		 // unique id
	CD3DMesh		*pMesh;
public:
	// constructor
	CParticle(){
		pMesh = new CD3DMesh();
	}
	~CParticle(){Delete();}

	void CreateMesh(LPDIRECT3DDEVICE9 pd3dDevice, TCHAR *filename);
	void RestoreDeviceObjects(LPDIRECT3DDEVICE9 pd3dDevice);
	void InvalidateDeviceObjects(){pMesh->InvalidateDeviceObjects();}
	void Destroy(){pMesh->Destroy();}
	void Delete(){SAFE_DELETE(pMesh);}
	
	// ----------------------------------------------------------------------------
	// Geter & Seter
	inline void SetId(int i) {id=i;}
	inline CD3DMesh *GetMesh() {return pMesh;}

};
// ----------------------------------------------------------------------------
// �p�[�e�B�N���̊Ǘ�
// ----------------------------------------------------------------------------
class CParticleMgr{
private:
	CParticle		object[PARTICLE_MAX];
public:
	 CParticleMgr(){for(DWORD i=0;i<PARTICLE_MAX;i++) object[i].SetId(i);}
	~CParticleMgr(){for(DWORD i=0;i<PARTICLE_MAX;i++) object[i].Delete();}
	void CreateMesh(LPDIRECT3DDEVICE9 pd3dDevice, TCHAR *filename){
		for(DWORD i=0;i<PARTICLE_MAX;i++){
			object[i].CreateMesh(pd3dDevice, filename);
		}
	}
	void RestoreDeviceObjects(LPDIRECT3DDEVICE9 pd3dDevice){
		for(DWORD i=0;i<PARTICLE_MAX;i++){
			object[i].RestoreDeviceObjects(pd3dDevice);
		}
	}
	void InvalidateDeviceObjects(){
		for(DWORD i=0;i<PARTICLE_MAX;i++){
			object[i].InvalidateDeviceObjects();
		}
	}
	void Destroy(){
		for(DWORD i=0;i<PARTICLE_MAX;i++){
			object[i].Destroy();
		}
	}

	CParticle *GetObj(DWORD i){return &object[i];}
};
//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	LPDIRECT3DVERTEXDECLARATION9 m_pDecl;	// ���_�錾
	CD3DMesh*				m_pMeshBg;		// �w�i���f��
	CParticleMgr*			m_pParticle;	// �p�[�e�B�N��
	FLOAT					m_TexWorldScale;

	// �V�F�[�_
	LPD3DXEFFECT     m_pEffect;		// �G�t�F�N�g�t�@�C��
	D3DXHANDLE		 m_hTechnique;	// �e�N�j�b�N
	D3DXHANDLE       m_hmWVP;		// ���[�J��-�ˉe�s��
	D3DXHANDLE       m_hvVector;	// �ėp�x�N�g��

	// �����_�����O�^�[�Q�b�g
	LPDIRECT3DTEXTURE9		m_pParticleTex;		// Particle map
	LPDIRECT3DSURFACE9		m_pParticleSurf;


    BOOL                    m_bLoadingApp;  // TRUE, if the app is loading
    CD3DFont*               m_pFont;        // Font for drawing text
    UserInput               m_UserInput;    // Struct for storing user input 

	D3DXMATRIX				m_mView;		// View matrix
	D3DXMATRIX				m_mProj;		// Projection matrix
    FLOAT                   m_fWorldRotX;   // World rotation state X-axis
    FLOAT                   m_fWorldRotY;   // World rotation state Y-axis
	FLOAT					m_zoom;			// Amount of track back of the camera


protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT, D3DFORMAT );

    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
	void	InitParticleMap();
	void	UpdateParticleMap();

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

