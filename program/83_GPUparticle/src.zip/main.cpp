//-----------------------------------------------------------------------------
// File: main.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"


#define PARTICLEMAP_WIDTH  64
#define PARTICLEMAP_HEIGHT 4


typedef struct {
	FLOAT p[4];
	D3DCOLOR c;
} LVERTEX;

typedef struct {
	FLOAT p[3];		// �ʒu���W
	FLOAT n[3];		// �@��
	FLOAT tu, tv;	// �e�N�X�`��
	FLOAT du, dv;	// �f�B�X�v���[�X�����g
} MESH_VERTEX;

//-----------------------------------------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;




//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}


// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// �p�[�e�B�N���N���X
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
void CParticle::CreateMesh(LPDIRECT3DDEVICE9 pd3dDevice, TCHAR *filename)
{
	pMesh->Create( pd3dDevice, filename );
}
// ----------------------------------------------------------------------------
void CParticle::RestoreDeviceObjects(LPDIRECT3DDEVICE9 pd3dDevice)
{
	if( pMesh->m_pSysMemMesh ){
		if( FAILED( pMesh->m_pSysMemMesh->CloneMesh(
						D3DXMESH_NPATCHES, decl,
						pd3dDevice, &pMesh->m_pLocalMesh ) ) )
			return;
		D3DXComputeNormals( pMesh->m_pLocalMesh, NULL );
		
		// �f�B�X�v���[�X�����g�}�b�v�̍��W���w�肷��
		MESH_VERTEX* pVertices;
		pMesh->m_pLocalMesh->LockVertexBuffer( 0L, (LPVOID*)&pVertices );
		for(DWORD i=0;i<pMesh->m_pLocalMesh->GetNumVertices();i++){
			pVertices[i].du = (0.5f+(FLOAT)id)/PARTICLEMAP_WIDTH;
			pVertices[i].dv = 0.5f/PARTICLEMAP_HEIGHT;
		}
		pMesh->m_pLocalMesh->UnlockVertexBuffer();
	}
}



//-----------------------------------------------------------------------------
// Name: InitParticleMap()
// Desc: �e�N�X�`���̏�����
//-----------------------------------------------------------------------------
void CMyD3DApplication::InitParticleMap()
{
	int i, j;
	D3DXVECTOR4 v;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;

	m_pd3dDevice->BeginScene();

	//-------------------------------------------------------------------------
	// �o�b�N�o�b�t�@�̑ޔ�
	//-------------------------------------------------------------------------
	m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
	m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
	m_pd3dDevice->GetViewport(&oldViewport);

	//-------------------------------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̕ύX
	//-------------------------------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, m_pParticleSurf);
	m_pd3dDevice->SetDepthStencilSurface(NULL);
	D3DVIEWPORT9 map_viewport = {0,0, PARTICLEMAP_WIDTH, PARTICLEMAP_HEIGHT, 0.0f,1.0f};
	m_pd3dDevice->SetViewport(&map_viewport);
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET, 0x808080, 1.0f, 0L );
	
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,   D3DTOP_DISABLE);
	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE );

	//-------------------------------------------------------------------------
	// �ʒu�A���x�̏�����
	//-------------------------------------------------------------------------
	LVERTEX Vertex[4] = {
		//        x                  y           z
		{{                0,                  0,0.5,1},},
		{{PARTICLEMAP_WIDTH,                  0,0.5,1},},
		{{                0, PARTICLEMAP_HEIGHT,0.5,1},},
		{{PARTICLEMAP_WIDTH, PARTICLEMAP_HEIGHT,0.5,1},},
	};

	m_pEffect->SetTechnique( m_hTechnique );
	m_pEffect->Begin( NULL, 0 );
	m_pEffect->Pass( 1 );
	for(i=0;i<PARTICLEMAP_WIDTH;i++){
	for(j=0;j<2;j++){
		v.x = 0.1f*(frand()-0.5f)+0.5f;
		v.y = 0.1f*(frand()-0.5f)+0.5f;
		v.z = 0.1f*(frand()-0.5f)+0.5f;
		v.w = 1.0f;

		Vertex[0].p[0] = (float)i    ;
		Vertex[1].p[0] = (float)(i+1);
		Vertex[2].p[0] = (float)i    ;
		Vertex[3].p[0] = (float)(i+1);
		Vertex[0].p[1] = (float)j    ;
		Vertex[1].p[1] = (float)j    ;
		Vertex[2].p[1] = (float)(j+1);
		Vertex[3].p[1] = (float)(j+1);

		m_pEffect->SetVector(m_hvVector, &v );
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, Vertex, sizeof( LVERTEX ) );
	}
	}
	m_pEffect->End();


	//-------------------------------------------------------------------------
	// ���ɖ߂�
	//-------------------------------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	m_pd3dDevice->SetViewport(&oldViewport);
	pOldBackBuffer->Release();
	pOldZBuffer->Release();

	m_pd3dDevice->EndScene();
}
//-----------------------------------------------------------------------------
// Name: UpdateParticleMap()
// Desc: 
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateParticleMap()
{
	D3DXVECTOR4 v;

	//-----------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̕ύX
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, m_pParticleSurf);
	m_pd3dDevice->SetDepthStencilSurface(NULL);
	D3DVIEWPORT9 viewport = {0,0
					, PARTICLEMAP_WIDTH
					, PARTICLEMAP_HEIGHT
					, 0.0f,1.0f};
	m_pd3dDevice->SetViewport(&viewport);

	//-----------------------------------------------------
	// �ړ�
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,   D3DTOP_DISABLE);

	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX2 | D3DFVF_TEXCOORDSIZE2(0) | D3DFVF_TEXCOORDSIZE2(1) );
	m_pEffect->SetTechnique( m_hTechnique );
	m_pEffect->Begin( NULL, 0 );
	m_pEffect->Pass( 2 );
	m_pEffect->SetTexture("ParticleMap", m_pParticleTex );

	typedef struct {FLOAT p[4]; FLOAT tu0, tv0; FLOAT tu1, tv1;} T2VERTEX;
	T2VERTEX TVertex[4] = {
		//         x         y  z rhw             tu1                     tv1                        tu2                     tv2
		{{                0, 0, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 0, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{                0, 2, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 2.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 3.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 2, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 2.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 3.5f/PARTICLEMAP_HEIGHT,},
	};
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, TVertex, sizeof( T2VERTEX ) );

	//-----------------------------------------------------
	// ���˕Ԃ�
	//-----------------------------------------------------

	// ���x����
	T2VERTEX TVertexV[4] = {
		//         x         y  z rhw             tu1                     tv1                        tu2                     tv2
		{{                0, 1, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 1, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{                0, 2, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 2, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
	};
	m_pEffect->Pass( 3 );
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, TVertexV, sizeof( T2VERTEX ) );
	// �ʒu����
	T2VERTEX TVertexX[4] = {
		//         x         y  z rhw             tu1                     tv1                        tu2                     tv2
		{{                0, 0, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 0, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{                0, 1, 0, 1}, 0+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 0+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
		{{PARTICLEMAP_WIDTH, 1, 0, 1}, 1+0.5f/PARTICLEMAP_WIDTH, 0.5f/PARTICLEMAP_HEIGHT, 1+0.5f/PARTICLEMAP_WIDTH, 1.5f/PARTICLEMAP_HEIGHT,},
	};
	m_pEffect->Pass( 4 );
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, TVertexX, sizeof( T2VERTEX ) );

	m_pEffect->End();

	//-----------------------------------------------------
	// �����x�̍Đݒ�
	//-----------------------------------------------------
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,   D3DTOP_DISABLE);

	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE );
	LVERTEX ClearVertex[4] = {
		//       x          y z rhw   color
		{{                0,2,0, 1}, 0x807c80,},
		{{PARTICLEMAP_WIDTH,2,0, 1}, 0x807c80,},
		{{                0,3,0, 1}, 0x807c80,},
		{{PARTICLEMAP_WIDTH,3,0, 1}, 0x807c80,},
	};
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, ClearVertex, sizeof( LVERTEX ) );

	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
}

//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pDecl						= NULL;
	m_pMeshBg					= new CD3DMesh();	
	m_pParticle					= new CParticleMgr();	
	m_TexWorldScale				= 1.0f;

	m_pEffect					= NULL;
	m_hTechnique				= NULL;
	m_hmWVP						= NULL;
	m_hvVector					= NULL;

	m_pParticleTex				= NULL;
	m_pParticleSurf				= NULL;
	
	m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    // Create a D3D font using d3dfont.cpp
    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = -0.10f*D3DX_PI;
    m_fWorldRotY                =  0.25f*D3DX_PI;
	m_zoom						=  4.5f;
}




//-----------------------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//-----------------------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // TODO: perform one time initialization

    // Drawing loading status message until app finishes loading
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}





//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
D3DFORMAT adapterFormat, D3DFORMAT backBufferFormat )
{
    UNREFERENCED_PARAMETER( adapterFormat );
    UNREFERENCED_PARAMETER( backBufferFormat );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
    // ���_�V�F�[�_
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    // �s�N�Z���V�F�[�_
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;
    if(!(pCaps->DevCaps2 & D3DDEVCAPS2_DMAPNPATCH ) ||
       FAILED( m_pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal
										, pCaps->DeviceType
                                        ,  adapterFormat
                                        ,  D3DUSAGE_RENDERTARGET|D3DUSAGE_DMAP
                                        ,  D3DRTYPE_TEXTURE
                                        ,  D3DFMT_A32B32G32R32F ) ))
		return E_FAIL;

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
	HRESULT hr;

	// ���_�錾
	if( FAILED( hr = m_pd3dDevice->CreateVertexDeclaration( decl, &m_pDecl ) ) )
		return DXTRACE_ERR( "CreateVertexDeclaration", hr );
	
	// ��Ԃ��
	m_pParticle->CreateMesh( m_pd3dDevice, "star.x" );

	// �w�i
	if( FAILED( hr = m_pMeshBg->Create(m_pd3dDevice, "InBox.x" )))
		return DXTRACE_ERR( "Load Mesh", hr );

    // �V�F�[�_
    LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
                m_pd3dDevice, "hlsl.fx", NULL, NULL, 
                0, NULL, &m_pEffect, &pErr ))){
        MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
                    , "ERROR", MB_OK);
        return DXTRACE_ERR( "CreateEffectFromFile", hr );
    }
    m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
    m_hmWVP = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvVector = m_pEffect->GetParameterByName( NULL, "vVector" );

    // Init the font
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    D3DXMATRIX m;
	
	if( m_pEffect != NULL ) m_pEffect->OnResetDevice();	// �V�F�[�_
	m_pMeshBg->RestoreDeviceObjects(m_pd3dDevice);		// ���b�V��
	m_pParticle->RestoreDeviceObjects(m_pd3dDevice);	// ���b�V��
    m_pFont->RestoreDeviceObjects();					// �t�H���g

	//-------------------------------------------------------------------------
	// �e�N�X�`���̐���
	//-------------------------------------------------------------------------
	// particle map
	if (FAILED(m_pd3dDevice->CreateTexture(
					  PARTICLEMAP_WIDTH, PARTICLEMAP_HEIGHT, 1
					, D3DUSAGE_RENDERTARGET|D3DUSAGE_DMAP, D3DFMT_A32B32G32R32F
					, D3DPOOL_DEFAULT, &m_pParticleTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pParticleTex->GetSurfaceLevel(0, &m_pParticleSurf)))
		return E_FAIL;
	
	this->InitParticleMap();	// ������

	
	// ���C�g
    D3DLIGHT9 light;
    D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -0.5f, -1.0f, 2.0f );
    m_pd3dDevice->SetLight( 0, &light );
    m_pd3dDevice->LightEnable( 0, TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // �e�N�X�`��
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

    // �����_�����O�X�e�[�g
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        D3DZB_TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // �r���[�s��
	D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_zoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mView );

    // �ˉe�s��
    D3DXMATRIX matProj;
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mProj );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    D3DXMATRIX m;
    D3DXMATRIX mCamera;
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	// �Y�[��
	if(m_UserInput.bZ && !m_UserInput.bX)
		m_zoom += 0.01f;
	else if(m_UserInput.bX && !m_UserInput.bZ)
		m_zoom -= 0.01f;

    // �J�����𓮂���
	if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
    D3DXMatrixMultiply( &mCamera, &matRotY, &matRotX );

    // �r���[�s��̍Đݒ�
	D3DXVECTOR3 vEye    = D3DXVECTOR3( 0.0f, 0.0f, -m_zoom );
    D3DXVECTOR3 vLookat = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m, &vEye, &vLookat, &vUp );

	m_mView = mCamera * m;

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );

	pUserInput->bZ = ( m_bActive && (GetAsyncKeyState( 'Z' ) & 0x8000) == 0x8000 );
	pUserInput->bX = ( m_bActive && (GetAsyncKeyState( 'X' ) & 0x8000) == 0x8000 );
}



//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	D3DXMATRIX matIdentity;
    D3DXMATRIX m, mVP;
	D3DXMATRIX mW;
    D3DXMATRIX mVisibleProj;
	D3DXVECTOR4 v;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;

	// �`��J�n
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//---------------------------------------------------------------------
		// �o�b�N�o�b�t�@�̑ޔ�
		//---------------------------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//---------------------------------------------------------------------
		// �p�[�e�B�N���̈ړ�
		//---------------------------------------------------------------------
		UpdateParticleMap( );

		//-------------------------------------------------
		// �o�b�N�o�b�t�@�����ɖ߂�
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
							0x404080, 1.0f, 0L );

		//---------------------------------------------------------------------
        // �w�i�̕`��
		//---------------------------------------------------------------------
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_USEW );
		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);

		D3DXMatrixIdentity( &matIdentity );
		m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );
		m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mView );
	    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mProj );

		m_pMeshBg->Render( m_pd3dDevice );

		m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
		m_pd3dDevice->SetSamplerState (0,D3DSAMP_MAGFILTER ,	D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState (0,D3DSAMP_MINFILTER ,	D3DTEXF_LINEAR );
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);

		//-------------------------------------------------------------------------
		// �f�B�X�v���[�X�����g�}�b�s���O���g���ăp�[�e�B�N����`�悷��
		//-------------------------------------------------------------------------
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );
		m_pEffect->Pass( 0 );

		// �ϊ��s��
		m = m_mView * m_mProj;
		m_pEffect->SetMatrix( m_hmWVP, &m );
		// �e�N�X�`��
		m_pEffect->SetTexture("DecaleMap", m_pParticle->GetObj(0)->GetMesh()->m_pTextures[0] );

		m_pd3dDevice->SetNPatchMode(1);	// �f�B�X�v���[�X�����g�}�b�v���g�p����
		m_pd3dDevice->SetVertexDeclaration( m_pDecl );
		m_pd3dDevice->SetTexture(D3DDMAPSAMPLER, m_pParticleTex);
		for(DWORD i=0;i<PARTICLE_MAX;i++){
			m_pParticle->GetObj(i)->GetMesh()->Render( m_pd3dDevice );
		}
		m_pd3dDevice->SetNPatchMode(0);	// �f�B�X�v���[�X�����g����߂�
		m_pEffect->End();

#if 1 // �f�o�b�O�p�Ƀe�N�X�`��������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetPixelShader(0);
		for(DWORD l = 0; l < 1; l++){
			const float scale =128.0f;
			FLOAT X = (FLOAT)this->m_rcWindowClient.right;
			FLOAT Y = (FLOAT)this->m_rcWindowClient.bottom;
			typedef struct {FLOAT p[4];	FLOAT tu, tv;} TVERTEX;
			TVERTEX Vertex[4] = {
				//  x       y    z rhw tu tv
				{X-(l+1)*scale,Y-scale,0, 1, 0.0f, 0.0f,},
				{X-(l+0)*scale,Y-scale,0, 1, 1.0f, 0.0f,},
				{X-(l+0)*scale,Y      ,0, 1, 1.0f, 1.0f,},
				{X-(l+1)*scale,Y      ,0, 1, 0.0f, 1.0f,},
			};
			switch(l){
			case 0:	m_pd3dDevice->SetTexture( 0, m_pParticleTex );	break;
			}
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
		}
#endif

        // Render stats and help text  
        RenderText();

		// End the scene.
        m_pd3dDevice->EndScene();
	}

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: Renders stats and help text to the scene.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    // Output display stats
    FLOAT fNextLine = 40.0f; 

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Draw on the window tell the user that the app is loading
                // TODO: change as needed
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }
    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    // TODO: Cleanup any objects created in RestoreDeviceObjects()
	SAFE_RELEASE(m_pParticleSurf);
	SAFE_RELEASE(m_pParticleTex);

	// mesh
	m_pMeshBg->InvalidateDeviceObjects();
	m_pParticle->InvalidateDeviceObjects();

	// Shader
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    m_pFont->InvalidateDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // TODO: Cleanup any objects created in InitDeviceObjects()

	// Mesh
	m_pMeshBg->Destroy();
	m_pParticle->Destroy();
	
	SAFE_RELEASE( m_pDecl );

	SAFE_RELEASE( m_pEffect );    // Shader

    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    // TODO: Perform any final cleanup needed

	// Mesh
	SAFE_DELETE( m_pMeshBg );
	
	SAFE_DELETE( m_pParticle );

    // Cleanup D3D font
    SAFE_DELETE( m_pFont );

    return S_OK;
}




