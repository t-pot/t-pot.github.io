//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Bitonic sort
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "Common/DXUtil.h"
#include "Common/D3DEnumeration.h"
#include "Common/D3DSettings.h"
#include "Common/D3DApp.h"
#include "Common/D3DFont.h"
#include "Common/D3DFile.h"
#include "Common/D3DUtil.h"
#include "resource.h"
#include "main.h"

// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState

#define frand() ((float)rand()/RAND_MAX)

#if 0
#define TEX_WIDTH  2
#define TEX_HEIGHT 2
#define LOG_SIZE   2 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#if 0
#define TEX_WIDTH  4
#define TEX_HEIGHT 4
#define LOG_SIZE   4 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#if 0
#define TEX_WIDTH  16
#define TEX_HEIGHT 16
#define LOG_SIZE   8 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#if 0
#define TEX_WIDTH  256
#define TEX_HEIGHT 256
#define LOG_SIZE   16 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#if 1
#define TEX_WIDTH  512
#define TEX_HEIGHT 512
#define LOG_SIZE   18 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#if 1
#define TEX_WIDTH  1024
#define TEX_HEIGHT 1024
#define LOG_SIZE   20 // log2(TEX_WIDTH*TEX_HEIGHT)
#else
#endif
#endif
#endif
#endif
#endif
#endif

//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pSeedTex					= NULL;

	m_pSortTex[0]				= NULL;
	m_pSortTex[1]				= NULL;
	m_pSortSurf[0]				= NULL;
	m_pSortSurf[1]				= NULL;
	m_id						= 0;
	this->SetState(STATE_INIT);

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_htSrcMap					= NULL;
	m_hstage					= NULL;
	m_hstepno					= NULL;
	m_hoffset					= NULL;

	m_dwCreationWidth           = 512+20;
    m_dwCreationHeight          = 512+20;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
	m_bDispText					= FALSE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: CreateSeedTex()
// Desc: CreateSeedTex �e�N�X�`���̍쐬
//-------------------------------------------------------------
VOID WINAPI CreateSeedTex (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexCoord );
    UNREFERENCED_PARAMETER( pTexelSize );
    UNREFERENCED_PARAMETER( pData );

#if 0
	float c = pTexCoord->x/pTexelSize->x-0.5;
	c = TEX_HEIGHT-c;
    pOut->x = 
	pOut->y = 
	pOut->z = 
	pOut->w = c/TEX_HEIGHT;
#else
    pOut->x = 
	pOut->y = 
	pOut->z = 
	pOut->w = frand();
#endif
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    return S_OK;
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_htSrcMap   = m_pEffect->GetParameterByName( NULL, "SrcMap" );
	m_hstage     = m_pEffect->GetParameterByName( NULL, "stage" );
	m_hstepno    = m_pEffect->GetParameterByName( NULL, "stepno" );
	m_hoffset    = m_pEffect->GetParameterByName( NULL, "offset" );
	// �e�N�X�`���T�C�Y
	D3DXVECTOR4 BufInfo = D3DXVECTOR4(TEX_WIDTH, TEX_HEIGHT, 0,0);
	m_pEffect->SetVector("BufInfo",  &BufInfo);

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}




//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    HRESULT hr;
	int i;
	
	// ��ԃ��Z�b�g
	this->SetState(STATE_INIT);

	// �G�t�F�N�g
	m_pEffect->OnResetDevice();
	
	// ������
	if( FAILED(hr = m_pd3dDevice->CreateTexture(TEX_WIDTH, TEX_HEIGHT, 1
                          , D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
                          , D3DPOOL_DEFAULT, &m_pSeedTex, NULL)))
        return hr;


    // �����_�����O�^�[�Q�b�g
	for(i=0;i<2;i++){
		if (FAILED(m_pd3dDevice->CreateTexture(TEX_WIDTH, TEX_HEIGHT, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8
							, D3DPOOL_DEFAULT, &m_pSortTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pSortTex[i]->GetSurfaceLevel(0, &m_pSortSurf[i])))
			return E_FAIL;
	}


	// �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
	RS( D3DRS_ZENABLE, FALSE );
	RS( D3DRS_LIGHTING, FALSE );

	TSS(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
	TSS(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	TSS(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);

    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Sort()
// Desc: �Q�����̃\�[�g������
//-------------------------------------------------------------
BOOL CMyD3DApplication::Sort()
{
	//-------------------------------------------------
	// �p�����[�^�̌v�Z
	//-------------------------------------------------
	int step = m_cnt;
	int rank;
	for(rank = 0; rank<step ; rank++){
		step -= rank+1;
	}

	float stepno = (float)(1<<(rank+1));
	float offset = (float)(1<<(rank-step));
	float stage  = 2*offset;

	if(LOG_SIZE<=rank) return FALSE;// ���łɃ\�[�g�ς�

	//-------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̐؂�ւ�
	//-------------------------------------------------
	m_id=1-m_id;
	m_pd3dDevice->SetRenderTarget(0, m_pSortSurf[m_id]);
	m_pd3dDevice->SetDepthStencilSurface(NULL);
	// �r���[�|�[�g�̕ύX
	D3DVIEWPORT9 viewport = {0,0 // ����̍��W
					, TEX_WIDTH  // ��
					, TEX_HEIGHT // ����
					, 0.0f,1.0f};// �O�ʁA���
	m_pd3dDevice->SetViewport(&viewport);

	if( m_pEffect != NULL ) 
	{
		//-------------------------------------------------
		// �V�F�[�_�̐ݒ�
		//-------------------------------------------------
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );
		m_pEffect->Pass( 0 );

		//-------------------------------------------------
		// �`��
		//-------------------------------------------------
		static CONST FLOAT w = TEX_WIDTH;
		static CONST FLOAT h = TEX_HEIGHT;
		static CONST TVERTEX Vertex1[4] = {
			//x  y   z   rhw   tu    tv
			{ 0, 0, 0.1f, 1,  0, 0,},
			{ w, 0, 0.1f, 1,  1, 0,},
			{ w, h, 0.1f, 1,  1, 1,},
			{ 0, h, 0.1f, 1,  0, 1,},
		};
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1);
		m_pEffect->SetTexture( m_htSrcMap,    m_pSortTex [1-m_id]);

		m_pEffect->SetFloat(m_hstage,  stage);
		m_pEffect->SetFloat(m_hstepno, stepno);
		m_pEffect->SetFloat(m_hoffset, offset);

		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, Vertex1, sizeof( TVERTEX ) );
		
		m_pEffect->End();
	}

	return TRUE;
}
//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
int CMyD3DApplication::RenderStateSort()
{
	int ret = 0;
	HRESULT hr;

	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
    D3DVIEWPORT9 oldViewport;

	//---------------------------------------------------------
	// �ЂƋx�� �ЂƋx��
	//---------------------------------------------------------
	Sleep(50);

	//---------------------------------------------------------
	// �����_�����O�^�[�Q�b�g�̕ۑ�
	//---------------------------------------------------------
	m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
	m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
	m_pd3dDevice->GetViewport(&oldViewport);

	//---------------------------------------------------------
	// ������
	//---------------------------------------------------------
	if(0==m_cnt){
		// ��̍쐬
	    if( FAILED(hr = D3DXFillTexture(m_pSeedTex, CreateSeedTex, NULL))) return hr;
		
		// �����_�����O�^�[�Q�b�g�̕ύX
		m_pd3dDevice->SetRenderTarget(0, m_pSortSurf[m_id]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		D3DVIEWPORT9 viewport = {0,0 // ����̍��W
						, TEX_WIDTH   // ��
						, TEX_HEIGHT  // ����
						, 0.0f,1.0f};// �O�ʁA���
		m_pd3dDevice->SetViewport(&viewport);

		// �e�N�X�`���𒣂�
		TVERTEX VertexSeed[4] = {
			//   x          y       z rhw tu tv
			{         0,         0, 0, 1, 0, 0,},
			{ TEX_WIDTH,         0, 0, 1, 1, 0,},
			{ TEX_WIDTH,TEX_HEIGHT, 0, 1, 1, 1,},
			{         0,TEX_HEIGHT, 0, 1, 0, 1,},
		};
		m_pd3dDevice->SetFVF(D3DFVF_XYZRHW| D3DFVF_TEX1);
		m_pd3dDevice->SetTexture( 0, m_pSeedTex );
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, VertexSeed, sizeof( TVERTEX ) );
	}
	
	//---------------------------------------------------------
	// �\�[�g
	//---------------------------------------------------------
	BOOL bDo;// ���ۂɃ\�[�g�����H
	bDo = this->Sort();

	//-----------------------------------------------------
	// �����_�����O�^�[�Q�b�g�����ɖ߂�
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	m_pd3dDevice->SetViewport(&oldViewport);

	pOldBackBuffer->Release();
	pOldZBuffer->Release();

	//-----------------------------------------------------
	// ��ʂ̕`��
	//-----------------------------------------------------
	if(bDo){
		// �\�[�g��
		m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, D3DCOLOR_RGBA(50,100,200,0), 0, 0);
	}else{
		// �\�[�g�I���I�I
		m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, D3DCOLOR_RGBA(255,50,50,0), 0, 0);
	}

	float w = (float)this->m_d3dsdBackBuffer.Width -20;
	float h = (float)this->m_d3dsdBackBuffer.Height-20;
	TVERTEX VertexFinal[4] = {
		//  x     y   z rhw tu tv
		{ 10+0, 10,  0, 1, 0, 0,},
		{ 10+w, 10,  0, 1, 1, 0,},
		{ 10+w, 10+h,0, 1, 1, 1,},
		{ 10+0, 10+h,0, 1, 0, 1,},
	};
	m_pd3dDevice->SetFVF(D3DFVF_XYZRHW| D3DFVF_TEX1);
	m_pd3dDevice->SetTexture( 0, m_pSortTex[m_id] );
	m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
					, 2, VertexFinal, sizeof( TVERTEX ) );

	//-----------------------------------------------------
	// �I������
	//-----------------------------------------------------
	int max = LOG_SIZE*(LOG_SIZE+1)/2;// �\�[�g�ɂ����鎞��
	if(max+100<=m_cnt+1){ret = -1;}
//	if(max<=m_cnt+1){ret = -1;}// �\�[�g����ɏI������Ƃ�

	return ret;
}
//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		switch(m_iState){
		case STATE_INIT:
			m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, 0, 0, 0);
			this->SetState(STATE_SORT);
			break;
		case STATE_SORT:
			if(this->RenderStateSort()) this->SetState(STATE_INIT);
			break;
		}

        // �w���v�̕\��
        if(m_bDispText)RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

	m_cnt++;

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }
        case WM_COMMAND:
            switch( LOWORD(wParam) ){
            case ID_MENUITEM_INFO:
				// �e�L�X�g�̕\����펞
				m_bDispText ^= 1;
				MENUITEMINFO menu; 
				ZeroMemory(&menu, sizeof(MENUITEMINFO)); 
				menu.cbSize = sizeof(MENUITEMINFO); 
				menu.fMask = MIIM_STATE; 
				if(m_bDispText)menu.fState = MFS_CHECKED; 
				SetMenuItemInfo(GetMenu(this->m_hWnd), ID_MENUITEM_INFO, FALSE, &menu); 
	            break;
            }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	SAFE_RELEASE(m_pSortSurf[1]);
	SAFE_RELEASE(m_pSortSurf[0]);
    SAFE_RELEASE(m_pSortTex[1]);
    SAFE_RELEASE(m_pSortTex[0]);

	SAFE_RELEASE( m_pSeedTex );

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	
    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




