//-------------------------------------------------------------
// File: main.cpp
//
// Desc: NV40 test
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <time.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE			(16*8)

//-------------------------------------------------------------
// Globals variables and definitions(�O���[�o���ϐ��ƒ�`)
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//       (���C���֐�)
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//       (�A�v���P�[�V�����̃R���X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	int i;

	for( i = 0; i < 2; i++ )
	{
		m_pReductionTex[i]		= NULL;
		m_pReductionSurf[i]		= NULL;
	}

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_htSrcTex					= NULL;
	m_fWidth					= NULL;
	m_fHeight					= NULL;

	m_dwCreationWidth           = 600;
    m_dwCreationHeight          = 300;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//       (�f�X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//      (��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // Drawing loading status message until app finishes loading
    // (���[�f�B���O���b�Z�[�W��\������)
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the device
//       for some minimum set of capabilities
//       (�������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

    // No fallback, so need ps2.0
	// (�s�N�Z���V�F�[�_�o�[�W�����`�F�b�N)
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // If device doesn't support 1.1 vertex shaders in HW, switch to SWVP.
    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}


//-------------------------------------------------------------
// SH coefficient of imcomming light
//-------------------------------------------------------------
// Variables send from application

VOID WINAPI ParaboloidJacobian (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexelSize );

	FLOAT x = 2.0f*( pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(-pTexCoord->y+0.5f);
	
	FLOAT r2 = x*x+y*y;
	FLOAT J = 0.5f*(1.0f+r2);

    FLOAT col = (r2<(1.0f-1.0f/(FLOAT)MAP_SIZE)*(1.0f-1.0f/(FLOAT)MAP_SIZE)) ? J : 0.0f;
	
	// Normal vector
	FLOAT nz = 0.5f * (1.0f-r2);
	FLOAT nx = x;
	FLOAT ny = y;
	FLOAT n = sqrtf(nx*nx+ny*ny+nz*nz);
	nx /= n;
	ny /= n;
	nz /= n;

	pOut->x = 0.5f * col * (-nx) + 0.5f;
	pOut->y = 0.5f * col * ( ny) + 0.5f;
	pOut->z = 0.5f * col * (-nz) + 0.5f;
	pOut->w = 0.5f * col         + 0.5f;
}

//-------------------------------------------------------------
// �^�񒆂������G�����
//-------------------------------------------------------------
VOID WINAPI FillTex (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pData );

	FLOAT x = 2.0f*(pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(pTexCoord->y-0.5f);
    FLOAT col = (x*x+y*y<(1.0f-pTexelSize->x)*(1.0f-pTexelSize->y))
				? 1.0f : 0.0f;
	
	pOut->x = pOut->y = pOut->z = pOut->w = col;
}

//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//      (�f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς������ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
        
	// Create textures
	if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
						, 0, D3DFMT_A8R8G8B8
						, D3DPOOL_MANAGED, &m_pJacobianTex, NULL)))
		return E_FAIL;
	if( FAILED(D3DXFillTexture(m_pJacobianTex, ParaboloidJacobian, NULL)))
		return E_FAIL;


    // Create the effect(�V�F�[�_�̓ǂݍ���)
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );
	m_fWidth	 = m_pEffect->GetParameterByName( NULL, "MAP_WIDTH" );
	m_fHeight	 = m_pEffect->GetParameterByName( NULL, "MAP_HEIGHT" );

    // Init the font(�t�H���g)
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//       (��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		 �m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i;

    // Set miscellaneous render states(�����_�����O���̐ݒ�)
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
    
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	int size = 16;
	for( i = 0; i < 2; i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture(size, size, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pReductionTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pReductionTex[i]->GetSurfaceLevel(0, &m_pReductionSurf[i])))
			return E_FAIL;
	}


    // Restore effect object
	m_pEffect->OnResetDevice();

    // Restore the font(�t�H���g)
    m_pFont->RestoreDeviceObjects();

	return S_OK;
}

//-------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//       (���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	return S_OK;
}


//-------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//       (��ʂ�`�悷��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;

	D3DVIEWPORT9 viewport = {0,0      // ����̍��W
					, 1, 1  // ��,����
					, 0.0f,1.0f};     // �O�ʁA���

	// Begin the scene(�`��J�n)
	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//---------------------------------------------------------
		// Create maps(�e�N�X�`���̐���)
		//---------------------------------------------------------

	    // Clear the render buffers(�t���[���o�b�t�@�̃N���A)
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000040, 1.0f, 0L);

		//-------------------------------------------------
		// �V�F�[�_�̐ݒ�
		//-------------------------------------------------
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );

		m_pEffect->SetFloat( m_fWidth,  8);
		m_pEffect->SetFloat( m_fHeight, 8);

		m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

		for( int i = 0; i < 2; i++ )
		{
			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ύX
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[i]);
			m_pd3dDevice->SetDepthStencilSurface(NULL);
			viewport.Width  = viewport.Height = 16;
			m_pd3dDevice->SetViewport(&viewport);

			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{-1.0f, +1.0f, 0.5f,  0, 0},
				{+1.0f, +1.0f, 0.5f,  1, 0},
				{+1.0f, -1.0f, 0.5f,  1, 1},
				{-1.0f, -1.0f, 0.5f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

			m_pEffect->SetFloat( m_fWidth,  128 );
			m_pEffect->SetFloat( m_fHeight, 128 );
			m_pEffect->SetTexture( m_htSrcTex, m_pJacobianTex );

			BEGIN_PASS( i );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

		}
		m_pEffect->End();
		
		
		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		float scale = 600.0f/3.0f;
		for(DWORD i=0; i<3; i++){
			TVERTEX Vertex[4] = {
				//    x                             y         z rhw tu tv
				{(i+0)*scale,     0, 0, 1, 0, 0,},
				{(i+1)*scale,     0, 0, 1, 1, 0,},
				{(i+1)*scale, scale, 0, 1, 1, 1,},
				{(i+0)*scale, scale, 0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pJacobianTex );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[0] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[1] );

			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}

        // Render stats and help text(�w���v�̕\��)
        RenderText();

		// End the scene.(�`��̏I��)
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: Draw the help & statistics for running sample
//       (��Ԃ�w���v����ʂɕ\������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");
    FLOAT fNextLine;

    // Draw help
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height-20; 
    m_pFont->DrawText( 6, fNextLine+2, 0xff000000, TEXT("t-pot.com") );
    m_pFont->DrawText( 4, fNextLine,   0xffff8040, TEXT("t-pot.com") );

    // Output statistics
    fNextLine -= 20.0f;
    lstrcpy( szMsg, m_strDeviceStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine -= 20.0f;
    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//       (WndProc ���I�[�o�[���C�h��������)
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Loading message(���[�h��)
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//       (RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// font(�t�H���g)
    m_pFont->InvalidateDeviceObjects();

	// Rendering targets (�����_�����O�^�[�Q�b�g)
	SAFE_RELEASE(m_pReductionSurf[1]);
	SAFE_RELEASE(m_pReductionTex[1]);
	SAFE_RELEASE(m_pReductionSurf[0]);
	SAFE_RELEASE(m_pReductionTex[0]);

	// Shaders(�V�F�[�_)
    if( m_pEffect    != NULL ) m_pEffect   ->OnLostDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//       (InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// font(�t�H���g)
    m_pFont->DeleteDeviceObjects();

	// textures (�e�N�X�`��)
	SAFE_RELEASE(m_pJacobianTex);

	// Shaders(�V�F�[�_)
	SAFE_RELEASE( m_pEffect );
	
    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//       (�I�����钼�O�ɌĂ΂��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	// font(�t�H���g)
    SAFE_DELETE( m_pFont );

    return S_OK;
}




