//-------------------------------------------------------------
// File: main.h
//
// Desc: NV40 test
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#pragma once

#define DX9C

#ifdef DX9C
	#define BEGIN_PASS(n) m_pEffect->BeginPass(n)
	#define END_PASS()    m_pEffect->EndPass()
#else// DX9C
	#define BEGIN_PASS(n) m_pEffect->Pass(n)
	#define END_PASS()
#endif // DX9C


//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Main class to run this application. Most functionality is inherited
//       from the CD3DApplication base class.
//       (�A�v���P�[�V�����̃N���X)
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	// Shader
	LPD3DXEFFECT		    m_pEffect;		// Effect for the sample(�G�t�F�N�g)
	D3DXHANDLE				m_hTechnique;	// Technique handle for RenderScene(�e�N�j�b�N)
	D3DXHANDLE				m_htSrcTex;		// Handle for the scene texture in effect(�e�N�X�`��)
	D3DXHANDLE				m_fWidth;		// Handle for the texture width in effect(�e�N�X�`����)
	D3DXHANDLE				m_fHeight;		// Handle for the texture height in effect(�e�N�X�`������)

	LPDIRECT3DTEXTURE9		m_pJacobianTex;	// SH coefficient of incoming light

	// Rendering targets (�����_�����O�^�[�Q�b�g)
	LPDIRECT3DTEXTURE9		m_pReductionTex [2];// Reduction buffer
	LPDIRECT3DSURFACE9		m_pReductionSurf[2];

	BOOL					m_bLoadingApp;	// TRUE, if the app is loading(���[�h���H)
    CD3DFont*				m_pFont;		// Font for drawing text(�t�H���g)

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

	HRESULT RenderText();

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

