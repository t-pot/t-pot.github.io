//-----------------------------------------------------------------------------
// File: main.cpp
//
// Desc: �����ϊ��ɂ��c�D�[��
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"



//-----------------------------------------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pTex = NULL;
	m_pMesh						= new CD3DMesh();

	m_pEffect = NULL;

    m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = -0.437504f;
    m_fWorldRotY                = 1.0f;

    m_fLightRotX                = 0.344792f;
    m_fLightRotY                =-0.722427f;
}




//-----------------------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-----------------------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}










//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(1,1) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}



//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �e�B�[�|�b�g�̓ǂݍ���
	if(FAILED(hr=m_pMesh  ->Create( m_pd3dDevice, _T("t-pot.x"))))
        return DXTRACE_ERR( "Load Object", hr );
	m_pMesh->UseMeshMaterials(FALSE);

	// �c�D�[���p�̃e�N�X�`��
	D3DXCreateTextureFromFile(m_pd3dDevice, "toon.bmp", &m_pTex);
    
	// �V�F�[�_�̓ǂݍ���
    LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
                m_pd3dDevice, "hlsl.fx", NULL, NULL, 
                D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
        MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
                    , "ERROR", MB_OK);
        return DXTRACE_ERR( "CreateEffectFromFile", hr );
    }

	// �t�H���g
    hr = m_pFont->InitDeviceObjects( m_pd3dDevice );
    if( FAILED( hr ) )
        return DXTRACE_ERR( "m_pFont->InitDeviceObjects", hr );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	// �V�F�[�_
	m_pEffect->OnResetDevice();

	// ���b�V��
	m_pMesh->RestoreDeviceObjects( m_pd3dDevice );

	// �����_�����O��Ԃ̐ݒ�
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

    // �r���[�s��
    D3DXMATRIX matView;
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -4.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mV, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    D3DXMATRIX matProj;
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mP, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;
	
	if(m_UserInput.bShift){
		// ���C�g�̉�]
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fLightRotY += m_fElapsedTime;
		else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fLightRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fLightRotX += m_fElapsedTime;
		else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fLightRotX -= m_fElapsedTime;
	}else{
		// �I�u�W�F�N�g�̉�]
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fWorldRotY += m_fElapsedTime;
		else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fWorldRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fWorldRotX += m_fElapsedTime;
		else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fWorldRotX -= m_fElapsedTime;
	}

	// �s��̍쐬
    D3DXMatrixRotationX( &matRotX, m_fLightRotX );
    D3DXMatrixRotationY( &matRotY, m_fLightRotY );
    D3DXMatrixMultiply( &m_mLight, &matRotY, &matRotX );

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
    D3DXMatrixMultiply( &m_mW, &matRotY, &matRotX );

    m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_mW );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );

	pUserInput->bShift = ((GetAsyncKeyState( VK_SHIFT )    & 0x8000) == 0x8000);
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	D3DXMATRIX m, mX, mY;
	D3DXVECTOR4 v;
	DWORD i;

	D3DXVECTOR4 LightPos = D3DXVECTOR4(0.0f, 0.0f, -3.0f, 0.0f);
	D3DXVec4Transform( &LightPos, &LightPos, &m_mLight );

	// �����_�����O�^�[�Q�b�g�̃N���A
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         0x000000ff, 1.0f, 0L );

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        if(m_pEffect){
			m_pEffect->SetTechnique( "TShader" );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );

			// �ϊ��s��̐ݒ�
			D3DXMATRIX mWVP = m_mW * m_mV * m_mP;
			m_pEffect->SetMatrix("mWVP", &mWVP);
			
			// ���C�g�̌���
			m = m_mW;
			D3DXMatrixInverse( &m, NULL, &m );
			D3DXVec4Transform( &v, &LightPos, &m );
			m_pEffect->SetVector("LightPos", &v);
			
			// ���_
			v = D3DXVECTOR4(0,0,-5,0);
			m = m_mW;
			D3DXMatrixInverse( &m, NULL, &m );
			D3DXVec4Transform( &v, &v, &m );
			m_pEffect->SetVector("EyePos", &v);
			
			m_pEffect->SetTexture("ToonTex", m_pTex);

			// Render the teapot mesh
			D3DMATERIAL9 *pMtrl = m_pMesh->m_pMaterials;
			for( i=0; i<m_pMesh->m_dwNumMaterials; i++ ) {
				v.x = pMtrl->Diffuse.r;
				v.y = pMtrl->Diffuse.g;
				v.z = pMtrl->Diffuse.b;
				m_pEffect->SetVector( "vColor", &v );
				m_pEffect->SetTexture( "DecaleTex", m_pMesh->m_pTextures[i] );
				m_pMesh->m_pLocalMesh->DrawSubset( i );  // �`��
				pMtrl++;
			}

			m_pEffect->End();
		}

		{// ���C�g�̈ʒu�̕\��
		m = m_mV * m_mP;
		v = LightPos;
		v.w = 1;
		D3DXVec4Transform( &v, &v, &m );
		float x = (this->m_rcWindowClient.right-this->m_rcWindowClient.left)*( 0.5f*v.x/v.w+0.5f);
		float y = (this->m_rcWindowClient.bottom-this->m_rcWindowClient.top)*(-0.5f*v.y/v.w+0.5f);

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE );
		m_pd3dDevice->SetPixelShader(0);

		typedef struct {FLOAT p[4]; DWORD color;} LVERTEX;
		for(DWORD i=0; i<2; i++){
			LVERTEX Vertex[4] = {
				// x  y   z rhw tu tv
				{x-3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y+3, v.z/v.w, 1, 0xffffc0,},
				{x-3,y+3, v.z/v.w, 1, 0xffffc0,},
			};
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( LVERTEX ) );
		}
		}

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 128.0f;
		typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;
		for(DWORD i=0; i<1; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pTex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		
        
		// �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

     FLOAT fNextLine = 40.0f; // �\�����鍂��

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 

    wsprintf( szMsg, TEXT("Arrow keys: Up=%d Down=%d Left=%d Right=%d"), 
              m_UserInput.bRotateUp, m_UserInput.bRotateDown, m_UserInput.bRotateLeft, m_UserInput.bRotateRight );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Use arrow keys to rotate object") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    if( m_pEffect ) m_pEffect->OnLostDevice();    // �V�F�[�_

	if( m_pMesh ) m_pMesh  ->InvalidateDeviceObjects(); // ���b�V��

    m_pFont->InvalidateDeviceObjects();    // �t�H���g

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// ���b�V��
	m_pMesh  ->Destroy();

	// �e�N�X�`��
	SAFE_RELEASE( m_pTex );

    // �V�F�[�_
    SAFE_RELEASE( m_pEffect );

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼�O�ɌĂ΂��
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	SAFE_DELETE( m_pMesh ); // ���b�V��
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




