
#include <d3d9.h>
#include <d3dx9.h>


#ifndef _PRIM_H_
#define _PRIM_H_

namespace Render {

// ---------------------------------------------------------------------------
// �v���~�e�B�u�̎��
// ---------------------------------------------------------------------------
enum {
	OBJ_TYPE_SPHERE = 0,
	OBJ_TYPE_TRIANGLE,
};
// ---------------------------------------------------------------------------
// ���������̂��߂̃f�[�^
// ---------------------------------------------------------------------------
typedef struct{
	float	COLOR_AMB[4];
	float	COLOR_DIF[4];
	float	COLOR_SPE[4];
	float	speq_power;
}Material;
// ---------------------------------------------------------------------------
typedef struct{
	int type;

	Material material;
	
	struct{
		// 3�p�`
		float x0[3];	// ���W�P
		float x1[3];	// ���W�Q
		float x2[3];	// ���W�R
	} triangle;
	struct {
		// �ʗp
		float center[3];// ���S
		float radius;	// ���a
	} sphere;

}OBJ_DATA;

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// �v���~�e�B�u
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
class CPrimitive
{
public:
	enum {
		INFINTY_DIST = 10000,
	};
	int m_type;
	Material m_material;

	void Init(OBJ_DATA *pData);
	float IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v){return INFINTY_DIST;}
	D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float LN, float HN );
};
// ---------------------------------------------------------------------------
// ��
// ---------------------------------------------------------------------------
class CSphere : public CPrimitive
{
private:
	D3DXVECTOR4 center;
	float radius_sq;

public:
	CSphere();

	void Init(OBJ_DATA *pData);
	float IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v);
};

// ---------------------------------------------------------------------------
// �R�p�`
// ---------------------------------------------------------------------------
class CTriangle : public CPrimitive
{
private:
	D3DXVECTOR4 pos[3];
	D3DXVECTOR4 t0; FLOAT l0;
	D3DXVECTOR4 t1; FLOAT l1;
	D3DXVECTOR4 normal;

public:
	CTriangle();

	void Init(OBJ_DATA *pData);
	float IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v);
};
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// ���b�V��
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
class CMesh
{
public:
	CMesh();
	~CMesh();
	CPrimitive **m_ppPrim;
	int         m_num;

	void  Init(OBJ_DATA *pData, int num);
	void  Delete();
	float IsAcross(float dist, D3DXVECTOR4 *n, D3DXVECTOR4 *p, CPrimitive **dest, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v);
	bool  IsAcross(float dist, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v);
};
// ---------------------------------------------------------------------------

};// namespace Render

#endif // !_PRIM_H_