#include "stdafx.h"
#include <d3d9.h>
#include <d3dx9.h>
#include "math.h"
#include "render.h"

namespace Render {

D3DXVECTOR3 BG_COLOR = D3DXVECTOR3(0.25f, 0.4f, 0.5f);// �w�i�F

class CCamera
{
private:
	D3DXMATRIX  m_mView;
	D3DXMATRIX  m_mProj;
	D3DXMATRIX  m_mVP;
	D3DXMATRIX  m_mVP_Inv;
	D3DXMATRIX  m_mView_Inv;
	D3DXVECTOR3 m_vFrom;
	D3DXVECTOR3 m_vLookat;
	D3DXVECTOR3 m_vUp;

	float	m_fFovy;
	float	m_fAspect;
	float   m_fNear;
	float   m_fFar;

public:

	void Update();
	void SetFrom  (const D3DXVECTOR3 *p){m_vFrom  =*p;}
	void SetLookAt(const D3DXVECTOR3 *p){m_vLookat=*p;}
	void SetUp    (const D3DXVECTOR3 *p){m_vUp    =*p;}
	void SetFovY  (float val){m_fFovy   = val;}
	void SetAspect(float val){m_fAspect = val;}
	void SetNear  (float val){m_fNear   = val;}
	void SetFar   (float val){m_fFar    = val;}
	inline const D3DXMATRIX *GetViewInverse() const {return &m_mView_Inv;}
	inline const D3DXMATRIX *GetViewProjInverse() const {return &m_mVP_Inv;}
};

// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
char s_data[4*RENDER_WIDTH*RENDER_HEIGHT];// ���z�t���[���o�b�t�@
CCamera camera;

// ---------------------------------------------------------------------------
// �֐��錾
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y);


// ---------------------------------------------------------------------------
// �J�����N���X
// ---------------------------------------------------------------------------
void CCamera::Update()
{
    D3DXMatrixLookAtLH( &m_mView, &m_vFrom, &m_vLookat, &m_vUp );
    D3DXMatrixPerspectiveFovLH( &m_mProj, m_fFovy, m_fAspect, m_fNear, m_fFar );
	m_mVP = m_mView * m_mProj;
	D3DXMatrixInverse( &m_mView_Inv, NULL, &m_mView);
	D3DXMatrixInverse( &m_mVP_Inv, NULL, &m_mVP);
}
// ---------------------------------------------------------------------------
char *GetDataPointer()
{
	return s_data;
}
// ---------------------------------------------------------------------------
void Init()
{
	// �t���[���o�b�t�@�̏�����
	for(int j=0;j<RENDER_HEIGHT;j++){
	for(int i=0;i<RENDER_WIDTH ;i++){
		s_data[4*(j*RENDER_WIDTH+i)+0]=(char)255;// R
		s_data[4*(j*RENDER_WIDTH+i)+1]=(char)(i*256/RENDER_WIDTH );// G
		s_data[4*(j*RENDER_WIDTH+i)+2]=(char)(j*256/RENDER_HEIGHT);// B
	}
	}
	
	camera.SetFrom  (&D3DXVECTOR3(0,1,5));
	camera.SetLookAt(&D3DXVECTOR3(0,1,0));
	camera.SetUp    (&D3DXVECTOR3(0,1,0));
	camera.SetFovY  (D3DX_PI/3);
	camera.SetAspect(1.0f);
	camera.SetNear  (0.01f);
	camera.SetFar   (100.0f);
	camera.Update();
}
// ---------------------------------------------------------------------------
void Delete()
{
}
// ---------------------------------------------------------------------------
void Render()
{
	for(int j=0;j<RENDER_HEIGHT;j++){
	for(int i=0;i<RENDER_WIDTH ;i++){
		D3DXVECTOR3 col;
		GetColor(&col, ((float)i+0.5f)/(float)RENDER_WIDTH
					 , ((float)j+0.5f)/(float)RENDER_HEIGHT);
		// 0�`1�͈̔͂̐F��0�`255�ɕϊ�
		s_data[4*(j*RENDER_WIDTH+i)+0]=(char)(255.9*col.x);// R
		s_data[4*(j*RENDER_WIDTH+i)+1]=(char)(255.9*col.y);// G
		s_data[4*(j*RENDER_WIDTH+i)+2]=(char)(255.9*col.z);// B
	}
	}
}

// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, D3DXVECTOR4 *x, D3DXVECTOR4 *v)
{
	// �����Ƌ��̔���
	D3DXVECTOR4 center = D3DXVECTOR4(0,1,0,1);			// ���S�ʒu
	FLOAT radius_sq = 1.0f*1.0f;

	D3DXVECTOR4 xc = (*x)-center;// ���S����̑��Έʒu
	FLOAT xc2 = D3DXVec3Dot((D3DXVECTOR3 *)&xc, (D3DXVECTOR3 *)&xc);
	FLOAT vxc = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&xc);
	FLOAT D = vxc*vxc-xc2+radius_sq;// ���ʎ�
	
	*dest = D3DXVECTOR3(1,0.9,0.5);	// ���������Ƃ��̐F

	if(D<0) {*dest = BG_COLOR; return dest;} // ��_�����݂��Ȃ��O�ꂽ
	
	float tn = -vxc-sqrtf(D);
	float tp = -vxc+sqrtf(D);

	if(tn<0 && tp<0) {*dest = BG_COLOR; return dest;}

	return dest;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y)
{
	D3DXVECTOR4 ray_start_proj = D3DXVECTOR4(-2*x+1, -2*y+1, 0, 1);// �O���N���b�v��
	D3DXVECTOR4 ray_eye        = D3DXVECTOR4(0, 0, 0, 1);// �r���[��Ԃł̃J�����̈ʒu
	D3DXVECTOR4 ray_start;
	D3DXVECTOR4 ray_to;
	D3DXVECTOR4 ray_dir;
	D3DXMATRIX mInv;
	
	// ���_���ˉe��Ԃ��烏�[���h���W�ɕϊ�����
	D3DXVec4Transform( &ray_start, &ray_eye,        camera.GetViewInverse() );
	D3DXVec4Transform( &ray_to,    &ray_start_proj, camera.GetViewProjInverse() );
	D3DXVec4Scale( &ray_to,    &ray_to,    1.0f/ray_to.w   );// w=1 �̎ˉe��Ԃɗ��Ƃ�
	// �����̌v�Z
	ray_dir = ray_to - ray_start;
	D3DXVec4Normalize(&ray_dir, &ray_dir);
	
	// �F�v�Z
	return GetColor(dest, &ray_start, &ray_dir);
}

};// namespace Render
