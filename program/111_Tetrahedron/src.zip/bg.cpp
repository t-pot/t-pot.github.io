// ----------------------------------------------------------------------------
// File: bg.cpp
//
// Desc: �l�p�`�̕`��
// ----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"


// ��
#define NUM_X	32	// �������ɉ��|���S���g����
#define NUM_Y	32	// �c�����ɉ��|���S���g����
#define NUM_VERTICES			((NUM_Y+1)*(NUM_X+1))
#define NUM_INDICES_PERFACE		(3*2)
#define NUM_FACES				(NUM_Y*NUM_X)
#define NUM_VERTICES_PERFACE	4

// ----------------------------------------------------------------------------
typedef struct{
	float x,y,z;
} FloorVertex;
#define FLOOR_VERTEX (D3DFVF_XYZ)

// ----------------------------------------------------------------------------
// ��

// ----------------------------------------------------------------------------
void CMyD3DApplication::InitQuad( )
{
	// ���_�o�b�t�@�̍쐬 
    m_pd3dDevice->CreateVertexBuffer( NUM_VERTICES * sizeof(FloorVertex),
                                D3DUSAGE_WRITEONLY, FLOOR_VERTEX, D3DPOOL_MANAGED,
                                &m_pVB, NULL );
	// ���_���Z�b�g�A�b�v
	{
		FloorVertex *pDest;
		m_pVB->Lock ( 0, 0, (VOID**)&pDest, 0 );
		for (DWORD i = 0; i <= NUM_X; i++) {
			for (DWORD j = 0; j <= NUM_Y; j++) {
				pDest->x = ((FLOAT)i - NUM_X/2) * 2.0f / NUM_X;
				pDest->y =-((FLOAT)j - NUM_Y/2) * 2.0f / NUM_Y;
				pDest->z = 0.5f;
				pDest += 1;
			}
		}		
		m_pVB->Unlock ();
	}

	// �C���f�b�N�X���Z�b�g�A�b�v
	WORD *pIndex;
    m_pd3dDevice->CreateIndexBuffer( NUM_INDICES_PERFACE  * NUM_FACES * sizeof(WORD),
                                     0 ,
                                     D3DFMT_INDEX16, D3DPOOL_DEFAULT,
                                     &m_pIB,0 );
	m_pIB->Lock ( 0, 0, (VOID**)&pIndex, 0 );
	{
	for (WORD i = 0; i < NUM_X; i++) {
		for (WORD j = 0; j < NUM_Y; j++) {
			*pIndex++ = j + 0 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);

			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+1) * (NUM_Y+1);
		}
	}
	}
	m_pIB->Unlock ();

}
// ----------------------------------------------------------------------------
void CMyD3DApplication::RenderQuad()
{
	m_pd3dDevice->SetStreamSource(0, m_pVB, 0, sizeof(FloorVertex));
	m_pd3dDevice->SetIndices( m_pIB );
	m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,	0, 0, NUM_VERTICES, 0, 2*NUM_FACES );
}

// ----------------------------------------------------------------------------
void CMyD3DApplication::DeleteQuad( )
{
	SAFE_RELEASE(m_pIB);
	SAFE_RELEASE(m_pVB);
}