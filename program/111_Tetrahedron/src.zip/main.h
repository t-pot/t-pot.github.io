//-------------------------------------------------------------
// File: main.h
//
// Desc: Real-Time Global Illumination
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#pragma once

//-------------------------------------------------------------
// Defines, and constants(��`��萔)
//-------------------------------------------------------------

// Struct to store the current input state(���݂̓��̓f�[�^��ۑ�����\����)
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
    BOOL bZoomIn;
    BOOL bZoomOut;
    BOOL bChangeShader;
    BOOL bPause;
};




//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Main class to run this application. Most functionality is inherited
//       from the CD3DApplication base class.
//       (�A�v���P�[�V�����̃N���X)
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	// Scene management(�V�[���Ǘ�)
	bool					m_bPause;				// Pause

	// Model
	CD3DMesh				*m_pMesh;
	CD3DMesh				*m_pMeshBg;
	CD3DMesh				*m_pMeshEnv;
	
	// Dynamics for a ball
	D3DXVECTOR3				m_pos;					// Position(�ʒu)
	D3DXVECTOR3				m_vel;					// Velocity(���x)
	D3DXVECTOR3				m_rot;					// Rotation(�ʒu)
	D3DXVECTOR3				m_omega;				// Angler velocity(�ʒu)

	// Shader
	LPD3DXEFFECT		    m_pEffect;				// Effect for the sample(�G�t�F�N�g)
	D3DXHANDLE				m_hTechnique;			// Technique handle for RenderScene(�e�N�j�b�N)
	D3DXHANDLE				m_hmWV;					// Handle for world+view matrix in effect(�ϊ��s��)
	D3DXHANDLE				m_hmWVP;				// Handle for world+view+projection matrix in effect(�ϊ��s��)
	D3DXHANDLE				m_htSrcTex;				// Handle for the scene texture in effect(�e�N�X�`��)
	D3DXHANDLE				m_fWidth;				// Handle for the texture width in effect(�e�N�X�`����)
	D3DXHANDLE				m_fHeight;				// Handle for the texture height in effect(�e�N�X�`������)

	// Rendering targets (�����_�����O�^�[�Q�b�g)
	LPDIRECT3DSURFACE9		m_pMapZ;				// Depth buffer
	LPDIRECT3DTEXTURE9		m_pParaboloidTex[2];	// Environment map
	LPDIRECT3DSURFACE9		m_pParaboloidSurf[2];
	LPDIRECT3DTEXTURE9		m_pTetrahedronTex[4];	// Environment map
	LPDIRECT3DSURFACE9		m_pTetrahedronSurf[4];

	// Geometry (�ʏ�̍��W�ϊ��s��)
	D3DXMATRIX				m_mWorld;				// World matrix
	D3DXMATRIX				m_mView;				// View matrix
	D3DXMATRIX				m_mProj;				// Projection matrix

	D3DXMATRIX				m_mViewTetrahedron[4];	// View matrix
	D3DXMATRIX				m_mProjTetrahedron;		// Projection matrix
	
	LPDIRECT3DVERTEXBUFFER9	m_pVB;
	LPDIRECT3DINDEXBUFFER9	m_pIB;

    FLOAT                   m_fWorldRotX;   // World rotation state X-axis(�w����])
    FLOAT                   m_fWorldRotY;   // World rotation state Y-axis(�x����])
    FLOAT                   m_fViewZoom;    // Distance to lookat (���_�̋���)

	BOOL					m_bLoadingApp;	// TRUE, if the app is loading(���[�h���H)
    CD3DFont*				m_pFont;		// Font for drawing text(�t�H���g)
    UserInput				m_UserInput;	// Struct for storing user input (���̓f�[�^)

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

	void RenderParaboloidMap();
	void DeleteQuad( );
	void RenderQuad();
	void InitQuad( );

	HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

