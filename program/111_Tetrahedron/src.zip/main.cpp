//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Real-Time Global Illumination
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <time.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE			128

#define frand() ((float)rand()/(float)RAND_MAX)

//-------------------------------------------------------------
// Globals variables and definitions(�O���[�o���ϐ��ƒ�`)
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//       (���C���֐�)
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//       (�A�v���P�[�V�����̃R���X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	time_t t;
	
	time( &t );
	srand( t );

	m_bPause = false;

	m_pos = D3DXVECTOR3(0,0,0);
	m_vel = D3DXVECTOR3(frand(),frand(),frand());
	m_rot = D3DXVECTOR3(0,0,0);
	m_omega = D3DXVECTOR3( frand(), frand(), frand() );

	m_pMesh						= new CD3DMesh();
	m_pMeshBg					= new CD3DMesh();
	m_pMeshEnv					= new CD3DMesh();

	m_pMapZ						= NULL;
	m_pParaboloidTex[0]			= NULL;
	m_pParaboloidSurf[0]		= NULL;
	m_pParaboloidTex[1]			= NULL;
	m_pParaboloidSurf[1]		= NULL;
	m_pTetrahedronTex[0]		= NULL;
	m_pTetrahedronTex[1]		= NULL;
	m_pTetrahedronTex[2]		= NULL;
	m_pTetrahedronTex[3]		= NULL;
	m_pTetrahedronSurf[0]		= NULL;
	m_pTetrahedronSurf[1]		= NULL;
	m_pTetrahedronSurf[2]		= NULL;
	m_pTetrahedronSurf[3]		= NULL;

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWV						= NULL;
	m_hmWVP						= NULL;
	m_htSrcTex					= NULL;
	m_fWidth					= NULL;
	m_fHeight					= NULL;

	m_fWorldRotX                = -0.0f;
    m_fWorldRotY                = D3DX_PI*0.5f;
	m_fViewZoom				    = 27.0f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;
 
    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//       (�f�X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//      (��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // Drawing loading status message until app finishes loading
    // (���[�f�B���O���b�Z�[�W��\������)
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the device
//       for some minimum set of capabilities
//       (�������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

    // No fallback, so need ps2.0
	// (�s�N�Z���V�F�[�_�o�[�W�����`�F�b�N)
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // If device doesn't support 1.1 vertex shaders in HW, switch to SWVP.
    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}


//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//      (�f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς������ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

    // Load objects (���f���̓ǂݍ���)
	if(FAILED(hr=m_pMesh->Create( m_pd3dDevice, _T("t-pot.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMesh->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
        
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMeshBg->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
        
	if(FAILED(hr=m_pMeshEnv->Create( m_pd3dDevice, _T("room.x"))))
        return DXTRACE_ERR( "Load Model", hr );
	m_pMeshEnv->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
        
	// Create textures
    // Create the effect(�V�F�[�_�̓ǂݍ���)
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWV 		 = m_pEffect->GetParameterByName( NULL, "mWV" );
	m_hmWVP		 = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );
	m_fWidth	 = m_pEffect->GetParameterByName( NULL, "MAP_WIDTH" );
	m_fHeight	 = m_pEffect->GetParameterByName( NULL, "MAP_HEIGHT" );

    // Init the font(�t�H���g)
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//       (��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		 �m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i;

	m_bPause = false;

	// Restore meshes(���b�V��)
	m_pMesh->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshEnv->RestoreDeviceObjects( m_pd3dDevice );

    // Setup a material (�����̐ݒ�)
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set miscellaneous render states(�����_�����O���̐ݒ�)
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
    
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // World transform to identity (���[���h�s��)
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

    // Set up the view parameters for the camera(�r���[�s��)
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // Set the camera projection matrix(�ˉe�s��)
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, 0.47108996f, fAspect, 1.0f, 100.0f );
	

	// Tetrahedron Matrix
	D3DXVECTOR3 lookat[4];
	D3DXVECTOR3 center;
	D3DXMATRIX mRot;
	float theta = 109.0f * D3DX_PI / 180.0f;
	center = D3DXVECTOR3(0,0,0);
	lookat[0] = D3DXVECTOR3(0,0,1);
	lookat[1] = D3DXVECTOR3(sinf(theta)*cosf(0.0*D3DX_PI/3.0f),sinf(theta)*sinf(0.0*D3DX_PI/3.0f), cosf(theta));
	lookat[2] = D3DXVECTOR3(sinf(theta)*cosf(2.0*D3DX_PI/3.0f),sinf(theta)*sinf(2.0*D3DX_PI/3.0f), cosf(theta));
	lookat[3] = D3DXVECTOR3(sinf(theta)*cosf(4.0*D3DX_PI/3.0f),sinf(theta)*sinf(4.0*D3DX_PI/3.0f), cosf(theta));
	
    D3DXMatrixRotationY( &mRot, -acosf(-1.0f/3.0f)/2.0f );
	D3DXVec3TransformCoord( &lookat[0], &lookat[0], &mRot);
	D3DXVec3TransformCoord( &lookat[1], &lookat[1], &mRot);
	D3DXVec3TransformCoord( &lookat[2], &lookat[2], &mRot);
	D3DXVec3TransformCoord( &lookat[3], &lookat[3], &mRot);
	for( i = 0; i < 4; i++ )
	{
	    D3DXMatrixLookAtLH( &m_mViewTetrahedron[i], &center, &lookat[i], &lookat[(i+1)&3] );
	}
	D3DXMatrixPerspectiveFovLH( &m_mProjTetrahedron, 1.27f * theta, 1.0f, 0.1f, 100.0f );

    // Create the stencil buffer to be used with the paraboloid textures(�[�x�}�b�v�̐���)
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
    // Create tetrahedron rendering targets(�e�g���փh�����}�b�v)
	for( i = 0; i < 4; i++ )
	{
		// Create paraboloid rendering targets(�����}�b�v)
		if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pTetrahedronTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pTetrahedronTex[i]->GetSurfaceLevel(0, &m_pTetrahedronSurf[i])))
			return E_FAIL;
	}
    // Create paraboloid rendering targets(�����}�b�v)
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[0], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[0]->GetSurfaceLevel(0, &m_pParaboloidSurf[0])))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[1], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[1]->GetSurfaceLevel(0, &m_pParaboloidSurf[1])))
		return E_FAIL;

	InitQuad();

    // Restore effect object
	m_pEffect->OnResetDevice();

    // Restore the font(�t�H���g)
    m_pFont->RestoreDeviceObjects();

	return S_OK;
}


//-------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//       (���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // Update user input state(���̓f�[�^�̍X�V)
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
    // Update the world state according to user input(���͂ɉ����č��W�n���X�V����)
	//---------------------------------------------------------
	// Rotation(��])
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

	if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
		m_fWorldRotY += m_fElapsedTime;
	else
	if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
		m_fWorldRotY -= m_fElapsedTime;

	if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
		m_fWorldRotX += m_fElapsedTime;
	else
	if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
		m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// Update view matrix(�r���[�s��̐ݒ�)
	//---------------------------------------------------------
	// Zoom(�Y�[��)
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.3f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	//---------------------------------------------------------
	// Pause(�|�[�Y)
	//---------------------------------------------------------
	if( m_UserInput.bPause ) m_bPause = !m_bPause;

	//---------------------------------------------------------
	// Move the ball (�ʂ̈ړ�)
	//---------------------------------------------------------
	if( !m_bPause )
	{
		D3DXVec3Normalize( &m_vel, &m_vel );
		D3DXVec3Scale( &m_vel, &m_vel, 10 );
		m_pos += m_vel * this->m_fElapsedTime;
		m_rot += m_omega * this->m_fElapsedTime;
		m_rot.x = (float)fmod(m_rot.x, 2.0f*D3DX_PI);
		m_rot.y = (float)fmod(m_rot.y, 2.0f*D3DX_PI);
		m_rot.z = (float)fmod(m_rot.z, 2.0f*D3DX_PI);

		float size = 5.0f - 1.0f;

		if( m_pos.x < -size )
		{
			m_pos.x = -size;
			m_vel.x *= -1;
		}
		if( size < m_pos.x )
		{
			m_pos.x = size;
			m_vel.x *= -1;
		}
		if( m_pos.y < -size )
		{
			m_pos.y = -size;
			m_vel.y *= -1;
		}
		if( size < m_pos.y )
		{
			m_pos.y = size;
			m_vel.y *= -1;
		}
		if( m_pos.z < -size )
		{
			m_pos.z = -size;
			m_vel.z *= -1;
		}
		if( size < m_pos.z )
		{
			m_pos.z = size;
			m_vel.z *= -1;
		}
	}

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//       (���̓f�[�^���X�V����)
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
    
	pUserInput->bChangeShader= ( m_bActive && (GetAsyncKeyState( 'A'      ) & 0x8001) == 0x8001 );
	pUserInput->bPause       = ( m_bActive && (GetAsyncKeyState( 'P'      ) & 0x8001) == 0x8001 );
}





//-------------------------------------------------------------
// Name: RenderParaboloidMap()
//-------------------------------------------------------------
void CMyD3DApplication::RenderParaboloidMap()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DMATERIAL9 *pMtrl;
	int i, j, pass;
    D3DXMATRIX m, mT, mR, mWI, mView, mProj, mW, mWVP;
    D3DXVECTOR3 vFrom;
    D3DXVECTOR3 vLookat;
    D3DXVECTOR3 vUpVec;

	D3DVIEWPORT9 viewport = {0, 0   // x,y(����̍��W)
					, 1, 1			// width, height(��,����)
					, 0.0f,1.0f};   // near, far(�O�ʁA���)

	//-------------------------------------------------
	// Backup rendering target(�����_�����O�^�[�Q�b�g�̕ۑ�)
	//-------------------------------------------------
	m_pd3dDevice->GetRenderTarget( 0, &pOldBackBuffer );
	m_pd3dDevice->GetDepthStencilSurface( &pOldZBuffer );
	m_pd3dDevice->GetViewport( &oldViewport );
	
	//-------------------------------------------------
	// Create environment map(���}�b�v�̍쐬)
	//-------------------------------------------------
	if( m_pEffect != NULL ) 
	{
		D3DXMatrixRotationX( &mWI, m_rot.x );
		D3DXMatrixRotationY( &mR, m_rot.y );
		mWI = mWI * mR;
		D3DXMatrixRotationZ( &mR, m_rot.z );
		mWI = mWI * mR;
		D3DXMatrixTranslation( &mT, m_pos.x, m_pos.y, m_pos.z );
		mWI = mWI * mT;

		for( pass = 0; pass < 4; pass++ )
		{
			mWVP = m_mWorld * m_mViewTetrahedron[pass] * m_mProjTetrahedron;

			m_pd3dDevice->SetRenderTarget( 0, m_pTetrahedronSurf[pass] );
			m_pd3dDevice->SetDepthStencilSurface( m_pMapZ );
			viewport.Width  = viewport.Height = MAP_SIZE;
			m_pd3dDevice->SetViewport( &viewport );

			// Clear the scene
			m_pd3dDevice->Clear(0L, NULL
				, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
				, 0xff000000, 1.0f, 0L);
			
			//-------------------------------------------------
			// Render ground(�n�`�̕`��)
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			// Set shader(�V�F�[�_�̐ݒ�)
			m_pEffect->Pass( 0 );

			// World+view+projection matrix(���[�J��-�ˉe�s��)
			D3DXMatrixTranslation( &mT, 0, -5, 0 );
			m = mT * mWVP;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// Set the texture and render(�e�N�X�`����ݒ肵�ĕ`��)
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );
				pMtrl++;
			}

			// Render back sphere(�V���̕`��)
			D3DXMatrixScaling ( &m, 10, 10, 10 );
			m = m * mWVP;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			pMtrl = m_pMeshEnv->m_pMaterials;
			for( i=0; i<m_pMeshEnv->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshEnv->m_pTextures[i] );
				m_pMeshEnv->m_pLocalMesh->DrawSubset( i );
				pMtrl++;
			}
//			m_pd3dDevice->Clear(0L, NULL
//			, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
//			, 0xffffff, 1.0f, 0L);
		}
		m_pEffect->End();

		// Set shader
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );
		m_pEffect->Pass( 1 );

		for( i = 0; i < 2; i++ )
		{
			// Chenge rendering target
			m_pd3dDevice->SetRenderTarget( 0, m_pParaboloidSurf[i] );
			m_pd3dDevice->SetDepthStencilSurface( m_pMapZ );
			viewport.Width  = viewport.Height = MAP_SIZE;
			m_pd3dDevice->SetViewport( &viewport );
			
			// Clear the scene
			m_pd3dDevice->Clear(0L, NULL
				, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
				, 0xff000000, 1.0f, 0L);
			
			// Set matrixs(�s��̐ݒ�)
			switch(i)
			{
			case 0:
				// Front of view(�O��)
				vLookat = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
				break;
			case 1:
				// Back of view(���)
				vLookat = D3DXVECTOR3( 0.0f, 0.0f, -1.0f );
				break;
			}
			vFrom   = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			vUpVec  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			vUpVec -= vFrom;
			D3DXMatrixLookAtLH( &mView, &vFrom, &vLookat, &vUpVec );
			
//m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
			for( j = 0; j < 4; j++ )
			{
				m = m_mViewTetrahedron[j] * m_mProjTetrahedron;
		        D3DXMatrixInverse( &m, NULL, &m );
				m = m * mView;
				m_pEffect->SetMatrix( m_hmWV, &m );

				m_pEffect->SetTexture(m_htSrcTex, m_pTetrahedronTex[j] );

				RenderQuad();
			}
//m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID );
		}

		m_pEffect->End();
	}


	//-----------------------------------------------------
    // Restore render target
	// (�����_�����O�^�[�Q�b�g�����ɖ߂�)
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetRenderTarget(1, NULL);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	m_pd3dDevice->SetViewport(&oldViewport);
	pOldBackBuffer->Release();
	pOldZBuffer->Release();

}
//-------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//       (��ʂ�`�悷��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
	DWORD i;
	D3DXVECTOR4 v;
	D3DMATERIAL9 *pMtrl;

	// Begin the scene(�`��J�n)
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//---------------------------------------------------------
		// Create maps(�e�N�X�`���̐���)
		//---------------------------------------------------------
		RenderParaboloidMap();

	    // Clear the render buffers(�t���[���o�b�t�@�̃N���A)
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// Set effect(�V�F�[�_�̐ݒ�)
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// Render model (���f���̕`��)
			//-------------------------------------------------
			m_pEffect->Pass( 2 );

			// Set matrixs(�s��̐ݒ�)
			D3DXMatrixRotationX( &mR, m_rot.x );
			D3DXMatrixRotationY( &m, m_rot.y );
			mR = mR * m;
			D3DXMatrixRotationZ( &m, m_rot.z );
			mR = mR * m;
			D3DXMatrixTranslation( &mT, m_pos.x, m_pos.y, m_pos.z );
			mW = mR * mT;
			m = mW * m_mWorld;
			m_pEffect->SetMatrix( "mW", &m );
			m = m * m_mView;
			m_pEffect->SetMatrix( m_hmWV, &m );
			m = m * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			// View point in the local coordinate system(���[�J���ł̎��_)
			m = mW * m_mWorld * m_mView;
            D3DXMatrixInverse( &m, NULL, &m );
			v = D3DXVECTOR4( 0, 0, 0, 1 );
            D3DXVec4Transform( &v, &v, &m);
			m_pEffect->SetVector( "vEye", &v );

			// Set the texture and render
			m_pEffect->SetTexture( "ParaboloidFrontTex", m_pParaboloidTex[0] );
			m_pEffect->SetTexture( "ParaboloidBackTex",  m_pParaboloidTex[1] );
			
			m_pEffect->SetTexture( "DecaleTex",  m_pMesh->m_pTextures[0] );
			m_pMesh->Render( m_pd3dDevice );

			//-------------------------------------------------
			// Render ground(�n�`�̕`��)
			//-------------------------------------------------
			// Set shader(�V�F�[�_�̐ݒ�)
			m_pEffect->Pass( 0 );

			// World+view+projection matrix(���[�J��-�ˉe�s��)
			m = m_mWorld * m_mView * m_mProj;
			D3DXMatrixTranslation( &mT, 0, -5, 0 );
			m = mT * m;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// Set the texture and render(�e�N�X�`����ݒ肵�ĕ`��)
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );
				pMtrl++;
			}

			//-------------------------------------------------
			// Render back sphere(�V���̕`��)
			//-------------------------------------------------
			// World+view+projection matrix(���[�J��-�ˉe�s��)
			D3DXMatrixScaling ( &m, 10, 10, 10 );
			m = m * m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// Set the texture and render(�e�N�X�`����ݒ肵�ĕ`��)
			pMtrl = m_pMeshEnv->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshEnv->m_pTextures[i] );
				m_pMeshEnv->m_pLocalMesh->DrawSubset( i );
				pMtrl++;
			}

			m_pEffect->End();
		}

        // Render stats and help text(�w���v�̕\��)
        RenderText();

#ifdef _DEBUG // Textures are displaying when debugging, (�f�o�b�O�p�Ƀe�N�X�`����\������)
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		float scale = 64.0f;
		for(DWORD i=0; i<6; i++){
			TVERTEX Vertex[4] = {
				//    x                             y         z rhw tu tv
				{(i+0)*scale, (FLOAT)m_d3dsdBackBuffer.Height-scale, 0, 1, 0, 0,},
				{(i+1)*scale, (FLOAT)m_d3dsdBackBuffer.Height-scale, 0, 1, 1, 0,},
				{(i+1)*scale, (FLOAT)m_d3dsdBackBuffer.Height-    0, 0, 1, 1, 1,},
				{(i+0)*scale, (FLOAT)m_d3dsdBackBuffer.Height-    0, 0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pTetrahedronTex[0] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pTetrahedronTex[1] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pTetrahedronTex[2] );
			if(3==i) m_pd3dDevice->SetTexture( 0, m_pTetrahedronTex[3] );
			if(4==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[0] );
			if(5==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[1] );

			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		// End the scene.(�`��̏I��)
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: Draw the help & statistics for running sample
//       (��Ԃ�w���v����ʂɕ\������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");
    FLOAT fNextLine;

    // Draw help
    fNextLine = 0; 

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

    lstrcpy( szMsg, TEXT("Press 'A' to change shader") );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

    // Output statistics
    lstrcpy( szMsg, m_strDeviceStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//       (WndProc ���I�[�o�[���C�h��������)
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Loading message(���[�h��)
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//       (RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	DeleteQuad( );

	// font(�t�H���g)
    m_pFont->InvalidateDeviceObjects();

	SAFE_RELEASE(m_pTetrahedronSurf[3]);
	SAFE_RELEASE(m_pTetrahedronSurf[2]);
	SAFE_RELEASE(m_pTetrahedronSurf[1]);
	SAFE_RELEASE(m_pTetrahedronSurf[0]);
	SAFE_RELEASE(m_pTetrahedronTex[3]);
	SAFE_RELEASE(m_pTetrahedronTex[2]);
	SAFE_RELEASE(m_pTetrahedronTex[1]);
	SAFE_RELEASE(m_pTetrahedronTex[0]);

	SAFE_RELEASE(m_pParaboloidSurf[1]);
	SAFE_RELEASE(m_pParaboloidTex[1]);
	SAFE_RELEASE(m_pParaboloidSurf[0]);
	SAFE_RELEASE(m_pParaboloidTex[0]);
	SAFE_RELEASE(m_pMapZ);

	// Models(���f��)
	m_pMeshEnv->InvalidateDeviceObjects();
	m_pMeshBg->InvalidateDeviceObjects();
	m_pMesh->InvalidateDeviceObjects();
	
	// Shaders(�V�F�[�_)
    if( m_pEffect    != NULL ) m_pEffect   ->OnLostDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//       (InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// font(�t�H���g)
    m_pFont->DeleteDeviceObjects();

	// Shaders(�V�F�[�_)
	SAFE_RELEASE( m_pEffect );
	
	// Models(���f��)
	m_pMeshEnv->Destroy();
	m_pMeshBg->Destroy();
	m_pMesh->Destroy();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//       (�I�����钼�O�ɌĂ΂��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	// font(�t�H���g)
    SAFE_DELETE( m_pFont );

	// Models(���f��)
    SAFE_DELETE( m_pMeshEnv );
    SAFE_DELETE( m_pMeshBg );
    SAFE_DELETE( m_pMesh );

    return S_OK;
}




