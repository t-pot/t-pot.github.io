//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
#ifndef H_RENDERTARGET_
#define H_RENDERTARGET_

#include <windows.h>
#include <d3d9.h>


typedef enum
{
	RTF_NONE = 0,

	RTF_RGBA,
	RTF_RGBA16F,
	RTF_RGBA32F,
	RTF_R16F,
	RTF_R32F,

	RTF_D16,
	RTF_D24S8,

	RTF_DEFAULT       = RTF_RGBA,
	RTF_DEPTH_DEFAULT = RTF_D16,
}RT_FORMAT;

typedef enum
{
	RT_FLAG_NOT_SET_ZBUFFER = (1<< 0),
}RT_FLAG;

typedef enum
{
	RTCF_AUTOGENMIPMAP = (1<< 0),
}RT_CREATE_FLAG;

class CRenderTarget
{
	 CRenderTarget();
	~CRenderTarget();

	HRESULT SetUp(IDirect3DDevice9* pd3dDevice, DWORD width, DWORD height, RT_FORMAT format, RT_FORMAT z_format, DWORD create_flag);

	LPDIRECT3DTEXTURE9      m_pTexture;
	LPDIRECT3DSURFACE9      m_pSurface;
	LPDIRECT3DSURFACE9      m_pSurfaceZ;
	D3DVIEWPORT9            m_Viewport;
	IDirect3DDevice9*       m_pd3dDevice;
	DWORD                   m_iMrt;
	DWORD                   m_iFlag;
	void PushBackBuffer(DWORD mrt=0);
	void PopBackBuffer (DWORD mrt=0);
	
	static LPDIRECT3DSURFACE9 g_apOriginalRenderTarget[4];
	static LPDIRECT3DSURFACE9 g_pOriginalZbuffer;
	static D3DVIEWPORT9       g_aViewport[4];
public:
	static CRenderTarget *Create(IDirect3DDevice9* pd3dDevice, DWORD width, DWORD height, RT_FORMAT format=RTF_DEFAULT, RT_FORMAT z_format=RTF_DEPTH_DEFAULT, DWORD create_flag=0);
	void Release();

	LPDIRECT3DTEXTURE9 GetTexture();
	HRESULT Begin(DWORD mrt=0, DWORD flag=0);
	void End();

	void SetZBuffer();
	void ResetZBuffer();
};

#endif // !H_RENDERTARGET_
