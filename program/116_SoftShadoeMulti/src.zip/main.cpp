//--------------------------------------------------------------------------------------
// File: main.cpp
//
// Starting point for new Direct3D applications
// �V����Direct3D�A�v���P�[�V�����̂��߂̊J�n�_
//
// Copyright (c) Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#include "dxstdafx.h"
#include "resource.h"

//#define DEBUG_VS   // Uncomment this line to debug vertex shaders 
                     // ���_�V�F�[�_���f�o�b�O����ɂ͂��̍s�̃R�����g���͂���
//#define DEBUG_PS   // Uncomment this line to debug pixel shaders 
                     // �s�N�Z���V�F�[�_���f�o�b�O����ɂ͂��̍s�̃R�����g���͂���

#define SHADOWMAP_SIZE 1024


//--------------------------------------------------------------------------------------
// Vertex format
//--------------------------------------------------------------------------------------
struct VERTEX 
{
    D3DXVECTOR3 pos;
    D3DXVECTOR2 tex;

    static const DWORD FVF;
};
const DWORD VERTEX::FVF = D3DFVF_XYZ | D3DFVF_TEX1;

//--------------------------------------------------------------------------------------
// Global variables
// �O���[�o���ϐ�
//--------------------------------------------------------------------------------------
ID3DXFont*              g_pFont = NULL;         // Font for drawing text
                                                // �e�L�X�g��`�悷�邽�߂̃e�L�X�g
ID3DXSprite*            g_pTextSprite = NULL;   // Sprite for batching draw text calls
                                                // 
ID3DXEffect*            g_pEffect = NULL;       // D3DX effect interface
                                                // D3DX �G�t�F�N�g�̃C���^�[�t�F�C�X
CModelViewerCamera      g_Camera;               // A model viewing camera
                                                // ���f�������Ă���J����
bool                    g_bShowHelp = true;     // If true, it renders the UI control text
                                                // �^�̎��ɂ�UI����̃e�L�X�g��`�悷��
CDXUTDialog             g_HUD;                  // dialog for standard controls
                                                // �W������̃_�C�A���O
CDXUTDialog             g_SampleUI;             // dialog for sample specific controls
                                                // �T���v�����L�̃R���g���[���̃_�C�A���O
FLOAT					g_fRadius;

D3DVIEWPORT9            g_ViewportFB;

D3DXMATRIXA16			g_mWorld1;
LPD3DXMESH              g_pScene1Mesh;
LPDIRECT3DTEXTURE9      g_pScene1MeshTexture;
LPD3DXMESH              g_pScene2Mesh;
LPDIRECT3DTEXTURE9      g_pScene2MeshTexture;

LPDIRECT3DTEXTURE9      g_pShadowMap = NULL;    // Texture to which the shadow map is rendered
LPDIRECT3DSURFACE9      g_pDSShadow = NULL;     // Depth-stencil buffer for rendering to shadow map
D3DXMATRIXA16           g_mShadowProj;          // Projection matrix for shadow map
D3DXMATRIXA16           g_mShadowView;          // View matrix for shadow map
D3DXVECTOR4             g_vLightDir;

//--------------------------------------------------------------------------------------
// UI control IDs
// UI �𐧌䂷�邽�߂�ID�Q
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN    1
#define IDC_TOGGLEREF           2
#define IDC_CHANGEDEVICE        3
#define IDC_CHANGE_LEVEL_STATIC 4
#define IDC_CHANGE_LEVEL        5



//--------------------------------------------------------------------------------------
// Forward declarations 
// �O�錾
//--------------------------------------------------------------------------------------
bool    CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat, bool bWindowed );
void    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps );
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc );
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc );
void    CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime );
void    CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime );
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing );
void    CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown  );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl );
void    CALLBACK OnLostDevice();
void    CALLBACK OnDestroyDevice();

void    InitApp();
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh );
void    RenderText();
void             RenderScene( IDirect3DDevice9* pd3dDevice, bool bRenderShadow, const D3DXMATRIX *pmViewProj );


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
// �v���O�����̊J�n�_�B�S�Ă����������ă��b�Z�[�W�������[�v�ɓ���B�ҋ@���Ԃ̓V�[���̕`��
// �Ɏg����
//--------------------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE, HINSTANCE, LPSTR, int )
{
    // Set the callback functions. These functions allow the sample framework to notify
    // the application about device changes, user input, and windows messages.  The 
    // callbacks are optional so you need only set callbacks for events you're interested 
    // in. However, if you don't handle the device reset/lost callbacks then the sample 
    // framework won't be able to reset your device since the application must first 
    // release all device resources before resetting.  Likewise, if you don't handle the 
    // device created/destroyed callbacks then the sample framework won't be able to 
    // recreate your device resources.
    DXUTSetCallbackDeviceCreated( OnCreateDevice );
    DXUTSetCallbackDeviceReset( OnResetDevice );
    DXUTSetCallbackDeviceLost( OnLostDevice );
    DXUTSetCallbackDeviceDestroyed( OnDestroyDevice );
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( KeyboardProc );
    DXUTSetCallbackFrameRender( OnFrameRender );
    DXUTSetCallbackFrameMove( OnFrameMove );

    // Show the cursor and clip it when in full screen
    DXUTSetCursorSettings( true, true );

    InitApp();

    // Initialize the sample framework and create the desired Win32 window and Direct3D 
    // device for the application. Calling each of these functions is optional, but they
    // allow you to set several options which control the behavior of the framework.
    DXUTInit( true, true, true ); // Parse the command line, handle the default hotkeys, and show msgboxes
    DXUTCreateWindow( L"main" );
    DXUTCreateDevice( D3DADAPTER_DEFAULT, true, 640, 480, IsDeviceAcceptable, ModifyDeviceSettings );

    // Pass control to the sample framework for handling the message pump and 
    // dispatching render calls. The sample framework will call your FrameMove 
    // and FrameRender callback when there is idle time between handling window messages.
    DXUTMainLoop();

    // Perform any application-level cleanup here. Direct3D device resources are released within the
    // appropriate callback functions and therefore don't require any cleanup code here.

    return DXUTGetExitCode();
}


//--------------------------------------------------------------------------------------
// Initialize the app 
// �A�v���P�[�V�����̏�����
//--------------------------------------------------------------------------------------
void InitApp()
{
	g_fRadius = 5.0f;

    g_pEffect = NULL;

    g_pScene1Mesh = NULL;
    g_pScene1MeshTexture = NULL;
    g_pScene2Mesh = NULL;
    g_pScene2MeshTexture = NULL;

	// Initialize dialogs
	// �_�C�A���O�̏�����
    g_HUD.SetCallback( OnGUIEvent ); int iY = 10; 
    g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
    g_HUD.AddButton( IDC_TOGGLEREF, L"Toggle REF (F3)", 35, iY += 24, 125, 22 );
    g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device (F2)", 35, iY += 24, 125, 22 );

    g_SampleUI.SetCallback( OnGUIEvent ); iY = 10; 
//    g_SampleUI.AddComboBox( 19, 35, iY += 24, 125, 22 );
//    g_SampleUI.GetComboBox( 19 )->AddItem( L"Text1", NULL );
//    g_SampleUI.GetComboBox( 19 )->AddItem( L"Text2", NULL );
//    g_SampleUI.GetComboBox( 19 )->AddItem( L"Text3", NULL );
//    g_SampleUI.GetComboBox( 19 )->AddItem( L"Text4", NULL );
//    g_SampleUI.AddCheckBox( 21, L"Checkbox1", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddCheckBox( 11, L"Checkbox2", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddRadioButton( 12, 1, L"Radio1G1", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddRadioButton( 13, 1, L"Radio2G1", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddRadioButton( 14, 1, L"Radio3G1", 35, iY += 24, 125, 22 );
//    g_SampleUI.GetRadioButton( 14 )->SetChecked( true ); 
//    g_SampleUI.AddButton( 17, L"Button1", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddButton( 18, L"Button2", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddRadioButton( 15, 2, L"Radio1G2", 35, iY += 24, 125, 22 );
//    g_SampleUI.AddRadioButton( 16, 2, L"Radio2G3", 35, iY += 24, 125, 22 );
//    g_SampleUI.GetRadioButton( 16 )->SetChecked( true );
//    g_SampleUI.AddSlider( 20, 50, iY += 24, 100, 22 );
//    g_SampleUI.GetSlider( 20 )->SetRange( 0, 100 );
//    g_SampleUI.GetSlider( 20 )->SetValue( 50 );
//    g_SampleUI.AddEditBox( 20, L"Test", 35, iY += 24, 125, 22 );

    WCHAR sz[100];
    iY += 0;
    _snwprintf( sz, 100, L"Radius: %0.2f", g_fRadius ); sz[99] = 0;
    g_SampleUI.AddStatic( IDC_CHANGE_LEVEL_STATIC, sz, 35, iY += 24, 125, 22 );
    g_SampleUI.AddSlider( IDC_CHANGE_LEVEL, 50, iY += 24, 100, 22, 0, 100, (int) (g_fRadius*10.0f) );
}

//--------------------------------------------------------------------------------------
// Called during device initialization, this code checks the device for some 
// minimum set of capabilities, and rejects those that don't pass by returning false.
//--------------------------------------------------------------------------------------
bool CALLBACK IsDeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, 
                                  D3DFORMAT BackBufferFormat, bool bWindowed )
{
    // Skip backbuffer formats that don't support alpha blending
	// �A���t�@�u�����f�B���O���T�|�[�g���Ă��Ȃ��o�b�N�o�b�t�@�t�H�[�}�b�g�̓X�L�b�v����
    IDirect3D9* pD3D = DXUTGetD3DObject(); 
    if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
                    AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING, 
                    D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
        return false;

    return true;
}


//--------------------------------------------------------------------------------------
// This callback function is called immediately before a device is created to allow the 
// application to modify the device settings. The supplied pDeviceSettings parameter 
// contains the settings that the framework has selected for the new device, and the 
// application can make any desired changes directly to this structure.  Note however that 
// the sample framework will not correct invalid device settings so care must be taken 
// to return valid device settings, otherwise IDirect3D9::CreateDevice() will fail.  
//--------------------------------------------------------------------------------------
void CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, const D3DCAPS9* pCaps )
{
    // If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
    // then switch to SWVP.
    if( (pCaps->DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT) == 0 ||
         pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) )
    {
        pDeviceSettings->BehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }
    else
    {
        pDeviceSettings->BehaviorFlags = D3DCREATE_HARDWARE_VERTEXPROCESSING;
    }

    // This application is designed to work on a pure device by not using 
    // IDirect3D9::Get*() methods, so create a pure device if supported and using HWVP.
    if ((pCaps->DevCaps & D3DDEVCAPS_PUREDEVICE) != 0 && 
        (pDeviceSettings->BehaviorFlags & D3DCREATE_HARDWARE_VERTEXPROCESSING) != 0 )
        pDeviceSettings->BehaviorFlags |= D3DCREATE_PUREDEVICE;

    // Debugging vertex shaders requires either REF or software vertex processing 
    // and debugging pixel shaders requires REF.  
#ifdef DEBUG_VS
    if( pDeviceSettings->DeviceType != D3DDEVTYPE_REF )
    {
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_HARDWARE_VERTEXPROCESSING;
        pDeviceSettings->BehaviorFlags &= ~D3DCREATE_PUREDEVICE;
        pDeviceSettings->BehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
    }
#endif
#ifdef DEBUG_PS
    pDeviceSettings->DeviceType = D3DDEVTYPE_REF;
#endif
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// created, which will happen during application initialization and windowed/full screen 
// toggles. This is the best location to create D3DPOOL_MANAGED resources since these 
// resources need to be reloaded whenever the device is destroyed. Resources created  
// here should be released in the OnDestroyDevice callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnCreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{
    HRESULT hr;
    WCHAR str[MAX_PATH];

	// Initialize the font
    V_RETURN( D3DXCreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         L"Arial", &g_pFont ) );

    // Load the meshs

    V_RETURN( LoadMesh( pd3dDevice, TEXT("t-pot.x"), &g_pScene1Mesh ) );
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"t-pot.bmp" ) );
    V_RETURN( D3DXCreateTextureFromFile( pd3dDevice, str, &g_pScene1MeshTexture) );

    V_RETURN( LoadMesh( pd3dDevice, TEXT("map.x"), &g_pScene2Mesh ) );
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"map.bmp" ) );
    V_RETURN( D3DXCreateTextureFromFile( pd3dDevice, str, &g_pScene2MeshTexture) );

	// Define DEBUG_VS and/or DEBUG_PS to debug vertex and/or pixel shaders with the 
    // shader debugger. Debugging vertex shaders requires either REF or software vertex 
    // processing, and debugging pixel shaders requires REF.  The 
    // D3DXSHADER_FORCE_*_SOFTWARE_NOOPT flag improves the debug experience in the 
    // shader debugger.  It enables source level debugging, prevents instruction 
    // reordering, prevents dead code elimination, and forces the compiler to compile 
    // against the next higher available software target, which ensures that the 
    // unoptimized shaders do not exceed the shader model limitations.  Setting these 
    // flags will cause slower rendering since the shaders will be unoptimized and 
    // forced into software.  See the DirectX documentation for more information about 
    // using the shader debugger.
    DWORD dwShaderFlags = 0;
    #ifdef DEBUG_VS
        dwShaderFlags |= D3DXSHADER_FORCE_VS_SOFTWARE_NOOPT;
    #endif
    #ifdef DEBUG_PS
        dwShaderFlags |= D3DXSHADER_FORCE_PS_SOFTWARE_NOOPT;
    #endif


    // Read the D3DX effect file
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"main.fx" ) );

    // If this fails, there should be debug output as to 
    // they the .fx file failed to compile
    V_RETURN( D3DXCreateEffectFromFile( pd3dDevice, str, NULL, NULL, dwShaderFlags, 
                                        NULL, &g_pEffect, NULL ) );

    // Setup the camera's view parameters
    D3DXVECTOR3 vecEye(0.0f, 5.0f, -10.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, -0.0f);
    g_Camera.SetViewParams( &vecEye, &vecAt );

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This function loads the mesh and ensures the mesh has normals; it also optimizes the 
// mesh for the graphics card's vertex cache, which improves performance by organizing 
// the internal triangle list for less cache misses.
//--------------------------------------------------------------------------------------
HRESULT LoadMesh( IDirect3DDevice9* pd3dDevice, WCHAR* strFileName, ID3DXMesh** ppMesh )
{
    ID3DXMesh* pMesh = NULL;
    WCHAR str[MAX_PATH];
    HRESULT hr;

    // Load the mesh with D3DX and get back a ID3DXMesh*.  For this
    // sample we'll ignore the X file's embedded materials since we know 
    // exactly the model we're loading.  See the mesh samples such as
    // "OptimizedMesh" for a more generic mesh loading example.
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, strFileName ) );

    V_RETURN( D3DXLoadMeshFromX(str, D3DXMESH_MANAGED, pd3dDevice, NULL, NULL, NULL, NULL, &pMesh) );

    DWORD *rgdwAdjacency = NULL;

    // Make sure there are normals which are required for lighting
    if( !(pMesh->GetFVF() & D3DFVF_NORMAL) )
    {
        ID3DXMesh* pTempMesh;
        V( pMesh->CloneMeshFVF( pMesh->GetOptions(), 
                                  pMesh->GetFVF() | D3DFVF_NORMAL, 
                                  pd3dDevice, &pTempMesh ) );
        V( D3DXComputeNormals( pTempMesh, NULL ) );

        SAFE_RELEASE( pMesh );
        pMesh = pTempMesh;
    }

    // Optimize the mesh for this graphics card's vertex cache 
    // so when rendering the mesh's triangle list the vertices will 
    // cache hit more often so it won't have to re-execute the vertex shader 
    // on those vertices so it will improve perf.     
    rgdwAdjacency = new DWORD[pMesh->GetNumFaces() * 3];
    if( rgdwAdjacency == NULL )
        return E_OUTOFMEMORY;
    V( pMesh->ConvertPointRepsToAdjacency(NULL, rgdwAdjacency) );
    V( pMesh->OptimizeInplace(D3DXMESHOPT_VERTEXCACHE, rgdwAdjacency, NULL, NULL, NULL) );
    delete []rgdwAdjacency;

    *ppMesh = pMesh;

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has been 
// reset, which will happen after a lost device scenario. This is the best location to 
// create D3DPOOL_DEFAULT resources since these resources need to be reloaded whenever 
// the device is lost. Resources created here should be released in the OnLostDevice 
// callback. 
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnResetDevice( IDirect3DDevice9* pd3dDevice, 
                                const D3DSURFACE_DESC* pBackBufferSurfaceDesc )
{
    HRESULT hr;

	// --------------------------------------------------------------------------
    // �V���h�E�}�b�v�̐���
	// --------------------------------------------------------------------------
	V_RETURN( pd3dDevice->CreateTexture( SHADOWMAP_SIZE, SHADOWMAP_SIZE,
                                         1, D3DUSAGE_RENDERTARGET,
                                         D3DFMT_R32F,
                                         D3DPOOL_DEFAULT,
                                         &g_pShadowMap,
                                         NULL ) );
	// ���o�b�t�@
    DXUTDeviceSettings d3dSettings = DXUTGetDeviceSettings();
    V_RETURN( pd3dDevice->CreateDepthStencilSurface( SHADOWMAP_SIZE,
                                                     SHADOWMAP_SIZE,
                                                     d3dSettings.pp.AutoDepthStencilFormat,
                                                     D3DMULTISAMPLE_NONE,
                                                     0,
                                                     TRUE,
                                                     &g_pDSShadow,
                                                     NULL ) );
    D3DXMatrixPerspectiveFovLH( &g_mShadowProj, D3DX_PI / 2.0f, 1, 1.0f, 20.0f);

    D3DXVECTOR3 vecEye(6.0f, 6.0f,  0.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, -0.0f);
    D3DXVECTOR3 vecUp (0.0f, 1.0f,  0.0f);
    D3DXMatrixLookAtLH( &g_mShadowView, &vecEye, &vecAt, &vecUp );
	
	D3DXVec3Normalize( &vecEye, &vecEye );
	g_vLightDir.x = vecEye.x;
	g_vLightDir.y = vecEye.y;
	g_vLightDir.z = vecEye.z;
	g_vLightDir.w = 0;

	// --------------------------------------------------------------------------
    // �J�����p�̍s��
	// --------------------------------------------------------------------------
    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 0.1f, 1000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );

	// --------------------------------------------------------------------------
    // UI
	// --------------------------------------------------------------------------
    // Create a sprite to help batch calls when drawing many lines of text
    V_RETURN( D3DXCreateSprite( pd3dDevice, &g_pTextSprite ) );

    g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 0 );
    g_HUD.SetSize( 170, 170 );
    g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width-170, pBackBufferSurfaceDesc->Height-350 );
    g_SampleUI.SetSize( 170, 300 );

	// --------------------------------------------------------------------------
    // ���̂ق�
	// --------------------------------------------------------------------------
	if( g_pFont )
        V_RETURN( g_pFont->OnResetDevice() );
    if( g_pEffect )
        V_RETURN( g_pEffect->OnResetDevice() );

    pd3dDevice->GetViewport(&g_ViewportFB);

    return S_OK;
}


//--------------------------------------------------------------------------------------
// This callback function will be called once at the beginning of every frame. This is the
// best location for your application to handle updates to the scene, but is not 
// intended to contain actual rendering calls, which should instead be placed in the 
// OnFrameRender callback.  
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );

    D3DXMATRIXA16 mT, mR;
	D3DXMatrixTranslation( &mT, 2.0f, 2.0f ,0.0f );
	D3DXMatrixRotationY( &mR, (FLOAT)fTime );
	g_mWorld1 = mT * mR;
}

void RenderScene( IDirect3DDevice9* pd3dDevice, bool bRenderShadow, const D3DXMATRIX &mViewProj )
{
    UINT iPass, cPasses;
	float fOffsetX = 0.5f + (0.5f / (float)SHADOWMAP_SIZE);
	float fOffsetY = 0.5f + (0.5f / (float)SHADOWMAP_SIZE);
	D3DXMATRIXA16 mScaleBias(  0.5f,     0.0f,     0.0f,   0.0f,
                               0.0f,    -0.5f,     0.0f,   0.0f,
                               0.0f,     0.0f,     0.0f,   0.0f,
                               fOffsetX, fOffsetY, 0.0f,   1.0f );
	D3DXMATRIXA16 mShadowViewProjection = g_mShadowView * g_mShadowProj;
	D3DXMATRIXA16 mShadowMatrix = mShadowViewProjection * mScaleBias;
	D3DXMATRIXA16 m, mWorld;
	D3DXVECTOR4   v;

	// �����_�����O�^�[�Q�b�g�Ƃ��o�b�t�@���N���A����
	if(bRenderShadow)
	{
		pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(255, 255, 255, 255), 1.0f, 0);
	}else{
	    pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 45, 50, 170), 1.0f, 0);
	}

	if(bRenderShadow)
	{
        g_pEffect->SetTechnique( "CreateShadowMap" );
	}else{
        g_pEffect->SetTechnique( "ShadowMap" );
		
		D3DXVECTOR4 offset[12] = 
		{
			D3DXVECTOR4( -0.326212*g_fRadius/SHADOWMAP_SIZE, -0.405810*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( -0.840144*g_fRadius/SHADOWMAP_SIZE, -0.073580*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( -0.695914*g_fRadius/SHADOWMAP_SIZE, +0.457137*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( -0.203345*g_fRadius/SHADOWMAP_SIZE, +0.620716*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.962340*g_fRadius/SHADOWMAP_SIZE, -0.194983*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.473434*g_fRadius/SHADOWMAP_SIZE, -0.480026*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.519456*g_fRadius/SHADOWMAP_SIZE, +0.767022*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.185461*g_fRadius/SHADOWMAP_SIZE, -0.893124*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.507431*g_fRadius/SHADOWMAP_SIZE, +0.064425*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( +0.896420*g_fRadius/SHADOWMAP_SIZE, +0.412458*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( -0.321940*g_fRadius/SHADOWMAP_SIZE, -0.932645*g_fRadius/SHADOWMAP_SIZE, 0,0),
			D3DXVECTOR4( -0.791550*g_fRadius/SHADOWMAP_SIZE, -0.597710*g_fRadius/SHADOWMAP_SIZE, 0,0),
		};
		g_pEffect->SetVectorArray( "g_Offset", offset, 12);
	}

	// -------------------------------------------------------------------
	// t-pot�̕\��
	// -------------------------------------------------------------------
	mWorld = g_mWorld1;

	if(bRenderShadow)
	{
		m = mWorld * mViewProj;
		g_pEffect->SetMatrix( "g_mWorldViewProjection", &m);
	}else{
		D3DXMatrixInverse( &m, NULL, &mWorld);
		D3DXVec4Transform( &v, &g_vLightDir, &m );
		D3DXVec4Normalize( &v, &v );
		g_pEffect->SetVector( "g_vLightDir", &v);
		
		m = mWorld * mViewProj;
		g_pEffect->SetMatrix( "g_mWorldViewProjection", &m);
		m = mWorld * mShadowViewProjection;
		g_pEffect->SetMatrix( "g_mShadowViewProjection", &m);
		m = mWorld * mShadowMatrix;
		g_pEffect->SetMatrix( "g_mShadowMatrix", &m);
		g_pEffect->SetTexture( "Texture", g_pScene1MeshTexture);
	}

	// Draw the mesh on the rendertarget
    g_pEffect->Begin(&cPasses, 0);
    for (iPass = 0; iPass < cPasses; iPass++)
    {
        g_pEffect->BeginPass(iPass);
        g_pScene1Mesh->DrawSubset(0);
        g_pEffect->EndPass();
    }
    g_pEffect->End();


	// -------------------------------------------------------------------
	// �n�ʂ̕\��
	// -------------------------------------------------------------------
    D3DXMatrixIdentity( &mWorld );

	if(bRenderShadow)
	{
		m = mWorld * mViewProj;
		g_pEffect->SetMatrix( "g_mWorldViewProjection", &m);
	}else{
		D3DXMatrixInverse( &m, NULL, &mWorld);
		D3DXVec4Transform( &v, &g_vLightDir, &m );
		D3DXVec4Normalize( &v, &v );
		g_pEffect->SetVector( "g_vLightDir", &v);
		
		m = mWorld * mViewProj;
		g_pEffect->SetMatrix( "g_mWorldViewProjection", &m);
		m = mWorld * mShadowViewProjection;
		g_pEffect->SetMatrix( "g_mShadowViewProjection", &m);
		m = mWorld * mShadowMatrix;
		g_pEffect->SetMatrix( "g_mShadowMatrix", &m);
		g_pEffect->SetTexture( "Texture", g_pScene2MeshTexture);
	}

    // Draw the mesh on the rendertarget
    g_pEffect->Begin(&cPasses, 0);
    for (iPass = 0; iPass < cPasses; iPass++)
    {
        g_pEffect->BeginPass(iPass);
        g_pScene2Mesh->DrawSubset(0);
        g_pEffect->EndPass();
    }
    g_pEffect->End();
}

//--------------------------------------------------------------------------------------
// This callback function will be called at the end of every frame to perform all the 
// rendering calls for the scene, and it will also be called if the window needs to be 
// repainted. After this function has returned, the sample framework will call 
// IDirect3DDevice9::Present to display the contents of the next buffer in the swap chain
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime )
{
    HRESULT hr;
    D3DXMATRIXA16 mWorld;
    D3DXMATRIXA16 mCamera;
    D3DXMATRIXA16 mView;
    D3DXMATRIXA16 mProj;
    D3DXMATRIXA16 mWorldViewProjection;
	D3DXMATRIXA16 matWorldViewProj;

    // Render the scene
    if( SUCCEEDED( pd3dDevice->BeginScene() ) )
    {
	    LPDIRECT3DSURFACE9 pOldRT = NULL;
	    LPDIRECT3DSURFACE9 pOldDS = NULL;
	    LPDIRECT3DSURFACE9 pShadowSurf;
		
		// -------------------------------------------------------------------
		// �Â������_�����O�^�[�Q�b�g��ۑ�����
		// -------------------------------------------------------------------
		V( pd3dDevice->GetRenderTarget( 0, &pOldRT ) );
		V( pd3dDevice->GetDepthStencilSurface( &pOldDS ) );

		// -------------------------------------------------------------------
		// �V���������_�����O�^�[�Q�b�g��ݒ肷��
		// -------------------------------------------------------------------
	    g_pShadowMap->GetSurfaceLevel( 0, &pShadowSurf );
        pd3dDevice->SetRenderTarget( 0, pShadowSurf );
        pd3dDevice->SetDepthStencilSurface( g_pDSShadow );
        SAFE_RELEASE( pShadowSurf );

		mWorldViewProjection = g_mShadowView * g_mShadowProj;
		RenderScene( pd3dDevice, true, mWorldViewProjection );

		// -------------------------------------------------------------------
		// �����_�����O�^�[�Q�b�g��߂�
		// -------------------------------------------------------------------
        pd3dDevice->SetDepthStencilSurface( pOldDS );
        pd3dDevice->SetRenderTarget( 0, pOldRT );
        SAFE_RELEASE( pOldDS );
        SAFE_RELEASE( pOldRT );

		// �ʏ�̃����_�����O�̍s�������
        mCamera = *g_Camera.GetWorldMatrix();
        mView = *g_Camera.GetViewMatrix();
        mProj = *g_Camera.GetProjMatrix();
        mWorldViewProjection = mCamera * mView * mProj;
		
		// �V���h�E�}�b�v��ݒ�
        V( g_pEffect->SetTexture( "ShadowTex", g_pShadowMap) );
		
		// �ʏ�V�[���̕`��
		RenderScene( pd3dDevice, false, mWorldViewProjection );



		DXUT_BeginPerfEvent( DXUT_PERFEVENTCOLOR, L"HUD / Stats" ); // These events are to help PIX identify what the code is doing
        RenderText();
        V( g_HUD.OnRender( fElapsedTime ) );
        V( g_SampleUI.OnRender( fElapsedTime ) );
        DXUT_EndPerfEvent();

#ifdef _DEBUG // Textures are displaying when debugging, (�f�o�b�O�p�Ƀe�N�X�`����\������)
		{
		pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		float scale = 128.0f;
		typedef struct { FLOAT p[4]; FLOAT tu, tv;} TVERTEX;

		for(DWORD i=0; i<1; i++){
			TVERTEX Vertex[4] = {
				//    x                             y         z rhw tu tv
				{(i+0)*scale, (FLOAT)g_ViewportFB.Height-scale, 0, 1, 0, 0,},
				{(i+1)*scale, (FLOAT)g_ViewportFB.Height-scale, 0, 1, 1, 0,},
				{(i+0)*scale, (FLOAT)g_ViewportFB.Height-    0, 0, 1, 0, 1,},
				{(i+1)*scale, (FLOAT)g_ViewportFB.Height-    0, 0, 1, 1, 1,},
			};
			if(0==i) pd3dDevice->SetTexture( 0, g_pShadowMap );
//			if(1==i) pd3dDevice->SetTexture( 0, g_pTetraTex[1] );
//			if(2==i) pd3dDevice->SetTexture( 0, g_pTetraTex[2] );
//			if(3==i) pd3dDevice->SetTexture( 0, g_pTetraTex[3] );
//			if(4==i) pd3dDevice->SetTexture( 0, g_pEnvTex );

			pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		V( pd3dDevice->EndScene() );
    }
}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText()
{
    // The helper object simply helps keep track of text position, and color
    // and then it calls pFont->DrawText( m_pSprite, strMsg, -1, &rc, DT_NOCLIP, m_clr );
    // If NULL is passed in as the sprite object, then it will work however the 
    // pFont->DrawText() will not be batched together.  Batching calls will improves performance.
    const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetBackBufferSurfaceDesc();
    CDXUTTextHelper txtHelper( g_pFont, g_pTextSprite, 15 );

    // Output statistics
    txtHelper.Begin();
    txtHelper.SetInsertionPos( 5, 5 );
    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    txtHelper.DrawTextLine( DXUTGetFrameStats() );
    txtHelper.DrawTextLine( DXUTGetDeviceStats() );

    txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
    txtHelper.DrawTextLine( L"Put whatever misc status here" );
    
    // Draw help
    if( g_bShowHelp )
    {
        txtHelper.SetInsertionPos( 10, pd3dsdBackBuffer->Height-15*6 );
        txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 0.75f, 0.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Controls (F1 to hide):" );

        txtHelper.SetInsertionPos( 40, pd3dsdBackBuffer->Height-15*5 );
        txtHelper.DrawTextLine( L"Blah: X\n"
                                L"Quit: ESC" );
    }
    else
    {
        txtHelper.SetInsertionPos( 10, pd3dsdBackBuffer->Height-15*2 );
        txtHelper.SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
        txtHelper.DrawTextLine( L"Press F1 for help" );
    }
    txtHelper.End();
}


//--------------------------------------------------------------------------------------
// Before handling window messages, the sample framework passes incoming windows 
// messages to the application through this callback function. If the application sets 
// *pbNoFurtherProcessing to TRUE, then the sample framework will not process this message.
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing )
{
    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;
    *pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// As a convenience, the sample framework inspects the incoming windows messages for
// keystroke messages and decodes the message parameters to pass relevant keyboard
// messages to the application.  The framework does not remove the underlying keystroke 
// messages, which are still passed to the application's MsgProc callback.
//--------------------------------------------------------------------------------------
void CALLBACK KeyboardProc( UINT nChar, bool bKeyDown, bool bAltDown )
{
    if( bKeyDown )
    {
        switch( nChar )
        {
            case VK_F1: g_bShowHelp = !g_bShowHelp; break;
        }
    }
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl )
{
    switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:        DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:     DXUTSetShowSettingsDialog( !DXUTGetShowSettingsDialog() ); break;
        case IDC_CHANGE_LEVEL:
        {
            WCHAR sz[100];
            g_fRadius = g_SampleUI.GetSlider( IDC_CHANGE_LEVEL )->GetValue() / 10.0f;
            _snwprintf( sz, 100, L"Radius: %0.2f", g_fRadius ); sz[99] = 0;
            g_SampleUI.GetStatic( IDC_CHANGE_LEVEL_STATIC )->SetText( sz );
            break;
        }
   }
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// entered a lost state and before IDirect3DDevice9::Reset is called. Resources created
// in the OnResetDevice callback should be released here, which generally includes all 
// D3DPOOL_DEFAULT resources. See the "Lost Devices" section of the documentation for 
// information about lost devices.
//--------------------------------------------------------------------------------------
void CALLBACK OnLostDevice()
{
	if( g_pFont )
        g_pFont->OnLostDevice();
    if( g_pEffect )
        g_pEffect->OnLostDevice();
    SAFE_RELEASE( g_pTextSprite );

    SAFE_RELEASE( g_pDSShadow );
    SAFE_RELEASE( g_pShadowMap );
}


//--------------------------------------------------------------------------------------
// This callback function will be called immediately after the Direct3D device has 
// been destroyed, which generally happens as a result of application termination or 
// windowed/full screen toggles. Resources created in the OnCreateDevice callback 
// should be released here, which generally includes all D3DPOOL_MANAGED resources. 
//--------------------------------------------------------------------------------------
void CALLBACK OnDestroyDevice()
{
    SAFE_RELEASE( g_pEffect );
    SAFE_RELEASE( g_pFont );

    SAFE_RELEASE(g_pScene2Mesh);
    SAFE_RELEASE(g_pScene2MeshTexture);
    SAFE_RELEASE(g_pScene1Mesh);
    SAFE_RELEASE(g_pScene1MeshTexture);
}



