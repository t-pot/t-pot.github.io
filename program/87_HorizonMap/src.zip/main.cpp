//-------------------------------------------------------------
// File: main.cpp
//
// Desc: �������}�b�v
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE	512


// ��������Z�k�`������Ă݂�
#define RS   m_pd3dDevice->SetRenderState
#define TSS  m_pd3dDevice->SetTextureStageState
#define SAMP m_pd3dDevice->SetSamplerState


//-------------------------------------------------------------
// ���_�̍\����
//-------------------------------------------------------------
typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

typedef struct {
    FLOAT       p[4];
    FLOAT       t[4][2];
} T4VERTEX;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

//-------------------------------------------------------------
// ���[�J���ϐ�
//-------------------------------------------------------------
// ���C�̕���
static FLOAT ray_dir[4*COVER_MAPS][2] = {
	{ cosf(D3DX_PI* 0/(2*COVER_MAPS)), sinf(D3DX_PI* 0/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 1/(2*COVER_MAPS)), sinf(D3DX_PI* 1/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 2/(2*COVER_MAPS)), sinf(D3DX_PI* 2/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 3/(2*COVER_MAPS)), sinf(D3DX_PI* 3/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 4/(2*COVER_MAPS)), sinf(D3DX_PI* 4/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 5/(2*COVER_MAPS)), sinf(D3DX_PI* 5/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 6/(2*COVER_MAPS)), sinf(D3DX_PI* 6/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 7/(2*COVER_MAPS)), sinf(D3DX_PI* 7/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 8/(2*COVER_MAPS)), sinf(D3DX_PI* 8/(2*COVER_MAPS))},
	{ cosf(D3DX_PI* 9/(2*COVER_MAPS)), sinf(D3DX_PI* 9/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*10/(2*COVER_MAPS)), sinf(D3DX_PI*10/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*11/(2*COVER_MAPS)), sinf(D3DX_PI*11/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*12/(2*COVER_MAPS)), sinf(D3DX_PI*12/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*13/(2*COVER_MAPS)), sinf(D3DX_PI*13/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*14/(2*COVER_MAPS)), sinf(D3DX_PI*14/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*15/(2*COVER_MAPS)), sinf(D3DX_PI*15/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*16/(2*COVER_MAPS)), sinf(D3DX_PI*16/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*17/(2*COVER_MAPS)), sinf(D3DX_PI*17/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*18/(2*COVER_MAPS)), sinf(D3DX_PI*18/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*19/(2*COVER_MAPS)), sinf(D3DX_PI*19/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*20/(2*COVER_MAPS)), sinf(D3DX_PI*20/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*21/(2*COVER_MAPS)), sinf(D3DX_PI*21/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*22/(2*COVER_MAPS)), sinf(D3DX_PI*22/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*23/(2*COVER_MAPS)), sinf(D3DX_PI*23/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*24/(2*COVER_MAPS)), sinf(D3DX_PI*24/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*25/(2*COVER_MAPS)), sinf(D3DX_PI*25/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*26/(2*COVER_MAPS)), sinf(D3DX_PI*26/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*27/(2*COVER_MAPS)), sinf(D3DX_PI*27/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*28/(2*COVER_MAPS)), sinf(D3DX_PI*28/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*29/(2*COVER_MAPS)), sinf(D3DX_PI*29/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*30/(2*COVER_MAPS)), sinf(D3DX_PI*30/(2*COVER_MAPS))},
	{ cosf(D3DX_PI*31/(2*COVER_MAPS)), sinf(D3DX_PI*31/(2*COVER_MAPS))},
#if 0
#endif
};

//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pMeshBg					= new CD3DMesh();

	m_pMapZ						= NULL;
	m_pHeightTex				= NULL;
	m_pHeightSurf				= NULL;
	for(int i=0;i<COVER_MAPS;i++){
		m_pCoverTex[i]			= NULL;
		m_pCoverSurf[i]			= NULL;
	}

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWVP						= NULL;
	m_hvCol						= NULL;
	m_hvDir						= NULL;
	m_htSrcTex					= NULL;

	m_fWorldRotX                = -0.5f;
    m_fWorldRotY                = 0.0f;
	m_fViewZoom				    = 13.0f;

	m_LighPos					= D3DXVECTOR3( -5.0f, 5.0f,-2.0f );

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}




//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �n�ʂ̓ǂݍ���
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load BG", hr );
	m_pMeshBg->UseMeshMaterials(FALSE);// �����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�
        
	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWVP		 = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvCol		 = m_pEffect->GetParameterByName( NULL, "vCol" );
	m_hvDir      = m_pEffect->GetParameterByName( NULL, "vLightDir" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i, j;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DMATERIAL9 *pMtrl;

	// ���b�V��
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );

    // �����̐ݒ�
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );


    // �����_�����O��Ԃ̐ݒ�
    RS( D3DRS_DITHERENABLE,   FALSE );
    RS( D3DRS_SPECULARENABLE, FALSE );
    RS( D3DRS_ZENABLE,        TRUE );
    RS( D3DRS_AMBIENT,        0x000F0F0F );
    
    TSS( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    TSS( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    TSS( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    TSS( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
    TSS( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // �ˉe�s��
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

	// �����_�����O�^�[�Q�b�g�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// �����}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pHeightTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pHeightTex->GetSurfaceLevel(0, &m_pHeightSurf)))
		return E_FAIL;
	// �Օ��}�b�v
	for(i=0;i<COVER_MAPS;i++){
		if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pCoverTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pCoverTex[i]->GetSurfaceLevel(0, &m_pCoverSurf[i])))
			return E_FAIL;
	}

	m_pEffect->OnResetDevice();

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ύX
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pHeightSurf);
			m_pd3dDevice->SetDepthStencilSurface(NULL);
			// �r���[�|�[�g�̕ύX
			D3DVIEWPORT9 viewport_height = {0,0      // ����̍��W
							, MAP_SIZE  // ��
							, MAP_SIZE // ����
							, 0.0f,1.0f};     // �O�ʁA���
			m_pd3dDevice->SetViewport(&viewport_height);

			// �����_�����O�^�[�Q�b�g�̃N���A
			m_pd3dDevice->Clear(0L, NULL
							, D3DCLEAR_TARGET
							, 0x00000000, 1.0f, 0L);

			//-------------------------------------------------
			// �����}�b�v�̍쐬
			//-------------------------------------------------
			RS( D3DRS_ZENABLE, FALSE );
			RS( D3DRS_CULLMODE, D3DCULL_NONE );
			m_pEffect->Pass( 0 );
			
			// �w�i�̕`��
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );	// �`��
				pMtrl++;
			}
			
			//-------------------------------------------------
			// �Օ��}�b�v�̍쐬
			//-------------------------------------------------
			typedef struct {FLOAT p[3]; FLOAT tu, tv;} TVERTEX3;
			TVERTEX3 Vertex[4] = {
				// x   y   z   tu tv
				{ -1, -1, 0.1f, 0, 1,},
				{  1, -1, 0.1f, 1, 1,},
				{  1,  1, 0.1f, 1, 0,},
				{ -1,  1, 0.1f, 0, 0,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture(m_htSrcTex, m_pHeightTex);
			RS(D3DRS_ALPHABLENDENABLE, TRUE);
			RS(D3DRS_BLENDOP, D3DBLENDOP_MAX);
			RS(D3DRS_SRCBLEND , D3DBLEND_ONE);
			RS(D3DRS_DESTBLEND , D3DBLEND_ONE);
			m_pEffect->Pass( 1 );

			for(i=0;i<4*COVER_MAPS;i++){
				if(0==(i%4)){
					m_pd3dDevice->SetRenderTarget(0, m_pCoverSurf[i/4]);
					m_pd3dDevice->Clear(0L, NULL
									, D3DCLEAR_TARGET
									, 0x00000000, 1.0f, 0L);
				}

				RS(D3DRS_COLORWRITEENABLE,(1<<(i%4)));
				for(j=1; j<MAP_SIZE; j++){
					// ���C�̍���
					FLOAT d = 10.0f*(FLOAT)j/MAP_SIZE + 0.0001f;
					m_pEffect->SetFloat("fRayHeight", d);
					// �e�N�X�`�������炷�ʒu
					D3DXVECTOR4 v = D3DXVECTOR4(
							ray_dir[i][0]*j/MAP_SIZE,
							ray_dir[i][1]*j/MAP_SIZE,0,0);
					m_pEffect->SetVector("vOffset", &v);
					// �`��
					m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
								, 2, Vertex, sizeof( TVERTEX3 ) );
				}
			}
			RS(D3DRS_ALPHABLENDENABLE, FALSE);
			RS(D3DRS_COLORWRITEENABLE, 0xf);
			RS( D3DRS_ZENABLE, TRUE );
			RS( D3DRS_CULLMODE, D3DCULL_CCW );
		}

		m_pEffect->End();

		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();
		m_pd3dDevice->EndScene();
	}

	return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else
    if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else
    if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// �r���[�s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.3f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
}


//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
	DWORD i;
	D3DXVECTOR4 v;
	D3DMATERIAL9 *pMtrl;

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		// �t���[���o�b�t�@�̃N���A
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 2 );

			//-------------------------------------------------
			// �V�[���̕`��
			//-------------------------------------------------
			// �Օ��}�b�v����������d��
			D3DXVECTOR4 array[COVER_MAPS];
			float acc=0;
			float theta = fmod(0.5*this->m_fTime, 2.0*D3DX_PI);
			float dir[2] = {sinf(theta), cosf(theta)};
			int no=0;
			for(i=0;i<COVER_MAPS;i++){
				array[i].x = max(0, dir[0]*ray_dir[no][0]+dir[1]*ray_dir[no][1]-cosf(D3DX_PI/(2*COVER_MAPS)));no++;
				array[i].y = max(0, dir[0]*ray_dir[no][0]+dir[1]*ray_dir[no][1]-cosf(D3DX_PI/(2*COVER_MAPS)));no++;
				array[i].z = max(0, dir[0]*ray_dir[no][0]+dir[1]*ray_dir[no][1]-cosf(D3DX_PI/(2*COVER_MAPS)));no++;
				array[i].w = max(0, dir[0]*ray_dir[no][0]+dir[1]*ray_dir[no][1]-cosf(D3DX_PI/(2*COVER_MAPS)));no++;
			}
			for(i=0;i<COVER_MAPS;i++)
				acc += array[i].x + array[i].y + array[i].z + array[i].w;
			for(i=0;i<COVER_MAPS;i++){
				array[i].x/=acc;
				array[i].y/=acc;
				array[i].z/=acc;
				array[i].w/=acc;
			}
			m_pEffect->SetVectorArray("vWeight", array, COVER_MAPS);


			// �ϊ��s��
			m = m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			m_pEffect->SetTexture("CoverTex0", m_pCoverTex[0]);
			m_pEffect->SetTexture("CoverTex1", m_pCoverTex[1]);
			m_pEffect->SetTexture("CoverTex2", m_pCoverTex[2]);
			m_pEffect->SetTexture("CoverTex3", m_pCoverTex[3]);
			m_pEffect->SetTexture("CoverTex4", m_pCoverTex[4]);
			m_pEffect->SetTexture("CoverTex5", m_pCoverTex[5]);
			m_pEffect->SetTexture("CoverTex6", m_pCoverTex[6]);
			m_pEffect->SetTexture("CoverTex7", m_pCoverTex[7]);

			// �w�i�̕`��
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );	// �`��
				pMtrl++;
			}

			m_pEffect->End();
		}

        // �w���v�̕\��
        RenderText();

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 128.0f;
		for(DWORD i=0; i<5; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pHeightTex );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pCoverTex[0] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pCoverTex[1] );
			if(3==i) m_pd3dDevice->SetTexture( 0, m_pCoverTex[2] );
			if(4==i) m_pd3dDevice->SetTexture( 0, m_pCoverTex[3] );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
	
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// �����_�����O�^�[�Q�b�g
	for(int i=0;i<COVER_MAPS;i++){
		SAFE_RELEASE(m_pCoverSurf[i]);
		SAFE_RELEASE(m_pCoverTex[i]);
	}
	SAFE_RELEASE(m_pHeightSurf);
	SAFE_RELEASE(m_pHeightTex);
	SAFE_RELEASE(m_pMapZ);

	m_pMeshBg->InvalidateDeviceObjects();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

	// �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    // �V�F�[�_
	SAFE_RELEASE( m_pEffect );
	
	// ���b�V��
	m_pMeshBg->Destroy();

    // �t�H���g
    m_pFont->DeleteDeviceObjects();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pMeshBg ); // ���b�V��

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




