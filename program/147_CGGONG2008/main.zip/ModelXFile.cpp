#include "DXUT.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "ModelXFile.h"
#include "SDKmisc.h"

ID3D10Device*					    MeshXFile::m_pd3dDevice = NULL;
ID3D10InputLayout*				    MeshXFile::m_pVertexLayout = NULL;
DWORD                               MeshXFile::g_nRef = 0;

typedef struct {
  float x,y,z;
  float nx,ny,nz;
  float u,v;
} ORIGINAL_VERTEX;

static const D3D10_INPUT_ELEMENT_DESC g_aVertexLayout[] =
{
    { "POSITION",  0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    { "NORMAL",    0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    { "TEXCOORD",  0, DXGI_FORMAT_R32G32_FLOAT,    0, 24, D3D10_INPUT_PER_VERTEX_DATA, 0 },
};
static UINT g_iNumVLElements = sizeof(g_aVertexLayout)/sizeof(D3D10_INPUT_ELEMENT_DESC);

#if 0
static void computeNormal(CUSTOMVERTEX *pVertex, DWORD *pIndex, DWORD nVertex, DWORD nFace)
{
	for(DWORD i = 0; i < nVertex; i++)
	{
		pVertex[i].nx = 0.0f;
		pVertex[i].ny = 0.0f;
		pVertex[i].nz = 0.0f;
	}

	for(DWORD i = 0; i < nFace; i++)
	{
		CUSTOMVERTEX *p0 = &pVertex[pIndex[3*i+0]];
		CUSTOMVERTEX *p1 = &pVertex[pIndex[3*i+1]];
		CUSTOMVERTEX *p2 = &pVertex[pIndex[3*i+2]];

        D3DXVECTOR3 v1, v2;
        D3DXVECTOR3 vNormal;
		v1 = *(D3DXVECTOR3*)&(p1->x) - *(D3DXVECTOR3*)&(p0->x);
        v2 = *(D3DXVECTOR3*)&(p2->x) - *(D3DXVECTOR3*)&(p1->x);
        D3DXVec3Cross( &vNormal, &v1, &v2 );

		p0->nx += vNormal.x; p0->ny += vNormal.y; p0->nz += vNormal.z;
		p1->nx += vNormal.x; p1->ny += vNormal.y; p1->nz += vNormal.z;
		p2->nx += vNormal.x; p2->ny += vNormal.y; p2->nz += vNormal.z;
	}

	for(DWORD i = 0; i < nVertex; i++)
	{
		D3DXVECTOR3 vNormal = D3DXVECTOR3(pVertex[i].nx, pVertex[i].ny, pVertex[i].nz);
        D3DXVec3Normalize( &vNormal, &vNormal );
		pVertex[i].nx = vNormal.x;
		pVertex[i].ny = vNormal.y;
		pVertex[i].nz = vNormal.z;
	}
}
#endif

FLOAT ComputeBoundingSphere(D3DXVECTOR3 &vCenter, const CUSTOMVERTEX *pVertex, DWORD nVertex)
{
	vCenter = D3DXVECTOR3(0,0,0);

	for(DWORD i = 0; i < nVertex; i++)
	{
		vCenter.x += pVertex[i].x;
		vCenter.y += pVertex[i].y;
		vCenter.z += pVertex[i].z;
	}

	vCenter.x /= (FLOAT)nVertex;
	vCenter.y /= (FLOAT)nVertex;
	vCenter.z /= (FLOAT)nVertex;

	FLOAT radius = 0.0f;
	for(DWORD i = 0; i < nVertex; i++)
	{
		D3DXVECTOR3 d;
        D3DXVec3Subtract(&d,  (D3DXVECTOR3*)&pVertex[i].x, &vCenter);
		FLOAT r = D3DXVec3Length(&d);

		radius = (radius < r) ? r : radius;
	}

	return radius;
}

HRESULT MeshXFile::LoadXfile( LPCTSTR szMesh )
{
    HRESULT hr = S_OK;
    IDirect3DDevice9 *pDev9 = NULL;
    ID3DXMesh *pRawMesh = NULL;
    ID3DXMesh *pMesh = NULL;

    // Create a d3d9 device
    LPDIRECT3D9 pD3D9 = Direct3DCreate9( D3D_SDK_VERSION );
    if( pD3D9 == NULL )
        return E_FAIL;

    D3DPRESENT_PARAMETERS pp;
    pp.BackBufferWidth = 320;
    pp.BackBufferHeight = 240;
    pp.BackBufferFormat = D3DFMT_X8R8G8B8;
    pp.BackBufferCount = 1;
    pp.MultiSampleType = D3DMULTISAMPLE_NONE;
    pp.MultiSampleQuality = 0;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    pp.hDeviceWindow = GetShellWindow();
    pp.Windowed = true;
    pp.Flags = 0;
    pp.FullScreen_RefreshRateInHz = 0;
    pp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
    pp.EnableAutoDepthStencil = false;

    hr = pD3D9->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, NULL, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, &pDev9 );
    if( FAILED( hr ) )
    {
        hr = pD3D9->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_REF, NULL, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &pp, &pDev9 );
        if( FAILED( hr ) )
            return E_FAIL;
    }

    if( FAILED( D3DXLoadMeshFromX( szMesh, 0, pDev9, NULL, NULL, NULL, NULL, &pRawMesh ) ) )
        return E_FAIL;

    // Make a clone with the desired vertex format (position).
    if( SUCCEEDED( pRawMesh->CloneMeshFVF( D3DXMESH_32BIT, D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1, pDev9, &pMesh ) ) )
//    if( SUCCEEDED( pRawMesh->CloneMeshFVF( D3DXMESH_32BIT, D3DFVF_XYZ|D3DFVF_TEX1, pDev9, &pMesh ) ) )
    {
        SAFE_RELEASE( pRawMesh );

		{
		// Fill vertex buffer
		m_nVertex = pMesh->GetNumVertices();
		CUSTOMVERTEX* pVertex = new CUSTOMVERTEX[ m_nVertex ];

        ORIGINAL_VERTEX* pOrigVerts = NULL;
        pMesh->LockVertexBuffer( 0, (void**)&pOrigVerts );
        for(UINT i=0; i<m_nVertex; i++)
        {
			pVertex[i].x = pOrigVerts[i].x;
			pVertex[i].y = pOrigVerts[i].y;
			pVertex[i].z = pOrigVerts[i].z;
			pVertex[i].nx = pOrigVerts[i].nx;
			pVertex[i].ny = pOrigVerts[i].ny;
			pVertex[i].nz = pOrigVerts[i].nz;
			pVertex[i].u = pOrigVerts[i].u;
			pVertex[i].v = pOrigVerts[i].v;
		}
		pMesh->UnlockVertexBuffer();

		// Fill vertex buffer
		m_nIndex = 3 * pMesh->GetNumFaces();
		DWORD* pIndex = new DWORD[ m_nIndex ];

        DWORD* pdwOrigIndices = NULL;
        pMesh->LockIndexBuffer( 0, (void**)&pdwOrigIndices);
        for(UINT i=0; i< m_nIndex; i++)
        {
			pIndex[i] = pdwOrigIndices[i];
		}
		pMesh->UnlockIndexBuffer();

		m_fBsRadius = ComputeBoundingSphere(m_vBsCenter, pVertex, m_nVertex);

//		computeNormal(pVertex, pIndex, m_nVertex, m_nIndex/3);

		// Create buffers
		UINT uiVertBufSize = m_nVertex * sizeof(CUSTOMVERTEX);
		D3D10_BUFFER_DESC vbdesc =
		{
			uiVertBufSize,
			D3D10_USAGE_DEFAULT,
			D3D10_BIND_VERTEX_BUFFER,
			0,
			0
		};

		D3D10_SUBRESOURCE_DATA InitData;
		InitData.pSysMem = pVertex;
		InitData.SysMemPitch = 0;
		InitData.SysMemSlicePitch = 0;
		V( m_pd3dDevice->CreateBuffer( &vbdesc, &InitData, &m_pVB ) );

		// �C���f�b�N�X�o�b�t�@�̍쐬
		vbdesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
		vbdesc.ByteWidth = m_nIndex * sizeof(DWORD);
		InitData.pSysMem = pIndex;
		V_RETURN( m_pd3dDevice->CreateBuffer( &vbdesc, &InitData, &m_pIB ) );

		SAFE_DELETE_ARRAY( pVertex );
		SAFE_DELETE_ARRAY( pIndex );
		}
	
	}

    SAFE_RELEASE( pMesh );
    SAFE_RELEASE( pDev9 );
    SAFE_RELEASE( pD3D9 );

    return hr;
}

HRESULT LoadTexture(ID3D10Device* pd3dDevice, LPCTSTR strTexFile, ID3D10ShaderResourceView** ppTexRV, ID3D10Texture2D** ppTexture)
{
	HRESULT hr;

	WCHAR strPath[MAX_PATH];
    V_RETURN( DXUTFindDXSDKMediaFileCch( strPath, MAX_PATH, strTexFile ) );
    
    ID3D10Resource *pRes = NULL;
    ID3D10Texture2D* pTexture = NULL;
    ID3D10ShaderResourceView* pTexRV = NULL;

    V_RETURN( D3DX10CreateTextureFromFile( pd3dDevice, strPath, NULL, NULL, &pRes, NULL ) );
    if( pRes )
    {
        D3D10_TEXTURE2D_DESC desc;
        ZeroMemory( &desc, sizeof(D3D10_TEXTURE2D_DESC) );
        pRes->QueryInterface( __uuidof( ID3D10Texture2D ), (LPVOID*)&pTexture );
        pTexture->GetDesc( &desc );        
        SAFE_RELEASE( pRes );

        D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
        ZeroMemory( &SRVDesc, sizeof(SRVDesc) );
        SRVDesc.Format = desc.Format;
        SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
        SRVDesc.TextureCube.MipLevels = desc.MipLevels;
        SRVDesc.TextureCube.MostDetailedMip = 0;
        V_RETURN(pd3dDevice->CreateShaderResourceView( pTexture, &SRVDesc, &pTexRV ));
    }

    *ppTexture   = pTexture;
    *ppTexRV     = pTexRV;

	return S_OK;
}

MeshXFile::MeshXFile()
{
	m_nVertex = 0;
	m_nIndex = 0;

    m_pVB                   = NULL;
    m_pIB                   = NULL;

    m_pTex                  = NULL;
    m_pTexRV                = NULL;
}

MeshXFile::~MeshXFile()
{
}


HRESULT MeshXFile::SetUp( ID3D10Device* pd3dDevice, ID3D10EffectTechnique *pTech )
{
	HRESULT hr;

	m_pd3dDevice = pd3dDevice;

#if 0
    // Read the D3DX effect file
    WCHAR str[MAX_PATH];
	WCHAR* strEffectFileName = TEXT("ModelXFile.fx");
    V( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, strEffectFileName ) );

    // If this fails, there should be debug output as to 
    // they the .fx file failed to compile
    DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
    V( D3DX10CreateEffectFromFile( str, NULL, NULL, "fx_4_0", dwShaderFlags, 0, pd3dDevice, NULL, NULL, &m_pEffect, NULL, NULL ) );

    // Get the technique
    m_apTech[SHADER_DEFAULT]            = m_pEffect->GetTechniqueByName( "Tech" );
    m_apTech[SHADER_DEPTH]              = m_pEffect->GetTechniqueByName( "TechDepth" );
    m_apTech[SHADER_SHADOWMAP]          = m_pEffect->GetTechniqueByName( "TechShadow" );
    m_apTech[SHADER_OBSTACLE]           = m_pEffect->GetTechniqueByName( "TechObstacle" );

    m_apTech[SHADER_DEFAULT_SHADOW]     = m_pEffect->GetTechniqueByName( "TechShadowing" );
    m_apTech[SHADER_DEPTH_SHADOW]       = m_pEffect->GetTechniqueByName( "TechShadowingDepth" );
	m_apTech[SHADER_DEFAULT_NO_SHADE]   = m_pEffect->GetTechniqueByName( "TechNoShade" );
    m_apTech[SHADER_DEPTH_NO_SHADE]     = m_pEffect->GetTechniqueByName( "TechDepthNoShade" );
    m_apTech[SHADER_DEFAULT_REFLECT]    = m_pEffect->GetTechniqueByName( "TechReflect" );
    m_apTech[SHADER_DEPTH_REFLECT]      = m_pEffect->GetTechniqueByName( "TechDepthReflect" );

    // Get the variables
    m_pmWorld               = m_pEffect->GetVariableByName("g_mWorld")->AsMatrix();
    m_pmWorldViewProjection = m_pEffect->GetVariableByName("g_mWorldViewProjection")->AsMatrix();
    m_pmWorldView           = m_pEffect->GetVariableByName("g_mWorldView")->AsMatrix();
    m_pTexRVal = m_pEffect->GetVariableByName("g_DecalTexture")->AsShaderResource();
    m_pMaskTexRVal = m_pEffect->GetVariableByName("g_MaskTexture")->AsShaderResource();
	// �e�p
    m_pmShadowWorld         = m_pEffect->GetVariableByName("g_mShadowWorld")->AsMatrix();
	m_pvDepthScaling        = m_pEffect->GetVariableByName("g_vDepthScaling")->AsVector();
    m_pvLightDir            = m_pEffect->GetVariableByName("g_vLightDir")->AsVector();
    m_pShadowMapRVal        = m_pEffect->GetVariableByName("g_ShadowMap")->AsShaderResource();

#endif
    // Create an input layout that matches the technique
    D3D10_PASS_DESC PassDesc;
    V( pTech->GetPassByIndex( 0 )->GetDesc( &PassDesc ) );
    V( pd3dDevice->CreateInputLayout( g_aVertexLayout, g_iNumVLElements, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_pVertexLayout ) );

	return S_OK;
}

HRESULT MeshXFile::OnCreateDevice( ID3D10Device* pd3dDevice, LPCTSTR filename, LPCTSTR strTexFile, ID3D10EffectTechnique *pTech )
{
	HRESULT hr;

	if(0==g_nRef++) SetUp(pd3dDevice, pTech);

    WCHAR str[MAX_PATH];
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, filename ) );

	V_RETURN(LoadXfile(str));

	V_RETURN(LoadTexture(m_pd3dDevice, strTexFile, &m_pTexRV, &m_pTex));

	return S_OK;
}

void MeshXFile::Release()
{
	m_pd3dDevice = NULL;
    SAFE_RELEASE( m_pVertexLayout );
}

void MeshXFile::OnDestroyDevice()
{
    SAFE_RELEASE( m_pVB );
    SAFE_RELEASE( m_pIB );
    SAFE_RELEASE( m_pTex );
    SAFE_RELEASE( m_pTexRV );

	if(0==--g_nRef) Release();
}


void MeshXFile::SetBuffers()
{
    m_pd3dDevice->IASetInputLayout( m_pVertexLayout );
    m_pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	UINT uStrides = sizeof(CUSTOMVERTEX);
    UINT uOffsets = 0;
    ID3D10Buffer *pBuffers[1] = { m_pVB };
    m_pd3dDevice->IASetVertexBuffers( 0, 1, pBuffers, &uStrides, &uOffsets );
    m_pd3dDevice->IASetIndexBuffer( m_pIB, DXGI_FORMAT_R32_UINT, 0 );
}

DWORD MeshXFile::GetVertexSize()
{
	return sizeof(CUSTOMVERTEX);
}
