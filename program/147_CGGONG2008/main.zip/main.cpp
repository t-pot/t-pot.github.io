//--------------------------------------------------------------------------------------
// File: main.cpp
//--------------------------------------------------------------------------------------
#include "DXUT.h"
#include "DXUTgui.h"
#include "DXUTmisc.h"
#include "DXUTCamera.h"
#include "DXUTSettingsDlg.h"
#include "SDKmisc.h"
#include "SDKmesh.h"
#include "resource.h"
#include "ModelXFile.h"

#define frand() ((float)rand()/(float)RAND_MAX)

//--------------------------------------------------------------------------------------
// Parameters for test
//--------------------------------------------------------------------------------------

//#define DEBUG_VS   // Uncomment this line to debug D3D9 vertex shaders 
//#define DEBUG_PS   // Uncomment this line to debug D3D9 pixel shaders 

#define MAX_SO_POLYGONE 65536


//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
CModelViewerCamera      g_Camera;               // A model viewing camera
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg         g_SettingsDlg;          // Device settings dialog
CDXUTTextHelper*		g_pTxtHelper = NULL;
CDXUTDialog             g_HUD;                  // dialog for standard controls
CDXUTDialog             g_SampleUI;             // dialog for sample specific controls
ID3D10Device*           g_pd3dDevice = NULL;

// Direct3D 10 resources
ID3DX10Font*            g_pFont10 = NULL;       
ID3DX10Sprite*          g_pSprite10 = NULL;     
ID3D10Effect*           g_pEffect10 = NULL;     
ID3D10InputLayout*      g_pVertexLayout = NULL; 
ID3D10EffectTechnique*  g_pTechRenderScene = NULL;
ID3D10EffectTechnique*  g_pTechRenderSceneClipping = NULL;
ID3D10EffectTechnique*  g_pTechPartialSortBack = NULL;
ID3D10EffectTechnique*  g_pTechPartialSortFront = NULL;
ID3D10EffectMatrixVariable*   g_pmWorldViewProj = NULL;
ID3D10EffectMatrixVariable*   g_pmWorldView = NULL;
ID3D10EffectMatrixVariable*   g_pmWorld = NULL;
ID3D10EffectVectorVariable*   g_pMaterialAmbientColor = NULL;
ID3D10EffectVectorVariable*   g_pMaterialDiffuseColor = NULL;
ID3D10EffectVectorVariable*   g_pLightDir = NULL;
ID3D10EffectVectorVariable*   g_pLightDiffuse = NULL;
ID3D10EffectScalarVariable*   g_pfZMin = NULL;
ID3D10EffectScalarVariable*   g_pfZMid = NULL;
ID3D10EffectScalarVariable*   g_pfZMax = NULL;
ID3D10EffectShaderResourceVariable* g_ptxMesh = NULL;

// SO objects
enum
{
	METHOD_NONE = 0,
	METHOD_SLICE,
	METHOD_PARTIAL,
};
unsigned int g_dwMethodIdx = METHOD_NONE;
unsigned int g_dwNumPartsLog = 1;
unsigned int g_dwNumParts = (1<<g_dwNumPartsLog);
ID3D10Buffer*           *g_pSO = NULL;


MeshXFile              *g_pMesh = 0;

// �w�i
typedef struct {
  float x,y,z;
  float u,v;
} BGVERTEX;
ID3D10ShaderResourceView* g_pTexRVBg = NULL;
ID3D10Texture2D* g_pTextureBg = NULL;
ID3D10InputLayout*      g_pVertexLayoutBg = NULL; 
ID3D10EffectTechnique*  g_pTechRenderBg = NULL;
ID3D10Buffer*                               g_pVBBg = NULL;
ID3D10Buffer*                               g_pIBBg = NULL;

// ��
#define SNOW_COUNT 10240
#define SNOW_VELOCITY 0.05
#define SNOW_X_MAX 1.0
#define SNOW_X_MIN -1.0
#define SNOW_Y_MAX 1.0
#define SNOW_Y_MIN -1.0
#define SNOW_Z_MAX 100.0
#define SNOW_Z_MIN 1.0
typedef struct {
  float x,y,z;
  float bx,by,bz;
  float tx,ty,tz;
} SNOWVERTEX;
ID3D10ShaderResourceView* g_pTexRVSnow = NULL;
ID3D10Texture2D*          g_pTextureSnow = NULL;
ID3D10InputLayout*        g_pVertexLayoutSnow = NULL; 
ID3D10EffectTechnique*    g_pTechRenderSnow = NULL;
ID3D10Buffer*             g_pVBSnow = NULL;
SNOWVERTEX                g_aSnowVertex[SNOW_COUNT];

// �ς�������
typedef struct {
  float x,y,z;
  float u,v;
} SNOWMAPVERTEX;
#define SNOWMAPSIZE 256
#define SNOWMAPINDEX_COUNT (6 * (SNOWMAPSIZE-1) * (SNOWMAPSIZE-1))
ID3D10Texture2D*            g_pSnowMapDepth;     // Depth stencil for the environment map
ID3D10DepthStencilView*     g_pSnowMapDSV;       // Depth stencil view for environment map for all 6 faces
ID3D10Texture2D*            g_pSnowMap;          // Environment map
ID3D10RenderTargetView*     g_pSnowMapRTV;       // Render target view for the alpha map
ID3D10ShaderResourceView*   g_pSnowMapSRV;       // Shader resource view for the cubic env map
ID3D10EffectTechnique*      g_pTechRenderDepth = NULL;
ID3D10EffectTechnique*      g_pTechRenderSnowMap = NULL;
ID3D10InputLayout*          g_pVertexLayoutSnowMap = NULL; 
ID3D10Buffer*               g_pVBSnowMap = NULL;
ID3D10Buffer*               g_pIBSnowMap = NULL;
ID3D10EffectScalarVariable* g_pfBaseValue = NULL;
ID3D10EffectScalarVariable* g_pfCompValue = NULL;

//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_TOGGLEFULLSCREEN    1
#define IDC_TOGGLEREF           2
#define IDC_CHANGEDEVICE        3
#define IDC_METHOD              4
#define IDC_PARTITIONLABEL      5
#define IDC_PARTITION           6


//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void    CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void    CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext );
bool    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext );

bool    CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext );
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext );
void    CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void    CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext );
void    CALLBACK OnD3D10DestroyDevice( void* pUserContext );

void    InitApp();
void    RenderText();


//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

    // DXUT will create and use the best device (either D3D9 or D3D10) 
    // that is available on the system depending on which D3D callbacks are set below

    // Set DXUT callbacks
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( OnKeyboard );
    DXUTSetCallbackFrameMove( OnFrameMove );
    DXUTSetCallbackDeviceChanging( ModifyDeviceSettings );

    DXUTSetCallbackD3D10DeviceAcceptable( IsD3D10DeviceAcceptable );
    DXUTSetCallbackD3D10DeviceCreated( OnD3D10CreateDevice );
    DXUTSetCallbackD3D10SwapChainResized( OnD3D10ResizedSwapChain );
    DXUTSetCallbackD3D10SwapChainReleasing( OnD3D10ReleasingSwapChain );
    DXUTSetCallbackD3D10DeviceDestroyed( OnD3D10DestroyDevice );
    DXUTSetCallbackD3D10FrameRender( OnD3D10FrameRender );

    InitApp();
    DXUTInit( true, true, NULL ); // Parse the command line, show msgboxes on error, no extra command line params
    DXUTSetCursorSettings( true, true );
    DXUTCreateWindow( L"Partial Sorting" );
    DXUTCreateDevice( true, 640, 480 );

    DXUTMainLoop(); // Enter into the DXUT render loop

    return DXUTGetExitCode();
}


//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    g_SettingsDlg.Init( &g_DialogResourceManager );
    g_HUD.Init( &g_DialogResourceManager );
    g_SampleUI.Init( &g_DialogResourceManager );

    g_HUD.SetCallback( OnGUIEvent ); int iY = 10; 
    g_HUD.AddButton( IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 35, iY, 125, 22 );
    g_HUD.AddButton( IDC_TOGGLEREF, L"Toggle REF (F3)", 35, iY += 24, 125, 22, VK_F3 );
    g_HUD.AddButton( IDC_CHANGEDEVICE, L"Change device (F2)", 35, iY += 24, 125, 22, VK_F2 );

    g_SampleUI.SetCallback( OnGUIEvent ); iY = 10; 
    g_SampleUI.AddComboBox( IDC_METHOD, 10, iY, 150, 24, L'M' );
    g_SampleUI.GetComboBox( IDC_METHOD )->AddItem( L"(M)ethod: None", (void*)0 );
    g_SampleUI.GetComboBox( IDC_METHOD )->AddItem( L"(M)ethod: Slice", (void*)1 );
    g_SampleUI.GetComboBox( IDC_METHOD )->AddItem( L"(M)ethod: Partial Sort", (void*)2 );
	g_SampleUI.GetComboBox( IDC_METHOD )->SetSelectedByData( (void*)g_dwMethodIdx );
    WCHAR wszBuf[256];
    StringCchPrintf( wszBuf, 256, L"Number of partitions: %u", g_dwNumParts );
    g_SampleUI.AddStatic( IDC_PARTITIONLABEL, wszBuf, 10, iY += 30, 150, 16 );
    g_SampleUI.AddSlider( IDC_PARTITION, 10, iY += 14, 140, 24, 1, 10, g_dwNumPartsLog );
}


//--------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//--------------------------------------------------------------------------------------
void RenderText()
{
    g_pTxtHelper->Begin();
    g_pTxtHelper->SetInsertionPos( 5, 5 );
    g_pTxtHelper->SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    g_pTxtHelper->DrawTextLine( DXUTGetFrameStats( DXUTIsVsyncEnabled() ) );  
    g_pTxtHelper->DrawTextLine( DXUTGetDeviceStats() );
    g_pTxtHelper->End();
}


//--------------------------------------------------------------------------------------
// Reject any D3D10 devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
    return true;
}

//--------------------------------------------------------------------------------------
void DestroyPartitions()
{
    for(unsigned int i = 0; i < g_dwNumPartsLog; i++)
    {
		SAFE_RELEASE(g_pSO[i]);
	}

	SAFE_DELETE( g_pSO );
}
typedef ID3D10Buffer *LPD3D10Buffer;

//--------------------------------------------------------------------------------------
HRESULT CreatePartitions(ID3D10Device* pd3dDevice)
{
    HRESULT hr;

	g_pSO = new LPD3D10Buffer[g_dwNumPartsLog];

    D3D10_BUFFER_DESC vbdesc =
    {
		3 * MAX_SO_POLYGONE * g_pMesh->GetVertexSize(),
        D3D10_USAGE_DEFAULT,
        D3D10_BIND_VERTEX_BUFFER | D3D10_BIND_STREAM_OUTPUT,
        0,
        0
    };

    for(unsigned int i = 0; i < g_dwNumPartsLog; i++)
    {
	    V_RETURN( pd3dDevice->CreateBuffer( &vbdesc, NULL, &g_pSO[i]) );
	}

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Create any D3D10 resources that aren't dependant on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC *pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

	g_pd3dDevice = pd3dDevice;

    V_RETURN( D3DX10CreateSprite( pd3dDevice, 500, &g_pSprite10 ) );
    V_RETURN( g_DialogResourceManager.OnD3D10CreateDevice( pd3dDevice ) );
    V_RETURN( g_SettingsDlg.OnD3D10CreateDevice( pd3dDevice ) );
    V_RETURN( D3DX10CreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                                OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                                L"Arial", &g_pFont10 ) );
    g_pTxtHelper = new CDXUTTextHelper( NULL, NULL, g_pFont10, g_pSprite10, 15 );

    // Read the D3DX effect file
    WCHAR str[MAX_PATH];
    V_RETURN( DXUTFindDXSDKMediaFileCch( str, MAX_PATH, L"main.fx" ) );
    DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
    #if defined( DEBUG ) || defined( _DEBUG )
    // Set the D3D10_SHADER_DEBUG flag to embed debug information in the shaders.
    // Setting this flag improves the shader debugging experience, but still allows 
    // the shaders to be optimized and to run exactly the way they will run in 
    // the release configuration of this program.
    dwShaderFlags |= D3D10_SHADER_DEBUG;
    #endif
    V_RETURN( D3DX10CreateEffectFromFile( str, NULL, NULL, "fx_4_0", dwShaderFlags, 0, pd3dDevice, NULL, NULL, &g_pEffect10, NULL, NULL ) );

    // Get effects variables
	g_pTechRenderScene = g_pEffect10->GetTechniqueByName("RenderScene");
	g_pTechRenderSceneClipping = g_pEffect10->GetTechniqueByName("RenderSceneClipping");
	g_pTechPartialSortFront = g_pEffect10->GetTechniqueByName("TechPartialSortFront");
	g_pTechPartialSortBack  = g_pEffect10->GetTechniqueByName("TechPartialSortBack");
	g_pTechRenderBg = g_pEffect10->GetTechniqueByName("RenderSceneBg");
	g_pTechRenderSnow = g_pEffect10->GetTechniqueByName("RenderSceneSnow");
	g_pTechRenderDepth = g_pEffect10->GetTechniqueByName("RenderSceneDepth");
	g_pTechRenderSnowMap = g_pEffect10->GetTechniqueByName("RenderSnowMap");
    g_pmWorldViewProj = g_pEffect10->GetVariableByName( "g_mWorldViewProjection" )->AsMatrix();
    g_pmWorldView = g_pEffect10->GetVariableByName( "g_mWorldView" )->AsMatrix();
    g_pmWorld = g_pEffect10->GetVariableByName( "g_mWorld" )->AsMatrix();
	g_ptxMesh = g_pEffect10->GetVariableByName( "g_MeshTexture" )->AsShaderResource();
    g_pfZMin  = g_pEffect10->GetVariableByName( "g_fZmin" )->AsScalar();
    g_pfZMid  = g_pEffect10->GetVariableByName( "g_fZmid" )->AsScalar();
	g_pfZMax  = g_pEffect10->GetVariableByName( "g_fZmax" )->AsScalar();
	g_pfBaseValue = g_pEffect10->GetVariableByName( "g_fBaseValue" )->AsScalar();
	g_pfCompValue = g_pEffect10->GetVariableByName( "g_fCompValue" )->AsScalar();

	g_pMaterialAmbientColor = g_pEffect10->GetVariableByName( "g_MaterialAmbientColor" )->AsVector();
	g_pMaterialDiffuseColor = g_pEffect10->GetVariableByName( "g_MaterialDiffuseColor" )->AsVector();
	g_pLightDir             = g_pEffect10->GetVariableByName( "g_LightDir"             )->AsVector();
	g_pLightDiffuse         = g_pEffect10->GetVariableByName( "g_LightDiffuse"         )->AsVector();

	FLOAT vMaterialAmbientColor[4] = {0.3f, 0.3f, 0.3f, 0.3f};
	g_pMaterialAmbientColor->SetFloatVector(vMaterialAmbientColor);
	FLOAT vMaterialDiffuseColor[4] = {0.7f, 0.7f, 0.7f, 0.0f};
	g_pMaterialDiffuseColor->SetFloatVector(vMaterialDiffuseColor);
	FLOAT vLightDir[4] = {0.7f, 0.7f, 0.7f, 0.0f};
	g_pLightDir->SetFloatVector(vLightDir);
	FLOAT vLightDiffuse[4] = {1.0f, 1.0f, 1.0f, 0.0f};
	g_pLightDiffuse->SetFloatVector(vLightDiffuse);

    const D3D10_INPUT_ELEMENT_DESC layout[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "NORMAL",   0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,    0, 24, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC PassDesc;
    g_pTechRenderScene->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V_RETURN( pd3dDevice->CreateInputLayout( layout, 3, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &g_pVertexLayout ) );

	g_pMesh = new MeshXFile();
	g_pMesh->OnCreateDevice(pd3dDevice, TEXT("t-pot.x"), TEXT("t-pot.bmp"), g_pTechRenderScene);
	
	// �w�i
	LoadTexture(pd3dDevice, TEXT("bg.jpg"), &g_pTexRVBg, &g_pTextureBg);
    const D3D10_INPUT_ELEMENT_DESC layoutBg[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,    0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    g_pTechRenderBg->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V_RETURN( pd3dDevice->CreateInputLayout( layoutBg, sizeof(layoutBg)/sizeof(D3D10_INPUT_ELEMENT_DESC)
		, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &g_pVertexLayoutBg ) );
	// ���_�o�b�t�@�̍쐬
	D3D10_BUFFER_DESC vbdesc =
	{
		4 * sizeof(BGVERTEX),
		D3D10_USAGE_DEFAULT,
		D3D10_BIND_VERTEX_BUFFER,
		0,
		0
	};
	BGVERTEX pVertexBg[4] = {{-1,1,0.5,0,0},{1,1,0.5,1,0},{-1,-1,0.5,0,1},{1,-1,0.5,1,1}};
	D3D10_SUBRESOURCE_DATA InitData;
	InitData.pSysMem = pVertexBg;
	InitData.SysMemPitch = 0;
	InitData.SysMemSlicePitch = 0;
	V( pd3dDevice->CreateBuffer( &vbdesc, &InitData, &g_pVBBg ) );
	// �C���f�b�N�X�o�b�t�@�̍쐬
	vbdesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
	vbdesc.ByteWidth = 6 * sizeof(DWORD);
	DWORD pIndexBg[] = {0,1,2,1,3,2};
	InitData.pSysMem = pIndexBg;
	V_RETURN( pd3dDevice->CreateBuffer( &vbdesc, &InitData, &g_pIBBg ) );

	// ��
	LoadTexture(pd3dDevice, TEXT("snow.jpg"), &g_pTexRVSnow, &g_pTextureSnow);
    const D3D10_INPUT_ELEMENT_DESC layoutSnow[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "BINORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TANGENT",  0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 24, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    g_pTechRenderSnow->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V_RETURN( pd3dDevice->CreateInputLayout( layoutSnow, sizeof(layoutSnow)/sizeof(D3D10_INPUT_ELEMENT_DESC)
		, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &g_pVertexLayoutSnow ) );
    vbdesc.ByteWidth = sizeof( SNOWVERTEX ) * SNOW_COUNT;
    vbdesc.Usage = D3D10_USAGE_DYNAMIC;
    vbdesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
    vbdesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    vbdesc.MiscFlags = 0;
	V( pd3dDevice->CreateBuffer( &vbdesc, NULL, &g_pVBSnow ) );
	SNOWVERTEX *pVertex = g_aSnowVertex;
	for(unsigned int i = 0; i < SNOW_COUNT; i++){
		pVertex->x = (SNOW_X_MAX - SNOW_X_MIN) * frand() + SNOW_X_MIN;
		pVertex->z = (SNOW_Z_MAX - SNOW_Z_MIN) * frand() + SNOW_Z_MIN;
		pVertex->y = (SNOW_Y_MAX - SNOW_Y_MIN) * (float)i / (float)SNOW_COUNT + SNOW_Y_MIN;
		pVertex->tx = 0.1f * (frand() - 0.5);
		pVertex->tz = 0.1f * (frand() - 0.5);
		pVertex->ty = -1.0f;
		// normalize
		float d = 1.0f/sqrtf(pVertex->tx*pVertex->tx+pVertex->ty*pVertex->ty+pVertex->tz*pVertex->tz);
		pVertex->tx *= d;
		pVertex->ty *= d;
		pVertex->tz *= d;
		// binormal = (0,1,0)�~tangent
		pVertex->bx = pVertex->tz;
		pVertex->by = 0.0f;
		pVertex->bz = -pVertex->tx;
		d = 1.0f/sqrtf(pVertex->bx*pVertex->bx+pVertex->by*pVertex->by+pVertex->bz*pVertex->bz);
		pVertex->bx *= d;
		pVertex->by *= d;
		pVertex->bz *= d;

		pVertex++;
	}

	// ���
    D3D10_TEXTURE2D_DESC dstex;
    dstex.Width = SNOWMAPSIZE;
    dstex.Height = SNOWMAPSIZE;
    dstex.MipLevels = 1;
    dstex.ArraySize = 1;
    dstex.SampleDesc.Count = 1;
    dstex.SampleDesc.Quality = 0;
    dstex.Format = DXGI_FORMAT_D32_FLOAT;
    dstex.Usage = D3D10_USAGE_DEFAULT;
    dstex.BindFlags = D3D10_BIND_DEPTH_STENCIL;
    dstex.CPUAccessFlags = 0;
    dstex.MiscFlags = 0;
    V_RETURN( pd3dDevice->CreateTexture2D( &dstex, NULL, &g_pSnowMapDepth ));

    D3D10_DEPTH_STENCIL_VIEW_DESC DescDS;
    DescDS.Format = DXGI_FORMAT_D32_FLOAT;
    DescDS.ViewDimension = D3D10_DSV_DIMENSION_TEXTURE2D;
    DescDS.Texture2DArray.FirstArraySlice = 0;
    DescDS.Texture2DArray.ArraySize = 1;
    DescDS.Texture2DArray.MipSlice = 0;
    V_RETURN( pd3dDevice->CreateDepthStencilView( g_pSnowMapDepth, &DescDS, &g_pSnowMapDSV ));

//    dstex.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    dstex.Format = DXGI_FORMAT_R32_FLOAT;
//    dstex.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    dstex.BindFlags = D3D10_BIND_RENDER_TARGET | D3D10_BIND_SHADER_RESOURCE;
    V_RETURN( pd3dDevice->CreateTexture2D( &dstex, NULL, &g_pSnowMap ));
	
    D3D10_RENDER_TARGET_VIEW_DESC DescRT;
    DescRT.Format = dstex.Format;
    DescRT.ViewDimension = D3D10_RTV_DIMENSION_TEXTURE2D;
    DescRT.Texture2DArray.FirstArraySlice = 0;
    DescRT.Texture2DArray.ArraySize = 1;
    DescRT.Texture2DArray.MipSlice = 0;
    V_RETURN( pd3dDevice->CreateRenderTargetView( g_pSnowMap, &DescRT, &g_pSnowMapRTV ));

    // Create the shader resource view for the cubic env map
    D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
    ZeroMemory( &SRVDesc, sizeof(SRVDesc) );
    SRVDesc.Format = dstex.Format;
    SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
    SRVDesc.TextureCube.MipLevels = 1;
    SRVDesc.TextureCube.MostDetailedMip = 0;
    V_RETURN( pd3dDevice->CreateShaderResourceView( g_pSnowMap, &SRVDesc, &g_pSnowMapSRV ));

    const D3D10_INPUT_ELEMENT_DESC layoutSnowMap[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0,  0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,    0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    g_pTechRenderBg->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V_RETURN( pd3dDevice->CreateInputLayout( layoutSnowMap, sizeof(layoutSnowMap)/sizeof(D3D10_INPUT_ELEMENT_DESC)
		, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &g_pVertexLayoutSnowMap ) );
	{
	// ���_�o�b�t�@�̍쐬
	D3D10_BUFFER_DESC vbdesc =
	{
		SNOWMAPSIZE * SNOWMAPSIZE * sizeof(SNOWMAPVERTEX),
		D3D10_USAGE_DEFAULT,
		D3D10_BIND_VERTEX_BUFFER,
		0,
		0
	};
	SNOWMAPVERTEX *pVertexSnowMap = new SNOWMAPVERTEX[SNOWMAPSIZE * SNOWMAPSIZE];
	unsigned int idx = 0;
	for(unsigned int y = 0; y < SNOWMAPSIZE; y++)
		for(unsigned int x = 0; x < SNOWMAPSIZE; x++)
		{
			pVertexSnowMap[idx].u = (float)x/(float)SNOWMAPSIZE;
			pVertexSnowMap[idx].v = (float)y/(float)SNOWMAPSIZE;
			pVertexSnowMap[idx].x = 3.0*(+(pVertexSnowMap[idx].u - 0.5f)-(pVertexSnowMap[idx].v - 0.5f))/1.41421356f;
			pVertexSnowMap[idx].z = 3.0*(-(pVertexSnowMap[idx].v - 0.5f)-(pVertexSnowMap[idx].u - 0.5f))/1.41421356f;
			pVertexSnowMap[idx].y = 1;
			idx++;
		}
	D3D10_SUBRESOURCE_DATA InitData;
	InitData.pSysMem = pVertexSnowMap;
	InitData.SysMemPitch = 0;
	InitData.SysMemSlicePitch = 0;
	V( pd3dDevice->CreateBuffer( &vbdesc, &InitData, &g_pVBSnowMap ) );
	delete[] pVertexSnowMap;
	// �C���f�b�N�X�o�b�t�@�̍쐬
	vbdesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
	vbdesc.ByteWidth = SNOWMAPINDEX_COUNT * sizeof(DWORD);
	DWORD *pIndexSnowMap = new DWORD[SNOWMAPINDEX_COUNT];
	idx = 0;
	for(unsigned int y = 0; y < SNOWMAPSIZE-1; y++)
		for(unsigned int x = 0; x < SNOWMAPSIZE-1; x++)
		{
			unsigned int id0 = y * SNOWMAPSIZE + x;
			pIndexSnowMap[idx + 0] = id0;
			pIndexSnowMap[idx + 1] = id0+1;
			pIndexSnowMap[idx + 2] = id0+SNOWMAPSIZE;
			pIndexSnowMap[idx + 3] = id0+1;
			pIndexSnowMap[idx + 4] = id0+SNOWMAPSIZE;
			pIndexSnowMap[idx + 5] = id0+SNOWMAPSIZE+1;
			idx+=6;
		}
	InitData.pSysMem = pIndexSnowMap;
	V_RETURN( pd3dDevice->CreateBuffer( &vbdesc, &InitData, &g_pIBSnowMap ) );
	delete[] pIndexSnowMap;
	}

	CreatePartitions(pd3dDevice);

	// Setup the camera's view parameters
    D3DXVECTOR3 vecEye(2.0f, 2.0f, -2.0f);
    D3DXVECTOR3 vecAt (0.0f, 0.0f, -0.0f);
    g_Camera.SetViewParams( &vecEye, &vecAt );


    return S_OK;
}

//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10CreateDevice 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10DestroyDevice( void* pUserContext )
{
	SAFE_RELEASE( g_pVBSnowMap );
    SAFE_RELEASE( g_pIBSnowMap );
    SAFE_RELEASE( g_pVertexLayoutSnowMap );
    SAFE_RELEASE( g_pSnowMapDepth );
    SAFE_RELEASE( g_pSnowMapDSV );
    SAFE_RELEASE( g_pSnowMapRTV );
    SAFE_RELEASE( g_pSnowMapSRV );
    SAFE_RELEASE( g_pSnowMap );

	SAFE_RELEASE( g_pVBSnow );
    SAFE_RELEASE( g_pVertexLayoutSnow );
    SAFE_RELEASE( g_pTexRVSnow );
    SAFE_RELEASE( g_pTextureSnow );

	SAFE_RELEASE( g_pVBBg );
    SAFE_RELEASE( g_pIBBg );
    SAFE_RELEASE( g_pVertexLayoutBg );
    SAFE_RELEASE( g_pTexRVBg );
    SAFE_RELEASE( g_pTextureBg );

	g_pMesh->OnDestroyDevice();
    SAFE_DELETE( g_pMesh );

	DestroyPartitions();

    g_DialogResourceManager.OnD3D10DestroyDevice();
    g_SettingsDlg.OnD3D10DestroyDevice();
    SAFE_RELEASE( g_pFont10 );
    SAFE_RELEASE( g_pEffect10 );
    SAFE_RELEASE( g_pVertexLayout );
    SAFE_RELEASE( g_pSprite10 );
    SAFE_DELETE( g_pTxtHelper );
}

//--------------------------------------------------------------------------------------
// Create any D3D10 resources that depend on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    V_RETURN( g_DialogResourceManager.OnD3D10ResizedSwapChain( pd3dDevice, pBackBufferSurfaceDesc ) );
    V_RETURN( g_SettingsDlg.OnD3D10ResizedSwapChain( pd3dDevice, pBackBufferSurfaceDesc ) );

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (FLOAT)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams( D3DX_PI/4, fAspectRatio, 0.1f, 1000.0f );
    g_Camera.SetWindow( pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height );
    g_Camera.SetButtonMasks( MOUSE_LEFT_BUTTON, MOUSE_WHEEL, MOUSE_MIDDLE_BUTTON );

    g_HUD.SetLocation( pBackBufferSurfaceDesc->Width-170, 0 );
    g_HUD.SetSize( 170, 170 );
    g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width-170, pBackBufferSurfaceDesc->Height-300 );
    g_SampleUI.SetSize( 170, 300 );

    return S_OK;
}

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
void RenderSort(ID3D10Device* pd3dDevice, float z_min, float z_max, unsigned int level, ID3D10Buffer *pSoSrc, MeshXFile *pMesh=NULL)
{
	float z_mid = 0.5f * (z_min + z_max);
	
	if(0==--level){
		// pSoSrc ��`��
	    ID3D10Buffer *buffersRT[1] = {NULL};
		UINT offsetRT[1] = {0};
	    pd3dDevice->SOSetTargets( 1, buffersRT, offsetRT );

	    ID3D10Buffer *buffers[1] = {pSoSrc};
	    UINT stride[1] = { sizeof(CUSTOMVERTEX) };
	    UINT offset[1] = { 0 };
	    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
	    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
	    pd3dDevice->IASetInputLayout( g_pVertexLayout );

	    D3D10_TECHNIQUE_DESC techDesc;
	    g_pTechRenderScene->GetDesc( &techDesc );

	    for( UINT p = 0; p < techDesc.Passes; ++p )
	    {
	        g_pTechRenderScene->GetPassByIndex( p )->Apply(0);
            pd3dDevice->DrawAuto();
	    }
		buffers[0] = NULL;
		pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
	}else{
		// pSoSrc �����ɁApSO0 �� ���������O�̃|���S�����ApSO1 �ɔ������牜�̃|���S������������
		for(unsigned int i = 0; i < 2; i++)
		{
			ID3D10Buffer *buffersRT[1] = {g_pSO[level-1]};
			UINT offsetRT[1] = { 0 };
			pd3dDevice->SOSetTargets( 1, buffersRT, offsetRT );

			// Set Effects Parameters
			g_pfZMid->SetFloat( z_mid );

			ID3D10EffectTechnique *pTech = (0==i) ? g_pTechPartialSortBack : g_pTechPartialSortFront; 
			D3D10_TECHNIQUE_DESC techDesc;
			pTech->GetDesc( &techDesc );

			if(NULL != pMesh)
			{
				pMesh->SetBuffers();

				for( UINT p = 0; p < techDesc.Passes; ++p )
				{
					pTech->GetPassByIndex( p )->Apply(0);
					pMesh->Draw();
				}
			}else{
				ID3D10Buffer *buffers[1] = {pSoSrc};
				UINT stride[1] = { sizeof(CUSTOMVERTEX) };
				UINT offset[1] = { 0 };
				pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
				pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

				for( UINT p = 0; p < techDesc.Passes; ++p )
				{
					pTech->GetPassByIndex( p )->Apply(0);
					pd3dDevice->DrawAuto();
				}
				ID3D10Buffer *buffersRT[1] = {NULL};
				pd3dDevice->SOSetTargets( 1, buffersRT, offsetRT );
				buffers[0] = NULL;
				pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
			}
			// �ċA�I�ɁA������`��
			if(0==i)
			{
				RenderSort(pd3dDevice, z_mid, z_max, level, buffersRT[0]);
			}else{
				RenderSort(pd3dDevice, z_min, z_mid, level, buffersRT[0]);
			}
		}
	}
}

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
void RenderSnowCover(ID3D10Device* pd3dDevice, float fElapsedTime, bool reset = false)
{
	static float rate = 0.5;
	if(reset) rate = 0.0;
	rate += fElapsedTime * 0.05f;
	if(1.0f < rate)rate = 1.0f;
	g_pfCompValue->SetFloat(rate * 0.00035);
	float alpha = rate * 100;
	alpha = (1.0 < alpha) ? 1.0 : alpha;
	g_pfBaseValue->SetFloat(alpha);
	
	// Save
    ID3D10RenderTargetView* apOldRTVs[1] = { NULL };
    ID3D10DepthStencilView* pOldDS = NULL;
    pd3dDevice->OMGetRenderTargets( 1, apOldRTVs, &pOldDS );
    D3D10_VIEWPORT OldVP;
    UINT cRT = 1;
    pd3dDevice->RSGetViewports( &cRT, &OldVP );

    // Set a new viewport
    D3D10_VIEWPORT MVP;
    MVP.Height = SNOWMAPSIZE;
    MVP.Width = SNOWMAPSIZE;
    MVP.MinDepth = 0;
    MVP.MaxDepth = 1;
    MVP.TopLeftX = 0;
    MVP.TopLeftY = 0;
    pd3dDevice->RSSetViewports( 1, &MVP );

	g_ptxMesh->SetResource(NULL);
    pd3dDevice->IASetInputLayout( NULL );
	UINT uStrides = sizeof(CUSTOMVERTEX);
    UINT uOffsets = 0;
    ID3D10Buffer *pBuffers[1] = { NULL };
    pd3dDevice->IASetVertexBuffers( 0, 1, pBuffers, &uStrides, &uOffsets );
    pd3dDevice->IASetIndexBuffer( NULL, DXGI_FORMAT_R32_UINT, 0 );

    float ClearColor[4] = { 10.0, 10.0, 0.0, 0.0 };
    pd3dDevice->ClearRenderTargetView( g_pSnowMapRTV, ClearColor);
    pd3dDevice->ClearDepthStencilView( g_pSnowMapDSV, D3D10_CLEAR_DEPTH, 1.0, 0);

    ID3D10RenderTargetView* aRTViews[ 1 ] = { g_pSnowMapRTV };
    pd3dDevice->OMSetRenderTargets( sizeof(aRTViews) / sizeof(aRTViews[0]), aRTViews, g_pSnowMapDSV );

	// Render scene	
    D3DXMATRIX  mWorld, mView, mProj;
    D3DXMATRIX  mWorldViewProjection;
	D3DXVECTOR3 vEyePt    = D3DXVECTOR3(0, 1, 0);
	D3DXVECTOR3 vLookatPt = D3DXVECTOR3(0, 0, 0);
	D3DXVECTOR3 vUp       = D3DXVECTOR3(1, 0, 1);
	D3DXMatrixLookAtLH( &mView, &vEyePt, &vLookatPt, &vUp );
	D3DXMatrixOrthoLH( &mProj, 3.0f, 3.0f, 0.0, 2.0f );// w,h,n,f
	mWorld = *g_Camera.GetWorldMatrix();
	mWorldViewProjection = mWorld * mView * mProj;
	g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );
	g_pMesh->SetBuffers();
	D3D10_TECHNIQUE_DESC techDesc;
	g_pTechRenderDepth->GetDesc( &techDesc );
	for( UINT p = 0; p < techDesc.Passes; ++p )
	{
		g_pTechRenderDepth->GetPassByIndex( p )->Apply(0);

		g_pMesh->Draw();
	}


	// Restore
	pd3dDevice->RSSetViewports( 1, &OldVP );
    pd3dDevice->OMSetRenderTargets( 1, apOldRTVs, pOldDS );
    SAFE_RELEASE( apOldRTVs[0] );
    SAFE_RELEASE( pOldDS );

	// VTF �Ő��`��
    ID3D10Buffer *buffers[1] = {g_pVBSnowMap};
    UINT stride[1] = { sizeof(SNOWMAPVERTEX) };
    UINT offset[1] = { 0 };
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
    pd3dDevice->IASetInputLayout( g_pVertexLayoutSnowMap );
    pd3dDevice->IASetIndexBuffer( g_pIBSnowMap, DXGI_FORMAT_R32_UINT, 0 );

	mWorld = *g_Camera.GetWorldMatrix();
	mProj = *g_Camera.GetProjMatrix();
	mView = *g_Camera.GetViewMatrix();
	mWorldViewProjection =  mView * mProj;
//	mWorldViewProjection = mWorld * mView * mProj;
	g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );

	g_ptxMesh->SetResource(g_pSnowMapSRV);

    g_pTechRenderSnowMap->GetPassByIndex( 0 )->Apply(0);
    pd3dDevice->DrawIndexed( SNOWMAPINDEX_COUNT, 0, 0 );

	g_ptxMesh->SetResource(NULL);
}


//--------------------------------------------------------------------------------------
// Render the scene using the D3D10 device
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
    D3DXMATRIX  mWorldViewProjection;
    D3DXMATRIX  mWorldView;
    D3DXMATRIX  mWorld;
    D3DXMATRIX  mView;
    D3DXMATRIX  mProj;

#if 0
	float ClearColor[4] = { 1.f, 1.f, 1.f, 0.0f };
//    float ClearColor[4] = { 0.176f, 0.196f, 0.667f, 0.0f };
    ID3D10RenderTargetView* pRTV = DXUTGetD3D10RenderTargetView();
    pd3dDevice->ClearRenderTargetView( pRTV, ClearColor );
#else
	// �w�i�`��
    ID3D10Buffer *buffers[1] = {g_pVBBg};
    UINT stride[1] = { sizeof(BGVERTEX) };
    UINT offset[1] = { 0 };
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
    pd3dDevice->IASetInputLayout( g_pVertexLayoutBg );
    pd3dDevice->IASetIndexBuffer( g_pIBBg, DXGI_FORMAT_R32_UINT, 0 );
	g_ptxMesh->SetResource(g_pTexRVBg);

//g_ptxMesh->SetResource(g_pSnowMapSRV);

	D3D10_TECHNIQUE_DESC techDesc;
    g_pTechRenderBg->GetDesc( &techDesc );

    for( UINT p = 0; p < techDesc.Passes; ++p )
    {
        g_pTechRenderBg->GetPassByIndex( p )->Apply(0);
        pd3dDevice->DrawIndexed( 6, 0, 0 );
    }
#endif

    // Clear the depth stencil
    ID3D10DepthStencilView* pDSV = DXUTGetD3D10DepthStencilView();
    pd3dDevice->ClearDepthStencilView( pDSV, D3D10_CLEAR_DEPTH, 1.0, 0 );

    // If the settings dialog is being shown, then render it instead of rendering the app's scene
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.OnRender( fElapsedTime );
        return;
    }

	switch(g_dwMethodIdx)
	{
	case METHOD_NONE:
		{
		// Get the projection & view matrix from the camera class
		mWorld = *g_Camera.GetWorldMatrix();
		mProj = *g_Camera.GetProjMatrix();
		mView = *g_Camera.GetViewMatrix();
		mWorldViewProjection = mWorld * mView * mProj;

		// Update the effect's variables.  Instead of using strings, it would 
		// be more efficient to cache a handle to the parameter by calling 
		// ID3DXEffect::GetParameterByName
		g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );
		g_pmWorld->SetMatrix( (float*)&mWorld );

		// Set vertex Layout
		pd3dDevice->IASetInputLayout( g_pVertexLayout );

		g_pMesh->SetBuffers();
		g_ptxMesh->SetResource(g_pMesh->GetTexture());

		D3D10_TECHNIQUE_DESC techDesc;
		g_pTechRenderScene->GetDesc( &techDesc );
		for( UINT p = 0; p < techDesc.Passes; ++p )
		{
			g_pTechRenderScene->GetPassByIndex( p )->Apply(0);

			g_pMesh->Draw();
		}
		}
		break;
	case METHOD_SLICE:
		{
		// Get the projection & view matrix from the camera class
		mWorld = *g_Camera.GetWorldMatrix();
		mProj = *g_Camera.GetProjMatrix();
		mView = *g_Camera.GetViewMatrix();
		mWorldView = mWorld * mView;
		mWorldViewProjection = mWorldView * mProj;

		// Update the effect's variables.  Instead of using strings, it would 
		// be more efficient to cache a handle to the parameter by calling 
		// ID3DXEffect::GetParameterByName
		g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );
		g_pmWorld->SetMatrix( (float*)&mWorld );

		// Set vertex Layout
		pd3dDevice->IASetInputLayout( g_pVertexLayout );

		g_pMesh->SetBuffers();
		g_ptxMesh->SetResource(g_pMesh->GetTexture());

		D3D10_TECHNIQUE_DESC techDesc;
		g_pTechRenderSceneClipping->GetDesc( &techDesc );

		const D3DXVECTOR3 *pCenter = g_pMesh->GetBoundingSphereCenter();
		FLOAT radius = g_pMesh->GetBoundingSphereRadius();

		for(unsigned int i = g_dwNumParts; 0 < i; i--)
		{
			D3DXVECTOR3 v_near;
			D3DXVECTOR3 v_far;

			D3DXVec3TransformCoord(&v_near, pCenter, &mWorldView);
			v_far = v_near;
			v_near.z += radius * (2.0f * (FLOAT)(i-1)/(FLOAT)g_dwNumParts-1.0f);
			v_far.z  += radius * (2.0f * (FLOAT)(i  )/(FLOAT)g_dwNumParts-1.0f);

			g_pfZMin->SetFloat( v_near.z );
			g_pfZMax->SetFloat( v_far.z );

			for( UINT p = 0; p < techDesc.Passes; ++p )
			{
				g_pTechRenderSceneClipping->GetPassByIndex( p )->Apply(0);

				g_pMesh->Draw();
			}
		}
		}
		break;
	case METHOD_PARTIAL:
		{
		// Get the projection & view matrix from the camera class
		mWorld = *g_Camera.GetWorldMatrix();
		mProj = *g_Camera.GetProjMatrix();
		mView = *g_Camera.GetViewMatrix();
		mWorldView = mWorld * mView;
		mWorldViewProjection = mWorldView * mProj;

		g_ptxMesh->SetResource(g_pMesh->GetTexture());
		g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );
		g_pmWorldView->SetMatrix( (float*)&mWorldView );
		g_pmWorld->SetMatrix( (float*)&mWorld );


		const D3DXVECTOR3 *pCenter = g_pMesh->GetBoundingSphereCenter();
		D3DXVECTOR3 vCenter;
		D3DXVec3TransformCoord(&vCenter, pCenter, &mWorldView);
		FLOAT radius = g_pMesh->GetBoundingSphereRadius();

		RenderSort(pd3dDevice
				 , vCenter.z-radius
				 , vCenter.z+radius
				 , g_dwNumPartsLog+1, NULL, g_pMesh);
		}
		break;
	default:
		assert(0);
		break;
	}

	// ��
	SNOWVERTEX *pVertex = g_aSnowVertex;
	float velo = SNOW_VELOCITY * fElapsedTime;
	for(unsigned int i = 0; i < SNOW_COUNT; i++){
		pVertex->x += pVertex->tx * velo;
		pVertex->x += (pVertex->x < SNOW_X_MIN) ? (SNOW_X_MAX - SNOW_X_MIN) : 0;
		pVertex->x -= (SNOW_X_MAX < pVertex->x) ? (SNOW_X_MAX - SNOW_X_MIN) : 0;
		pVertex->y += pVertex->ty * velo;
		pVertex->y += (pVertex->y < SNOW_Y_MIN) ? (SNOW_Y_MAX - SNOW_Y_MIN) : 0;
		pVertex->y -= (SNOW_Y_MAX < pVertex->y) ? (SNOW_Y_MAX - SNOW_Y_MIN) : 0;
		pVertex->z += pVertex->tz * velo;
		pVertex->z += (pVertex->z < SNOW_Z_MIN) ? (SNOW_Z_MAX - SNOW_Z_MIN) : 0;
		pVertex->z -= (SNOW_Z_MAX < pVertex->z) ? (SNOW_Z_MAX - SNOW_Z_MIN) : 0;
		pVertex++;
	}
    SNOWVERTEX *pVB;
    if( SUCCEEDED( g_pVBSnow->Map( D3D10_MAP_WRITE_DISCARD, 0, (LPVOID*)&pVB ) ) )
    {
        CopyMemory( pVB, g_aSnowVertex, sizeof(g_aSnowVertex) );
        g_pVBSnow->Unmap();
    }
    buffers[0] = g_pVBSnow;
    stride[0] = sizeof(SNOWVERTEX);
    offset[0] = 0;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, stride, offset );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );
    pd3dDevice->IASetInputLayout( g_pVertexLayoutSnow );
    pd3dDevice->IASetIndexBuffer( g_pIBBg, DXGI_FORMAT_R32_UINT, 0 );
	g_ptxMesh->SetResource(g_pTexRVSnow);
	mProj = *g_Camera.GetProjMatrix();
	mView = *g_Camera.GetViewMatrix();
	mWorldViewProjection = mProj;
	g_pmWorldViewProj->SetMatrix( (float*)&mWorldViewProjection );
	g_pTechRenderSnow->GetPassByIndex(0)->Apply(0);
    pd3dDevice->Draw( SNOW_COUNT, 0 );

	bool bReset = false;
	D3DXVECTOR3 vecEye(2.0f, 2.0f, -2.0f);
	static D3DXVECTOR3 vecEyeLast(2.0f, 2.0f, -2.0f);
	mWorldView = mWorld * mView;
	static bool init = false;
	if(!init){init = true;
		mWorldView = mWorld * mView;
		D3DXVec3TransformCoord(&vecEyeLast, &vecEyeLast, &mWorldView);
	}
	D3DXVec3TransformCoord(&vecEye, &vecEye, &mWorldView);
	if(0.001 < (vecEyeLast.x - vecEye.x) * (vecEyeLast.x - vecEye.x)) bReset = true;// �������U��ƃ��Z�b�g
	vecEyeLast = vecEye;
	RenderSnowCover(pd3dDevice, fElapsedTime, bReset);


	DXUT_BeginPerfEvent( DXUT_PERFEVENTCOLOR, L"HUD / Stats" );
    RenderText();
    g_HUD.OnRender( fElapsedTime ); 
    g_SampleUI.OnRender( fElapsedTime );
    DXUT_EndPerfEvent();
}


//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10ResizedSwapChain 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext )
{
    g_DialogResourceManager.OnD3D10ReleasingSwapChain();
}


//--------------------------------------------------------------------------------------
// Called right before creating a D3D9 or D3D10 device, allowing the app to modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext )
{
    // For the first device created if its a REF device, optionally display a warning dialog box
    static bool s_bFirstTime = true;
    if( s_bFirstTime )
    {
        s_bFirstTime = false;
        if( (DXUT_D3D10_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d10.DriverType == D3D10_DRIVER_TYPE_REFERENCE) )
            DXUTDisplaySwitchingToREFWarning( pDeviceSettings->ver );
    }

	pDeviceSettings->d3d10.SyncInterval = 0;

    return true;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene.  This is called regardless of which D3D API is used
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext )
{
    // Update the camera's position based on user input 
    g_Camera.FrameMove( fElapsedTime );
}


//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
    // Pass messages to dialog resource manager calls so GUI state is updated correctly
    *pbNoFurtherProcessing = g_DialogResourceManager.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass messages to settings dialog if its active
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
        return 0;
    }

    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;
    *pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
    if( *pbNoFurtherProcessing )
        return 0;

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// Handle key presses
//--------------------------------------------------------------------------------------
void CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{
}


//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
    switch( nControlID )
    {
        case IDC_TOGGLEFULLSCREEN: DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:        DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:     g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive() ); break;
        case IDC_METHOD:
        {
            g_dwMethodIdx = (unsigned int)((CDXUTComboBox*)pControl)->GetSelectedData();
//            pd3dDevice->SetRenderState( D3DRS_FILLMODE, g_bWireframe ? D3DFILL_WIREFRAME : D3DFILL_SOLID );
            break;
        }
        case IDC_PARTITION:
			DestroyPartitions();
            g_dwNumPartsLog = ((CDXUTSlider*)pControl)->GetValue();
			g_dwNumParts = (1<<g_dwNumPartsLog);
            WCHAR wszBuf[256];
            StringCchPrintf( wszBuf, 256, L"Number of partitions: %u", g_dwNumParts );
            g_SampleUI.GetStatic( IDC_PARTITIONLABEL )->SetText( wszBuf );
			CreatePartitions(g_pd3dDevice);
            break;
	}
}


