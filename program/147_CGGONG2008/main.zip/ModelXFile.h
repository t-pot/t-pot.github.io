//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
#ifndef H_MESH_XFILE_
#define H_MESH_XFILE_

#include <windows.h>
//#include "DXUT.h"
//#include "DX10.h"
//#include "DXUT.h"

typedef struct {
  float x,y,z;
  float nx,ny,nz;
  float u,v;
} CUSTOMVERTEX;

// ���̊֐��ł��g����悤�Ɍ�
HRESULT LoadTexture(ID3D10Device* pd3dDevice, LPCTSTR strTexFile, ID3D10ShaderResourceView** ppTexRV, ID3D10Texture2D** ppTexture);

class MeshXFile
{
public:
	 MeshXFile();
	~MeshXFile();

    HRESULT OnCreateDevice( ID3D10Device* pd3dDevice, LPCTSTR filename, LPCTSTR texfile, ID3D10EffectTechnique *pTech );
    void    OnDestroyDevice();
    // �`��p�̊֐�
    ID3D10ShaderResourceView *GetTexture(){return m_pTexRV;}
    void    SetBuffers();
	void    Draw(){m_pd3dDevice->DrawIndexed( m_nIndex, 0, 0 );}
	DWORD   GetVertexSize();

	// Bounding Sphere
	const D3DXVECTOR3 *GetBoundingSphereCenter()const{return &m_vBsCenter;}
	FLOAT GetBoundingSphereRadius()const{return m_fBsRadius;}

private:

    DWORD                                       m_nVertex;
	DWORD                                       m_nIndex;
	ID3D10Buffer*                               m_pVB;
	ID3D10Buffer*                               m_pIB;
    ID3D10Texture2D*							m_pTex;
    ID3D10ShaderResourceView*					m_pTexRV;

	// BOunding Sphere
	FLOAT                                       m_fBsRadius;
	D3DXVECTOR3                                 m_vBsCenter;

	static DWORD                                g_nRef;
    static ID3D10InputLayout*				    m_pVertexLayout;
    static ID3D10Device*					    m_pd3dDevice;
	static HRESULT SetUp( ID3D10Device* pd3dDevice, ID3D10EffectTechnique *pTech );
	static void Release();
    HRESULT LoadXfile( LPCTSTR filename );
};

#endif // !H_MESH_XFILE_

