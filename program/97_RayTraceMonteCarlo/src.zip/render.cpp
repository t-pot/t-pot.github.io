#include "stdafx.h"
#include <mmsystem.h>
#include "math.h"
#include "prim.h"
#include "render.h"

#define frand() ((float)rand()/(float)RAND_MAX)

namespace Render {

D3DXVECTOR3 BG_COLOR = D3DXVECTOR3(0.25f, 0.4f, 0.5f);

class CCamera
{
private:
	D3DXMATRIX  m_mView;
	D3DXMATRIX  m_mProj;
	D3DXMATRIX  m_mVP;
	D3DXMATRIX  m_mVP_Inv;
	D3DXMATRIX  m_mView_Inv;

	D3DXVECTOR3 m_vFrom;
	D3DXVECTOR3 m_vLookat;
	D3DXVECTOR3 m_vUp;

	float	m_fFovy;
	float	m_fAspect;
	float   m_fNear;
	float   m_fFar;

public:

	void Update();
	void SetFrom  (const D3DXVECTOR3 *p){m_vFrom  =*p;}
	void SetLookAt(const D3DXVECTOR3 *p){m_vLookat=*p;}
	void SetUp    (const D3DXVECTOR3 *p){m_vUp    =*p;}
	void SetFovY  (float val){m_fFovy   = val;}
	void SetAspect(float val){m_fAspect = val;}
	void SetNear  (float val){m_fNear   = val;}
	void SetFar   (float val){m_fFar    = val;}

	inline const D3DXMATRIX *GetViewInverse() const {return &m_mView_Inv;}
	inline const D3DXMATRIX *GetViewProjInverse() const {return &m_mVP_Inv;}
	inline void GetFrom (D3DXVECTOR3 *dest) const {*dest = m_vFrom;}
};

// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
char  s_data [4*RENDER_WIDTH*RENDER_HEIGHT];// ���z�t���[���o�b�t�@
float s_total[4*RENDER_WIDTH*RENDER_HEIGHT];// �ݐσt���[���o�b�t�@

CCamera camera;

CMesh *pRoom       = NULL;
CMesh *pBlockSmall = NULL;
CMesh *pBlockTall  = NULL;
CMesh *pShpereS    = NULL;
CMesh *pShpereT    = NULL;

static int s_x = 0;			// �����_�����O�s�N�Z���̂����W
static int s_y = 0;			// �����_�����O�s�N�Z���̂����W
static int s_state = 0;		// �����_�����O�֐��̏��
static float render_cnt = 0;// �`���
enum{
	STATE_IDLE=0,			// �����҂�
	STATE_RENDER_BEGIN,		// ������
	STATE_RENDER,			// �`��
	STATE_RENDER_END,		// ��Еt��
};

OBJ_DATA sphere_data[] = {
{// �������̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.10f, 0.100f, 0.10f},
		0.2f, 0.8f, 0.0f, 0.0f,
	},{{0,0,0},{0,0,0},{0,0,0},},{
		{125.5, 0+100,169},
//		{185.5, 165+100,169},
		100.0f,
	}
},{// �傫���̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.05f, 0.050f, 0.05f},
		0.80f, 0.00f, 0.20f, 0.0f,
	},{{0,0,0},{0,0,0},{0,0,0},},{
		{368.5, 330+100,351},
		100.0f,
	}
}};
OBJ_DATA room_data[14] = {
{
// ���C�g�P
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f*1.00f, 100.0f*0.90f, 100.0f*0.50f},
		0.0f, 0.0f, 0.0f, 1.0f,
	},{
		{213.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 227.0},
	}
},{// ���C�g�Q
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f*1.00f, 100.0f*0.90f, 100.0f*0.50f},
		0.0f, 0.0f, 0.0f, 1.0f,
	},{
		{343.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 332.0},
	}
},{	// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.15f, 0.15f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{552.8f,   0.0f,   0.0f},
		{556.0f, 548.8f,   0.0f},
		{549.6f,   0.0f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.15f, 0.15f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f,   0.0f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �E�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.15f, 0.15f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{0.0f,   0.0f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f,   0.0f},
	}

},{// �E�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.15f, 0.15f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{0.0f, 548.8f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f, 559.2f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f,   0.0f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{  0.0f, 548.8f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �V��P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f,   0.0f},
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// �V��Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 0.0f,   0.0f},
		{552.8f, 0.0f,   0.0f},
		{  0.0f, 0.0f, 559.2f},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 0.0f, 559.2f},
		{552.8f, 0.0f,   0.0f},
		{549.6f, 0.0f, 559.2f},
	}
},{// ��O�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f,   0.0f, 0.0f},
		{  0.0f, 548.8f, 0.0f},
		{549.6f,   0.0f, 0.0f},
	}

},{// ��O�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 0.0f},
		{556.0f, 548.8f, 0.0f},
		{549.6f,   0.0f, 0.0f},
	}


}};


OBJ_DATA Short_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0f, 165.0f, 225.0f},
		{130.0f, 165.0f,  65.0f},
		{240.0f, 165.0f, 272.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0, 165.0, 114.0},
		{240.0, 165.0, 272.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0, 165.0, 114.0},
		{290.0,   0.0, 114.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0, 165.0, 272.0},
		{290.0,   0.0, 114.0},
		{240.0,   0.0, 272.0},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0,   0.0, 114.0},
		{290.0, 165.0, 114.0},
		{130.0,   0.0,  65.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{130.0,   0.0,  65.0},
		{290.0, 165.0, 114.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0, 165.0,  65.0},
		{ 82.0, 165.0, 225.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0,   0.0,  65.0},
		{130.0, 165.0,  65.0},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0, 165.0, 225.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0,   0.0, 225.0},
		{ 82.0, 165.0, 225.0},
	}
}};

OBJ_DATA Tall_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{314.0f, 330.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f, 330.0f, 406.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f,   0.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{423.0f, 330.0f, 247.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{472.0f, 330.0f, 406.0f},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{314.0f, 330.0f, 456.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f, 330.0f, 456.0f},
		{472.0f, 330.0f, 406.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f,   0.0f, 296.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{265.0f,   0.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{265.0f, 330.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{423.0f, 330.0f, 247.0f},
	}
}};

// ---------------------------------------------------------------------------
// �֐��錾
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y);


// ---------------------------------------------------------------------------
// �J�����N���X
// ---------------------------------------------------------------------------
void CCamera::Update()
{
    D3DXMatrixLookAtLH( &m_mView, &m_vFrom, &m_vLookat, &m_vUp );
    D3DXMatrixPerspectiveFovLH( &m_mProj, m_fFovy, m_fAspect, m_fNear, m_fFar );
	m_mVP = m_mView * m_mProj;

	D3DXMatrixInverse( &m_mView_Inv, NULL, &m_mView);
	D3DXMatrixInverse( &m_mVP_Inv, NULL, &m_mVP);
}


// ---------------------------------------------------------------------------
char *GetDataPointer()
{
	return s_data;
}
// ---------------------------------------------------------------------------
int GetRenderCount()
{
	return (int)(render_cnt+0.5f);
}
// ---------------------------------------------------------------------------
void Init()
{
	int i, j;

	camera.SetFrom  (&D3DXVECTOR3(278,273,-800));
	camera.SetLookAt(&D3DXVECTOR3(278,273,0));
	camera.SetUp    (&D3DXVECTOR3(0,1,0));
	camera.SetFovY  (D3DX_PI/4);
	camera.SetAspect(1.0f);
	camera.SetNear  (0.01f);
	camera.SetFar   (100.0f);
	camera.Update();

	pRoom = new CMesh();
	pRoom->Init( room_data, 14 );
	
	pBlockSmall = new CMesh();
	pBlockSmall->Init( Short_block, 10);

	pBlockTall = new CMesh();
	pBlockTall->Init( Tall_block, 10);
	
	pShpereS = new CMesh();
	pShpereS->Init( sphere_data, 1);
	
	pShpereT = new CMesh();
	pShpereT->Init( sphere_data+1,1);

	render_cnt = 0; // �����_�����O��
	// �t���[���o�b�t�@�̏�����
	for(j=0; j<RENDER_HEIGHT; j++){
	for(i=0; i<RENDER_WIDTH ; i++){
		s_data [4*(j*RENDER_WIDTH+i)+0]=(char)255;// R
		s_data [4*(j*RENDER_WIDTH+i)+1]=(char)(i*256/RENDER_WIDTH );// G
		s_data [4*(j*RENDER_WIDTH+i)+2]=(char)(j*256/RENDER_HEIGHT);// B
		s_total[4*(j*RENDER_WIDTH+i)+0]=0;// R
		s_total[4*(j*RENDER_WIDTH+i)+1]=0;// G
		s_total[4*(j*RENDER_WIDTH+i)+2]=0;// B
	}
	}
}
// ---------------------------------------------------------------------------
void Delete()
{
	if(pShpereT){delete pShpereT;pShpereT=NULL;}
	if(pShpereS){delete pShpereS;pShpereS=NULL;}
	if(pBlockTall){delete pBlockTall;pBlockTall=NULL;}
	if(pBlockSmall){delete pBlockSmall;pBlockSmall=NULL;}
	if(pRoom){delete pRoom; pRoom=NULL;}
}
// ---------------------------------------------------------------------------
void Begin()
{
	s_state = STATE_RENDER_BEGIN;
}
// ---------------------------------------------------------------------------
int Render()
{
	if(STATE_IDLE==s_state) return 0;

	int i,j,no;
	D3DXVECTOR3 col;
	int ret = -1;

	timeBeginPeriod( 500 );// �^�C�}�[���x�̐ݒ�

	for(unsigned long t = timeGetTime()
		; timeGetTime()-t < 1000		// 1�b��������
		&& STATE_IDLE!=s_state;){		// �I��������

		switch(s_state){
		case STATE_IDLE:		// �ҋ@
			break;
		case STATE_RENDER_BEGIN:// ������
			s_x = 0;
			s_y = 0;
			render_cnt+=1.0f;
			s_state = STATE_RENDER;
			break;
		case STATE_RENDER:		// ��ʂ̕`��
			GetColor(&col, ((float)s_x+frand())/(float)RENDER_WIDTH
						 , ((float)s_y+frand())/(float)RENDER_HEIGHT);
			s_total[4*(s_y*RENDER_WIDTH+s_x)+0]+=col.x;// R
			s_total[4*(s_y*RENDER_WIDTH+s_x)+1]+=col.y;// G
			s_total[4*(s_y*RENDER_WIDTH+s_x)+2]+=col.z;// B

			// ���̃s�N�Z���Ɉړ�
			if(RENDER_WIDTH<=++s_x){
				// �s��ς���
				s_x = 0;
				if(RENDER_HEIGHT<=++s_y){
					s_state = STATE_RENDER_END;
					break;
				}
			}
			break;
		case STATE_RENDER_END:	// �`��̏I��
			// ��ʂ̔��f
			no = 0;
			for(j=0; j<RENDER_HEIGHT; j++){
			for(i=0; i<RENDER_WIDTH ; i++){
				s_data [no+0]=(char)(255.9*min(1,s_total[no+0]/render_cnt));// R
				s_data [no+1]=(char)(255.9*min(1,s_total[no+1]/render_cnt));// G
				s_data [no+2]=(char)(255.9*min(1,s_total[no+2]/render_cnt));// B
				no += 4;
			}
			}
			s_state = STATE_RENDER_BEGIN;// �������[�v
			break;
		}
	}

	timeEndPeriod( 500 );// �^�C�}�[���x��߂�

	return ret;
}

// ---------------------------------------------------------------------------
bool GetColor(D3DXVECTOR3 *dest, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v, int depth)
{
	D3DXVECTOR3 diffuse_color=D3DXVECTOR3(0,0,0);

	// -----------------------------------------------------------------------
	// �������F�������܁A���˂������Ȃ��ŉ��X�ƒ��˕Ԃ����Ƃ��́A�����͂��Ȃ����F
	// -----------------------------------------------------------------------
	if(0==depth) *dest = D3DXVECTOR3(0,0,0);

	// -----------------------------------------------------------------------
	// �ċA���������ꍇ�͌����͂��Ă��Ȃ����̂ƍl����
	// -----------------------------------------------------------------------
	const int DEPTH_MAX = 3;
	if(DEPTH_MAX <= depth) { *dest=D3DXVECTOR3(0,0,0); return FALSE;}

	// -----------------------------------------------------------------------
	// ���������_�����߂�
	// -----------------------------------------------------------------------
	float t = CPrimitive::INFINTY_DIST;
	CPrimitive *pObj = NULL;
	D3DXVECTOR4 p, n;// ��_�̈ʒu�Ɩ@��

	t = pShpereS   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pShpereT   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pRoom      ->IsAcross(t, &n, &p, &pObj, x, v);
//	t = pBlockSmall->IsAcross(t, &n, &p, &pObj, x, v);
	t = pBlockTall ->IsAcross(t, &n, &p, &pObj, x, v);

	if( NULL == pObj ){
		// �����̓I�u�W�F�N�g����O�ꂽ�I
		*dest = BG_COLOR;
		return TRUE;
	}

	// -----------------------------------------------------------------------
	// ���˕��������V�A�����[���b�g�Ō��߂�
	// -----------------------------------------------------------------------
	float cd = pObj->m_material.diffuse;	// �g�U��
	float cr = pObj->m_material.reflection;	// ���˗�
	float cn = pObj->m_material.refraction;	// ���ܗ�
	float ce = pObj->m_material.emmisive;	// ���˗�
	float total = cd+cr+cn+ce;
	float prob = total * frand();

	int type = 0;// �g�U
	if(prob < cr      ) type = 1; else// ����
	if(prob < cr+cn   ) type = 2; else// ����
	if(prob < cr+cn+ce) type = 3;     // ����

	// -----------------------------------------------------------------------
	// ��_���A�e�ɉB��Ă��邩�ǂ������ׂāA�g�U�����Z�o����
	// -----------------------------------------------------------------------
	if(0==type){
		if(++depth<DEPTH_MAX){
			// ����ɉ�������
			D3DXVECTOR4 dir, pos;
			
			// �����I�Ƀ��C���΂�
			float theta =      D3DX_PI * frand();
			float phi   = 2.0f*D3DX_PI * frand();
			dir.x = sinf(theta) * cosf(phi);
			dir.y = sinf(theta) * sinf(phi);
			dir.z = cosf(theta);
			float dn = D3DXVec3Dot((D3DXVECTOR3 *)&dir, (D3DXVECTOR3 *)&n);
			if(dn<0){
				// �@���Ɣ��Ό����ɔ�Ԃ���Ȃ�A�����𔽑΂ɂ���
				dn = -dn;
				dir.x *= -1;
				dir.y *= -1;
				dir.z *= -1;
			}

			pos = p + 0.01f*(dir);
			GetColor(&diffuse_color, &pos, &dir, depth);
			// �v���~�e�B�u�̐F��g�U���̗]������K�p
			diffuse_color.x *= pObj->m_material.COLOR_DIF[0] * dn;
			diffuse_color.y *= pObj->m_material.COLOR_DIF[1] * dn;
			diffuse_color.z *= pObj->m_material.COLOR_DIF[2] * dn;
		}
	}

	// -----------------------------------------------------------------------
	// �ċA�I�Ɍ������΂��āA��荂���̔��˂��l���ɓ����
	// -----------------------------------------------------------------------
	// ����
	D3DXVECTOR3 reflect_color=D3DXVECTOR3(0,0,0);
	if(1==type){
		// ���˃x�N�g��
		D3DXVECTOR4 r = *v - 2.0f*D3DXVec3Dot((D3DXVECTOR3 *)&n, (D3DXVECTOR3 *)v) * n;
		D3DXVECTOR4 pos = p + 0.01f*n;// ������ƕ�����
		if(!GetColor( &reflect_color, &pos, &r, depth)){
			cr = 0;// ���ǁA�����͂��Ȃ�����
		}
	}

	// -----------------------------------------------------------------------
	// ����
	// -----------------------------------------------------------------------
	D3DXVECTOR3 refract_color=D3DXVECTOR3(0,0,0);
	if(2==type){
		// ���܃x�N�g��
		D3DXVECTOR4 t, pos;
		float VN = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&n);
		float eta = 1.5f;
		if(VN<0){
			// ����
			float D = 1-(1+VN)*(1+VN)/(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = (-VN/eta-sqrtf(D))*n+(1/eta)*(*v);
			pos = p - 0.01f*n;// ������ƕ�����
		}else{
			// �o�čs��
			float D = 1-(1-VN)*(1-VN)*(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = -(VN*eta-sqrtf(D))*n+eta*(*v);
			pos = p + 0.01f*n;// ������ƕ�����
		}
		D3DXVec3Normalize( (D3DXVECTOR3 *)&t, (D3DXVECTOR3 *)&t );
		if(!GetColor( &refract_color, &pos, &t, depth)){
			cn = 0;// ���ǁA�����͂��Ȃ�����
		}
	}
no_refract:

	// -----------------------------------------------------------------------
	// ����
	// -----------------------------------------------------------------------
	D3DXVECTOR3 emmisive_color = *(D3DXVECTOR3*)&pObj->m_material.COLOR_DIF;

	// -----------------------------------------------------------------------
	// �F���o�͂���
	// -----------------------------------------------------------------------
	switch(type){
	case 0:// �g�U
		*dest = (cd+cr+cn) * diffuse_color;
		break;
	case 1:// ����
		*dest = (cd+cr+cn) * reflect_color;		
		break;
	case 2:// ����
		*dest = (cd+cr+cn) * refract_color;
		break;
	case 3:// ����
		*dest = ce * emmisive_color;
		break;
	}

	return TRUE;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y)
{
	D3DXVECTOR4 ray_start_proj = D3DXVECTOR4(-2*x+1, -2*y+1, 0, 1);// �O���N���b�v��
	D3DXVECTOR4 ray_eye        = D3DXVECTOR4(0, 0, 0, 1);// �r���[��Ԃł̃J�����̈ʒu
	D3DXVECTOR4 ray_start;
	D3DXVECTOR4 ray_to;
	D3DXVECTOR4 ray_dir;
	D3DXMATRIX mInv;
	
	// ���_���ˉe��Ԃ��烏�[���h���W�ɕϊ�����
	D3DXVec4Transform( &ray_start, &ray_eye,        camera.GetViewInverse() );
	D3DXVec4Transform( &ray_to,    &ray_start_proj, camera.GetViewProjInverse() );
	D3DXVec4Scale( &ray_to,    &ray_to,    1.0f/ray_to.w   );// w=1 �̎ˉe��Ԃɗ��Ƃ�
	// �����̌v�Z
	ray_dir = ray_to - ray_start;
	D3DXVec4Normalize(&ray_dir, &ray_dir);
	
	GetColor(dest, &ray_start, &ray_dir, 0);

	return dest;
}

};// namespace Render
