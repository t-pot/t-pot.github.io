//--------------------------------------------------------------------------------------
// File: CRand.h
//
// Mersenne Twister�[�����������@�ɂ�闐��
//
// Copyright (c) Takashi Imagire. All rights reserved.
// Mersenne Twister : Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura, All rights reserved.
//--------------------------------------------------------------------------------------
#ifndef __CRAND_H_
#define __CRAND_H_

#include "MyTypes.h"

#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */


class CRand
{
private:
	void Init( u32 seed );

	u32 mt[N];   /* the array for the state vector  */
	s32 mti; 

public:
	// �R���X�g���N�^
	CRand( u32 seed = 0 );
	
	// �[����������������
	u32    GetU32(void);
	double GetF32(void);
};


// ---------------------------------------------------------------------------
inline CRand::CRand( u32 seed )
{
	mti = N+1; /* mti==N+1 means mt[N] is not initialized */
	Init( seed );
}

// ---------------------------------------------------------------------------
inline void CRand::Init( u32 s )
{
    mt[0]= s & 0xffffffff;
    for (mti=1; mti<N; mti++) {
        mt[mti] = 
	    (1812433253 * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffff;
        /* for >32 bit machines */
    }
}

// ---------------------------------------------------------------------------
inline u32 CRand::GetU32(void)
{
    u32 y;
    static u32 mag01[2]={0x0UL, MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */

    if (mti >= N) { /* generate N words at one time */
        int kk;

        if (mti == N+1)   /* if init_genrand() has not been called, */
            Init(5489UL); /* a default initial seed is used */

        for (kk=0;kk<N-M;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        for (;kk<N-1;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }
  
    y = mt[mti++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y <<  7) & 0x9d2c5680;
    y ^= (y << 15) & 0xefc60000;
    y ^= (y >> 18);

    return y;
}

// ---------------------------------------------------------------------------
// ��l������[0,1) (32�r�b�g���x)
double CRand::GetF32(void)
{
    return GetU32()*(1.0/4294967296.0); 
    /* 2^32 �Ŋ��� */
}


#endif // !__RAND_H_
