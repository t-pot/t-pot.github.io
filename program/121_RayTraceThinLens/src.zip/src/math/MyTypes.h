//--------------------------------------------------------------------------------------
// File: types.h
//
// �^�̈ˑ������Ȃ���
//
// Copyright (c) Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#pragma once

#include <tchar.h>

#ifndef	TRUE
#define TRUE		(1)
#endif	TRUE

#ifndef	FALSE
#define	FALSE		(0)
#endif	FALSE

typedef _TCHAR               chr;
typedef signed   char        s8;
typedef BYTE                 u8;
typedef SHORT                s16;
typedef WORD                 u16;
typedef INT32                s32;
typedef UINT32               u32;

typedef float                f32;
typedef double               f64;
