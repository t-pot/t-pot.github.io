#include "stdafx.h"
#include <process.h>
#include "math.h"
#include "prim.h"
#include "render.h"
#include "math\CRand.h"
#include "CBitmap.h"


namespace Render {

D3DXVECTOR3 BG_COLOR = D3DXVECTOR3(0.25f, 0.4f, 0.5f);

typedef struct
{
	s32 left;
	s32 right;
	s32 top;
	s32 bottom;
} rect;


class CCamera
{
private:
	D3DXVECTOR3 m_vFrom;
	D3DXVECTOR3 m_vLookat;
	D3DXVECTOR3 m_vUp;

	float   m_fFilmSize[2];  // �t�B�����̎���0.036*0.024[m*m]0.025*0.025(Cornell Box)
	float   m_fFocalLength;  // �œ_���� 0.035(Cornell Box )
	float   m_fFNumber;      // F�l
	float   m_fFocusDistance;// �s���g�������ʒu�܂ł̋���

	float   m_fLensRadius;   // �����Y�̔��a(f/2F)
	float   m_fFilmDistance; // �t�B�����܂ł̋��� Lf/(L-f)

	D3DXVECTOR3 u, v, w;

public:

	void Update();
	void SetFrom  (const D3DXVECTOR3 *p){m_vFrom  =*p;}
	void SetLookAt(const D3DXVECTOR3 *p){m_vLookat=*p;}
	void SetUp    (const D3DXVECTOR3 *p){m_vUp    =*p;}
	void SetFilmSize      (float w, float h){m_fFilmSize[0] = w; m_fFilmSize[1] = h;}
	void SetFocalLength   (float v){m_fFocalLength   = v;}
	void SetFNumber       (float v){m_fFNumber       = v;}
	void SetFocusDistance (float v){m_fFocusDistance = v;}
	
	void GetRay( D3DXVECTOR3 *o, D3DXVECTOR3 *v, float x, float y);
};

// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
char  s_data [4*RENDER_WIDTH*RENDER_HEIGHT];// ���z�t���[���o�b�t�@
float s_total[4*RENDER_WIDTH*RENDER_HEIGHT];// �ݐσt���[���o�b�t�@

CCamera camera;

CRand   *g_pRand = NULL;
#define frand() ((float)g_pRand->GetF32())

CMesh *pRoom       = NULL;
CMesh *pBlockSmall = NULL;
CMesh *pBlockTall  = NULL;
CMesh *pShpereS    = NULL;
CMesh *pShpereT    = NULL;

static int s_x = 0;			// �����_�����O�s�N�Z���̂����W
static int s_y = 0;			// �����_�����O�s�N�Z���̂����W
static float render_cnt = 0;// �`���
enum{
	STATE_IDLE=0,			// �����҂�
	STATE_RENDER_BEGIN,		// ������
	STATE_RENDER,			// �`��
	STATE_RENDER_END,		// ��Еt��
};

OBJ_DATA sphere_data[] = {
{// �������̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.10f, 0.100f, 0.10f},
		0.2f, 0.8f, 0.0f, 0.0f,
	},{{0,0,0},{0,0,0},{0,0,0},},{
		{125.5, 0+100,169},
//		{185.5, 165+100,169},
		100.0f,
	}
},{// �傫���̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.05f, 0.050f, 0.05f},
		0.80f, 0.00f, 0.20f, 0.0f,
	},{{0,0,0},{0,0,0},{0,0,0},},{
		{368.5, 330+100,351},
		100.0f,
	}
}};
OBJ_DATA room_data[14] = {
{
// ���C�g�P
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f*1.00f, 100.0f*0.90f, 100.0f*0.50f},
		0.0f, 0.0f, 0.0f, 1.0f,
	},{
		{213.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 227.0},
	}
},{// ���C�g�Q
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f*1.00f, 100.0f*0.90f, 100.0f*0.50f},
		0.0f, 0.0f, 0.0f, 1.0f,
	},{
		{343.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 332.0},
	}
},{	// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.15f, 0.15f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{552.8f,   0.0f,   0.0f},
		{556.0f, 548.8f,   0.0f},
		{549.6f,   0.0f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.15f, 0.15f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f,   0.0f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �E�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.15f, 0.15f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{0.0f,   0.0f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f,   0.0f},
	}

},{// �E�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.15f, 0.15f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{0.0f, 548.8f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f, 559.2f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f,   0.0f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{  0.0f, 548.8f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �V��P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f,   0.0f},
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// �V��Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 0.0f,   0.0f},
		{552.8f, 0.0f,   0.0f},
		{  0.0f, 0.0f, 559.2f},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 0.0f, 559.2f},
		{552.8f, 0.0f,   0.0f},
		{549.6f, 0.0f, 559.2f},
	}
},{// ��O�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f,   0.0f, 0.0f},
		{  0.0f, 548.8f, 0.0f},
		{549.6f,   0.0f, 0.0f},
	}

},{// ��O�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{  0.0f, 548.8f, 0.0f},
		{556.0f, 548.8f, 0.0f},
		{549.6f,   0.0f, 0.0f},
	}


}};


OBJ_DATA Short_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0f, 165.0f, 225.0f},
		{130.0f, 165.0f,  65.0f},
		{240.0f, 165.0f, 272.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0, 165.0, 114.0},
		{240.0, 165.0, 272.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0, 165.0, 114.0},
		{290.0,   0.0, 114.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0, 165.0, 272.0},
		{290.0,   0.0, 114.0},
		{240.0,   0.0, 272.0},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{290.0,   0.0, 114.0},
		{290.0, 165.0, 114.0},
		{130.0,   0.0,  65.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{130.0,   0.0,  65.0},
		{290.0, 165.0, 114.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0, 165.0,  65.0},
		{ 82.0, 165.0, 225.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0,   0.0,  65.0},
		{130.0, 165.0,  65.0},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0, 165.0, 225.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0,   0.0, 225.0},
		{ 82.0, 165.0, 225.0},
	}
}};

OBJ_DATA Tall_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{314.0f, 330.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f, 330.0f, 406.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f,   0.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{423.0f, 330.0f, 247.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{472.0f, 330.0f, 406.0f},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{314.0f, 330.0f, 456.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f, 330.0f, 456.0f},
		{472.0f, 330.0f, 406.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f,   0.0f, 296.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{265.0f,   0.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.70f, 0.70f, 0.70f},
		0.0f, 0.0f, 1.0f, 0.0f,
	},{
		{265.0f, 330.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{423.0f, 330.0f, 247.0f},
	}
}};

// ---------------------------------------------------------------------------
// �֐��錾
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y);


// ---------------------------------------------------------------------------
// �J�����N���X
// ---------------------------------------------------------------------------
void CCamera::Update()
{
	// ���K���s���̌v�Z
	D3DXVec3Subtract( &w, &m_vLookat, &m_vFrom );
	D3DXVec3Cross( &v, &w, &m_vUp );
	D3DXVec3Cross( &u, &v, &w );
	D3DXVec3Normalize( &u, &u );
	D3DXVec3Normalize( &v, &v );
	D3DXVec3Normalize( &w, &w );

	// �����Y�̔��a(f/2F)
	m_fLensRadius = 0.5f * m_fFocalLength / m_fFNumber;
	// �t�B�����܂ł̋��� Lf/(L-f)
	m_fFilmDistance = m_fFocusDistance*m_fFocalLength/(m_fFocusDistance-m_fFocalLength);
}
// ---------------------------------------------------------------------------
void CCamera::GetRay( D3DXVECTOR3 *o, D3DXVECTOR3 *dir, float x, float y)
{
	D3DXVECTOR3 ds, e;
	D3DXVECTOR3 tmp, tmp1;
	float z1 = frand();
	float z2 = frand();

	float r = m_fLensRadius * sqrtf(z1);
	float theta = 2.0f * D3DX_PI * z2;
	
	// ���C���΂��ʒu
	D3DXVec3Scale( &tmp, &v, cosf(theta) );
	D3DXVec3Scale( &ds,  &u, cosf(theta) );
	D3DXVec3Add( &ds, &ds, &tmp );
	D3DXVec3Scale( &ds, &ds, r );
	D3DXVec3Add( o, &ds, &m_vFrom );

	// �����Y�̒��S����s���g�̓�����ʒu�ւ̃x�N�g��
	D3DXVec3Scale( &e,    &w,   m_fFilmDistance );
	D3DXVec3Scale( &tmp,  &v,   m_fFilmSize[0] * (x-0.5f) );
	D3DXVec3Scale( &tmp1, &u, - m_fFilmSize[1] * (y-0.5f) );
	D3DXVec3Add( &e, &e, &tmp );
	D3DXVec3Add( &e, &e, &tmp1 );
	D3DXVec3Normalize( &e, &e );

	D3DXVec3Scale( dir, &e, m_fFocusDistance / D3DXVec3Dot( &e, &w ) );
	D3DXVec3Subtract( dir, dir, &ds );
	D3DXVec3Normalize( dir, dir );
}



// ---------------------------------------------------------------------------
char *GetDataPointer()
{
	return s_data;
}
// ---------------------------------------------------------------------------
int GetRenderCount()
{
	return (int)(render_cnt+0.5f);
}
// ---------------------------------------------------------------------------
void Init()
{
	int i, j;

	camera.SetFrom  (&D3DXVECTOR3(278,273,-800));
	camera.SetLookAt(&D3DXVECTOR3(278,273,0));
	camera.SetUp    (&D3DXVECTOR3(0,1,0));
	camera.SetFilmSize      ( ASPECT*25, 25 );
	camera.SetFocalLength   ( 35 );
	camera.SetFNumber       ( 0.14f  );
	camera.SetFocusDistance ( 1200.0 );
	camera.Update();
	
	g_pRand = new CRand();

	pRoom = new CMesh();
	pRoom->Init( room_data, 14 );
	
	pBlockSmall = new CMesh();
	pBlockSmall->Init( Short_block, 10);

	pBlockTall = new CMesh();
	pBlockTall->Init( Tall_block, 10);
	
	pShpereS = new CMesh();
	pShpereS->Init( sphere_data, 1);
	
	pShpereT = new CMesh();
	pShpereT->Init( sphere_data+1,1);

	render_cnt = 0; // �����_�����O��
	// �t���[���o�b�t�@�̏�����
	for(j=0; j<RENDER_HEIGHT; j++){
	for(i=0; i<RENDER_WIDTH ; i++){
		s_data [4*(j*RENDER_WIDTH+i)+0]=(char)255;// R
		s_data [4*(j*RENDER_WIDTH+i)+1]=(char)(i*256/RENDER_WIDTH );// G
		s_data [4*(j*RENDER_WIDTH+i)+2]=(char)(j*256/RENDER_HEIGHT);// B
		s_total[4*(j*RENDER_WIDTH+i)+0]=0;// R
		s_total[4*(j*RENDER_WIDTH+i)+1]=0;// G
		s_total[4*(j*RENDER_WIDTH+i)+2]=0;// B
	}
	}
}
// ---------------------------------------------------------------------------
void Delete()
{
	if(pShpereT){delete pShpereT;pShpereT=NULL;}
	if(pShpereS){delete pShpereS;pShpereS=NULL;}
	if(pBlockTall){delete pBlockTall;pBlockTall=NULL;}
	if(pBlockSmall){delete pBlockSmall;pBlockSmall=NULL;}
	if(pRoom){delete pRoom; pRoom=NULL;}
	if(g_pRand){delete g_pRand; g_pRand=NULL;}
}
// ---------------------------------------------------------------------------

#define BLOCK_X 2
#define BLOCK_Y 2

// ---------------------------------------------------------------------------
unsigned int WINAPI RayTrace ( LPVOID pParam )
{
	rect *pRect = (rect *)pParam;
	D3DXVECTOR3 col;
	
for(int i=0;i<10;i++)
	for( s32 y = pRect->top; y < pRect->bottom; y++ )
	{
		for( s32 x = pRect->left; x < pRect->right; x++ )
		{
			GetColor(&col, ((float)x+0.5f)/(float)RENDER_WIDTH
					     , ((float)y+0.5f)/(float)RENDER_HEIGHT);
			int no = 4*(y*RENDER_WIDTH+x);
			s_total[no+0]+=col.x;// R
			s_total[no+1]+=col.y;// G
			s_total[no+2]+=col.z;// B
		}
	}

    return 0;
}


// ---------------------------------------------------------------------------
int Render()
{
	int k,no;
	static unsigned int save_bit = 0;

	render_cnt+=10.0f;

	static rect r[BLOCK_Y][BLOCK_X];
	HANDLE  hThread[BLOCK_Y][BLOCK_X];
	unsigned int  dummy;
	
	for( s32 i = 0; i < BLOCK_Y; i++ )
	{
		for( s32 j = 0; j < BLOCK_X; j++ )
		{
			r[i][j].left   = (j+0)*RENDER_WIDTH /BLOCK_X;
			r[i][j].right  = (j+1)*RENDER_WIDTH /BLOCK_X;
			r[i][j].top    = (i+0)*RENDER_HEIGHT/BLOCK_Y;
			r[i][j].bottom = (i+1)*RENDER_HEIGHT/BLOCK_Y;
		}
	}
	
	bool bFinished[BLOCK_Y][BLOCK_X]; // �I������H
	
	// �I���t���O
	for( s32 i = 0; i < BLOCK_Y; i++ )
		for( s32 j = 0; j < BLOCK_X; j++ )
			bFinished[i][j] = false;
	
	for( u32 n = BLOCK_X * BLOCK_Y; 0 < n; )
	{
		// �X���b�h�𐶐�����
		for( s32 i = 0; i < BLOCK_Y; i++ )
		{
			for( s32 j = 0; j < BLOCK_X; j++ )
			{
				if( !bFinished[i][j] )
				{
					hThread[i][j] = (HANDLE)_beginthreadex( NULL, 0, &RayTrace, (LPVOID)&r[i][j], 0, &dummy );
				}
				if(0==hThread[i][j])
				{
					hThread[i][j]=0;
				}
			}
		}
		
		// �X���b�h��҂�
		for( s32 i = 0; i < BLOCK_Y; i++ )
		{
			for( s32 j = 0; j < BLOCK_X; j++ )
			{
				if( !bFinished[i][j] && 0 != hThread[i][j] )
				{
					WaitForSingleObject( hThread[i][j], INFINITE );  // ��M�X���b�h�I���҂�
					CloseHandle( hThread[i][j] );                    // �n���h�������
					bFinished[i][j] = true;
					n--;
				}
			}
		}
	}

	// ��ʂ̔��f
	no = 0;
	for(s32 j=0; j<RENDER_HEIGHT; j++){
	for(s32 i=0; i<RENDER_WIDTH ; i++){
		s_data [no+0]=(unsigned char)(255.9*min(1,s_total[no+0]/render_cnt));// R
		s_data [no+1]=(unsigned char)(255.9*min(1,s_total[no+1]/render_cnt));// G
		s_data [no+2]=(unsigned char)(255.9*min(1,s_total[no+2]/render_cnt));// B
		no += 4;
	}
	}

	// �K���ȂƂ��ɉ摜��ۑ�����
	if( (1<<save_bit) <= GetRenderCount() )
	{
		// �t�@�C���������߂�
		_TCHAR buf[256];
		_stprintf( buf, _T("%d.bmp"), GetRenderCount());
		
		// �r�b�g�}�b�v�C���[�W�����
		BYTE *pImage = new BYTE[3 * RENDER_WIDTH * RENDER_HEIGHT];
		k = 0;
		for(s32 j=0; j<RENDER_HEIGHT; j++)
		{
			no = 4*RENDER_WIDTH*(RENDER_HEIGHT-j-1);
			for(s32 i=0; i<RENDER_WIDTH ; i++)
			{
				pImage[k+0] = s_data [no+2];
				pImage[k+1] = s_data [no+1];
				pImage[k+2] = s_data [no+0];
				no += 4;
				k += 3;
			}
		}

		// �r�b�g�}�b�v�ɕK�v�ȏ����i�[����
		SAVE_BITMAP tBitmap_Info;
		tBitmap_Info.pFileName = buf;
		tBitmap_Info.iWidth  = RENDER_WIDTH;
		tBitmap_Info.iHeight = RENDER_HEIGHT;
		tBitmap_Info.iBitCount = 24;
		tBitmap_Info.pData = (BYTE*)pImage;

		SaveBitMap( tBitmap_Info );

		delete[] pImage;

		save_bit++;
	}

	return 0;
}

// ---------------------------------------------------------------------------
bool GetColor(D3DXVECTOR3 *dest, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v, int depth)
{
	D3DXVECTOR3 diffuse_color=D3DXVECTOR3(0,0,0);

	// -----------------------------------------------------------------------
	// �������F�������܁A���˂������Ȃ��ŉ��X�ƒ��˕Ԃ����Ƃ��́A�����͂��Ȃ����F
	// -----------------------------------------------------------------------
	if(0==depth) *dest = D3DXVECTOR3(0,0,0);

	// -----------------------------------------------------------------------
	// �ċA���������ꍇ�͌����͂��Ă��Ȃ����̂ƍl����
	// -----------------------------------------------------------------------
	const int DEPTH_MAX = 3;
	if(DEPTH_MAX <= depth) { *dest=D3DXVECTOR3(0,0,0); return FALSE;}

	// -----------------------------------------------------------------------
	// ���������_�����߂�
	// -----------------------------------------------------------------------
	float t = CPrimitive::INFINTY_DIST;
	CPrimitive *pObj = NULL;
	D3DXVECTOR4 p, n;// ��_�̈ʒu�Ɩ@��

	t = pShpereS   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pShpereT   ->IsAcross(t, &n, &p, &pObj, x, v);
	t = pRoom      ->IsAcross(t, &n, &p, &pObj, x, v);
//	t = pBlockSmall->IsAcross(t, &n, &p, &pObj, x, v);
	t = pBlockTall ->IsAcross(t, &n, &p, &pObj, x, v);

	if( NULL == pObj ){
		// �����̓I�u�W�F�N�g����O�ꂽ�I
		*dest = BG_COLOR;
		return TRUE;
	}

	// -----------------------------------------------------------------------
	// ���˕��������V�A�����[���b�g�Ō��߂�
	// -----------------------------------------------------------------------
	float cd = pObj->m_material.diffuse;	// �g�U��
	float cr = pObj->m_material.reflection;	// ���˗�
	float cn = pObj->m_material.refraction;	// ���ܗ�
	float ce = pObj->m_material.emmisive;	// ���˗�
	float total = cd+cr+cn+ce;
	float prob = total * (float)frand();

	int type = 0;// �g�U
	if(prob < cr      ) type = 1; else// ����
	if(prob < cr+cn   ) type = 2; else// ����
	if(prob < cr+cn+ce) type = 3;     // ����

	// -----------------------------------------------------------------------
	// ��_���A�e�ɉB��Ă��邩�ǂ������ׂāA�g�U�����Z�o����
	// -----------------------------------------------------------------------
	if(0==type){
		if(++depth<DEPTH_MAX){
			// ����ɉ�������
			D3DXVECTOR4 dir, pos;
			
			// �����I�Ƀ��C���΂�
			float theta =      D3DX_PI * (float)frand();
			float phi   = 2.0f*D3DX_PI * (float)frand();
			dir.x = sinf(theta) * cosf(phi);
			dir.y = sinf(theta) * sinf(phi);
			dir.z = cosf(theta);
			float dn = D3DXVec3Dot((D3DXVECTOR3 *)&dir, (D3DXVECTOR3 *)&n);
			if(dn<0){
				// �@���Ɣ��Ό����ɔ�Ԃ���Ȃ�A�����𔽑΂ɂ���
				dn = -dn;
				dir.x *= -1;
				dir.y *= -1;
				dir.z *= -1;
			}

			pos = p + 0.01f*(dir);
			GetColor(&diffuse_color, &pos, &dir, depth);
			// �v���~�e�B�u�̐F��g�U���̗]������K�p
			diffuse_color.x *= pObj->m_material.COLOR_DIF[0] * dn * 0.5f*D3DX_PI;
			diffuse_color.y *= pObj->m_material.COLOR_DIF[1] * dn * 0.5f*D3DX_PI;
			diffuse_color.z *= pObj->m_material.COLOR_DIF[2] * dn * 0.5f*D3DX_PI;
		}
	}

	// -----------------------------------------------------------------------
	// �ċA�I�Ɍ������΂��āA��荂���̔��˂��l���ɓ����
	// -----------------------------------------------------------------------
	// ����
	D3DXVECTOR3 reflect_color=D3DXVECTOR3(0,0,0);
	if(1==type){
		// ���˃x�N�g��
		D3DXVECTOR4 r = *v - 2.0f*D3DXVec3Dot((D3DXVECTOR3 *)&n, (D3DXVECTOR3 *)v) * n;
		D3DXVECTOR4 pos = p + 0.01f*n;// ������ƕ�����
		if(!GetColor( &reflect_color, &pos, &r, depth)){
			cr = 0;// ���ǁA�����͂��Ȃ�����
		}
	}

	// -----------------------------------------------------------------------
	// ����
	// -----------------------------------------------------------------------
	D3DXVECTOR3 refract_color=D3DXVECTOR3(0,0,0);
	if(2==type){
		// ���܃x�N�g��
		D3DXVECTOR4 t, pos;
		float VN = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&n);
		float eta = 1.5f;
		if(VN<0){
			// ����
			float D = 1-(1+VN)*(1+VN)/(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = (-VN/eta-sqrtf(D))*n+(1/eta)*(*v);
			pos = p - 0.01f*n;// ������ƕ�����
		}else{
			// �o�čs��
			float D = 1-(1-VN)*(1-VN)*(eta*eta);
			if(D<0){cn=0;goto no_refract;}// �S����
			t = -(VN*eta-sqrtf(D))*n+eta*(*v);
			pos = p + 0.01f*n;// ������ƕ�����
		}
		D3DXVec3Normalize( (D3DXVECTOR3 *)&t, (D3DXVECTOR3 *)&t );
		if(!GetColor( &refract_color, &pos, &t, depth)){
			cn = 0;// ���ǁA�����͂��Ȃ�����
		}
	}
no_refract:

	// -----------------------------------------------------------------------
	// ����
	// -----------------------------------------------------------------------
	D3DXVECTOR3 emmisive_color = *(D3DXVECTOR3*)&pObj->m_material.COLOR_DIF;

	// -----------------------------------------------------------------------
	// �F���o�͂���
	// -----------------------------------------------------------------------
	switch(type){
	case 0:// �g�U
		*dest = (cd+cr+cn) * diffuse_color;
		break;
	case 1:// ����
		*dest = (cd+cr+cn) * reflect_color;		
		break;
	case 2:// ����
		*dest = (cd+cr+cn) * refract_color;
		break;
	case 3:// ����
		*dest = ce * emmisive_color;
		break;
	}

	return TRUE;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y)
{
	D3DXVECTOR4 ray_start;
	D3DXVECTOR4 ray_dir;
	
	ray_start.w = 1.0f;
	ray_dir.w   = 0.0f;

	camera.GetRay( (D3DXVECTOR3*)&ray_start, (D3DXVECTOR3*)&ray_dir, x, y);
	
	GetColor(dest, &ray_start, &ray_dir, 0);

	return dest;
}

};// namespace Render
