//-------------------------------------------------------------
// File: main.h
//
// Desc: Real-Time Global Illumination
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#pragma once

#define DX9C

#ifdef DX9C
	#define BEGIN_PASS(n) m_pEffect->BeginPass(n)
	#define END_PASS()    m_pEffect->EndPass()
#else// DX9C
	#define BEGIN_PASS(n) m_pEffect->Pass(n)
	#define END_PASS()
#endif // DX9C

//-------------------------------------------------------------
// Defines, and constants(��`��萔)
//-------------------------------------------------------------

// Struct to store the current input state(���݂̓��̓f�[�^��ۑ�����\����)
struct UserInput
{
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
    BOOL bZoomIn;
    BOOL bZoomOut;
    BOOL bChangeShader;
    BOOL bDiffuseUp;
    BOOL bDiffuseDown;
    BOOL bSpecularUp;
    BOOL bSpecularDown;
    BOOL bTranslucentUp;
    BOOL bTranslucentDown;
    BOOL bPause;
};




//-------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Main class to run this application. Most functionality is inherited
//       from the CD3DApplication base class.
//       (�A�v���P�[�V�����̃N���X)
//-------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
	enum{
		L_MAX = 1,							// The maximum expansion degree(�ő�̌v�Z����)
		TEX_MAX = ((L_MAX+1)*(L_MAX+1)+3)/4,// The number of texture for SH expansion(SH�̃e�N�X�`������)

		REDUCTION_MAPS = 3,					// The number of times of reduction(�k����)
	};
	 
	float                   m_fDiffuse;
	float                   m_fSpecular;
	float                   m_fTranslucent;

	// Scene management(�V�[���Ǘ�)
	int						m_iState;		// State(��ԕϐ�)
	int						m_iChangeState;	// 
	int						m_iCount;		// Increment per rendering(��ԕϐ��Ǘ��p���ԕϐ�)
	bool					m_bPause;		// Pause

	// Model
	CD3DMesh				*m_pMesh;
	CD3DMesh				*m_pMeshBg;
	CD3DMesh				*m_pMeshEnv;
	
	// Dynamics for a ball
	D3DXVECTOR3				m_pos;			// Position(�ʒu)
	D3DXVECTOR3				m_vel;			// Velocity(���x)
	D3DXVECTOR3				m_rot;			// Rotation(�p�x)
	D3DXVECTOR3				m_omega;		// Angler velocity(�p���x)
	
	D3DXVECTOR3				m_EnvRot[4];	// Rotation
	FLOAT                   m_EnvRate;
	D3DXMATRIX				m_mEnv;

	// Shader
	int						m_Shader;		// Type of shader(�V�F�[�_�̎��)
	LPD3DXEFFECT		    m_pEffect;		// Effect for the sample(�G�t�F�N�g)
	D3DXHANDLE				m_hTechnique;	// Technique handle for RenderScene(�e�N�j�b�N)
	D3DXHANDLE				m_hmWV;			// Handle for world+view matrix in effect(�ϊ��s��)
	D3DXHANDLE				m_hmWVP;		// Handle for world+view+projection matrix in effect(�ϊ��s��)
	D3DXHANDLE				m_htSrcTex;		// Handle for the scene texture in effect(�e�N�X�`��)
	D3DXHANDLE				m_fWidth;		// Handle for the texture width in effect(�e�N�X�`����)
	D3DXHANDLE				m_fHeight;		// Handle for the texture height in effect(�e�N�X�`������)

	// Rendering targets (�����_�����O�^�[�Q�b�g)
	LPDIRECT3DSURFACE9		m_pMapZ;					// Depth buffer
	LPDIRECT3DTEXTURE9		m_pPosTex;					// Height map(�����}�b�v)
	LPDIRECT3DSURFACE9		m_pPosSurf;					// 
	LPDIRECT3DTEXTURE9		m_pPosLockTex;				// 
	LPDIRECT3DSURFACE9		m_pPosLockSurf;				// 
	LPDIRECT3DTEXTURE9		m_pNormalTex;				// Normal map(�@���}�b�v)
	LPDIRECT3DSURFACE9		m_pNormalSurf;				// 
	LPDIRECT3DTEXTURE9		m_pNormalLockTex;			// 
	LPDIRECT3DSURFACE9		m_pNormalLockSurf;			// 

	LPDIRECT3DTEXTURE9		m_pParaboloidTex[2];		// Environment map
	LPDIRECT3DSURFACE9		m_pParaboloidSurf[2];
	LPDIRECT3DTEXTURE9		m_pJacobianTex[TEX_MAX][2];	// SH coefficient of incoming light

	LPDIRECT3DTEXTURE9		m_pReductionTex [REDUCTION_MAPS];// Reduction buffer
	LPDIRECT3DSURFACE9		m_pReductionSurf[REDUCTION_MAPS];

	LPDIRECT3DTEXTURE9		m_p64Tex ;// Reduction buffer
	LPDIRECT3DSURFACE9		m_p64Surf;
	LPDIRECT3DSURFACE9		m_p64Z;
	LPDIRECT3DTEXTURE9		m_p64Tex2;// Reduction buffer
	LPDIRECT3DSURFACE9		m_p64Surf2;
	LPDIRECT3DTEXTURE9		m_p8Tex ;// Reduction buffer
	LPDIRECT3DSURFACE9		m_p8Surf;

	LPDIRECT3DTEXTURE9		m_pFinalTex[TEX_MAX];// PRT �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pFinalSurf[TEX_MAX];
	LPDIRECT3DTEXTURE9		m_pFinalSSTex[TEX_MAX];// SS_PRT �e�N�X�`��
	LPDIRECT3DSURFACE9		m_pFinalSSSurf[TEX_MAX];
	LPDIRECT3DTEXTURE9		m_pMaskTex;			// �W���v�Z

	// Geometry (�ʏ�̍��W�ϊ��s��)
	D3DXMATRIX				m_mWorld;		// World matrix
	D3DXMATRIX				m_mView;		// View matrix
	D3DXMATRIX				m_mProj;		// Projection matrix

    FLOAT                   m_fWorldRotX;   // World rotation state X-axis(�w����])
    FLOAT                   m_fWorldRotY;   // World rotation state Y-axis(�x����])
    FLOAT                   m_fViewZoom;    // Distance to lookat (���_�̋���)

	BOOL					m_bLoadingApp;	// TRUE, if the app is loading(���[�h���H)
    CD3DFont*				m_pFont;		// Font for drawing text(�t�H���g)
    UserInput				m_UserInput;	// Struct for storing user input (���̓f�[�^)

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );

	int  FrameMoveCreateMap();
	void RenderCreateMap();
	int  FrameMovePRT();
	void RenderPRT();
	int  FrameMoveSSPRT();
	void RenderSSPRT();
	void RenderParaboloidMap();

	HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );
public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

