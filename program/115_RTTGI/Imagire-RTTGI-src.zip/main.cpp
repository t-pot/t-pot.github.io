//-------------------------------------------------------------
// File: main.cpp
//
// Desc: Real-Time Global Illumination
// Copyright (c) 2004 IMAGIRE Takashi. All rights reserved.
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <time.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

#define MAP_SIZE			128
#define DECALE_MAP_SIZE		512

#define frand() ((float)rand()/(float)RAND_MAX)

//-------------------------------------------------------------
// Globals variables and definitions(�O���[�o���ϐ��ƒ�`)
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

typedef struct {
    FLOAT       p[4];
    FLOAT       tu, tv;
} TVERTEX;

//-------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//       (���C���֐�)
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: Application constructor.   Paired with ~CMyD3DApplication()
//       Member variables should be initialized to a known state here.  
//       The application window has not yet been created and no Direct3D device 
//       has been created, so any initialization that depends on a window or 
//       Direct3D should be deferred to a later stage. 
//       (�A�v���P�[�V�����̃R���X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	int i;
	time_t t;
	
	time( &t );
	srand( t );

	m_iState = -1;
	m_bPause = false;

	m_Shader = 0;

	m_fDiffuse     = 1.0f;
	m_fSpecular    = 0.2f;
	m_fTranslucent = 3.0f;

	m_pos = D3DXVECTOR3(0,0,0);
	m_vel = D3DXVECTOR3(frand(),frand(),frand());
	m_rot = D3DXVECTOR3(0,0,0);
	m_omega = D3DXVECTOR3( 0, 1.0, 0 );
//	m_omega = D3DXVECTOR3( frand(), frand(), frand() );
	
	m_EnvRate = 0;
	for(i=0;i<4;i++)
	{
		m_EnvRot[i] = D3DXVECTOR3( 2.0*D3DX_PI*frand(), 2.0*D3DX_PI*frand(), 2.0*D3DX_PI*frand() );
	}
	D3DXMATRIX mx,my,mz;
    D3DXMatrixRotationX( &mx, m_EnvRot[1].x );
    D3DXMatrixRotationY( &my, m_EnvRot[1].y );
    D3DXMatrixRotationZ( &mz, m_EnvRot[1].z );
	m_mEnv = mx*my*mz;

	m_pMesh						= new CD3DMesh();
	m_pMeshBg					= new CD3DMesh();
	m_pMeshEnv					= new CD3DMesh();

	m_pMapZ						= NULL;
	m_pPosTex					= NULL;
	m_pPosSurf					= NULL;
	m_pPosLockTex				= NULL;
	m_pPosLockSurf				= NULL;
	m_pNormalTex				= NULL;
	m_pNormalSurf				= NULL;
	m_pNormalLockTex			= NULL;
	m_pNormalLockSurf			= NULL;
	m_pParaboloidTex[0]			= NULL;
	m_pParaboloidSurf[0]		= NULL;
	m_pParaboloidTex[1]			= NULL;
	m_pParaboloidSurf[1]		= NULL;
	for(i=0;i<TEX_MAX;i++){
		m_pJacobianTex[i][0]	= NULL;
		m_pJacobianTex[i][1]	= NULL;
	}

	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		m_pReductionTex[i]		= NULL;
		m_pReductionSurf[i]		= NULL;
	}
	for( i=0;i<TEX_MAX;i++){
		m_pFinalTex[i]			= NULL;
		m_pFinalSurf[i]			= NULL;
		m_pFinalSSTex[i]		= NULL;
		m_pFinalSSSurf[i]		= NULL;
	}
	m_p64Tex					= NULL;
	m_p64Surf					= NULL;
	m_p64Tex2					= NULL;
	m_p64Surf2					= NULL;
	m_p64Z						= NULL;
	m_p8Tex						= NULL;
	m_p8Surf					= NULL;
	m_pMaskTex					= NULL;

	m_pEffect					= NULL;
	m_hTechnique  				= NULL;
	m_hmWV						= NULL;
	m_hmWVP						= NULL;
	m_htSrcTex					= NULL;
	m_fWidth					= NULL;
	m_fHeight					= NULL;

	m_fWorldRotX                = -0.28f;
    m_fWorldRotY                = D3DX_PI*0.5f;
	m_fViewZoom				    = 7.0f;

	m_dwCreationWidth           = 512;
    m_dwCreationHeight          = 512;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: Application destructor.  Paired with CMyD3DApplication()
//       (�f�X�g���N�^)
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: Paired with FinalCleanup().
//       The window has been created and the IDirect3D9 interface has been
//       created, but the device has not been created yet.  Here you can
//       perform application-related initialization and cleanup that does
//       not depend on a device.
//      (��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // Drawing loading status message until app finishes loading
    // (���[�f�B���O���b�Z�[�W��\������)
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the device
//       for some minimum set of capabilities
//       (�������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps,
                     DWORD dwBehavior,    D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    

    // No fallback, so need ps2.0
	// (�s�N�Z���V�F�[�_�o�[�W�����`�F�b�N)
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
		return E_FAIL;

    // If device doesn't support 1.1 vertex shaders in HW, switch to SWVP.
    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;

    return S_OK;
}


//-------------------------------------------------------------
// SH coefficient of imcomming light
//-------------------------------------------------------------
// Variables send from application
typedef struct {
	int iRank;		// SH dimension
	bool bFront;	// Front or back
}sParaboloid;

VOID WINAPI ParaboloidJacobian (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pTexelSize );

	sParaboloid *p = (sParaboloid *)pData;

	FLOAT x = 2.0f*( pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(-pTexCoord->y+0.5f);
	
	FLOAT r2 = x*x+y*y;
	FLOAT J = 0.5f*(1.0f+r2);

    FLOAT col = (r2<(1.0f-1.0f/(FLOAT)MAP_SIZE)*(1.0f-1.0f/(FLOAT)MAP_SIZE)) ? J : 0.0f;
	
	// Normal vector
	FLOAT nz = 0.5f * (1.0f-r2);
	FLOAT nx = x;
	FLOAT ny = y;
	FLOAT n = sqrtf(nx*nx+ny*ny+nz*nz);
	nx /= n;
	ny /= n;
	nz /= n;
	if(p->bFront) nz *= -1;

	pOut->x = 0.5f * col * (-nx) + 0.5f;
	pOut->y = 0.5f * col * ( ny) + 0.5f;
	pOut->z = 0.5f * col * (-nz) + 0.5f;
	pOut->w = 0.5f * col         + 0.5f;
}

//-------------------------------------------------------------
// �^�񒆂������G�����
//-------------------------------------------------------------
VOID WINAPI FillTex (D3DXVECTOR4* pOut, CONST D3DXVECTOR2* pTexCoord, 
CONST D3DXVECTOR2* pTexelSize, LPVOID pData)
{
    UNREFERENCED_PARAMETER( pData );

	FLOAT x = 2.0f*(pTexCoord->x-0.5f);
    FLOAT y = 2.0f*(pTexCoord->y-0.5f);
    FLOAT col = (x*x+y*y<(1.0f-pTexelSize->x)*(1.0f-pTexelSize->y))
				? 1.0f : 0.0f;
	
	pOut->x = pOut->y = pOut->z = pOut->w = col;
}

//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: Paired with DeleteDeviceObjects()
//       The device has been created.  Resources that are not lost on
//       Reset() can be created here -- resources in D3DPOOL_MANAGED,
//       D3DPOOL_SCRATCH, or D3DPOOL_SYSTEMMEM.  Image surfaces created via
//       CreateImageSurface are never lost and can be created here.  Vertex
//       shaders and pixel shaders can also be created here as they are not
//       lost on Reset().
//      (�f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς������ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	int i;

    // Load objects (���f���̓ǂݍ���)
#ifdef DX9C
	if(FAILED(hr=m_pMesh->Create( m_pd3dDevice, (LPCWSTR)("t-pot.x"))))
        return DXTRACE_ERR( "Load Model", hr );
        
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, (LPCWSTR)("map.x"))))
        return DXTRACE_ERR( "Load Model", hr );
        
	if(FAILED(hr=m_pMeshEnv->Create( m_pd3dDevice, (LPCWSTR)("room.x"))))
        return DXTRACE_ERR( "Load Model", hr );
#else
	if(FAILED(hr=m_pMesh->Create( m_pd3dDevice, _T("t-pot.x"))))
        return DXTRACE_ERR( "Load Model", hr );
        
	if(FAILED(hr=m_pMeshBg->Create( m_pd3dDevice, _T("map.x"))))
        return DXTRACE_ERR( "Load Model", hr );
        
	if(FAILED(hr=m_pMeshEnv->Create( m_pd3dDevice, _T("room.x"))))
        return DXTRACE_ERR( "Load Model", hr );
#endif
	m_pMesh->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
	m_pMeshBg->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
	m_pMeshEnv->UseMeshMaterials(FALSE);// Not set textures when rendering(�����_�����O���Ƀe�N�X�`���̐ݒ�����Ȃ�)
        
	// Create textures
	sParaboloid data;
	for( i = 0; i < TEX_MAX; i++ )
	{
		data.iRank = i;
		// SH coefficient of incoming light (�d�ݕt���̃e�N�X�`��)
		data.bFront = 0;
		if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
							, 0, D3DFMT_A8R8G8B8
							, D3DPOOL_MANAGED, &m_pJacobianTex[i][0], NULL)))
			return E_FAIL;
		if( FAILED(D3DXFillTexture(m_pJacobianTex[i][0], ParaboloidJacobian, &data)))
			return E_FAIL;

		data.bFront = 1;
		if( FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1
							, 0, D3DFMT_A8R8G8B8
							, D3DPOOL_MANAGED, &m_pJacobianTex[i][1], NULL)))
			return E_FAIL;
		if( FAILED(D3DXFillTexture(m_pJacobianTex[i][1], ParaboloidJacobian, &data)))
			return E_FAIL;
	}

    // Create the effect(�V�F�[�_�̓ǂݍ���)
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
				m_pd3dDevice, "hlsl.fx", NULL, NULL, 
				D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
					, "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechnique = m_pEffect->GetTechniqueByName( "TShader" );
	m_hmWV 		 = m_pEffect->GetParameterByName( NULL, "mWV" );
	m_hmWVP		 = m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_htSrcTex   = m_pEffect->GetParameterByName( NULL, "SrcTex" );
	m_fWidth	 = m_pEffect->GetParameterByName( NULL, "MAP_WIDTH" );
	m_fHeight	 = m_pEffect->GetParameterByName( NULL, "MAP_HEIGHT" );

    // Init the font(�t�H���g)
    m_pFont->InitDeviceObjects( m_pd3dDevice );

    return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: Paired with InvalidateDeviceObjects()
//       The device exists, but may have just been Reset().  Resources in
//       D3DPOOL_DEFAULT and any other device state that persists during
//       rendering should be set here.  Render states, matrices, textures,
//       etc., that don't change during rendering can be set once here to
//       avoid redundant state setting during Render() or FrameMove().
//       (��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		 �m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	DWORD i;

	m_iState = -1;
	m_iChangeState = TRUE;
	m_bPause = false;

	// Restore meshes(���b�V��)
	m_pMesh->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshBg->RestoreDeviceObjects( m_pd3dDevice );
	m_pMeshEnv->RestoreDeviceObjects( m_pd3dDevice );

    // Setup a material (�����̐ݒ�)
    D3DMATERIAL9 mtrl;
    D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
    m_pd3dDevice->SetMaterial( &mtrl );

    // Set miscellaneous render states(�����_�����O���̐ݒ�)
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,        0x000F0F0F );
    
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

    // World transform to identity (���[���h�s��)
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &m_mWorld );

    // Set up the view parameters for the camera(�r���[�s��)
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

    // Set the camera projection matrix(�ˉe�s��)
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect, 1.0f, 100.0f );

    // Create the stencil buffer to be used with the paraboloid textures(�[�x�}�b�v�̐���)
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// Create height map(�ʒu�}�b�v)
	if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &m_pPosTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pPosTex->GetSurfaceLevel(0, &m_pPosSurf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
		0, D3DFMT_A32B32G32R32F, D3DPOOL_SYSTEMMEM , &m_pPosLockTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pPosLockTex->GetSurfaceLevel(0, &m_pPosLockSurf)))
		return E_FAIL;
	// Create normal map(�@���}�b�v)
	if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A32B32G32R32F, D3DPOOL_DEFAULT, &m_pNormalTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pNormalTex->GetSurfaceLevel(0, &m_pNormalSurf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
		0, D3DFMT_A32B32G32R32F, D3DPOOL_SYSTEMMEM , &m_pNormalLockTex, NULL)))
		return E_FAIL;
	if (FAILED(m_pNormalLockTex->GetSurfaceLevel(0, &m_pNormalLockSurf)))
		return E_FAIL;
    // Create the paraboloid textures(�����}�b�v)
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[0], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[0]->GetSurfaceLevel(0, &m_pParaboloidSurf[0])))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pParaboloidTex[1], NULL)))
		return E_FAIL;
	if (FAILED(m_pParaboloidTex[1]->GetSurfaceLevel(0, &m_pParaboloidSurf[1])))
		return E_FAIL;

	// �}�X�N�p�̃e�N�X�`���̐���
    if( FAILED(m_pd3dDevice->CreateTexture( 64, 64, 1
                          , 0, D3DFMT_A8R8G8B8
                          , D3DPOOL_DEFAULT, &m_pMaskTex, NULL)))
        return E_FAIL;
    if( FAILED(D3DXFillTexture(m_pMaskTex, FillTex, NULL)))
        return E_FAIL;

    // Create the reduction textures(�k���o�b�t�@)
	int size = 128;
	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		if (FAILED(m_pd3dDevice->CreateTexture(size, size, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pReductionTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pReductionTex[i]->GetSurfaceLevel(0, &m_pReductionSurf[i])))
			return E_FAIL;
		size /= 8;
	}
	if (FAILED(m_pd3dDevice->CreateTexture( 64, 64, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_p64Tex, NULL)))
		return E_FAIL;
	if (FAILED(m_p64Tex->GetSurfaceLevel(0, &m_p64Surf)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture( 64, 64, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_p64Tex2, NULL)))
		return E_FAIL;
	if (FAILED(m_p64Tex2->GetSurfaceLevel(0, &m_p64Surf2)))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface( 64, 64, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_p64Z, NULL)))
		return E_FAIL;

	if (FAILED(m_pd3dDevice->CreateTexture( 8, 8, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_p8Tex, NULL)))
		return E_FAIL;
	if (FAILED(m_p8Tex->GetSurfaceLevel(0, &m_p8Surf)))
		return E_FAIL;

	// �g�U�}�b�v
	for(i=0;i<TEX_MAX;i++){
		if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pFinalTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pFinalTex[i]->GetSurfaceLevel(0, &m_pFinalSurf[i])))
			return E_FAIL;
		if (FAILED(m_pd3dDevice->CreateTexture(DECALE_MAP_SIZE, DECALE_MAP_SIZE, 1, 
			D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pFinalSSTex[i], NULL)))
			return E_FAIL;
		if (FAILED(m_pFinalSSTex[i]->GetSurfaceLevel(0, &m_pFinalSSSurf[i])))
			return E_FAIL;
	}

    // Restore effect object
	m_pEffect->OnResetDevice();

    // Restore the font(�t�H���g)
    m_pFont->RestoreDeviceObjects();

	return S_OK;
}

void CatmullRom( D3DXVECTOR3 *v, const D3DXVECTOR3 *v0, const D3DXVECTOR3 *v1, const D3DXVECTOR3 *v2, const D3DXVECTOR3 *v3,FLOAT rate)
{
	const D3DXMATRIX mCatmullRom = D3DXMATRIX(
		-1.0/2.0, 3.0/2.0,-3.0/2.0, 1.0/2.0,
		 2.0/2.0,-5.0/2.0, 4.0/2.0,-1.0/2.0,
		-1.0/2.0, 0.0/2.0, 1.0/2.0, 0.0/2.0,
		 0.0/2.0, 2.0/2.0, 0.0/2.0, 0.0/2.0);

	D3DXVECTOR4 vr = D3DXVECTOR4(rate*rate*rate,rate*rate,rate,1);
	D3DXVECTOR4 v4;

	D3DXVec4Transform(&v4, &vr, &mCatmullRom);

	*v = v4.x * (*v0) + v4.y * (*v1) + v4.z * (*v2) + v4.w * (*v3);
}

//-------------------------------------------------------------
// Name: FrameMove()
// Desc: Called once per frame, the call is the entry point for animating
//       the scene.
//       (���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	m_iCount++;
	
	if(m_iChangeState) {m_iState++;m_iCount=0;m_iChangeState=0;}

	switch(m_iState){
	case 0:
		m_iChangeState = this->FrameMoveCreateMap();
		return S_OK;
	case 1:
		m_iChangeState = this->FrameMoveSSPRT();
		return S_OK;
	case 2:
		m_iChangeState = this->FrameMovePRT();
		return S_OK;
	default:
		break;
	}

    // Update user input state(���̓f�[�^�̍X�V)
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
    // Update the world state according to user input(���͂ɉ����č��W�n���X�V����)
	//---------------------------------------------------------
	// Rotation(��])
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;

	if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
		m_fWorldRotY += m_fElapsedTime;
	else
	if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
		m_fWorldRotY -= m_fElapsedTime;

	if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
		m_fWorldRotX += m_fElapsedTime;
	else
	if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
		m_fWorldRotX -= m_fElapsedTime;

    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );

    D3DXMatrixMultiply( &m_mWorld, &matRotY, &matRotX );
	
	//---------------------------------------------------------
	// Update view matrix(�r���[�s��̐ݒ�)
	//---------------------------------------------------------
	// Zoom(�Y�[��)
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;

    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.3f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vFromPt, &vLookatPt, &vUpVec );

	//---------------------------------------------------------
	// Change the shader(�V�F�[�_�̕ύX)
	//---------------------------------------------------------
    if( m_UserInput.bChangeShader ) m_Shader = (m_Shader + 1) % 3;

	//---------------------------------------------------------
	// Pause(�|�[�Y)
	//---------------------------------------------------------
	if( m_UserInput.bPause ) m_bPause = !m_bPause;

	//---------------------------------------------------------
	// Move the ball (�ʂ̈ړ�)
	//---------------------------------------------------------
	if( !m_bPause )
	{
		D3DXVec3Normalize( &m_vel, &m_vel );
		D3DXVec3Scale( &m_vel, &m_vel, 10 );
//		m_pos += m_vel * this->m_fElapsedTime;
		m_rot.y += 1.0 * this->m_fElapsedTime;
		m_rot.y = (float)fmod(m_rot.y, 2.0f*D3DX_PI);

		float size = 5.0f - 1.0f;

		if( m_pos.x < -size )
		{
			m_pos.x = -size;
			m_vel.x *= -1;
		}
		if( size < m_pos.x )
		{
			m_pos.x = size;
			m_vel.x *= -1;
		}
		if( m_pos.y < -size )
		{
			m_pos.y = -size;
			m_vel.y *= -1;
		}
		if( size < m_pos.y )
		{
			m_pos.y = size;
			m_vel.y *= -1;
		}
		if( m_pos.z < -size )
		{
			m_pos.z = -size;
			m_vel.z *= -1;
		}
		if( size < m_pos.z )
		{
			m_pos.z = size;
			m_vel.z *= -1;
		}
		// rotation of environment
		m_EnvRate += 0.1f * this->m_fElapsedTime;
		while(1.0f<m_EnvRate)
		{
			m_EnvRate -= 1.0f;
			for(DWORD i=0;i<3;i++)
			{
				m_EnvRot[i] = m_EnvRot[i+1];
			}
			m_EnvRot[3] = D3DXVECTOR3( 2.0*D3DX_PI*frand(),
										2.0*D3DX_PI*frand(),
										2.0*D3DX_PI*frand() );
		}

		D3DXVECTOR3 v;
		CatmullRom( &v, m_EnvRot+0, m_EnvRot+1, m_EnvRot+2, m_EnvRot+3, m_EnvRate);
		D3DXMATRIX mx,my,mz;
		D3DXMatrixRotationX( &mx, v.x );
		D3DXMatrixRotationY( &my, v.y );
		D3DXMatrixRotationZ( &mz, v.z );
		m_mEnv = mx*my*mz;
	}

 	//---------------------------------------------------------
	// Reflectivity
	//---------------------------------------------------------
    if( m_UserInput.bDiffuseUp && !m_UserInput.bDiffuseDown )
        m_fDiffuse += min(0.1f,m_fElapsedTime);
    else if( m_UserInput.bDiffuseDown && !m_UserInput.bDiffuseUp )
        m_fDiffuse -= min(0.1f,m_fElapsedTime);
	if(m_fDiffuse<0)m_fDiffuse=0;

    if( m_UserInput.bSpecularUp && !m_UserInput.bSpecularDown )
        m_fSpecular += min(0.1f,m_fElapsedTime);
    else if( m_UserInput.bSpecularDown && !m_UserInput.bSpecularUp )
        m_fSpecular -= min(0.1f,m_fElapsedTime);
	if(m_fSpecular<0)m_fSpecular=0;

    if( m_UserInput.bTranslucentUp && !m_UserInput.bTranslucentDown )
        m_fTranslucent += min(0.1f,m_fElapsedTime);
    else if( m_UserInput.bTranslucentDown && !m_UserInput.bTranslucentUp )
        m_fTranslucent -= min(0.1f,m_fElapsedTime);
	if(m_fTranslucent<0)m_fTranslucent=0;

	return S_OK;
}
//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: Update the user input.  Called once per frame 
//       (���̓f�[�^���X�V����)
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
	pUserInput->bPause           = ( m_bActive && (GetAsyncKeyState( 'P'      ) & 0x8001) == 0x8001 );
	pUserInput->bChangeShader    = ( m_bActive && (GetAsyncKeyState( 'Q'      ) & 0x8001) == 0x8001 );

	pUserInput->bRotateUp        = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown      = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft      = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight     = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
    
	pUserInput->bZoomIn          = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut         = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );
    
	pUserInput->bDiffuseUp       = ( m_bActive && (GetAsyncKeyState( 'D'     )  & 0x8000) == 0x8000 );
    pUserInput->bDiffuseDown     = ( m_bActive && (GetAsyncKeyState( 'C'      ) & 0x8000) == 0x8000 );
	pUserInput->bSpecularUp      = ( m_bActive && (GetAsyncKeyState( 'F'     )  & 0x8000) == 0x8000 );
    pUserInput->bSpecularDown    = ( m_bActive && (GetAsyncKeyState( 'V'      ) & 0x8000) == 0x8000 );
	pUserInput->bTranslucentUp   = ( m_bActive && (GetAsyncKeyState( 'G'     )  & 0x8000) == 0x8000 );
    pUserInput->bTranslucentDown = ( m_bActive && (GetAsyncKeyState( 'B'      ) & 0x8000) == 0x8000 );
}



//-------------------------------------------------------------
// Name: FrameMoveCreateMap()
// Desc: Create height map and normal map
//       (�ʒu�A�@���}�b�v���쐬����B)
//-------------------------------------------------------------
int CMyD3DApplication::FrameMoveCreateMap()
{
	// �Q��ڂ̈ȍ~�͎��̏����Ɉڂ�
	if(1<m_iCount) return 1;

	return 0;
}

//-------------------------------------------------------------
// Name: RenderCreateMap()
// Desc: Create height map and normal map
//       (�ʒu�A�@���}�b�v���쐬����B)
//-------------------------------------------------------------
void CMyD3DApplication::RenderCreateMap()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;

    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ύX
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pPosSurf);
		m_pd3dDevice->SetRenderTarget(1, m_pNormalSurf);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		D3DVIEWPORT9 viewport_height = {0,0      // ����̍��W
						, DECALE_MAP_SIZE  // ��
						, DECALE_MAP_SIZE // ����
						, 0.0f,1.0f};     // �O�ʁA���
		m_pd3dDevice->SetViewport(&viewport_height);

		//-------------------------------------------------
		// �t���[���o�b�t�@�̃N���A
		//-------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET
						, 0xffffffff, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

			//-------------------------------------------------
			// ���f���̕`��
			//-------------------------------------------------
			BEGIN_PASS(10);
			m_pMesh->Render(m_pd3dDevice);
			END_PASS();

			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

			m_pEffect->End();
		}

		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		//-----------------------------------------------------
		// ���܂����̉��
		//-----------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		m_pd3dDevice->EndScene();
	}
}


//-------------------------------------------------------------
// Name: FrameMoveSSPRT()
// Desc: �ʒu�A�@���}�b�v���쐬����B
//-------------------------------------------------------------
static int itex=0;
static int ix=0;
static int iy=0;
static float pos[DECALE_MAP_SIZE][DECALE_MAP_SIZE][3];
static float normal[DECALE_MAP_SIZE][DECALE_MAP_SIZE][3];
int CMyD3DApplication::FrameMoveSSPRT()
{
	itex = this->m_iCount / (DECALE_MAP_SIZE*DECALE_MAP_SIZE);
	ix = this->m_iCount % DECALE_MAP_SIZE;
	iy = (this->m_iCount / DECALE_MAP_SIZE) % DECALE_MAP_SIZE;
	
	if(0==this->m_iCount){
		D3DLOCKED_RECT d3dlr;
		float *p;
		m_pd3dDevice->GetRenderTargetData(m_pPosSurf,m_pPosLockSurf);
		m_pPosLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;
		for(int y=0;y<DECALE_MAP_SIZE;y++){
		for(int x=0;x<DECALE_MAP_SIZE;x++){
			pos[x][y][0]=p[0];
			pos[x][y][1]=p[1];
			pos[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pPosLockSurf->UnlockRect();

		m_pd3dDevice->GetRenderTargetData(m_pNormalSurf,m_pNormalLockSurf);
		m_pNormalLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;        
		for( y=0;y<DECALE_MAP_SIZE;y++){
		for( int x=0;x<DECALE_MAP_SIZE;x++){
			normal[x][y][0]=p[0];
			normal[x][y][1]=p[1];
			normal[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pNormalLockSurf->UnlockRect();
	}

	// �I������
	if(DECALE_MAP_SIZE-1==ix && DECALE_MAP_SIZE-1==iy && TEX_MAX-1==itex) return 1;

	return 0;
}


//-------------------------------------------------------------
// Name: RenderSSPRT()
// Desc: ���ꂼ��̈ʒu����̃��f�B�A���X���v�Z����B
//-------------------------------------------------------------
void CMyD3DApplication::RenderSSPRT()
{
	D3DXMATRIX m, mView;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DSURFACE_DESC d3dsd;

	D3DVIEWPORT9 viewport = {0,0      // ����̍��W
					, 1, 1  // ��,����
					, 0.0f,1.0f};     // �O�ʁA���

	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		//-------------------------------------------------
		// �e�_���猩�����f�B�A���X�̕`��
		//-------------------------------------------------
		//-------------------------------------------------

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ύX
		//-------------------------------------------------
		// �r���[�|�[�g�̕ύX
		m_pReductionSurf[0]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �d�݂��������̕��������`��
			//-------------------------------------------------
			float x[3] = {pos[ix][iy][0], pos[ix][iy][1], pos[ix][iy][2]};
			float n[3] = {normal[ix][iy][0], normal[ix][iy][1], normal[ix][iy][2]};
			D3DXVECTOR3 vFromPt   = D3DXVECTOR3( x[0], x[1], x[2] ) - 0.05f*D3DXVECTOR3( n[0], n[1], n[2] );
			D3DXVECTOR3 vLookatPt = D3DXVECTOR3( -n[0], -n[1], -n[2] ) + vFromPt;
			D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			D3DXMatrixLookAtLH( &mView, &vFromPt, &vLookatPt, &vUpVec );
			m_pEffect->SetMatrix( "mWV", &mView );

			D3DXMatrixTranspose(&m, &mView);
			m_pEffect->SetMatrix( "mST", &m );

			// �V�F�[�_�̐ݒ�
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// ���f���̕`��
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_p64Surf2 );
			m_pd3dDevice->SetDepthStencilSurface( m_p64Z );
			m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xffffffff, 1.0f, 0L);
			BEGIN_PASS(16);
			m_pMesh->Render(m_pd3dDevice);
			END_PASS();

			//-------------------------------------------------
			// SH�W���̕`��
			//-------------------------------------------------
			TVERTEX Vertex[4] = {
				// x  y  z tu tv
				{-1,-1,0,  0, 0,},
				{+1,-1,0,  1, 0,},
				{+1,+1,0,  1, 1,},
				{-1,+1,0,  0, 1,},
			};
			m_pd3dDevice->SetRenderTarget(0, m_p64Surf );
			m_pd3dDevice->SetDepthStencilSurface(NULL);
			m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
			m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture(m_htSrcTex, m_pMaskTex);
			m_pEffect->SetTexture( "SSTex", m_p64Tex2 );
			BEGIN_PASS( 17 + itex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
		}
		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���~�b�v�}�b�v�̗v�̂ŏ���������
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget( 0, m_p8Surf );
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_p8Surf->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			m_pEffect->SetFloat( m_fWidth,  64);
			m_pEffect->SetFloat( m_fHeight, 64);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{-1.0f, +1.0f, 0.1f,  0, 0},
				{+1.0f, +1.0f, 0.1f,  1, 0},
				{+1.0f, -1.0f, 0.1f,  1, 1},
				{-1.0f, -1.0f, 0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcTex, m_p64Tex );
			BEGIN_PASS( 3 );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
		}

		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���e�N�X�`���̑Ή�����ʒu�ɒ���
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pFinalSSSurf[itex]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_pFinalSSSurf[itex]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);
		
		// �ŏ��͊D�F�œh��Ԃ�
		if(0==ix&&0==iy)m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, 0x80808080, 1.0f, 0L);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			m_pEffect->SetFloat( m_fWidth,  8);
			m_pEffect->SetFloat( m_fHeight, 8);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			float x =  2.0f*((float)ix/(float)DECALE_MAP_SIZE) - 1.0f;
			float y = -2.0f*((float)iy/(float)DECALE_MAP_SIZE) + 1.0f;
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{x,                      y,                     0.1f,  0, 0},
				{x+2.0f/(float)DECALE_MAP_SIZE, y,                     0.1f,  1, 0},
				{x+2.0f/(float)DECALE_MAP_SIZE, y-2.0f/(float)DECALE_MAP_SIZE,0.1f,  1, 1},
				{x,                      y-2.0f/(float)DECALE_MAP_SIZE,0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcTex, m_p8Tex );
			BEGIN_PASS(3);
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
		}

		
		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

		//---------------------------------------------------------
		// ��ʂ̕\��
		//---------------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x00001020, 1.0f, 0L);

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 256.0f*2/3;
		for(DWORD i=0; i<3; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pFinalSSTex[itex] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_p64Tex );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_p8Tex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
		TCHAR szMsg[MAX_PATH] = TEXT("");

		sprintf( szMsg, TEXT("Precomputing 1/2\nx:%4d\ny:%4d"), ix, iy);
		m_pFont->DrawText( 2, (FLOAT)m_d3dsdBackBuffer.Height-60, fontColor, szMsg );

		m_pd3dDevice->EndScene();
	}
}


//-------------------------------------------------------------
// Name: FrameMovePRT()
// Desc: �ʒu�A�@���}�b�v���쐬����B
//-------------------------------------------------------------
int CMyD3DApplication::FrameMovePRT()
{
	itex = this->m_iCount / (DECALE_MAP_SIZE*DECALE_MAP_SIZE);
	ix = this->m_iCount % DECALE_MAP_SIZE;
	iy = (this->m_iCount / DECALE_MAP_SIZE) % DECALE_MAP_SIZE;
	
	if(0==this->m_iCount){
#if 0
		D3DLOCKED_RECT d3dlr;
		float *p;
		m_pd3dDevice->GetRenderTargetData(m_pPosSurf,m_pPosLockSurf);
		m_pPosLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;
		for(int y=0;y<DECALE_MAP_SIZE;y++){
		for(int x=0;x<DECALE_MAP_SIZE;x++){
			pos[x][y][0]=p[0];
			pos[x][y][1]=p[1];
			pos[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pPosLockSurf->UnlockRect();

		m_pd3dDevice->GetRenderTargetData(m_pNormalSurf,m_pNormalLockSurf);
		m_pNormalLockSurf->LockRect(&d3dlr,NULL,D3DLOCK_READONLY); //�T�[�t�F�C�X��̋�`�����b�N    
		p = (float *)d3dlr.pBits;        
		for( y=0;y<DECALE_MAP_SIZE;y++){
		for( int x=0;x<DECALE_MAP_SIZE;x++){
			normal[x][y][0]=p[0];
			normal[x][y][1]=p[1];
			normal[x][y][2]=p[2];
			p+=4;
		}
		}
		m_pNormalLockSurf->UnlockRect();
#endif
	}

	// �I������
	if(DECALE_MAP_SIZE-1==ix && DECALE_MAP_SIZE-1==iy && TEX_MAX-1==itex) return 1;

	return 0;
}


//-------------------------------------------------------------
// Name: RenderPRT()
// Desc: ���ꂼ��̈ʒu����̃��f�B�A���X���v�Z����B
//-------------------------------------------------------------
void CMyD3DApplication::RenderPRT()
{
	D3DXMATRIX m, mView;
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DSURFACE_DESC d3dsd;

	D3DVIEWPORT9 viewport = {0,0      // ����̍��W
					, 1, 1  // ��,����
					, 0.0f,1.0f};     // �O�ʁA���

	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ۑ�
		//-------------------------------------------------
		m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
		m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
		m_pd3dDevice->GetViewport(&oldViewport);

		//-------------------------------------------------
		//-------------------------------------------------
		// �e�_���猩�����f�B�A���X�̕`��
		//-------------------------------------------------
		//-------------------------------------------------

		//-------------------------------------------------
		// �����_�����O�^�[�Q�b�g�̕ύX
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_p64Surf );
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_p64Surf->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// �d�݂��������̕��������`��
			//-------------------------------------------------
			float x[3] = {pos[ix][iy][0], pos[ix][iy][1], pos[ix][iy][2]};
			float n[3] = {normal[ix][iy][0], normal[ix][iy][1], normal[ix][iy][2]};
			D3DXVECTOR3 vFromPt   = D3DXVECTOR3( x[0], x[1], x[2] ) + 0.01f*D3DXVECTOR3( n[0], n[1], n[2] );
			D3DXVECTOR3 vLookatPt = D3DXVECTOR3( n[0], n[1], n[2] ) + vFromPt;
			D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			D3DXMatrixLookAtLH( &mView, &vFromPt, &vLookatPt, &vUpVec );
			m_pEffect->SetMatrix( "mWV", &mView );

			D3DXMatrixTranspose(&m, &mView);
			m_pEffect->SetMatrix( "mST", &m );

			// �V�F�[�_�̐ݒ�
			m_pEffect->SetTechnique( "TShader" );
			m_pEffect->Begin( NULL, 0 );

			TVERTEX Vertex[4] = {
				// x  y  z tu tv
				{-1,-1,0,  0, 0,},
				{+1,-1,0,  1, 0,},
				{+1,+1,0,  1, 1,},
				{-1,+1,0,  0, 1,},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture(m_htSrcTex, m_pMaskTex);
			BEGIN_PASS( 11 + itex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			END_PASS();

			//-------------------------------------------------
			// ���f���̕`��
			//-------------------------------------------------
			BEGIN_PASS( 15 );
			m_pMesh->Render(m_pd3dDevice);
			END_PASS();
			m_pEffect->End();
		}
		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���~�b�v�}�b�v�̗v�̂ŏ���������
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget( 0, m_p8Surf );
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_p8Surf->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			m_pEffect->SetFloat( m_fWidth,  64);
			m_pEffect->SetFloat( m_fHeight, 64);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{-1.0f, +1.0f, 0.1f,  0, 0},
				{+1.0f, +1.0f, 0.1f,  1, 0},
				{+1.0f, -1.0f, 0.1f,  1, 1},
				{-1.0f, -1.0f, 0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcTex, m_p64Tex );
			BEGIN_PASS( 3 );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
		}

		//-------------------------------------------------
		//-------------------------------------------------
		// ���f�B�A���X���e�N�X�`���̑Ή�����ʒu�ɒ���
		//-------------------------------------------------
		//-------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, m_pFinalSurf[itex]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		// �r���[�|�[�g�̕ύX
		m_pFinalSurf[itex]->GetDesc(&d3dsd);
		viewport.Height = d3dsd.Width;
		viewport.Width  = d3dsd.Height;
		m_pd3dDevice->SetViewport(&viewport);
		
		// �ŏ��͊D�F�œh��Ԃ�
		if(0==ix&&0==iy)m_pd3dDevice->Clear(0L, NULL, D3DCLEAR_TARGET, 0x80808080, 1.0f, 0L);

		if( m_pEffect != NULL ) {
			//-------------------------------------------------
			// �V�F�[�_�̐ݒ�
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			m_pEffect->SetFloat( m_fWidth,  8);
			m_pEffect->SetFloat( m_fHeight, 8);

			//-------------------------------------------------
			// �t�B���^�����O
			//-------------------------------------------------
			float x =  2.0f*((float)ix/(float)DECALE_MAP_SIZE) - 1.0f;
			float y = -2.0f*((float)iy/(float)DECALE_MAP_SIZE) + 1.0f;
			TVERTEX Vertex1[4] = {
				//   x    y     z    tu tv
				{x,                      y,                     0.1f,  0, 0},
				{x+2.0f/(float)DECALE_MAP_SIZE, y,                     0.1f,  1, 0},
				{x+2.0f/(float)DECALE_MAP_SIZE, y-2.0f/(float)DECALE_MAP_SIZE,0.1f,  1, 1},
				{x,                      y-2.0f/(float)DECALE_MAP_SIZE,0.1f,  0, 1},
			};
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
			m_pEffect->SetTexture( m_htSrcTex, m_p8Tex );
			BEGIN_PASS( 3 );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
							, 2, Vertex1, sizeof( TVERTEX ) );
			END_PASS();

			m_pEffect->End();
		}

		
		//-----------------------------------------------------
		// �����_�����O�^�[�Q�b�g�����ɖ߂�
		//-----------------------------------------------------
		m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
		m_pd3dDevice->SetRenderTarget(1, NULL);
		m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
		m_pd3dDevice->SetViewport(&oldViewport);
		pOldBackBuffer->Release();
		pOldZBuffer->Release();

		m_pd3dDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
		m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

		//---------------------------------------------------------
		// ��ʂ̕\��
		//---------------------------------------------------------
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0x00001020, 1.0f, 0L);

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pd3dDevice->SetPixelShader(0);
		float scale = 256.0f*2/3;
		for(DWORD i=0; i<3; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pFinalTex[itex] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_p64Tex );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_p8Tex );
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

		D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
		TCHAR szMsg[MAX_PATH] = TEXT("");

		sprintf( szMsg, TEXT("Precomputing 2/2\nx:%4d\ny:%4d"), ix, iy);
		m_pFont->DrawText( 2, (FLOAT)m_d3dsdBackBuffer.Height-60, fontColor, szMsg );

		m_pd3dDevice->EndScene();
	}
}


//-------------------------------------------------------------
// Name: RenderParaboloidMap()
//-------------------------------------------------------------
void CMyD3DApplication::RenderParaboloidMap()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DMATERIAL9 *pMtrl;
	int i, j, k;
    D3DXMATRIX m, mT, mR, mW, mView, mProj;
    D3DXVECTOR3 vFrom;
    D3DXVECTOR3 vLookat;
    D3DXVECTOR3 vUpVec;

	D3DVIEWPORT9 viewport = {0, 0   // x,y(����̍��W)
					, 1, 1			// width, height(��,����)
					, 0.0f,1.0f};   // near, far(�O�ʁA���)

	//-------------------------------------------------
	// Backup rendering target(�����_�����O�^�[�Q�b�g�̕ۑ�)
	//-------------------------------------------------
	m_pd3dDevice->GetRenderTarget( 0, &pOldBackBuffer );
	m_pd3dDevice->GetDepthStencilSurface( &pOldZBuffer );
	m_pd3dDevice->GetViewport( &oldViewport );
	
	//-------------------------------------------------
	// Create environment map(���}�b�v�̍쐬)
	//-------------------------------------------------
	if( m_pEffect != NULL ) 
	{
		// Set shader
		m_pEffect->SetTechnique( m_hTechnique );
		m_pEffect->Begin( NULL, 0 );

		for( i = 0; i < 2; i++ )
		{
			// Chenge rendering target
			m_pd3dDevice->SetRenderTarget( 0, m_pParaboloidSurf[i] );
			m_pd3dDevice->SetDepthStencilSurface( m_pMapZ );
			viewport.Width  = viewport.Height = MAP_SIZE;
			m_pd3dDevice->SetViewport( &viewport );
			
			// Clear the scene
			m_pd3dDevice->Clear(0L, NULL
				, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
				, 0xff000000, 1.0f, 0L);
			
			// Create view matrix

			// Set matrixs(�s��̐ݒ�)
			D3DXMatrixRotationX( &mW, m_rot.x );
			D3DXMatrixRotationY( &mR, m_rot.y );
			mW = mW * mR;
			D3DXMatrixRotationZ( &mR, m_rot.z );
			mW = mW * mR;
			D3DXMatrixTranslation( &mT, m_pos.x, m_pos.y, m_pos.z );
			mW = mW * mT;

			vFrom   = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			D3DXVec3TransformCoord( &vFrom, &vFrom, &mW);
			switch(i)
			{
			case 0:
				// Front of view(�O��)
				vLookat = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
				break;
			case 1:
				// Back of view(���)
				vLookat = D3DXVECTOR3( 0.0f, 0.0f, -1.0f );
				break;
			}
			D3DXVec3TransformCoord( &vLookat, &vLookat, &mW);
			vUpVec  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
			D3DXVec3TransformCoord( &vUpVec, &vUpVec, &mW);
			vUpVec -= vFrom;
			D3DXMatrixLookAtLH( &mView, &vFrom, &vLookat, &vUpVec );

			// Render ground(�n�ʂ̕`��)
			m = mView;
			D3DXMatrixTranslation( &mT, 0, -3, 0 );
			m = mT * m;
//D3DXMatrixTranslation( &mT, 0, -2, 0 );
//D3DXMatrixRotationZ( &m, 0.5*D3DX_PI );
//m = mT * m * mView;
			m_pEffect->SetMatrix( m_hmWV, &m );

			pMtrl = m_pMeshBg->m_pMaterials;
			for( unsigned int s=0; s<m_pMeshBg->m_dwNumMaterials; s++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[s] );
				BEGIN_PASS( 4 );
				m_pMeshBg->m_pLocalMesh->DrawSubset( s );
				END_PASS();
				pMtrl++;
			}
			
			// Render back sphere(�V���̕`��)
			D3DXMatrixScaling ( &m, 100, 100, 100 );
			m = m_mEnv * m * mView;
			m_pEffect->SetMatrix( m_hmWV, &m );
			
			pMtrl = m_pMeshEnv->m_pMaterials;
			for( s=0; s<m_pMeshEnv->m_dwNumMaterials; s++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshEnv->m_pTextures[s] );
				BEGIN_PASS( 4 );
				m_pMeshEnv->m_pLocalMesh->DrawSubset( s );
				END_PASS();
				pMtrl++;
			}
		}
		//-------------------------------------------------
		// Reduction in the way of a mip-map.(�~�b�v�}�b�v�̗v�̂ŏ���������)
		//-------------------------------------------------

		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[0]);
		m_pd3dDevice->SetDepthStencilSurface(NULL);
		viewport.Width  = viewport.Height = 128;
		m_pd3dDevice->SetViewport(&viewport);
		
		// Reduces to the screen divided into four by 1/2,
		// and both sides are compounded by multiplying the SH coefficient
		// (�S����������ʂ�1/2�k�����ė��ʂ�SH�W���ō�������)
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX2 );
		m_pEffect->SetTexture( "ParaboloidFrontTex", m_pParaboloidTex[0] );
		m_pEffect->SetTexture( "ParaboloidBackTex",  m_pParaboloidTex[1] );
		m_pEffect->SetTexture( "WeightTexFront", m_pJacobianTex[0][0] );
		m_pEffect->SetTexture( "WeightTexBack", m_pJacobianTex[0][1] );
		float scale = 64;
		int pass = 6;
		for( j = 0; j < 2; j++)
		{
			for( k = 0; k < 2; k++)
			{
				TVERTEX Vertex[4] = {
					//    x           y       z rhw  tu       tv
					{(j+0)*scale,(k+0)*scale, 0, 1, 0+1/128, 0+1/128 },
					{(j+1)*scale,(k+0)*scale, 0, 1, 1+1/128, 0+1/128 },
					{(j+1)*scale,(k+1)*scale, 0, 1, 1+1/128, 1+1/128 },
					{(j+0)*scale,(k+1)*scale, 0, 1, 0+1/128, 1+1/128 },
				};
				BEGIN_PASS( pass++ );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
				END_PASS();
			}
		}


		// 2nd reduction (16x16) (2�i�K)
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[1]);
		viewport.Width  = viewport.Height = 16;
		m_pd3dDevice->SetViewport(&viewport);

		TVERTEX Vertex1[4] = {
			//   x    y     z    tu tv
			{-1.0f, +1.0f, 0.5f,  0, 0},
			{+1.0f, +1.0f, 0.5f,  1, 0},
			{+1.0f, -1.0f, 0.5f,  1, 1},
			{-1.0f, -1.0f, 0.5f,  0, 1},
		};
		m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

		m_pEffect->SetFloat( m_fWidth,  128 );
		m_pEffect->SetFloat( m_fHeight, 128 );
		m_pEffect->SetTexture( m_htSrcTex, m_pReductionTex[0] );
		BEGIN_PASS( 3 );
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, Vertex1, sizeof( TVERTEX ) );
		END_PASS();


		// 3rd reduction (2x2) (3�i�K)
		m_pd3dDevice->SetRenderTarget(0, m_pReductionSurf[2]);
		viewport.Width  = viewport.Height = 2;
		m_pd3dDevice->SetViewport(&viewport);

		m_pEffect->SetFloat( m_fWidth,  16 );
		m_pEffect->SetFloat( m_fHeight, 16 );
		m_pEffect->SetTexture(m_htSrcTex, m_pReductionTex[1]);
		BEGIN_PASS( 3 );
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN
						, 2, Vertex1, sizeof( TVERTEX ) );
		END_PASS();

		m_pEffect->End();
	}


	//-----------------------------------------------------
    // Restore render target
	// (�����_�����O�^�[�Q�b�g�����ɖ߂�)
	//-----------------------------------------------------
	m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
	m_pd3dDevice->SetRenderTarget(1, NULL);
	m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
	m_pd3dDevice->SetViewport(&oldViewport);
	pOldBackBuffer->Release();
	pOldZBuffer->Release();

}
//-------------------------------------------------------------
// Name: Render()
// Desc: Called once per frame, the call is the entry point for 3d
//       rendering. This function sets up render states, clears the
//       viewport, and renders the scene.
//       (��ʂ�`�悷��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
    D3DXMATRIX m, mT, mR, mView, mProj;
	DWORD i;
	D3DXVECTOR4 v;
	D3DMATERIAL9 *pMtrl;

	switch(m_iState){
	case 0:
		this->RenderCreateMap();
		return S_OK;
	case 1:
		this->RenderSSPRT();
		return S_OK;
	case 2:
		this->RenderPRT();
		return S_OK;
	default:
		break;
	}


	// Begin the scene(�`��J�n)
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
		//---------------------------------------------------------
		// Create maps(�e�N�X�`���̐���)
		//---------------------------------------------------------
		RenderParaboloidMap();

	    // Clear the render buffers(�t���[���o�b�t�@�̃N���A)
		m_pd3dDevice->Clear(0L, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER
						, 0xff000000, 1.0f, 0L);

		if( m_pEffect != NULL ) 
		{
			//-------------------------------------------------
			// Set effect(�V�F�[�_�̐ݒ�)
			//-------------------------------------------------
			m_pEffect->SetTechnique( m_hTechnique );
			m_pEffect->Begin( NULL, 0 );

			//-------------------------------------------------
			// Render model (���f���̕`��)
			//-------------------------------------------------
			// Set matrixs(�s��̐ݒ�)
			D3DXMatrixRotationX( &mR, m_rot.x );
			D3DXMatrixRotationY( &m, m_rot.y );
			mR = mR * m;
			D3DXMatrixRotationZ( &m, m_rot.z );
			mR = mR * m;
			D3DXMatrixTranslation( &mT, m_pos.x, m_pos.y, m_pos.z );
			m = mR * mT * m_mWorld * m_mView;
			m_pEffect->SetMatrix( m_hmWV, &m );
			m = m * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			// View point in the local coordinate system(���[�J���ł̎��_)
			m = mR * mT * m_mWorld * m_mView;
            D3DXMatrixInverse( &m, NULL, &m);
			v = D3DXVECTOR4( 0, 0, 0, 1 );
            D3DXVec4Transform( &v, &v, &m);
			m_pEffect->SetVector( "vEye", &v );

			m_pEffect->SetFloat( "diffuse", m_fDiffuse );
			m_pEffect->SetFloat( "specular", m_fSpecular );
			m_pEffect->SetFloat( "translucent", m_fTranslucent );

			// Set the texture and render
			m_pEffect->SetTexture( "ParaboloidFrontTex", m_pParaboloidTex[0] );
			m_pEffect->SetTexture( "ParaboloidBackTex",  m_pParaboloidTex[1] );
			m_pEffect->SetTexture( m_htSrcTex, m_pReductionTex[2]);

			m_pEffect->SetTexture( "PRTTex",  m_pFinalTex[0] );
			m_pEffect->SetTexture( "SSTex",   m_pFinalSSTex[0] );
			
			m_pEffect->SetTexture( "DecaleTex",  m_pMesh->m_pTextures[0] );
			BEGIN_PASS( 0+m_Shader );
			m_pMesh->Render( m_pd3dDevice );
			END_PASS();

			//-------------------------------------------------
			// Render ground(�n�`�̕`��)
			//-------------------------------------------------
			// World+view+projection matrix(���[�J��-�ˉe�s��)
			m = m_mWorld * m_mView * m_mProj;
			D3DXMatrixTranslation( &mT, 0, -3, 0 );
			m = mT * m;
//D3DXMatrixTranslation( &mT, 0, -2, 0 );
//D3DXMatrixRotationZ( &m, 0.5*D3DX_PI );
//m = mT * m * m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// Set the texture and render(�e�N�X�`����ݒ肵�ĕ`��)
			pMtrl = m_pMeshBg->m_pMaterials;
			for( i=0; i<m_pMeshBg->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshBg->m_pTextures[i] );
				BEGIN_PASS( 5 );
				m_pMeshBg->m_pLocalMesh->DrawSubset( i );
				END_PASS();
				pMtrl++;
			}

			//-------------------------------------------------
			// Render back sphere(�V���̕`��)
			//-------------------------------------------------
			// World+view+projection matrix(���[�J��-�ˉe�s��)
			D3DXMatrixScaling ( &m, 100, 100, 100 );
			m = m * m_mEnv * m_mWorld * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );
			
			// Set the texture and render(�e�N�X�`����ݒ肵�ĕ`��)
			pMtrl = m_pMeshEnv->m_pMaterials;
			for( i=0; i<m_pMeshEnv->m_dwNumMaterials; i++ ) {
				m_pEffect->SetTexture(m_htSrcTex, m_pMeshEnv->m_pTextures[i] );
				BEGIN_PASS( 5 );
				m_pMeshEnv->m_pLocalMesh->DrawSubset( i );
				END_PASS();
				pMtrl++;
			}

			m_pEffect->End();
		}

#ifdef _DEBUG // Textures are displaying when debugging, (�f�o�b�O�p�Ƀe�N�X�`����\������)
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		float scale = 512.0f/11;
		for(DWORD i=0; i<11; i++){
			TVERTEX Vertex[4] = {
				//    x                             y         z rhw tu tv
				{(i+0)*scale, (FLOAT)m_d3dsdBackBuffer.Height-scale, 0, 1, 0, 0,},
				{(i+1)*scale, (FLOAT)m_d3dsdBackBuffer.Height-scale, 0, 1, 1, 0,},
				{(i+1)*scale, (FLOAT)m_d3dsdBackBuffer.Height-    0, 0, 1, 1, 1,},
				{(i+0)*scale, (FLOAT)m_d3dsdBackBuffer.Height-    0, 0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[0] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pParaboloidTex[1] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pJacobianTex[0][0] );
			if(3==i) m_pd3dDevice->SetTexture( 0, m_pJacobianTex[0][1] );
			if(4==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[0] );
			if(5==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[1] );
			if(6==i) m_pd3dDevice->SetTexture( 0, m_pReductionTex[2] );
			if(7==i) m_pd3dDevice->SetTexture( 0, m_pPosTex );
			if(8==i) m_pd3dDevice->SetTexture( 0, m_pNormalTex );
			if(9==i) m_pd3dDevice->SetTexture( 0, m_pFinalSSTex[0] );
			if(10==i) m_pd3dDevice->SetTexture( 0, m_pFinalTex[0] );

			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		

        // Render stats and help text(�w���v�̕\��)
        RenderText();

		// End the scene.(�`��̏I��)
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: Draw the help & statistics for running sample
//       (��Ԃ�w���v����ʂɕ\������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");
    FLOAT fNextLine;

    // Draw help
    fNextLine = 0; 

	static const TCHAR *shader_str[]=
	{
		"Diffuse+Translucent+Specular",
		"Diffuse",
		"Translucent",
	};

	sprintf( szMsg, TEXT("Press 'Q' to change shader[%s]"), shader_str[m_Shader] );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

	sprintf( szMsg, TEXT("Diffuse[D-C] : %f"), m_fDiffuse );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

	sprintf( szMsg, TEXT("Specular[F-V] : %f"), m_fSpecular );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

	sprintf( szMsg, TEXT("Translucent[G-B] : %f"), m_fTranslucent );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;

    // Output statistics
    lstrcpy( szMsg, m_strDeviceStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
    lstrcpy( szMsg, m_strFrameStats );
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    fNextLine += 20.0f;
	
#ifndef _DEBUG
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height-20; 
    m_pFont->DrawText( 6, fNextLine+2, 0xff000000, TEXT("t-pot.com") );
    m_pFont->DrawText( 4, fNextLine,   0xffff8040, TEXT("t-pot.com") );
#endif //!_DEBUG

	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: Overrrides the main WndProc, so the sample can do custom message
//       handling (e.g. processing mouse, keyboard, or menu commands).
//       (WndProc ���I�[�o�[���C�h��������)
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Loading message(���[�h��)
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct
                		, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: Invalidates device objects.  Paired with RestoreDeviceObjects()
//       (RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	int i;

	// font(�t�H���g)
    m_pFont->InvalidateDeviceObjects();

	// Rendering targets (�����_�����O�^�[�Q�b�g)
	for(int j=0;j<TEX_MAX;j++){
		SAFE_RELEASE(m_pFinalSSSurf[j]);
		SAFE_RELEASE(m_pFinalSSTex[j]);
		SAFE_RELEASE(m_pFinalSurf[j]);
		SAFE_RELEASE(m_pFinalTex[j]);
	}
	SAFE_RELEASE( m_p8Surf );
	SAFE_RELEASE( m_p8Tex );
	SAFE_RELEASE( m_p64Z );
	SAFE_RELEASE( m_p64Surf2 );
	SAFE_RELEASE( m_p64Tex2 );
	SAFE_RELEASE( m_p64Surf );
	SAFE_RELEASE( m_p64Tex );
	for( i = 0; i < REDUCTION_MAPS; i++ )
	{
		SAFE_RELEASE(m_pReductionSurf[i]);
		SAFE_RELEASE(m_pReductionTex[i]);
	}
	SAFE_RELEASE(m_pMaskTex);
	SAFE_RELEASE(m_pParaboloidSurf[1]);
	SAFE_RELEASE(m_pParaboloidTex[1]);
	SAFE_RELEASE(m_pParaboloidSurf[0]);
	SAFE_RELEASE(m_pParaboloidTex[0]);
	SAFE_RELEASE(m_pNormalLockSurf);
	SAFE_RELEASE(m_pNormalLockTex);
	SAFE_RELEASE(m_pNormalSurf);
	SAFE_RELEASE(m_pNormalTex);
	SAFE_RELEASE(m_pPosLockSurf);
	SAFE_RELEASE(m_pPosLockTex);
	SAFE_RELEASE(m_pPosSurf);
	SAFE_RELEASE(m_pPosTex);
	SAFE_RELEASE(m_pMapZ);

	// Models(���f��)
	m_pMeshEnv->InvalidateDeviceObjects();
	m_pMeshBg->InvalidateDeviceObjects();
	m_pMesh->InvalidateDeviceObjects();
	
	// Shaders(�V�F�[�_)
    if( m_pEffect    != NULL ) m_pEffect   ->OnLostDevice();

	return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: Paired with InitDeviceObjects()
//       Called when the app is exiting, or the device is being changed,
//       this function deletes any device dependent objects.  
//       (InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// font(�t�H���g)
    m_pFont->DeleteDeviceObjects();

	// textures (�e�N�X�`��)
	for( int i = 0; i < TEX_MAX; i++ )
	{
		SAFE_RELEASE(m_pJacobianTex[i][0]);
		SAFE_RELEASE(m_pJacobianTex[i][1]);
	}

	// Shaders(�V�F�[�_)
	SAFE_RELEASE( m_pEffect );
	
	// Models(���f��)
	m_pMeshEnv->Destroy();
	m_pMeshBg->Destroy();
	m_pMesh->Destroy();

    return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//       (�I�����钼�O�ɌĂ΂��)
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	// font(�t�H���g)
    SAFE_DELETE( m_pFont );

	// Models(���f��)
    SAFE_DELETE( m_pMeshEnv );
    SAFE_DELETE( m_pMeshBg );
    SAFE_DELETE( m_pMesh );

    return S_OK;
}




