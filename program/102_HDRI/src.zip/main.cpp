//-----------------------------------------------------------------------------
// File: main.cpp
//
// Desc: �A�v���P�[�V�����\�[�X
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "hdr.h"
#include "main.h"



//-----------------------------------------------------------------------------
// �O���[�o���ϐ�
//-----------------------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;

//-----------------------------------------------------------------------------
// �N���X�̐ÓI�ϐ�
//-----------------------------------------------------------------------------
char CMyD3DApplication::BRDF_name[BRDF_MAX][256] = {
	"Cornell Garnet Red Duplicolor T-345 Paint",
	"Cornell Krylon Latex Enamel #7205, True Blue",
	"Cornell Cayman Blue Lacquer",
	"Cornell Mystique Lacquer",
	"CURET Velvet",
	"CURET Leather",
	"Analytic Anisotropic Poulin-Fournier \"Satin\"",
};

char CMyD3DApplication::BRDF_file[BRDF_MAX][2][256] = {
	{"garnetredp.bmp",	"garnetredq.bmp"},
	{"krylonbluep.bmp",	"krylonblueq.bmp"},
	{"caymanp.bmp",		"caymanq.bmp"},
	{"mystiquep.bmp",	"mystiqueq.bmp"},
	{"velvetp.bmp",		"velvetq.bmp"},
	{"leatherp.bmp",	"leatherq.bmp"},
	{"satinp.bmp",		"satinq.bmp"},
};

float CMyD3DApplication::BRDF_color[][4]= {
	{30*0.04324800f,   30*0.0725744f,   30*0.0527886f,   0},// Cornell Garnet Red Duplicolor T-345 Paint
	{20*11.4187000f,   20*0.0555595f,   20*0.0841939f,   0},// Cornell Krylon Latex Enamel #7205, True Blue
	{50*2.38849e-05f,  50*0.0185791f,   50*0.0232454f,   0},// Cornell Cayman Blue Lacquer
	{100*0.00096388f, 100*0.1627260f,  100*0.0199128f,   0},// Cornell Mystique Lacquer
	{20*0.03070830f,   20*0.000387719f, 20*9.24145e-07f, 0},//CURET Velvet
	{ 4*0.34032900f,    4*0.2709300f,    4*0.1450500f,   0},// CURET Leather
	{ 1*0.76236700f,    1*0.7623670f,    1*0.7623670f,   0},// Analytic Anisotropic Poulin-Fournier "Satin"
};
//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-----------------------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-----------------------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_nBrdf = BRDF_Garnet_Red;
	for(int i=0; i< BRDF_MAX; i++){
		m_pTex[i][0] = NULL;
		m_pTex[i][1] = NULL;
	}

	m_pEffect = NULL;

    m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
    m_pD3DXMesh                 = NULL;
	m_pEnvMap					= NULL;

    ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
    m_fWorldRotX                = -0.437504f;
    m_fWorldRotY                = 2.35087f;
	m_fViewZoom					= 5.0f;

    m_fLightRotX                = 1.57997f;
    m_fLightRotY                =-0.487442f;
}




//-----------------------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-----------------------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-----------------------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
	// �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(1,1) )
		return E_FAIL;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1)
    &&  0==(dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING) )
			return E_FAIL;
	
	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;
	LPCTSTR	pErrMsg;

	hr = HDR::CreateTextureFromFile(m_pd3dDevice, "galileo_probe.hdr", &pErrMsg, &m_pEnvMap);
	if(FAILED(hr)){
        MessageBox( NULL, pErrMsg, "ERROR", MB_OK);
	}

	// �e�N�X�`���̓ǂݍ���
	for(int i=0; i< BRDF_MAX; i++){
		D3DXCreateTextureFromFile(m_pd3dDevice, BRDF_file[i][0], &m_pTex[i][0]);
		D3DXCreateTextureFromFile(m_pd3dDevice, BRDF_file[i][1], &m_pTex[i][1]);
	}
    
	// �V�F�[�_�̓ǂݍ���
    LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
                m_pd3dDevice, "hlsl.fx", NULL, NULL, 
                D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ))){
        MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer()
                    , "ERROR", MB_OK);
        return DXTRACE_ERR( "CreateEffectFromFile", hr );
    }

	// �t�H���g
    hr = m_pFont->InitDeviceObjects( m_pd3dDevice );
    if( FAILED( hr ) ) return DXTRACE_ERR( "m_pFont->InitDeviceObjects", hr );
    
	// teapot
    if( FAILED( hr = D3DXCreateTeapot( m_pd3dDevice, &m_pD3DXMesh, NULL ) ) )
        return DXTRACE_ERR( "D3DXCreateTeapot", hr );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	// �V�F�[�_
	m_pEffect->OnResetDevice();

    // �����_�����O��Ԃ̐ݒ�
    m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
    m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
    m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
    m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

    // ���[���h�s��
    D3DXMATRIX matIdentity;
    D3DXMatrixIdentity( &matIdentity );
    m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

	// �r���[�s��
    D3DXMATRIX matView;
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mV, &vFromPt, &vLookatPt, &vUpVec );
    m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mV );

    // �ˉe�s��
    D3DXMATRIX matProj;
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
    D3DXMatrixPerspectiveFovLH( &m_mP, D3DX_PI/4, fAspect, 1.0f, 100.0f );
    m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mP );

    // �t�H���g
    m_pFont->RestoreDeviceObjects();

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
    // ���̓f�[�^�̍X�V
    UpdateInput( &m_UserInput );

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// BRDF �̃^�C�v
    if( m_UserInput.b2 && !m_UserInput.b1 ){
		this->m_nBrdf++;
		if(BRDF_MAX<=this->m_nBrdf)this->m_nBrdf = 0;
	}else if( m_UserInput.b1 && !m_UserInput.b2 ){
		this->m_nBrdf--;
		if(this->m_nBrdf<0)this->m_nBrdf = BRDF_MAX-1;
	}

	// ��]
    D3DXMATRIX matRotY;
    D3DXMATRIX matRotX;
	
	if(m_UserInput.bShift){
		// ���C�g
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fLightRotY += m_fElapsedTime;
		else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fLightRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fLightRotX += m_fElapsedTime;
		else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fLightRotX -= m_fElapsedTime;
	}else{
		// �I�u�W�F�N�g
		if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
			m_fWorldRotY += m_fElapsedTime;
		else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
			m_fWorldRotY -= m_fElapsedTime;

		if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
			m_fWorldRotX += m_fElapsedTime;
		else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
			m_fWorldRotX -= m_fElapsedTime;
	}

	//---------------------------------------------------------
	// �s��̐ݒ�
	//---------------------------------------------------------
	// �Y�[��
    if( m_UserInput.bZoomIn && !m_UserInput.bZoomOut )
        m_fViewZoom += m_fElapsedTime;
    else if( m_UserInput.bZoomOut && !m_UserInput.bZoomIn )
        m_fViewZoom -= m_fElapsedTime;
	// �r���[�s��
    D3DXVECTOR3 vFromPt   = D3DXVECTOR3( 0.0f, 0.0f, -m_fViewZoom );
    D3DXVECTOR3 vLookatPt = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUpVec    = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mV, &vFromPt, &vLookatPt, &vUpVec );
	
	// ���C�g�̃x�N�g��
    D3DXMatrixRotationX( &matRotX, m_fLightRotX );
    D3DXMatrixRotationY( &matRotY, m_fLightRotY );
    D3DXMatrixMultiply( &m_mLight, &matRotY, &matRotX );
	// ���[���h�s��
    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
    D3DXMatrixMultiply( &m_mW, &matRotY, &matRotX );

    m_pd3dDevice->SetTransform( D3DTS_WORLD, &m_mW );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-----------------------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
	pUserInput->bZoomIn      = ( m_bActive && (GetAsyncKeyState( 'Z'     )  & 0x8000) == 0x8000 );
    pUserInput->bZoomOut     = ( m_bActive && (GetAsyncKeyState( 'X'      ) & 0x8000) == 0x8000 );

	pUserInput->bShift = ((GetAsyncKeyState( VK_SHIFT )    & 0x8000) == 0x8000);

    pUserInput->b1 = ( m_bActive && (GetAsyncKeyState( '1' ) & 0x8001) == 0x8001 );
    pUserInput->b2 = ( m_bActive && (GetAsyncKeyState( '2' ) & 0x8001) == 0x8001 );
}




//-----------------------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	D3DXMATRIX m, mX, mY;
	D3DXVECTOR4 v;
	
	// ���C�g�̈ʒu
	D3DXVECTOR4 LightPos = D3DXVECTOR4(0.0f, 0.0f, -1.8f, 0.0f);
	D3DXVec4Transform( &LightPos, &LightPos, &m_mLight );
	
	// ��ʂ̃N���A
    m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
                         0x000000ff, 1.0f, 0L );

	//---------------------------------------------------------
	// �`��
	//---------------------------------------------------------
    if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
    {
        if(m_pEffect){
			// �V�F�[�_�̐ݒ�
			m_pEffect->SetTechnique( "TShader" );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );
			
			// �ϊ��s��
			D3DXMATRIX mWVP = m_mW * m_mV * m_mP;
			m_pEffect->SetMatrix("mWVP", &mWVP);

			D3DXMATRIX mWV = m_mW * m_mV;
			m_pEffect->SetMatrix("mWV", &mWV);

			D3DXMatrixInverse( &m, NULL, &mWV );
			D3DXMatrixTranspose( &m, &m );
			m_pEffect->SetMatrix("mWV_IT", &m);
			
			// ���C�g�̌���
			m = m_mW;
			D3DXMatrixInverse( &m, NULL, &m );
			D3DXVec4Transform( &v, &LightPos, &m );
			m_pEffect->SetVector("LightPos", &v);
			
			// ���_
			v = D3DXVECTOR4(0,0,-5,0);
			m = m_mW;
			D3DXMatrixInverse( &m, NULL, &m );
			D3DXVec4Transform( &v, &v, &m );
			m_pEffect->SetVector("EyePos", &v);
			
			// �ǉ�����F
			m_pEffect->SetVector("alpha", (D3DXVECTOR4*)&BRDF_color[m_nBrdf][0]);
			
			// �e�N�X�`��
			m_pEffect->SetTexture("MapP", m_pTex[m_nBrdf][0]);
			m_pEffect->SetTexture("MapQ", m_pTex[m_nBrdf][1]);
			m_pEffect->SetTexture("EnvMap", m_pEnvMap);

			// �e�B�[�|�b�g�̕\��
			m_pD3DXMesh->DrawSubset(0);

		
#if 0
			m_pEffect->Pass( 1 );
			{
				m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
				float scale = 256.0f;
				typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;
				TVERTEX Vertex[4] = {
					// x  y  z rhw tu tv
					{    0,(+0)*scale,0, 1, 0, 0,},
					{scale,(+0)*scale,0, 1, 1, 0,},
					{scale,(+1)*scale,0, 1, 1, 1,},
					{    0,(+1)*scale,0, 1, 0, 1,},
				};
				m_pd3dDevice->SetTexture( 0, m_pTex[0][0] );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
			}
#endif

			m_pEffect->End();
		}

		//---------------------------------------------------------
		// ���C�g�̈ʒu�̕\��
		//---------------------------------------------------------
		{
		m = m_mV * m_mP;
		v = LightPos;
		v.w = 1;
		D3DXVec4Transform( &v, &v, &m );
		float x = (this->m_rcWindowClient.right-this->m_rcWindowClient.left)*( 0.5f*v.x/v.w+0.5f);
		float y = (this->m_rcWindowClient.bottom-this->m_rcWindowClient.top)*(-0.5f*v.y/v.w+0.5f);

		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_DIFFUSE );
		m_pd3dDevice->SetPixelShader(0);

		typedef struct {FLOAT p[4]; DWORD color;} LVERTEX;
		for(DWORD i=0; i<2; i++){
			LVERTEX Vertex[4] = {
				// x  y   z rhw tu tv
				{x-3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y-3, v.z/v.w, 1, 0xffffc0,},
				{x+3,y+3, v.z/v.w, 1, 0xffffc0,},
				{x-3,y+3, v.z/v.w, 1, 0xffffc0,},
			};
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( LVERTEX ) );
		}
		}

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
		{
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pd3dDevice->SetVertexShader(NULL);
		m_pd3dDevice->SetPixelShader(0);
		m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		float scale = 128.0f;
		typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;
		for(DWORD i=0; i<3; i++){
			TVERTEX Vertex[4] = {
				// x  y  z rhw tu tv
				{    0,(i+0)*scale,0, 1, 0, 0,},
				{scale,(i+0)*scale,0, 1, 1, 0,},
				{scale,(i+1)*scale,0, 1, 1, 1,},
				{    0,(i+1)*scale,0, 1, 0, 1,},
			};
			if(0==i) m_pd3dDevice->SetTexture( 0, m_pTex[m_nBrdf][0] );
			if(1==i) m_pd3dDevice->SetTexture( 0, m_pTex[m_nBrdf][1] );
			if(2==i) m_pd3dDevice->SetTexture( 0, m_pEnvMap );;
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
		}
		}
#endif		
        
        // �w���v�̕\��
        RenderText();

		// �`��̏I��
        m_pd3dDevice->EndScene();
    }

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; // �\�����鍂��

    // ����@��p�����[�^��\������
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f;
    m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 

    wsprintf( szMsg, TEXT("Arrow keys: Up=%d Down=%d Left=%d Right=%d"), 
              m_UserInput.bRotateUp, m_UserInput.bRotateDown, m_UserInput.bRotateLeft, m_UserInput.bRotateRight );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press '1' or '2' to change the factorization") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    lstrcpy( szMsg, TEXT("Press 'F2' to configure display") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    wsprintf( szMsg, TEXT("%d: %s"), this->m_nBrdf, BRDF_name[this->m_nBrdf] );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-----------------------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    // �V�F�[�_
    if( m_pEffect != NULL ) m_pEffect->OnLostDevice();

    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	// �e�N�X�`��
	for(int i=0; i< BRDF_MAX; i++){
		SAFE_RELEASE( m_pTex[i][1] );
		SAFE_RELEASE( m_pTex[i][0] );
	}

	SAFE_RELEASE( m_pEnvMap );
	
    // �V�F�[�_
    SAFE_RELEASE( m_pEffect );

    m_pFont->DeleteDeviceObjects();	// �t�H���g
    SAFE_RELEASE( m_pD3DXMesh );	// ���b�V��

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-----------------------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




