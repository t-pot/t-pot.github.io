// ----------------------------------------------------------------------------
//
// draw.cpp - Rendering
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include <windows.h>
#include "main.h"
#include "draw.h"
#include "load.h"

#include "Cg/cgD3D.h"

// Cg Env
cgDirect3D cg;
cgContextContainer * pContextContainer = 0;

// Ordinal shader
cgProgramContainer *pVertexProgramContainer = 0;
cgBindIter * vertex_mat_iter = 0;
cgProgramContainer  *pPixelProgramContainer = 0;
cgBindIter * tex0_iter = 0;
cgBindIter * tex1_iter = 0;

// Collision
cgProgramContainer *pCollVC = 0;
cgBindIter * trans_iter           = 0;
cgBindIter * velocity_iter        = 0;
cgBindIter * viewproj_matrix_iter = 0;
cgBindIter * color_iter           = 0;

// Burn
cgProgramContainer *pBurnVC = 0;
cgProgramContainer *pBurnPC = 0;
cgBindIter * BurnTex0_iter = 0;
cgBindIter * BurnTex1_iter = 0;
cgBindIter * BurnTex2_iter = 0;

// Black spot
cgProgramContainer *pBlackVC = 0;

CMyMesh	mesh;						// ground
CMyView	view;						// camera
CBulletMgr bullet;					// bullet
float		mouse[2]={150.f,200.f};	// cursol position

D3DXMATRIX gProj;					// Projectio matrix

LPDIRECT3DSURFACE8		pBackbuffer = NULL;
LPDIRECT3DTEXTURE8		pTexture=NULL;
LPDIRECT3DSURFACE8		pTextureSurface=NULL;

// catmap
LPDIRECT3DTEXTURE8		pCatTexture[2]={NULL,NULL};
LPDIRECT3DSURFACE8		pCatTextureSurface[2]={NULL,NULL};
LPDIRECT3DTEXTURE8		pCatSeedTexture=NULL;

// envmap
LPDIRECT3DTEXTURE8		pEnvTexture=NULL;
LPDIRECT3DSURFACE8		pEnvTextureSurface=NULL;

// Result of the collision check
LPDIRECT3DTEXTURE8		pHitTexture[2]={NULL,NULL};
LPDIRECT3DSURFACE8		pHitTextureSurface[2]={NULL,NULL};
LPDIRECT3DTEXTURE8		pBurnTexture=NULL;
LPDIRECT3DSURFACE8		pBurnTextureSurface=NULL;

// Black spot
LPDIRECT3DTEXTURE8		pBlackTexture=NULL;
LPDIRECT3DSURFACE8		pBlackTextureSurface=NULL;


// ----------------------------------------------------------------------------
// Vertex format
// ----------------------------------------------------------------------------
struct TLVERTEX
{
	float x,y,z,rhw;
	float tu,tv;
};
#define	FVF_TLVERTEX (D3DFVF_XYZRHW | D3DFVF_TEX1)

// ----------------------------------------------------------------------------
void InitBg(LPDIRECT3DDEVICE8 lpD3DDev);
void DrawBg(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP, bool texture);
void CleanBg(LPDIRECT3DDEVICE8 lpD3DDev);


//-----------------------------------------------------------------------------
// Name: InitRender()
//-----------------------------------------------------------------------------
HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	HRESULT hr;
	DWORD i;

    cgVertexDefinition vertex_attributes[] = {
		{D3DVSDT_FLOAT4, "position",  0},
		{D3DVSDT_FLOAT2, "texcoord0", 0},
        CGVERTEXDEFINITIONEND
	};

	// ==================================================
	// Initialization of the sky
	// ==================================================
	InitBg(lpD3DDev);
	
	// ==================================================
	// read the ground mesh
	// ==================================================
	mesh.Load(lpD3DDev, "map.x");

	// ==================================================
	// Initializatioon of the Cg
	// ==================================================
    cg.AddFilePath("..");
	pContextContainer = cg.CreateContextContainer(lpD3DDev);

	// ==================================================
	// Almost fixed function
	// ==================================================
	pVertexProgramContainer = pContextContainer->LoadCGProgramFromFile(
		"vs.cg", "Vertex Shader", cgDX8VertexProfile, vertex_attributes);

    if (pVertexProgramContainer == NULL) {// error
        const char * listing = pContextContainer->GetLastListing();
        if (listing == 0) listing = "Could not find cgc.exe.";
        cg.NotePad("���_�V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n", listing);
        exit(1);	// end
    }
	vertex_mat_iter = pVertexProgramContainer->GetParameterBindByName("worldviewproj_matrix");

	pPixelProgramContainer = pContextContainer->LoadCGProgramFromFile(
								"ps.cg", "test", cgDX8PixelProfile);
	if (NULL == pPixelProgramContainer) { // error
		const char * error_text = pContextContainer->GetLastListing();
		cg.NotePad("�s�N�Z���V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n\n", error_text);
		exit(1);	// end
    }
	tex0_iter = pPixelProgramContainer->GetTextureBindByName("tex0");
	tex1_iter = pPixelProgramContainer->GetTextureBindByName("tex1");
	
	// ==================================================
	// Collision Shader
	// ==================================================
	pCollVC = pContextContainer->LoadCGProgramFromFile(
		"CollisionV.cg", "Vertex Shader", cgDX8VertexProfile, vertex_attributes);
    if (NULL == pCollVC) {
        const char * listing = pContextContainer->GetLastListing();
        if (listing == 0) listing = "Could not find cgc.exe.";
        cg.NotePad("���_�V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n", listing);
        exit(1);
    }
	trans_iter			= pCollVC->GetParameterBindByName("trans");
	velocity_iter		= pCollVC->GetParameterBindByName("velocity");
	viewproj_matrix_iter= pCollVC->GetParameterBindByName("viewproj_matrix");
	color_iter			= pCollVC->GetParameterBindByName("color");

	// ==================================================
	// This program creates the fire effect
	// ==================================================
	pBurnVC = pContextContainer->LoadCGProgramFromFile(
		"BurnV.cg", "Vertex Shader", cgDX8VertexProfile, vertex_attributes);
    if (NULL == pBurnVC) {
        const char * listing = pContextContainer->GetLastListing();
        if (listing == 0) listing = "Could not find cgc.exe.";
        cg.NotePad("���_�V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n", listing);
        exit(1);
    }

	pBurnPC = pContextContainer->LoadCGProgramFromFile(
		"BurnP.cg", "test", cgDX8PixelProfile);
	if (NULL == pBurnPC) {
		const char * error_text = pContextContainer->GetLastListing();
		cg.NotePad("�s�N�Z���V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n\n", error_text);
		exit(1);
    }
	BurnTex0_iter = pBurnPC->GetTextureBindByName("tex0");
	BurnTex1_iter = pBurnPC->GetTextureBindByName("tex1");
	BurnTex2_iter = pBurnPC->GetTextureBindByName("tex2");

	// ==================================================
	// This program creates the black spots
	// ==================================================
	pBlackVC = pContextContainer->LoadCGProgramFromFile(
		"BlackV.cg", "Vertex Shader", cgDX8VertexProfile, vertex_attributes);
    if (NULL == pBlackVC) {
        const char * listing = pContextContainer->GetLastListing();
        if (listing == 0) listing = "Could not find cgc.exe.";
        cg.NotePad("���_�V�F�[�_�[�v���O�����̐����Ɏ��s���܂���\n\n", listing);
        exit(1);
    }
	// ==================================================
	// Texture for the seed of the fire (CatMap)
	// ==================================================
	D3DXCreateTextureFromFileEx(lpD3DDev, "fire.bmp",0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, &pCatSeedTexture);
	

	// ==================================================
	// Create Rendering Texture
	// ==================================================
	// Backup back buffers
	D3DSURFACE_DESC Desc;
	LPDIRECT3DSURFACE8 lpZbuffer = NULL;
	if( FAILED(hr = lpD3DDev->GetRenderTarget(&pBackbuffer))) return hr;
	if( FAILED(hr = pBackbuffer->GetDesc( &Desc ))) return hr;
	if( FAILED(hr = lpD3DDev->GetDepthStencilSurface( &lpZbuffer ))) return hr;

	// Collision map
	if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pTexture))) return hr;
	if( FAILED(hr = pTexture->GetSurfaceLevel(0,&pTextureSurface))) return hr;
	if( FAILED(hr = lpD3DDev->SetRenderTarget(pTextureSurface, lpZbuffer ))) return hr;

	// Collision result in this frame
	if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pBurnTexture))) return hr;
	if( FAILED(hr = pBurnTexture->GetSurfaceLevel(0,&pBurnTextureSurface))) return hr;
	if( FAILED(hr = lpD3DDev->SetRenderTarget(pBurnTextureSurface, NULL ))) return hr;

	if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pBlackTexture))) return hr;
	if( FAILED(hr = pBlackTexture->GetSurfaceLevel(0,&pBlackTextureSurface))) return hr;
	if( FAILED(hr = lpD3DDev->SetRenderTarget(pBlackTextureSurface, NULL ))) return hr;

	// Total collision result
	if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
							, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pEnvTexture))) return hr;
	if( FAILED(hr = pEnvTexture->GetSurfaceLevel(0,&pEnvTextureSurface))) return hr;
	if( FAILED(hr = lpD3DDev->SetRenderTarget(pEnvTextureSurface, lpZbuffer ))) return hr;

	for(i=0;i<2;i++){
		// CatMap
		if( FAILED(hr = lpD3DDev->CreateTexture(128, 128, 1
								, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pCatTexture[i]))) return hr;
		if( FAILED(hr = pCatTexture[i]->GetSurfaceLevel(0,&pCatTextureSurface[i]))) return hr;
		// hit map
		if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
								, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pHitTexture[i]))) return hr;
		if( FAILED(hr = pHitTexture[i]->GetSurfaceLevel(0,&pHitTextureSurface[i]))) return hr;
	}

	// Set rendering target to back buffer
	lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );

	// ==================================================
	// Initialize render states
	// ==================================================
	lpD3DDev->SetRenderState( D3DRS_ZENABLE, TRUE );
    lpD3DDev->SetRenderState( D3DRS_LIGHTING,  FALSE );
	lpD3DDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	lpD3DDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
	lpD3DDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCCOLOR);

	D3DXMatrixPerspectiveFovLH(&gProj
		,60.0f*D3DX_PI/180.0f
		,(float)WIDTH/(float)HEIGHT
		,0.01f,100.0f
		);

    return S_OK;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//    type 0 normal
//    type 1 burn envmap
//    type 2 collision depth
//-----------------------------------------------------------------------------
VOID DrawModel(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP, DWORD type)
{
	if(2!=type)DrawBg(lpD3DDev, mVP, 0==type);

	if(0==type) bullet.Render(lpD3DDev, mVP);

	D3DXMATRIX m;
	D3DXMatrixTranspose( &m, &mVP );
	pVertexProgramContainer->SetShaderConstant( vertex_mat_iter, &m  );
	
	lpD3DDev->SetStreamSource(0, mesh.pVB, sizeof(D3D_CUSTOMVERTEX));
	lpD3DDev->SetIndices(mesh.pIndex,0);

	switch(type){
	case 1:
		pPixelProgramContainer->SetTexture(tex0_iter, pBurnTexture);
		pPixelProgramContainer->SetTexture(tex1_iter, NULL);
		break;
	case 2:
		pPixelProgramContainer->SetTexture(tex0_iter, NULL);
		pPixelProgramContainer->SetTexture(tex1_iter, NULL);
		break;
	default:
		pPixelProgramContainer->SetTexture(tex0_iter, mesh.pTextures[0]);
		pPixelProgramContainer->SetTexture(tex1_iter, pBlackTexture);
		break;
	}

	lpD3DDev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 
									mesh.pSubsetTable[0].VertexStart,
									mesh.pSubsetTable[0].VertexCount,
									mesh.pSubsetTable[0].FaceStart * 3,
									mesh.pSubsetTable[0].FaceCount);
}
//-----------------------------------------------------------------------------
// Name: Render()
//-----------------------------------------------------------------------------
static BOOL		init = TRUE;
VOID Render(LPDIRECT3DDEVICE8 lpD3DDev)
{
	D3DXMATRIX		mWorld, mView, mProj, m, mat;
	DWORD			i;
	static DWORD	id=0;
	LPDIRECT3DSURFACE8 lpZbuffer = NULL;
	lpD3DDev->GetDepthStencilSurface( &lpZbuffer );

	static DWORD last = 0;
	DWORD now = timeGetTime();
	DWORD cnt = now-last;
	last = now;
	
	if(init){
		cnt = 0;
		bullet.Reset();
		//-----------------------------------------------------------------------------
		// Clear the burning information
		//-----------------------------------------------------------------------------
		lpD3DDev->SetRenderTarget(pBurnTextureSurface, NULL );
		lpD3DDev->Clear(0,NULL,D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0),1.0f,0);
		lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );
	}

	//-----------------------------------------------------------------------------
	// Sometimes shooting a star
	//-----------------------------------------------------------------------------
	static DWORD start_cnt=0xffffffff;
	if(now<start_cnt || 3000<now-start_cnt){
		D3DXVECTOR4 x, v;
		x.x = (10.0f/4096.0f)*(float)(rand()%0xfff)-5.0f;
		x.z = (10.0f/4096.0f)*(float)(rand()%0xfff)-5.0f;
		x.y = 10.0f;
		v.x = (10.0f/4096.0f)*(float)(rand()%0xfff)-5.0f;
		v.z = (10.0f/4096.0f)*(float)(rand()%0xfff)-5.0f;
		v.y = 0.0f;
		v = v - x;
		D3DXVec4Normalize(&v,&v);
		bullet.Add(x, BULLET_SPEED*v);

		start_cnt = now;
	}
	
	//-----------------------------------------------------------------------------
	// Move bullets
	//-----------------------------------------------------------------------------
	bullet.Update(cnt);

	//-----------------------------------------------------------------------------
	// CatMap
	//-----------------------------------------------------------------------------
	{
		lpD3DDev->SetRenderTarget(pCatTextureSurface[id], NULL);

		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_POINT );
		lpD3DDev->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_POINT );
		float size = 128.0f;
		TLVERTEX Vertex[] = {
			//   x          y     z rhw  tu    tv
			{0.0f*size, 0.0f*size,0, 1, 0.0f, 0.0f,},
			{0.5f*size, 0.0f*size,0, 1, 1.0f, 0.5f,},
			{0.0f*size, 1.0f*size,0, 1, 1.0f, 1.0f,},

			{0.5f*size, 0.0f*size,0, 1, 0.0f, 0.5f,},
			{1.0f*size, 0.0f*size,0, 1, 1.0f, 1.0f,},
			{0.0f*size, 1.0f*size,0, 1, 0.0f, 1.0f,},

			{0.0f*size, 1.0f*size,0, 1, 0.0f, 0.0f,},
			{1.0f*size, 0.0f*size,0, 1, 1.0f, 0.0f,},
			{0.5f*size, 1.0f*size,0, 1, 1.0f, 0.5f,},

			{0.5f*size, 1.0f*size,0, 1, 0.0f, 0.5f,},
			{1.0f*size, 0.0f*size,0, 1, 0.0f, 0.0f,},
			{1.0f*size, 1.0f*size,0, 1, 1.0f, 1.0f,},
		};

		if(init){
			lpD3DDev->SetTexture( 0, pCatSeedTexture);		// initialize
		}else{
			lpD3DDev->SetTexture( 0, pCatTexture[1-id] );	// ordinary
		}
		lpD3DDev->SetVertexShader( FVF_TLVERTEX );
		lpD3DDev->SetPixelShader(0);
		lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 4, Vertex, sizeof( TLVERTEX ) );
	}

	//-----------------------------------------------------------------------------
	// Create Collision Map
	//-----------------------------------------------------------------------------
	lpD3DDev->SetRenderTarget(pTextureSurface, lpZbuffer);
	lpD3DDev->Clear(0,NULL,D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,0),1.0f,0);
	
	// Create Depth Map
	D3DXVECTOR3 eye    = D3DXVECTOR3(0.0f,-10.0f,  0.0f);
	D3DXVECTOR3 lookAt = D3DXVECTOR3(0.0f,  0.0f,  0.0f);
	D3DXVECTOR3 up     = D3DXVECTOR3(0.0f,  0.0f,  1.0f);
	D3DXMatrixLookAtLH(&mView, &eye, &lookAt, &up);
	D3DXMatrixPerspectiveFovLH(&mProj
		,D3DX_PI/3.5f
		,1.0f
		,0.01f,100.0f
		);
	mat = mView * mProj;
	lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	lpD3DDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0);
	pVertexProgramContainer->SetShaderActive();
	pPixelProgramContainer->SetShaderActive();
	DrawModel(lpD3DDev, mat, 2);
	lpD3DDev->SetRenderState(D3DRS_COLORWRITEENABLE, 0xf);
	lpD3DDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	
	D3DXMatrixTranspose( &m, &mat );
	pCollVC->SetShaderConstant( viewproj_matrix_iter, &m  );

	for(i=0;i<bullet.GetNum();i++){
		if(!bullet.IsActive(i)) continue;
		D3DXVECTOR4 &x = bullet.GetPosition(i);
		D3DXVECTOR4 &v = bullet.GetVelosity(i);

		lpD3DDev->SetRenderTarget(pTextureSurface, lpZbuffer);
		lpD3DDev->Clear(0,NULL,D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0),1.0f,0);
		// Draw bullte from Front side
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_DIFFUSE);
		lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		pCollVC->SetShaderActive();
		lpD3DDev->SetPixelShader(0);

		pCollVC->SetShaderConstant( trans_iter, &x  );
		pCollVC->SetShaderConstant( velocity_iter, &v  );
		pCollVC->SetShaderConstant( color_iter, D3DXVECTOR4(1.0f,1.0f,1.0f,1.0f)  );
		bullet.Draw(i, lpD3DDev);

		// Draw bullte from Back side
		lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
		pCollVC->SetShaderConstant( color_iter, D3DXVECTOR4(0.0f,0.0f,0.0f,1.0f)  );
		bullet.Draw(i, lpD3DDev);
		lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

		// Add 
		lpD3DDev->SetRenderTarget(pBurnTextureSurface, NULL );
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		float size = 512.0f;
		TLVERTEX Vertex[4] = {
			// x    y   z rhw tu tv
			{   0,    0,0, 1, 1, 0,},
			{size,    0,0, 1, 0, 0,},
			{size, size,0, 1, 0, 1,},
			{   0, size,0, 1, 1, 1,},
		};
		lpD3DDev->SetTexture( 0, pTexture);
		lpD3DDev->SetVertexShader( FVF_TLVERTEX );
		lpD3DDev->SetPixelShader(0);
		lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TLVERTEX ) );
		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	}
	lpD3DDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	lpD3DDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	//-----------------------------------------------------------------------------
	// Create 16 box sampling of the pBurnTexture
	//-----------------------------------------------------------------------------
	lpD3DDev->SetRenderTarget(pBlackTextureSurface, NULL );
	lpD3DDev->Clear(0,NULL,D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0),1.0f,0);
	lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
	lpD3DDev->SetTextureStageState(1,D3DTSS_COLOROP,	D3DTOP_ADD);
	lpD3DDev->SetTextureStageState(2,D3DTSS_COLOROP,	D3DTOP_ADD);
	lpD3DDev->SetTextureStageState(3,D3DTSS_COLOROP,	D3DTOP_ADD);
	lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(1,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(2,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(3,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(1,D3DTSS_COLORARG2,	D3DTA_CURRENT);
	lpD3DDev->SetTextureStageState(2,D3DTSS_COLORARG2,	D3DTA_CURRENT);
	lpD3DDev->SetTextureStageState(3,D3DTSS_COLORARG2,	D3DTA_CURRENT);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(1,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(2,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(3,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(1,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(2,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
	lpD3DDev->SetTextureStageState(3,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);

	TLVERTEX BlackVertex[] = {
		// x    y   z   rhw tu tv
		{ -1,  1, 0.1f, 1.f, 0, 0,},
		{  1,  1, 0.1f, 1.f, 1, 0,},
		{  1, -1, 0.1f, 1.f, 1, 1,},
		{ -1, -1, 0.1f, 1.f, 0, 1,},
	};

	pBlackVC->SetShaderActive();
	lpD3DDev->SetTexture(0, pBurnTexture);
	lpD3DDev->SetTexture(1, pBurnTexture);
	lpD3DDev->SetTexture(2, pBurnTexture);
	lpD3DDev->SetTexture(3, pBurnTexture);
	lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, BlackVertex, sizeof( TLVERTEX ) );
	lpD3DDev->SetTexture(0, NULL);
	lpD3DDev->SetTexture(1, NULL);
	lpD3DDev->SetTexture(2, NULL);
	lpD3DDev->SetTexture(3, NULL);

	//-----------------------------------------------------------------------------
	// Create 3D Collision map
	//-----------------------------------------------------------------------------
	eye    = D3DXVECTOR3(0.0f,  2.0f,  4.0f);
	lookAt = D3DXVECTOR3(0.0f,  1.0f,  0.0f);
	up     = D3DXVECTOR3(0.0f,  1.0f,  0.0f);
	D3DXMatrixLookAtLH(&mView, &eye, &lookAt, &up);
	mat = view.Get() * gProj;

	lpD3DDev->SetRenderTarget(pEnvTextureSurface, lpZbuffer );
	lpD3DDev->Clear(0,NULL,D3DCLEAR_ZBUFFER, 0,1.0f,0);
	pVertexProgramContainer->SetShaderActive();
	pPixelProgramContainer->SetShaderActive();
	DrawModel(lpD3DDev, mat, 1);
		
	//-----------------------------------------------------------------------------
	// Create fire effect
	//-----------------------------------------------------------------------------
	lpD3DDev->SetRenderTarget(pHitTextureSurface[id], NULL);
	lpD3DDev->Clear(0,NULL,D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0),1.0f,0);
		
	if(!init){
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetTextureStageState(1,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(1,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_POINT );
		lpD3DDev->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_POINT );
		lpD3DDev->SetTextureStageState(1, D3DTSS_MAGFILTER, D3DTEXF_POINT );
		lpD3DDev->SetTextureStageState(1, D3DTSS_MINFILTER, D3DTEXF_POINT );
		lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
		lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
		lpD3DDev->SetTextureStageState(1,D3DTSS_ADDRESSU,	D3DTADDRESS_CLAMP);
		lpD3DDev->SetTextureStageState(1,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);
		TLVERTEX Vertex[] = {
			// x    y   z   rhw tu tv
			{ -1,  1, 0.1f, 1.f, 0+0.5f/512.0f, 1+0.5f/512.0f,},
			{  1,  1, 0.1f, 1.f, 1+0.5f/512.0f, 1+0.5f/512.0f,},
			{  1, -1, 0.1f, 1.f, 1+0.5f/512.0f, 0+0.5f/512.0f,},
			{ -1, -1, 0.1f, 1.f, 0+0.5f/512.0f, 0+0.5f/512.0f,},
		};

		pBurnVC->SetShaderActive();
		pBurnPC->SetShaderActive();
		pBurnPC->SetTexture(BurnTex0_iter, pHitTexture[1-id]);
		pBurnPC->SetTexture(BurnTex1_iter, pEnvTexture);
		pBurnPC->SetTexture(BurnTex2_iter, pCatTexture[id]);
		lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TLVERTEX ) );
	}

	//-----------------------------------------------------------------------------
	// Make final result
	//-----------------------------------------------------------------------------
	lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );
	lpD3DDev->Clear(0,NULL,D3DCLEAR_ZBUFFER, 0,1.0f,0);

	pVertexProgramContainer->SetShaderActive();
	pPixelProgramContainer->SetShaderActive();
	lpD3DDev->SetTextureStageState(1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
	lpD3DDev->SetTextureStageState(1, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
	DrawModel(lpD3DDev, mat, 0);

	// Add burned result
	{
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		float size = 512.0f;
		TLVERTEX Vertex[4] = {
			// x    y   z rhw tu tv
			{   0,    0,0, 1, 0, 0,},
			{size,    0,0, 1, 1, 0,},
			{size, size,0, 1, 1, 1,},
			{   0, size,0, 1, 0, 1,},
		};
		lpD3DDev->SetTexture( 0, pHitTexture[id] );
		lpD3DDev->SetVertexShader( FVF_TLVERTEX );
		lpD3DDev->SetPixelShader(0);
		lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TLVERTEX ) );
		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	}

#if 0
	//-----------------------------------------------------------------------------
	// For debugging, this part shows rendered texture.
	//-----------------------------------------------------------------------------
	{
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		lpD3DDev->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		float scale = 128.0f;
		TLVERTEX Vertex[4] = {
			// x  y  z rhw tu tv
			{    0,    0,0, 1, 0, 0,},
			{scale,    0,0, 1, 1, 0,},
			{scale,scale,0, 1, 1, 1,},
			{    0,scale,0, 1, 0, 1,},
		};
//		lpD3DDev->SetTexture( 0, pCatTexture[id] );
//		lpD3DDev->SetTexture( 0, pHitTexture[id] );
//		lpD3DDev->SetTexture( 0, pEnvTexture );
		lpD3DDev->SetTexture( 0, pBlackTexture );
//		lpD3DDev->SetTexture( 0, pBurnTexture );
//		lpD3DDev->SetTexture( 0, pTexture );
		lpD3DDev->SetVertexShader( FVF_TLVERTEX );
		lpD3DDev->SetPixelShader(0);
		lpD3DDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TLVERTEX ) );
	}
#endif
	init=FALSE;
	id=1-id;
}
//-----------------------------------------------------------------------------
// Name: CleanRender()
//-----------------------------------------------------------------------------
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	RELEASE(pCatSeedTexture);
	RELEASE(pCatTextureSurface[1]);
	RELEASE(pCatTextureSurface[0]);
	RELEASE(pCatTexture[1]);
	RELEASE(pCatTexture[0]);

	RELEASE(pHitTextureSurface[1]);
	RELEASE(pHitTextureSurface[0]);
	RELEASE(pHitTexture[1]);
	RELEASE(pHitTexture[0]);

	RELEASE(pEnvTextureSurface);
	RELEASE(pEnvTexture);

	RELEASE(pBurnTextureSurface);
	RELEASE(pBurnTexture);

	RELEASE(pBlackTextureSurface);
	RELEASE(pBlackTexture);

	RELEASE(pTextureSurface);
	RELEASE(pTexture);
	RELEASE(pBackbuffer);

	CleanBg(lpD3DDev);
}
//-----------------------------------------------------------------------------
// eazy camera setting
//-----------------------------------------------------------------------------
static void set_camera(float cam_r, float cam_theta, float cam_phi, const D3DXVECTOR4 &cam_tr)
{
	D3DXVECTOR4 v = cam_tr;
	view.SetLookAt(v);
	v.z += cam_r * (float)cos(cam_phi) * (float)cos(cam_theta);
	v.x += cam_r * (float)cos(cam_phi) * (float)sin(cam_theta);
	v.y += cam_r * (float)sin(cam_phi);
	view.SetEye(v);
}
//-----------------------------------------------------------------------------
// Name: MyMsgProc()
//-----------------------------------------------------------------------------
LRESULT CALLBACK MyMsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	static int	type = 0;
	// mouse position
	static long prevX = 0;
	static long prevY = 0;
	long x,y,dx,dy;
	// camera
	static D3DXVECTOR4 cam_tr = D3DXVECTOR4(0.0f, 0.5f, 0.0f, 0.0f);
	static float cam_r		= 5.0f;
	static float cam_theta	= 0.0f;
	static float cam_phi	= 0.1f*D3DX_PI;

	switch(msg){
	case WM_CREATE:
		set_camera(cam_r, cam_theta, cam_phi, cam_tr);
		break;
	case WM_RBUTTONDOWN:
		type=1;
		prevX = (lParam << 16) >> 16;
		prevY = lParam >> 16;
		SetCapture(hWnd);
		break;
	case WM_LBUTTONDOWN:
		{
			D3DXMATRIX mat = view.Get() * gProj;
			D3DXVECTOR4 c = D3DXVECTOR4(mouse[0]/256.0f-1,1-mouse[1]/256.0f,1.0f,1.f);
			D3DXMatrixInverse(&mat, NULL, &mat);
			D3DXVec4Transform (&c, &c, &mat);
			D3DXVECTOR4 x = view.GetEye(); x.y -= 0.2f;
			D3DXVECTOR4 v = 100.0f*c-x;
			D3DXVec4Normalize(&v,&v);
			bullet.Add(x, BULLET_SPEED*v);
		}
		break;
	case WM_RBUTTONUP:
		type=0;
		ReleaseCapture();
		break;
	case WM_MOUSEMOVE:
		x = (lParam << 16) >> 16;
		y = lParam >> 16;
		mouse[0] = (float)x;
		mouse[1] = (float)y;
		dx = x - prevX;
		dy = y - prevY;
		switch(type){
		case 1:// camera
			if(wParam & MK_RBUTTON){
				if(dy != 0){
					cam_phi += 0.005f*dy;
					if( 0.499f*D3DX_PI<cam_phi)cam_phi = 0.499f*D3DX_PI;
					if(cam_phi<-0.000f*D3DX_PI)cam_phi =-0.000f*D3DX_PI;
					set_camera(cam_r, cam_theta, cam_phi, cam_tr);
				}
				if(dx != 0){
					cam_theta += 0.005f*dx;
					set_camera(cam_r, cam_theta, cam_phi, cam_tr);
				}
			}
			break;
		}
		prevX = x;
		prevY = y;
		break;
	case 0x020A:// WM_MOUSEWHEEL
		cam_r += 0.001f*(float)(short)HIWORD(wParam);
		if(cam_r<=0.1f)cam_r = 0.1f;
		if(5.0f<cam_r)cam_r = 5.0f;

		set_camera(cam_r, cam_theta, cam_phi, cam_tr);
		break;
	case WM_KEYDOWN:
		switch(wParam){
		case VK_SPACE:
			init = TRUE;
			break;
		default:
			break;
		}
		break;
	}

	return 0L;
}