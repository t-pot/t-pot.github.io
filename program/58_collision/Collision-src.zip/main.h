// ----------------------------------------------------------------------------
//
// main.h - Imporant constants
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _MAIN_H
#define	_MAIN_H

#define	FULLSCREEN		0

#define	CAPTION			"Collision Shader"
#define	WIDTH			512		// Width
#define	HEIGHT			512		// Height

#define RELEASE(o)	if (o){o->Release();o=NULL;}

#endif /* !_MAIN_H */
