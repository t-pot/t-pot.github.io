// ----------------------------------------------------------------------------
//
// bg.cpp - Back ground objects
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include <d3dx8.h>
#include <Cg/cgD3D.h>
#include "main.h"
#include "draw.h"

extern cgProgramContainer *pVertexProgramContainer;
extern cgProgramContainer  *pPixelProgramContainer;
extern cgBindIter * vertex_mat_iter;
extern cgBindIter * tex0_iter;
extern cgBindIter * tex1_iter;

// Sky
#define NUM_Y		1
#define NUM_CIRCLE	32
#define NUM_VERTICES			((NUM_Y+1)*(NUM_CIRCLE+1))
#define NUM_INDICES_PERFACE		(3*2)
#define NUM_FACES				(NUM_Y*NUM_CIRCLE)
#define NUM_VERTICES_PERFACE	4

// ----------------------------------------------------------------------------
typedef struct{
	float x,y,z,w;
	float tu,tv;
} MyVertex;

// ----------------------------------------------------------------------------
// Sky
LPDIRECT3DVERTEXBUFFER8		pCylinderVB;
LPDIRECT3DINDEXBUFFER8		pCylinderIB;
LPDIRECT3DTEXTURE8			pCylinderTex;

// Bullet
LPDIRECT3DVERTEXBUFFER8		pEarthVB;
LPDIRECT3DINDEXBUFFER8		pEarthIB;
LPDIRECT3DTEXTURE8			pEarthTex;
#define EARTH_R				(0.1f)
#define NUM_EARTH_X			32
#define NUM_EARTH_Y			16
#define NUM_EARTH_VERTICES	((NUM_EARTH_X+1)*(NUM_EARTH_Y+1))
#define NUM_EARTH_POLYGONE	(2*NUM_EARTH_X*NUM_EARTH_Y)
#define NUM_EARTH_INDEX		(6*NUM_EARTH_X*NUM_EARTH_Y)

// ----------------------------------------------------------------------------
// Initialization of the Bullet
// ----------------------------------------------------------------------------
static void InitEarth(LPDIRECT3DDEVICE8 lpD3DDev)
{
	WORD i, j;
	
	// Create the vertex buffer 
	MyVertex *pEarthDest;
    lpD3DDev->CreateVertexBuffer( NUM_EARTH_VERTICES * sizeof(MyVertex),
                                0, 0, D3DPOOL_MANAGED,
                                &pEarthVB );
	// Set up vertexs
	pEarthVB->Lock ( 0, 0, (BYTE**)&pEarthDest, 0 );
	for ( j = 0; j <= NUM_EARTH_Y; j++) {
	for ( i = 0; i <= NUM_EARTH_X; i++) {
		float theta = ((float)i)*2*D3DX_PI/NUM_EARTH_X;
		float phi   = ((float)j)*  D3DX_PI/NUM_EARTH_Y-D3DX_PI/2;
		pEarthDest->x   = EARTH_R * (float)cos(phi) * (float)cos(theta);
		pEarthDest->z   = EARTH_R * (float)cos(phi) * (float)sin(theta);
		pEarthDest->y   = EARTH_R * (float)sin(phi);
		pEarthDest->w   = 1.0f;
		pEarthDest->tu = (float)i/NUM_EARTH_X;
		pEarthDest->tv = 1.0f-(float)j/NUM_EARTH_Y;
		pEarthDest++;
	}
	}
	pEarthVB->Unlock ();


	// Set up indexs
	WORD *pIndex;
    lpD3DDev->CreateIndexBuffer( NUM_EARTH_INDEX * sizeof(WORD),
                               0,
                               D3DFMT_INDEX16, D3DPOOL_MANAGED,
                               &pEarthIB );
	pEarthIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
	for ( j = 0; j < NUM_EARTH_Y; j++) {
	for ( i = 0; i < NUM_EARTH_X; i++) {
		*pIndex++ = (j+0)*(NUM_EARTH_X+1)+i+0;
		*pIndex++ = (j+1)*(NUM_EARTH_X+1)+i+0;
		*pIndex++ = (j+0)*(NUM_EARTH_X+1)+i+1;
		*pIndex++ = (j+0)*(NUM_EARTH_X+1)+i+1;
		*pIndex++ = (j+1)*(NUM_EARTH_X+1)+i+0;
		*pIndex++ = (j+1)*(NUM_EARTH_X+1)+i+1;
	}
	}
	pEarthIB->Unlock ();

	D3DXCreateTextureFromFileEx(lpD3DDev, "earth.bmp", 0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, &pEarthTex);

}

// ----------------------------------------------------------------------------
// Initialization of the back ground object
// ----------------------------------------------------------------------------
void InitBg(LPDIRECT3DDEVICE8 lpD3DDev)
{
	//
	// Sky
	//
	// Create the vertex buffer 
	MyVertex *pDest;
    lpD3DDev->CreateVertexBuffer( NUM_VERTICES * sizeof(MyVertex),
                                0, 0, D3DPOOL_MANAGED, &pCylinderVB );

	// Set up vertexs
	WORD k=0;
	pCylinderVB->Lock ( 0, 0, (BYTE**)&pDest, 0 );
	float r = 5.0f;
	float h = 10.0f;
	for (DWORD i = 0; i <= NUM_CIRCLE; i++) {
		float theta = (2*D3DX_PI*(float)i)/(float)NUM_CIRCLE;
		for (DWORD j = 0; j <= NUM_Y; j++) {
			pDest->x = r * (float)cos(theta);
			pDest->z = r * (float)sin(theta);
			pDest->y = h*((float)j/(float)NUM_Y-0.0f);
			pDest->w   = 1.0f;
			pDest->tu = (float)i / (float)NUM_CIRCLE;
			pDest->tv = 1.0f-(float)j / (float)NUM_Y;
			pDest += 1;
		}
	}		
	pCylinderVB->Unlock ();


	// Set up indexs
	WORD *pIndex;
    lpD3DDev->CreateIndexBuffer( NUM_INDICES_PERFACE  * NUM_FACES * sizeof(WORD),
                                     0 ,
                                     D3DFMT_INDEX16, D3DPOOL_DEFAULT,
                                     &pCylinderIB );
	pCylinderIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
	{
	for (WORD i = 0; i < NUM_CIRCLE; i++) {
		for (WORD j = 0; j < NUM_Y; j++) {
			*pIndex++ = j + 0 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);

			*pIndex++ = j + 1 + (i+0) * (NUM_Y+1);
			*pIndex++ = j + 0 + (i+1) * (NUM_Y+1);
			*pIndex++ = j + 1 + (i+1) * (NUM_Y+1);
		}
	}
	}
	pCylinderIB->Unlock ();

	D3DXCreateTextureFromFileEx(lpD3DDev, "sky.bmp", 0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, &pCylinderTex);

	
	//
	// Bullet
	//
	InitEarth(lpD3DDev);
}
// ----------------------------------------------------------------------------
void CleanBg(LPDIRECT3DDEVICE8 lpD3DDev)
{
	RELEASE(pEarthTex);
	RELEASE(pEarthIB);
	RELEASE(pEarthVB);

	RELEASE(pCylinderTex);
	RELEASE(pCylinderIB);
	RELEASE(pCylinderVB);
}
// ----------------------------------------------------------------------------
void DrawBg(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP, bool texture)
{
	D3DXMATRIX mWorld, m;

	D3DXMatrixTranspose( &m, &mVP );
	pVertexProgramContainer->SetShaderConstant( vertex_mat_iter, &m  );

	lpD3DDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_MODULATE);
	lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	lpD3DDev->SetTextureStageState(0,D3DTSS_COLORARG2,	D3DTA_DIFFUSE);
	lpD3DDev->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
	lpD3DDev->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR );
	lpD3DDev->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR );
	
	//
	// Sky
	//
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_WRAP);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);

	pPixelProgramContainer->SetTexture(tex0_iter, texture?pCylinderTex:NULL);
	pPixelProgramContainer->SetTexture(tex1_iter, NULL);
	lpD3DDev->SetStreamSource(0, pCylinderVB, sizeof(MyVertex));
	lpD3DDev->SetIndices(pCylinderIB,0);
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,	0, NUM_VERTICES, 0 , NUM_FACES*2 );
}
// ----------------------------------------------------------------------------
void CBullet::Draw(LPDIRECT3DDEVICE8 lpD3DDev)
{
	lpD3DDev->SetStreamSource(0, pEarthVB, sizeof(MyVertex));
	lpD3DDev->SetIndices(pEarthIB,0);
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,	0, NUM_EARTH_VERTICES, 0 , NUM_EARTH_POLYGONE );
}
// ----------------------------------------------------------------------------
void CBullet::Render(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP)
{
	if(!bActive) return;
	
	D3DXMATRIX m;
	D3DXMatrixTranslation(&m, pos.x, pos.y, pos.z);
	m = m*mVP;
	D3DXMatrixTranspose( &m, &m );
	pVertexProgramContainer->SetShaderConstant( vertex_mat_iter, &m  );
	pPixelProgramContainer->SetTexture(tex0_iter, pEarthTex);
	pPixelProgramContainer->SetTexture(tex1_iter, NULL);
	
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSU,	D3DTADDRESS_WRAP);
	lpD3DDev->SetTextureStageState(0,D3DTSS_ADDRESSV,	D3DTADDRESS_CLAMP);

	Draw(lpD3DDev);
}
