// ----------------------------------------------------------------------------
//
// load.h - Load mesh
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _LOAD_H
#define	_LOAD_H

#include <d3d8.h>
#include <d3dx8.h>

// ----------------------------------------------------------------------------
// ���_�̒�`
// ----------------------------------------------------------------------------
typedef struct {
    D3DXVECTOR4  position;
    D3DXVECTOR2  texcoord0;
}D3D_CUSTOMVERTEX;

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ | D3DFVF_TEX1)

extern DWORD dwDecl[];

// ----------------------------------------------------------------------------
// ���f��
// ----------------------------------------------------------------------------

class CMyMesh{
public:
	CMyMesh(){
		bActive = false;
		pVB = NULL;
		pIndex = NULL;
		pSubsetTable = NULL;
		pTextures = NULL;
		pMaterials = NULL;
		nFaces = nVertices = dwNumMaterials = 0;
		rot.x = rot.y = rot.z = 0;
	}
	bool					bActive;
	float					radius;		// �傫��
	D3DXVECTOR3				center;		// ���S�ʒu
	D3DXVECTOR3				rot;

	LPDIRECT3DVERTEXBUFFER8	pVB;
	LPDIRECT3DINDEXBUFFER8	pIndex;
	D3DXATTRIBUTERANGE		*pSubsetTable;
	DWORD					nFaces;
	DWORD					nVertices;
	D3DMATERIAL8			*pMaterials;		// ���b�V���̎���
	LPDIRECT3DTEXTURE8		*pTextures;		// ���b�V���̃e�N�X�`���[
	DWORD					dwNumMaterials;	// �}�e���A���̐�

	HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, char *filename);
	void Release();
};
// ----------------------------------------------------------------------------
// �e�N�X�`���[
// ----------------------------------------------------------------------------
class CTextureMgr{
public:
	static HRESULT Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, LPDIRECT3DTEXTURE8 *ppTexture);
	static void Release(LPDIRECT3DTEXTURE8 pTexture);
};


#endif /* !_LOAD_H */
