// ----------------------------------------------------------------------------
//
// draw.h - Rendering
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _DRAW_H
#define	_DRAW_H

#include <d3d8.h>
#include <d3dx8.h>

HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDEV);
void Render(LPDIRECT3DDEVICE8 lpD3DDEV);
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDEV);

// ----------------------------------------------------------------------------
// Management of the camera
// ----------------------------------------------------------------------------
class CMyView{
	D3DXMATRIX				m_mView;	// View matrix
	D3DXVECTOR4				m_eye;		// camera position
	D3DXVECTOR4				m_lookAt;	// camera look at
	D3DXVECTOR4				m_up;		// up direction

	void Calc(){D3DXMatrixLookAtLH(&m_mView,(D3DXVECTOR3*)&m_eye,(D3DXVECTOR3*)&m_lookAt,(D3DXVECTOR3*)&m_up);}
public:
	CMyView(){Init();}
	void Init(){m_eye.x    = 0.0f; m_eye.y	  = 1.0f; m_eye.z    = 2.5f; m_eye.w    = 1.0f;
				m_lookAt.x = 0.0f; m_lookAt.y = 0.5f; m_lookAt.z = 0.0f; m_lookAt.w = 1.0f; 
				m_up.x	   = 0.0f; m_up.y 	  = 1.0f; m_up.z	 = 0.0f; m_up.w	    = 1.0f; 
				this->Calc();}
	void SetEye   (const D3DXVECTOR4    eye){m_eye   =   eye;this->Calc();}
	void SetLookAt(const D3DXVECTOR4 lookAt){m_lookAt=lookAt;this->Calc();}
	void SetUp    (const D3DXVECTOR4     up){m_up    =    up;this->Calc();}
	const D3DXVECTOR4 &GetEye()    const {return m_eye;}
	const D3DXVECTOR4 &GetLookAt() const {return m_lookAt;}
	const D3DXVECTOR4 &GetUp()     const {return m_up;}
	const D3DXMATRIX  &Get()       const {return m_mView;}
};

// ----------------------------------------------------------------------------
// bullet
// ----------------------------------------------------------------------------
#define BULLET_SPEED 5.0f

class CBullet{
private:
	BOOL			bActive;
	D3DXVECTOR4		pos;
	D3DXVECTOR4		velosity;
public:
	CBullet():bActive(FALSE){;}

	void Reset(){bActive=FALSE;}

	DWORD Create(D3DXVECTOR4 &x, D3DXVECTOR4 &v){
		if(bActive) return -1;
		bActive = TRUE;
		pos = x;
		velosity = v;
		velosity.w = 0;
		return 0;
	}
	DWORD Update(DWORD dt){
		if(bActive){
			pos += velosity*0.001f*(float)dt;
			pos.w=0.0f;
			// Dead check
			if(pos.x < -10.0f || 10.0f < pos.x
			|| pos.y < - 5.0f || 15.0f < pos.y
			|| pos.z < -10.0f || 10.0f < pos.z
			){
				bActive = FALSE;
				return 1;
			}
			return 0;
		}
		return -1;
	}
	void Render(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP);
	void Draw(LPDIRECT3DDEVICE8 lpD3DDev);
	
	// ----------------------------------------------------------------------------
	// Geter
	BOOL  IsActive() const {return bActive;}
	D3DXVECTOR4 &GetPosition(){return pos;}
	D3DXVECTOR4 &GetVelosity(){return velosity;}
};
// ----------------------------------------------------------------------------
#define BULLET_MAX 10	// The max count what we can shoot
class CBulletMgr{
private:
	CBullet	bullet[BULLET_MAX];
public:
	DWORD Add(D3DXVECTOR4 &x, D3DXVECTOR4 &v){
		DWORD i;
		for(i=0;i<BULLET_MAX;i++){
			if(0==bullet[i].Create(x,v)) return 0;
		}
		return -1;
	}
	void Update(DWORD dt){
		for(DWORD i=0;i<BULLET_MAX;i++){
			bullet[i].Update(dt);
		}
	}
	void Render(LPDIRECT3DDEVICE8 lpD3DDev, D3DXMATRIX &mVP){
		for(DWORD i=0;i<BULLET_MAX;i++){
			bullet[i].Render(lpD3DDev, mVP);
		}
	}
	void Reset(){
		for(DWORD i=0;i<BULLET_MAX;i++){
			bullet[i].Reset();
		}
	}
	DWORD GetNum()const{return BULLET_MAX;}
	BOOL  IsActive(DWORD i) const {return bullet[i].IsActive();}
	D3DXVECTOR4 &GetPosition(DWORD i){return bullet[i].GetPosition();}
	D3DXVECTOR4 &GetVelosity(DWORD i){return bullet[i].GetVelosity();}
	VOID Draw(DWORD i, LPDIRECT3DDEVICE8 lpD3DDev){bullet[i].Draw(lpD3DDev);}
};

#endif /* !_DRAW_H */
