// ----------------------------------------------------------------------------
//
// main.cpp - starting point
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT
#define INITGUID

#include <windows.h>
#include <d3d8.h>
#include <d3dx8.h>
#include "main.h"
#include "draw.h"

// ----------------------------------------------------------------------------
// Objects
// ----------------------------------------------------------------------------
static LPDIRECT3D8				s_lpD3D = NULL;
static LPDIRECT3DDEVICE8		s_lpD3DDEV = NULL;
static D3DPRESENT_PARAMETERS	s_d3dpp;

static bool						s_end;		// the flag to judge the end

// ----------------------------------------------------------------------------
// Declaration
// ----------------------------------------------------------------------------
int PASCAL WinMain(HINSTANCE hInst,HINSTANCE hPrev,char *CmdLine,int CmdShow);
LRESULT CALLBACK MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
HRESULT InitD3D( HWND hWnd );
LRESULT CALLBACK MyMsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);

// ----------------------------------------------------------------------------
// Name: WinMain()
//-----------------------------------------------------------------------------
int PASCAL WinMain(HINSTANCE hInst,HINSTANCE hPrev,char *CmdLine,int CmdShow)
{
	s_end = 0;
	
	srand(timeGetTime());

	// Creation of the window
	RECT    rect;
	SetRect(&rect, 0, 0, WIDTH, HEIGHT);
	DWORD   style = (FULLSCREEN) ? WS_POPUP :(WS_CAPTION|WS_SYSMENU|WS_BORDER|WS_MINIMIZEBOX);
	AdjustWindowRect(&rect, style, FALSE);
	int width  = rect.right - rect.left;
	int height = rect.bottom - rect.top;	
	
	WNDCLASS wc;
	ZeroMemory(&wc, sizeof(WNDCLASS));
	wc.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wc.hInstance		= hInst;
	wc.lpfnWndProc		= MsgProc;
	wc.lpszClassName	= CAPTION;
	if(RegisterClass(&wc) == 0) return 0;
	
	HWND hWnd = CreateWindow(CAPTION		// class name
							,"Collision Shader - [Left-click]:Shoot [Right-Drag]:Camera Control [SPACE]:reset"		// window name
							,style			// window style
							,CW_USEDEFAULT
							,CW_USEDEFAULT
							,width
							,height
							,NULL
							,NULL
							,hInst
							,NULL
							);
	if(hWnd == NULL) return 0;
	
	// Initialization of the Direct3D
    if(SUCCEEDED(InitD3D(hWnd))){
		
		if(FAILED(InitRender(s_lpD3DDEV))) s_end = true;
		
		ShowWindow(hWnd, SW_SHOW);
		UpdateWindow(hWnd);
	
		// The main loop
		MSG msg;
		while (!s_end)
		{
			if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)){
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}else{
				s_lpD3DDEV->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(0,0,0),1.0f,0);
				s_lpD3DDEV->BeginScene();
				
				Render(s_lpD3DDEV);
				
				s_lpD3DDEV->EndScene();
				if (FAILED(s_lpD3DDEV->Present(NULL,NULL,NULL,NULL)))
					s_lpD3DDEV->Reset(&s_d3dpp);
			}
		}
	}
	
	// END
	CleanRender(s_lpD3DDEV);
	RELEASE(s_lpD3DDEV);
	RELEASE(s_lpD3D);
	
	return 0;
}
// ----------------------------------------------------------------------------
// Name: MsgProc()
//-----------------------------------------------------------------------------
LRESULT CALLBACK MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch (msg){
	case WM_CLOSE:
		s_end = true;
		return 1;
		break;
	default:
		break;
	}

	MyMsgProc(hWnd,msg,wParam,lParam);

	return DefWindowProc(hWnd,msg,wParam,lParam);
}
//-----------------------------------------------------------------------------
// Name: InitD3D()
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
	// Create Direct3D Object
	if (NULL == (s_lpD3D = Direct3DCreate8(D3D_SDK_VERSION))){
		MessageBox(NULL,"Direct3D �̍쐬�Ɏ��s���܂����B",CAPTION,MB_OK | MB_ICONSTOP);
		return E_FAIL;
	}

	// Get the video mode
    D3DDISPLAYMODE d3ddm;
    if( FAILED( s_lpD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) ) return E_FAIL;
	// Seach the ability of the video card
	D3DCAPS8 caps;
	s_lpD3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps);

	ZeroMemory(&s_d3dpp, sizeof(D3DPRESENT_PARAMETERS));

	s_d3dpp.BackBufferCount = 1;
	if (FULLSCREEN){
		s_d3dpp.Windowed = FALSE;
		s_d3dpp.BackBufferWidth = WIDTH;
		s_d3dpp.BackBufferHeight = HEIGHT;
	}else{
		s_d3dpp.Windowed = TRUE;
		s_d3dpp.BackBufferWidth = WIDTH;
		s_d3dpp.BackBufferHeight = HEIGHT;
	}
	s_d3dpp.BackBufferFormat = d3ddm.Format;
	s_d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	s_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	s_d3dpp.hDeviceWindow = hWnd;
	// Judge the z-buffer
	s_d3dpp.EnableAutoDepthStencil = TRUE;
	if( FAILED( s_lpD3D->CheckDeviceFormat( caps.AdapterOrdinal, 
                                           caps.DeviceType, d3ddm.Format, 
                                           D3DUSAGE_DEPTHSTENCIL, 
                                           D3DRTYPE_SURFACE,
                                           D3DFMT_D24S8 ) ) ){
		s_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
	}else{
		s_d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;
	}
 
	DWORD  vs[] = {D3DCREATE_HARDWARE_VERTEXPROCESSING, D3DCREATE_MIXED_VERTEXPROCESSING, D3DCREATE_SOFTWARE_VERTEXPROCESSING,0 };
	D3DDEVTYPE ps[] = {D3DDEVTYPE_HAL, D3DDEVTYPE_REF, (D3DDEVTYPE)0};
	
	DWORD v = (caps.VertexShaderVersion < D3DVS_VERSION(1,0)) ? 1 : 0;
	DWORD p = (caps.PixelShaderVersion  < D3DPS_VERSION(1,0)) ? 1 : 0;

	for(;ps[p];p++){
	for(;vs[v];v++){
		if(SUCCEEDED(s_lpD3D->CreateDevice(D3DADAPTER_DEFAULT, ps[p],hWnd,vs[v],&s_d3dpp,&s_lpD3DDEV))) goto set_up;
	}
	}
set_up:
    return S_OK;
}
