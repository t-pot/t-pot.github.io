// ----------------------------------------------------------------------------
//
// load.cpp - Load the Object
// 
// Copyright (c) 2002 IMAGIRE Takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include "main.h"
#include "load.h"

// ----------------------------------------------------------------------------
// Declaration
// ----------------------------------------------------------------------------
// Original model
typedef struct {
	float x,y,z;
	float nx,ny,nz;
	float tu0,tv0;
}D3DVERTEX;
#define D3DFVF_VERTEX 		(D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)

// D3D_CUSTOMVERTEX
DWORD dwDecl[] = {
	D3DVSD_STREAM(0),
	D3DVSD_REG( D3DVSDE_POSITION,	D3DVSDT_FLOAT3 ),			// D3DVSDE_POSITION = 0
	D3DVSD_REG( D3DVSDE_BLENDWEIGHT,D3DVSDT_FLOAT4 ),			// D3DVSDE_BLENDWEIGHT = 1
	D3DVSD_REG( D3DVSDE_NORMAL,		D3DVSDT_FLOAT3 ),			// D3DVSDE_NORMAL,	= 3
	D3DVSD_REG( D3DVSDE_TEXCOORD0,	D3DVSDT_FLOAT2 ),		    // D3DVSDE_TEXCOORD0= 7
	D3DVSD_END()
};

// ----------------------------------------------------------------------------
// ���f��
// ----------------------------------------------------------------------------
HRESULT CMyMesh::Load(LPDIRECT3DDEVICE8 lpD3DDev, char *filename)
{
	LPD3DXMESH pMesh, pMeshOpt;
	LPD3DXBUFFER pD3DXMtrlBuffer = NULL;
	DWORD i;
	HRESULT hr;
	
	this->Release();
	hr = D3DXLoadMeshFromX(filename, D3DXMESH_MANAGED,
								lpD3DDev, NULL,
								&pD3DXMtrlBuffer, &this->dwNumMaterials,
								&pMesh);
	if(FAILED(hr)) return E_FAIL;

	// sort the data
	pMesh->Optimize(D3DXMESHOPT_ATTRSORT, NULL, NULL, NULL, NULL, &pMeshOpt);
	RELEASE(pMesh);

	// search the size of the mesh
	LPDIRECT3DVERTEXBUFFER8 pVB;
	BYTE* pVByte;
	pMeshOpt->GetVertexBuffer(&pVB);
	pVB->Lock(0,0,&pVByte,0);
	D3DXComputeBoundingSphere(pVByte, pMeshOpt->GetNumVertices(), pMeshOpt->GetFVF(), &this->center, &this->radius);
	pVB->Unlock();
	pVB->Release();

	pMeshOpt->GetAttributeTable(NULL,&this->dwNumMaterials);
	this->pSubsetTable = new D3DXATTRIBUTERANGE[this->dwNumMaterials];
	pMeshOpt->GetAttributeTable(this->pSubsetTable, &this->dwNumMaterials);

	// transformation of the FVF
	hr = pMeshOpt->CloneMeshFVF(pMeshOpt->GetOptions(), D3DFVF_VERTEX, lpD3DDev, &pMesh);
	if(FAILED(hr)) return E_FAIL;
	RELEASE(pMeshOpt);
	D3DXComputeNormals(pMesh,NULL);

	// Copy to the Vertex Buffer
	D3DVERTEX* pSrc;
	D3D_CUSTOMVERTEX* pDest;
	LPDIRECT3DINDEXBUFFER8 pSrcIndex;
	WORD* pISrc;
	WORD* pIDest;

	DWORD nMeshVertices = pMesh->GetNumVertices();
	DWORD nMeshFaces = pMesh->GetNumFaces();
	lpD3DDev->CreateVertexBuffer(nMeshVertices * sizeof(D3D_CUSTOMVERTEX),
							D3DUSAGE_WRITEONLY, D3DFVF_CUSTOMVERTEX, D3DPOOL_MANAGED, &this->pVB);
	lpD3DDev->CreateIndexBuffer(nMeshFaces * 3 * sizeof(WORD),0,D3DFMT_INDEX16,D3DPOOL_MANAGED,&this->pIndex);

	pMesh->GetVertexBuffer(&pVB);
	pVB->Lock(0,0,(BYTE**)&pSrc,0);
	this->pVB->Lock(0,0,(BYTE**)&pDest,0);
	for(i=0;i<nMeshVertices;i++){
		pDest->position[0] = pSrc->x;
		pDest->position[1] = pSrc->y;
		pDest->position[2] = pSrc->z;
		pDest->position[3] = 1.0f;
		pDest->texcoord0[0] = pSrc->tu0;
		pDest->texcoord0[1] = pSrc->tv0;

		pSrc++;
		pDest++;
	}
	pVB->Unlock();
	pVB->Release();
	this->pVB->Unlock();

	// Copy the Index buffer
	pMesh->GetIndexBuffer(&pSrcIndex);
	pSrcIndex->Lock(0,0,(BYTE**)&pISrc,0);
	this->pIndex->Lock(0,0,(BYTE**)&pIDest,0);
	CopyMemory(pIDest,pISrc,nMeshFaces * 3 * sizeof(WORD));
	pSrcIndex->Unlock();
	this->pIndex->Unlock();
	pSrcIndex->Release();

	// Read the material information
	D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();
	this->pTextures = new LPDIRECT3DTEXTURE8[this->dwNumMaterials];
	this->pMaterials = new D3DMATERIAL8[this->dwNumMaterials];

	for(i = 0; i < this->dwNumMaterials; i++){
		this->pMaterials[i] = d3dxMaterials[i].MatD3D;
		this->pMaterials[i].Ambient = this->pMaterials[i].Diffuse;
        hr = D3DXCreateTextureFromFile( lpD3DDev, 
                                        d3dxMaterials[i].pTextureFilename, 
                                        &this->pTextures[i] );
	    if(FAILED(hr)) this->pTextures[i] = NULL;
	}
	RELEASE(pD3DXMtrlBuffer);
	
	RELEASE(pMesh);
	
	this->bActive = true;		// OK. Use this mesh!
	
	return S_OK;
}
// ----------------------------------------------------------------------------
void CMyMesh::Release()
{
	DWORD i;

	if(this->pVB == NULL) return;

	for(i=0; i<this->dwNumMaterials; i++){
		RELEASE(this->pTextures[i]);
	}
	delete[] this->pTextures;
	delete[] this->pMaterials;
	delete[] this->pSubsetTable;

	RELEASE(this->pVB);
	RELEASE(this->pIndex);
	
	this->bActive = false;
}
// ----------------------------------------------------------------------------
// Texture
// ----------------------------------------------------------------------------
HRESULT CTextureMgr::Load(LPDIRECT3DDEVICE8 lpD3DDev, const char *filename, LPDIRECT3DTEXTURE8 *ppTexture)
{
	D3DXCreateTextureFromFileEx(lpD3DDev, filename,0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, ppTexture);
	
	return S_OK;
}
// ----------------------------------------------------------------------------
void CTextureMgr::Release(LPDIRECT3DTEXTURE8 pTexture)
{
	RELEASE(pTexture);
}
