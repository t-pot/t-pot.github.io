//--------------------------------------------------------------------------------------
// File: color.h
//
// �F���������߂̃N���X
//
// Copyright (c) Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#ifndef __CCOLOR_H_
#define __CCOLOR_H_

#include <assert.h>
#include <iostream>
#include "common\my_types.h"


class CColor
{
private:
public:
    float r,g,b,a;
    
    CColor() {}
    CColor(float fr, float fg, float fb) { r = fr; g = fg; b = fb; a = 0.0f;}
    CColor(const CColor &c) { r = c.r; g = c.g; b = c.b; a = c.b; }

    CColor operator+() const { return CColor( r, g, b); }
    CColor operator-() const { return CColor(-r,-g,-b); }

    CColor& operator+=(const CColor &c) { r += c.r; g += c.g; b += c.b; a += c.a; return *this; } 
    CColor& operator-=(const CColor &c) { r -= c.r; g -= c.g; b -= c.b; a -= c.a; return *this; } 
    CColor& operator*=(const CColor &c) { r *= c.r; g *= c.g; b *= c.b; a *= c.a; return *this; } 
    CColor& operator/=(const CColor &c) { r /= c.r; g /= c.g; b /= c.b; a /= c.a; return *this; } 
    CColor& operator*=(float f) { r *= f; g *= f; b *= f; a *= f; return *this; } 
    CColor& operator/=(float f) { r /= f; g /= f; b /= f; a /= f; return *this; } 

};

inline float dot( const CColor &c1, const CColor &c2 )
{
	return c1.r*c2.r + c1.g*c2.g + c1.b*c2.b;
}


// ---------------------------------------------------------------------------
inline bool operator==(CColor c1, CColor c2)
{
	return (c1.r == c2.r && c1.g == c2.g && c1.b == c2.b);
}
// ---------------------------------------------------------------------------
inline bool operator!=(CColor c1, CColor c2)
{
	return (c1.r != c2.r || c1.g != c2.g || c1.b != c2.b);
}

// ---------------------------------------------------------------------------
inline CColor operator+(CColor c1, CColor c2)
{
	return CColor(c1.r+c2.r, c1.g+c2.g, c1.b+c2.b);
}
// ---------------------------------------------------------------------------
inline CColor operator-(CColor c1, CColor c2)
{
	return CColor(c1.r-c2.r, c1.g-c2.g, c1.b-c2.b);
}
// ---------------------------------------------------------------------------
inline CColor operator*(CColor c1, CColor c2)
{
	return CColor(c1.r*c2.r, c1.g*c2.g, c1.b*c2.b);
}
// ---------------------------------------------------------------------------
inline CColor operator/(CColor c1, CColor c2)
{
	return CColor(c1.r/c2.r, c1.g/c2.g, c1.b/c2.b);
}
// ---------------------------------------------------------------------------
inline CColor operator*(CColor c, float f)
{
	return CColor(f*c.r, f*c.g, f*c.b);
}
// ---------------------------------------------------------------------------
inline CColor operator*(float f, CColor c)
{
	return CColor(c.r*f, c.g*f, c.b*f);
}
// ---------------------------------------------------------------------------
inline CColor operator/(CColor c, float f)
{
	return CColor(c.r/f, c.g/f, c.b/f);
}


#endif // !__CCOLOR_H_
