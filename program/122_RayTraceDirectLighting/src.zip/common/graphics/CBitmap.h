#ifndef __FONT2BMP_H_
#define __FONT2BMP_H_

#include "..\..\stdafx.h"

// ---------------------------------------------------------------------------
// �A�v���P�[�V�����̃N���X
// ---------------------------------------------------------------------------
typedef struct
{
	_TCHAR        *pFileName;
	BYTE          *pData;     // b0,g0,r0,a0,b1,g1,r1,a1,... �œ���Ă�����
	DWORD          iWidth;
	DWORD          iHeight;
	WORD           iBitCount; // 24 �� 32
} SAVE_BITMAP;

void SaveBitMap( SAVE_BITMAP &sInfo );

#endif // !__FONT2BMP_H_

