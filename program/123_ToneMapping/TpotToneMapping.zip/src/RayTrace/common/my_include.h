#ifndef __MY_INCLUDE_H_
#define __MY_INCLUDE_H_

#include "my_types.h"
#include "CColor.h"
#include "math/CRand.h"
#include "system/CThread.h"
#include "graphics/CBitmap.h"

#endif // !__MY_INCLUDE_H_
