//--------------------------------------------------------------------------------------
// File: OrthoNormalBasis.h
//
// ���K�������
//
// Copyright (c) Takashi Imagire. All rights reserved.
//--------------------------------------------------------------------------------------
#ifndef _OrthoNormalBasis_H_
#define _OrthoNormalBasis_H_

#include <d3d9.h>
#include <d3dx9.h>

class Vector3 : public D3DXVECTOR3
{
public:
	f32 length() {return D3DXVec3Length(this);}
	f32 squaredLength() {return D3DXVec3LengthSq(this);}
};

inline Vector3 normalize( const Vector3 &v )
{
	Vector3 vOut;
	
	D3DXVec3Normalize( &vOut, &v );
	
	return vOut;
}

inline Vector3 cross( const Vector3 &v0, const Vector3 &v1 )
{
	Vector3 vOut;
	
	D3DXVec3Cross( &vOut, &v0, &v1 );
	
	return vOut;
}


#define ONB_EPSILON 0.01f 

class ONB
{
protected:
   Vector3 m_vU, m_vV, m_vW;

public:
    // �R���X�g���N�^
    ONB() {};
    ONB( const Vector3& u, const Vector3& v, const Vector3& w ) { m_vU = u; m_vV = v; m_vW = w; }
    
    // �����I�ɒl��ݒ肷��
    void Set(const Vector3& a, const Vector3& b, const Vector3& c) { m_vU = a; m_vV = b; m_vW = c; }

    // ���K���s�����쐬����
    void initFromU( const Vector3& u );
    void initFromV( const Vector3& v );
    void initFromW( const Vector3& w );

    void  initFromUV( const Vector3& u, const Vector3& v );
    void  initFromVU( const Vector3& v, const Vector3& u );

    void  initFromUW( const Vector3& u, const Vector3& w );
    void  initFromWU( const Vector3& w, const Vector3& u );

    void  initFromVW( const Vector3& v, const Vector3& w );
    void  initFromWV( const Vector3& w, const Vector3& v );
   
    friend bool  operator==(const ONB& o1, const ONB &o2);

    // ���x�N�g���̏���
    Vector3 &u() { return m_vU; }
    Vector3 &v() { return m_vV; }
    Vector3 &w() { return m_vW; }

};


inline void ONB::initFromU( const Vector3& u )
{
   Vector3 n(1.0f, 0.0f, 0.0f);
   Vector3 m(0.0f, 1.0f, 0.0f);
   
   m_vU = normalize( u );
   m_vV = cross( m_vU, n );
   if (m_vV.length() < ONB_EPSILON) m_vV = cross( m_vU, m ); 
   m_vW = cross( m_vU, m_vV );
}

inline void  ONB::initFromV( const Vector3& v )
{
   Vector3 n(1.0f, 0.0f, 0.0f);
   Vector3 m(0.0f, 1.0f, 0.0f);
   
   m_vV = normalize( v );
   m_vU = cross( m_vV, n );
   if ( m_vU.squaredLength() < ONB_EPSILON ) m_vU = cross( m_vV, m ); 
   m_vW = cross( m_vU, m_vV );
}

inline void  ONB::initFromW( const Vector3& w )
{
   Vector3 n(1.0f, 0.0f, 0.0f);
   Vector3 m(0.0f, 1.0f, 0.0f);
   
   m_vW = normalize( w );
   m_vU = cross( m_vW, n );
   if ( m_vU.length() < ONB_EPSILON ) m_vU = cross( m_vW, m ); 
   m_vV = cross( m_vW, m_vU );
}

inline void ONB::initFromUV( const Vector3& u, const Vector3& v )
{
   m_vU = normalize( u );
   m_vW = normalize( cross(u, v) );
   m_vV = cross( m_vW, m_vU );
}

inline void ONB::initFromVU( const Vector3& v, const Vector3& u )
{
   m_vV = normalize( v );
   m_vW = normalize( cross( u, v ) );
   m_vU = cross( m_vV, m_vW );
}

inline void ONB::initFromUW( const Vector3& u, const Vector3& w )
{
   m_vU = normalize( u );
   m_vV = normalize( cross( w, u ) );
   m_vW = cross( m_vU, m_vV );
}

inline void  ONB::initFromWU( const Vector3& w, const Vector3& u )
{
   m_vW = normalize( w );
   m_vV = normalize( cross( w, u ) );
   m_vU = cross( m_vV, m_vW );
}

inline void  ONB::initFromVW( const Vector3& v, const Vector3& w )
{
   m_vV = normalize( v );
   m_vU = normalize( cross( v, w ) );
   m_vW = cross( m_vU, m_vV );
}

inline void ONB::initFromWV( const Vector3& w, const Vector3& v )
{
   m_vW = normalize( w );
   m_vU = normalize( cross( v, w ) );
   m_vV = cross( m_vW, m_vU );
}

inline bool  operator==( const ONB & o1, const ONB & o2 )
{
    return (o1.u() == o2.u()
         && o1.v() == o2.v()
         && o1.w() == o2.w());
}





#endif // _OrthoNormalBasis_H_
