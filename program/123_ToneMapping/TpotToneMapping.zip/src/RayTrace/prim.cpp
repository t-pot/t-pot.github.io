#include "dxstdafx.h"
#include "math.h"
#include "prim.h"

namespace Render {

// ---------------------------------------------------------------------------
// ��{�I�u�W�F�N�g
// ---------------------------------------------------------------------------
void CPrimitive::Init(OBJ_DATA *pData)
{
	m_type=pData->type;

	this->m_material = pData->material;
}
// ---------------------------------------------------------------------------
// ��
// ---------------------------------------------------------------------------
CSphere::CSphere()
{
}
// ---------------------------------------------------------------------------
void CSphere::Init(OBJ_DATA *pData)
{
	((CPrimitive*)this)->Init(pData);

	this->center.x = pData->sphere.center[0];
	this->center.y = pData->sphere.center[1];
	this->center.z = pData->sphere.center[2];

	radius_sq = pData->sphere.radius;
	radius_sq *= radius_sq;
}
// ---------------------------------------------------------------------------
float CSphere::IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	FLOAT t, tp, tn;

	// �����Ƃ̔���

	D3DXVECTOR4 xc = (*x)-center;
	FLOAT xc2 = D3DXVec3Dot((D3DXVECTOR3 *)&xc, (D3DXVECTOR3 *)&xc);
	FLOAT vxc = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&xc);
	FLOAT D = sqrtf(vxc*vxc-xc2+radius_sq);
	
	if(D<0) return -INFINTY_DIST;

	tp = -vxc+D;
	tn = -vxc-D;

	if(tn<0){
		if(tp<0) return -INFINTY_DIST;
		t = tp;
	}else{
		t = tn;
	}

	*p = (*x)+t*(*v);
	*n = *p-center;
	D3DXVec3Normalize((D3DXVECTOR3*)n, (D3DXVECTOR3*)n);

	return t;
}
// ---------------------------------------------------------------------------
// �R�p�`
// ---------------------------------------------------------------------------
CTriangle::CTriangle()
{
}
// ---------------------------------------------------------------------------
void CTriangle::Init(OBJ_DATA *pData)
{
	((CPrimitive*)this)->Init(pData);

	this->pos[0] = D3DXVECTOR4(	pData->triangle.x0[0],
								pData->triangle.x0[1],
								pData->triangle.x0[2],
								1.0f);
	this->pos[1] = D3DXVECTOR4(	pData->triangle.x1[0],
								pData->triangle.x1[1],
								pData->triangle.x1[2],
								1.0f);
	this->pos[2] = D3DXVECTOR4(	pData->triangle.x2[0],
								pData->triangle.x2[1],
								pData->triangle.x2[2],
								1.0f);

	// �@���x�N�g���̌v�Z
	D3DXVECTOR4 t0 = this->pos[1]-this->pos[0];
	D3DXVECTOR4 t1 = this->pos[2]-this->pos[0];
	D3DXVec3Cross((D3DXVECTOR3*)&normal, (D3DXVECTOR3*)&t1, (D3DXVECTOR3*)&t0);
	D3DXVec3Normalize((D3DXVECTOR3*)&normal, (D3DXVECTOR3*)&normal);
	normal.w = 0;
}
// ---------------------------------------------------------------------------
float CTriangle::IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	FLOAT t;

	// �����Ƃ̔���
	D3DXVECTOR4 xp = this->pos[0]-(*x);

	FLOAT xpn = D3DXVec3Dot((D3DXVECTOR3 *)&xp, (D3DXVECTOR3 *)&normal);
	FLOAT vn = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&normal);
	
	if(-0.00001f<=vn)return -INFINTY_DIST;// �J�����O�Ɩ�������O��

	t = xpn/vn;
	
	if(t<0) return -INFINTY_DIST;// �������̃��C�͖���

	*p = (*x)+t*(*v);
	*n = normal;

	D3DXVECTOR4 d0, d1;
	D3DXVECTOR3 c;
	d0 = (*p)-this->pos[0];
	d1 = this->pos[1]-this->pos[0];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	d0 = (*p)-this->pos[1];
	d1 = this->pos[2]-this->pos[1];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	d0 = (*p)-this->pos[2];
	d1 = this->pos[0]-this->pos[2];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	
	return t;
}


// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// �R���X�g���N�^
CMesh::CMesh()
{
	m_num = 0;
	m_ppPrim = NULL;
}
// ---------------------------------------------------------------------------
CMesh::~CMesh()
{
	Delete();
}
// ---------------------------------------------------------------------------
void CMesh::Init(OBJ_DATA *pData, int num)
{
	this->m_num = num;
	
	m_ppPrim = new CPrimitive*[num];

	for(int i=0;i<num;i++){
		switch(pData[i].type){
		case OBJ_TYPE_SPHERE:
			m_ppPrim[i] = new CSphere();
			((CSphere*)m_ppPrim[i])->Init(pData+i);
			break;
		case OBJ_TYPE_TRIANGLE:
			m_ppPrim[i] = new CTriangle();
			((CTriangle*)m_ppPrim[i])->Init(pData+i);
			break;
		}
	}
}
// ---------------------------------------------------------------------------
void CMesh::Delete()
{
	int i;

	if(m_ppPrim){
		for(i=0;i<m_num;i++){
			if(m_ppPrim[i]) {delete m_ppPrim[i];m_ppPrim[i]=NULL;}
		}
		delete[] m_ppPrim;
		m_ppPrim = NULL;
	}
	m_num = 0;
}
// ---------------------------------------------------------------------------
float CMesh::IsAcross(float dist, D3DXVECTOR4 *n, D3DXVECTOR4 *p, CPrimitive **dest, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	float ttmp;
	D3DXVECTOR4 ntmp, ptmp;

	for(int i = 0; i<m_num; i++){
		switch(m_ppPrim[i]->m_type){
		case OBJ_TYPE_SPHERE:
			ttmp = ((CSphere*)m_ppPrim[i])->IsAcross(&ntmp, &ptmp, x, v);
			break;
		case OBJ_TYPE_TRIANGLE:
			ttmp = ((CTriangle*)m_ppPrim[i])->IsAcross(&ntmp, &ptmp, x, v);
			break;
		}
		if(0<=ttmp && ttmp<dist){
			dist = ttmp;
			*n = ntmp;
			*p = ptmp;
			*dest = m_ppPrim[i];
		}
	}

	return dist;
}
// ---------------------------------------------------------------------------
bool CMesh::IsAcross(float dist, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	D3DXVECTOR4 ntmp, ptmp;

	for(int i = 0; i<m_num; i++){
		float d;
		switch(m_ppPrim[i]->m_type){
		case OBJ_TYPE_SPHERE:
			d = ((CSphere*)m_ppPrim[i])->IsAcross(&ntmp, &ptmp, x, v);
			break;
		case OBJ_TYPE_TRIANGLE:
			d = ((CTriangle*)m_ppPrim[i])->IsAcross(&ntmp, &ptmp, x, v);
			break;
		}
		if(0.001*dist<=d && d<0.99f*dist) return TRUE;
	}

	return FALSE;
}


};// namespace Render
