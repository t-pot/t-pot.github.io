// ----------------------------------------------------------------------------
//
// draw.h - Render scene
// 
// Copyright (c) 2002 imagire takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _DRAW_H
#define	_DRAW_H

#include <d3d8.h>
#include <d3dx8.h>

HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDEV);
void Render(LPDIRECT3DDEVICE8 lpD3DDEV);
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDEV);

#endif /* !_DRAW_H */
