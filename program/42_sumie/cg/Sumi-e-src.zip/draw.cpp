// ----------------------------------------------------------------------------
//
// draw.cpp : Render scene
// 
// Copyright (c) 2002 imagire takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#define STRICT

#include <windows.h>
#include "Cg/cgD3D.h"
#include "main.h"
#include "draw.h"

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Objects
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Cg object
cgDirect3D cg;
cgContextContainer * pCg = 0;

// ----------------------------------------------------------------------------
// vertex shader
cgProgramContainer		*pVs = 0;           // vertex container
cgBindIter				*const_texcoord0= 0;// texture coord
cgBindIter				*const_texcoord1= 0;// texture coord
cgBindIter				*const_texcoord2= 0;// texture coord
cgBindIter				*const_texcoord3= 0;// texture coord

cgVertexAttribute vertex_attributes[] = {   // input
    {4, "Position", 0},
    {2, "Texcoord", 0},
    {0, 0, 0},
};

// ----------------------------------------------------------------------------
// pixel shader
cgProgramContainer		*pPs = 0;           // pixel shader
cgBindIter * tex0_iter = 0;                 // texture
cgBindIter * tex1_iter = 0;                 // texture
cgBindIter * tex2_iter = 0;                 // texture
cgBindIter * tex3_iter = 0;                 // texture


// ----------------------------------------------------------------------------
// vertex & index buffer

#define D3DFVF_SUMIE_VERTEX 	(D3DFVF_XYZ    | D3DFVF_TEX1)
#define D3DFVF_DROP_VERTEX 		(D3DFVF_XYZRHW | D3DFVF_TEX1)	// for Drop texture
typedef struct {
	float x, y, z, w;
	float tu,tv;
}D3D_SUMIE_VERTEX;

LPDIRECT3DVERTEXBUFFER8	pFinalVB = NULL;
LPDIRECT3DVERTEXBUFFER8	pDropVB = NULL;
LPDIRECT3DVERTEXBUFFER8	pSumieVB = NULL;
LPDIRECT3DINDEXBUFFER8	pSumieIB = NULL;

// ----------------------------------------------------------------------------
// Surface & texture
LPDIRECT3DTEXTURE8		pDropTexture = NULL;		// dot texture
LPDIRECT3DTEXTURE8		pRenderTexture[2] = {NULL,NULL};
LPDIRECT3DSURFACE8		pRenderSurface[2] = {NULL,NULL};
LPDIRECT3DSURFACE8		pBackbuffer = NULL;



// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Drop dot
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Initialize
HRESULT InitDrop(LPDIRECT3DDEVICE8 lpD3DDev)
{
    HRESULT hr = S_OK;

	// Create vertex buffers
    D3D_SUMIE_VERTEX vertices[] = {
        //     x,      y,    z,  rhw,  tu  tv
        { 100.0f, 100.0f, 0.5f, 1.0f, 0.0f,0.0f,},
        { 420.0f, 100.0f, 0.5f, 1.0f, 1.0f,0.0f,},
        { 100.0f, 340.0f, 0.5f, 1.0f, 0.0f,1.0f,},
        { 420.0f, 340.0f, 0.5f, 1.0f, 1.0f,1.0f,},
    };
    
    hr = lpD3DDev->CreateVertexBuffer( 4*sizeof(D3D_SUMIE_VERTEX),0,
                    D3DFVF_DROP_VERTEX, D3DPOOL_DEFAULT, &pDropVB);
    if(FAILED(hr)) return E_FAIL;

    VOID* pVertices;
    hr = pDropVB->Lock( 0, sizeof(vertices), (BYTE**)&pVertices, 0);
    if(FAILED(hr)) return E_FAIL;
    memcpy( pVertices, vertices, sizeof(vertices) );
    pDropVB->Unlock();

	// Load texture
	D3DXCreateTextureFromFileEx(lpD3DDev, "mask.bmp",0,0,0,0,D3DFMT_A8R8G8B8,
                                D3DPOOL_MANAGED, D3DX_FILTER_LINEAR, D3DX_FILTER_LINEAR,
                                0, NULL, NULL, &pDropTexture);

	return hr;
}
// ----------------------------------------------------------------------------
// Request
static float drop_x=0;
static float drop_y=0;
static int drop = 0;
// ----------------------------------------------------------------------------
void SetDrop(float x , float y)
{
	drop = 100;
	drop_x = x;
	drop_y = y;
}
// ----------------------------------------------------------------------------
void ResetDrop()
{
	drop = 0;
}
// ----------------------------------------------------------------------------
int IsDrop()
{
	return drop;
}
// ----------------------------------------------------------------------------
// Rendering
void RenderDrop(LPDIRECT3DDEVICE8 lpD3DDev)
{
	if(drop){
		D3D_SUMIE_VERTEX *p;
		pDropVB->Lock( 0, 4*sizeof(D3D_SUMIE_VERTEX), (BYTE**)&p, 0);
		const float r = 8.0f;// radius of dot
		p[0].x = p[2].x = drop_x-r;
		p[1].x = p[3].x = drop_x+r;
		p[0].y = p[1].y = drop_y-r;
		p[2].y = p[3].y = drop_y+r;
		pDropVB->Unlock();

		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		lpD3DDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCCOLOR);
		lpD3DDev->SetRenderState(D3DRS_SRCBLEND,  D3DBLEND_ZERO);

		lpD3DDev->SetTexture( 0, pDropTexture);
		lpD3DDev->SetTexture( 1, 0);
		lpD3DDev->SetTexture( 2, 0);
		lpD3DDev->SetTexture( 3, 0);
		lpD3DDev->SetStreamSource( 0, pDropVB, sizeof(D3D_SUMIE_VERTEX) );
		lpD3DDev->SetVertexShader( D3DFVF_DROP_VERTEX );
		lpD3DDev->SetPixelShader ( 0 );
		lpD3DDev->DrawPrimitive(  D3DPT_TRIANGLESTRIP, 0, 2 );

		lpD3DDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	}
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Render Target
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Initialize Rendering Texture
//-----------------------------------------------------------------------------
HRESULT InitRenderTexture(LPDIRECT3DDEVICE8 lpD3DDev)
{
	HRESULT hr;
	DWORD i;
	
    // ==================================================
    // Vertex & Index buffer
    // ==================================================
	// Create Vertex buffer
    D3D_SUMIE_VERTEX *pDest;
    WORD *pIndex;
    hr = lpD3DDev->CreateVertexBuffer( 4 * sizeof(D3D_SUMIE_VERTEX),
                                D3DUSAGE_WRITEONLY, D3DFVF_SUMIE_VERTEX, D3DPOOL_MANAGED,
                                &pSumieVB );
    pSumieVB->Lock ( 0, 0, (BYTE**)&pDest, 0 );
    for (i = 0; i < 4; i++) {
        pDest->x   = (i == 0 || i == 1)?-1:(float)1;
        pDest->y   = (i == 0 || i == 2)?-1:(float)1;
        pDest->z   = 0.5f;
        pDest->w   = 1.0f;
        pDest->tu = (i == 2 || i == 3)?1:(float)0;
        pDest->tv = (i == 0 || i == 2)?1:(float)0;
        pDest++;
    }       
    pSumieVB->Unlock ();
    // Create Index Buffer
    hr = lpD3DDev->CreateIndexBuffer( 6 * sizeof(WORD),
                               0,
                               D3DFMT_INDEX16, D3DPOOL_MANAGED,
                               &pSumieIB );
    pSumieIB->Lock ( 0, 0, (BYTE**)&pIndex, 0 );
    pIndex[0] = 0;  pIndex[1] = 1;  pIndex[2] = 2;
    pIndex[3] = 1;  pIndex[4] = 3;  pIndex[5] = 2;
    pSumieIB->Unlock ();

    // ==================================================
    // Programmable shader
    // ==================================================
    cg.AddFilePath("..");
    pCg = cg.CreateContextContainer(lpD3DDev);

    // ==================================================
    // Vertex Shader
    pVs = pCg->LoadCGProgramFromFile(
        "sumie.vsh", "Sumie Vertex Shader", cgDX8VertexProfile, vertex_attributes);
    
   if (NULL == pVs) {
        // ERROR
        const char * listing = pCg->GetLastListing();
        if (listing == 0) listing = "Could not find cgc.exe.";
        cg.NotePad("Failed to Create Vertex Program\n\n", listing);    // Output error
        exit(1);    // END
    }
  
    const_texcoord0 = pVs->GetParameterBindByName("const_texcoord0");
    const_texcoord1 = pVs->GetParameterBindByName("const_texcoord1");
    const_texcoord2 = pVs->GetParameterBindByName("const_texcoord2");
    const_texcoord3 = pVs->GetParameterBindByName("const_texcoord3");

    float const inv_w = 1.0f / (float)WIDTH;
    float const inv_h = 1.0f / (float)HEIGHT;
	pVs->SetShaderConstant( const_texcoord0, &D3DXVECTOR2  (( 0.0f    +0.5f)*inv_w, ( 0.0f+0.5f)*inv_h)  );
	pVs->SetShaderConstant( const_texcoord1, &D3DXVECTOR2  (( 0.0f    +0.5f)*inv_w, (-1.0f+0.5f)*inv_h)  );
	pVs->SetShaderConstant( const_texcoord2, &D3DXVECTOR2  ((-0.57735f+0.5f)*inv_w, ( 0.5f+0.5f)*inv_h)  );
	pVs->SetShaderConstant( const_texcoord3, &D3DXVECTOR2  ((+0.57735f+0.5f)*inv_w, ( 0.5f+0.5f)*inv_h)  );

    // ==================================================
    // Pixel Shader
    pPs = pCg->LoadCGProgramFromFile( "sumie.psh", "Sumie Pixel Shader", cgDX8PixelProfile);
    
    if (NULL == pPs) {
        // ERROR
        const char * error_text = pCg->GetLastListing();
        cg.NotePad("Failed to Create Pixel Program\n\n", error_text);    // Output error

        exit(1);    // END
    }
 
    tex0_iter = pPs->GetTextureBindByName("tex0");
    tex1_iter = pPs->GetTextureBindByName("tex1");
    tex2_iter = pPs->GetTextureBindByName("tex2");
    tex3_iter = pPs->GetTextureBindByName("tex3");

    // ==================================================
    // Surface
    // ==================================================
	D3DSURFACE_DESC Desc;
	LPDIRECT3DSURFACE8 lpZbuffer = NULL;
	if( FAILED(hr = lpD3DDev->GetRenderTarget(&pBackbuffer))) return hr;
	if( FAILED(hr = pBackbuffer->GetDesc( &Desc ))) return hr;

	if( FAILED(hr = lpD3DDev->GetDepthStencilSurface( &lpZbuffer ))) return hr;
	
	for( i=0 ; i<2 ; i++ ){
		if( FAILED(hr = lpD3DDev->CreateTexture(Desc.Width, Desc.Height, 1
								, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &pRenderTexture[i]))) return hr;
		if( FAILED(hr = pRenderTexture[i]->GetSurfaceLevel(0,&pRenderSurface[i]))) return hr;
		if( FAILED(hr = lpD3DDev->SetRenderTarget(pRenderSurface[i], lpZbuffer ))) return hr;
	}

	lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );
	
	return S_OK;
}
// ----------------------------------------------------------------------------
// Rendering
// ----------------------------------------------------------------------------
void RenderSumie(LPDIRECT3DDEVICE8 lpD3DDev, int id)
{
	pVs->SetShaderActive();
	pPs->SetShaderActive();
	pPs->SetTexture(tex0_iter, pRenderTexture[id]);
	pPs->SetTexture(tex1_iter, pRenderTexture[id]);
	pPs->SetTexture(tex2_iter, pRenderTexture[id]);
	pPs->SetTexture(tex3_iter, pRenderTexture[id]);
	lpD3DDev->SetStreamSource( 0, pSumieVB, sizeof(D3D_SUMIE_VERTEX) );
	lpD3DDev->SetIndices(pSumieIB,0);
	lpD3DDev->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, 4, 0, 2 );
}

// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
// Final rendering
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Initialize
HRESULT InitFinal(LPDIRECT3DDEVICE8 lpD3DDev)
{
    HRESULT hr = S_OK;

	// Create vertex buffer
    D3D_SUMIE_VERTEX vertices[] = {
        //  x,      y,    z,   rhw,  tu  tv
        {  0.0f,   0.0f, 0.5f, 1.0f, 0.0f,0.0f,},
        { WIDTH,   0.0f, 0.5f, 1.0f, 1.0f,0.0f,},
        {  0.0f, HEIGHT, 0.5f, 1.0f, 0.0f,1.0f,},
        { WIDTH, HEIGHT, 0.5f, 1.0f, 1.0f,1.0f,},
    };
    
    hr = lpD3DDev->CreateVertexBuffer( 4*sizeof(D3D_SUMIE_VERTEX),0,
                    D3DFVF_DROP_VERTEX, D3DPOOL_DEFAULT, &pFinalVB);
    if(FAILED(hr)) return hr;

    VOID* pVertices;
    hr = pFinalVB->Lock( 0, sizeof(vertices), (BYTE**)&pVertices, 0);
    if(FAILED(hr)) return hr;
    memcpy( pVertices, vertices, sizeof(vertices) );
    pFinalVB->Unlock();

	return hr;
}
// ----------------------------------------------------------------------------
// Rendering
void RenderFinal(LPDIRECT3DDEVICE8 lpD3DDev)
{
	lpD3DDev->SetStreamSource( 0, pFinalVB, sizeof(D3D_SUMIE_VERTEX) );
	lpD3DDev->SetVertexShader( D3DFVF_DROP_VERTEX );
	lpD3DDev->SetPixelShader(NULL);	
	lpD3DDev->DrawPrimitive(  D3DPT_TRIANGLESTRIP, 0, 2 );
}



//-----------------------------------------------------------------------------
// Name: Initialize and setup some rendering states
//-----------------------------------------------------------------------------
HRESULT InitRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	HRESULT hr = S_OK;
	int i;

	if ( FAILED(hr = InitDrop(lpD3DDev)))return hr;

	// �����_�����O�e�N�X�`���[�p�̏�����
	if ( FAILED(hr = InitRenderTexture(lpD3DDev)))return hr;

	// �ŏI�`�撸�_�o�b�t�@�̏�����
	if ( FAILED(hr = InitFinal(lpD3DDev)))return hr;

	// �s�ςȃ��W�X�^�̐ݒ�
	lpD3DDev->SetRenderState( D3DRS_ZENABLE, TRUE );
    lpD3DDev->SetRenderState( D3DRS_LIGHTING,  FALSE );
    for (i = 0; i < 4; ++i) {
		lpD3DDev->SetTextureStageState(i, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
		lpD3DDev->SetTextureStageState(i, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
		lpD3DDev->SetTextureStageState(i, D3DTSS_MIPFILTER, D3DTEXF_NONE);
		lpD3DDev->SetTextureStageState(i, D3DTSS_ADDRESSU,  D3DTADDRESS_CLAMP);
		lpD3DDev->SetTextureStageState(i, D3DTSS_ADDRESSV,  D3DTADDRESS_CLAMP);
		lpD3DDev->SetTextureStageState(i, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
		lpD3DDev->SetTextureStageState(i, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    }

    return hr;
}

//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID Render(LPDIRECT3DDEVICE8 lpD3DDev)
{
	static DWORD id = 0;
	id = 1-id;

	LPDIRECT3DSURFACE8 lpZbuffer = NULL;
	lpD3DDev->GetDepthStencilSurface( &lpZbuffer );
	lpD3DDev->SetRenderTarget(pRenderSurface[id], lpZbuffer);

	RenderSumie(lpD3DDev, 1-id);
	RenderDrop(lpD3DDev);

	static int first = 2;
	if(0<first){
		first--;
		lpD3DDev->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(255,255,255,255),1.0f,0);
	}

	lpD3DDev->SetRenderTarget(pBackbuffer, lpZbuffer );
	lpD3DDev->SetTexture( 0, pRenderTexture[id]);
	lpD3DDev->SetTexture( 1, NULL);
	lpD3DDev->SetTexture( 2, NULL);
	lpD3DDev->SetTexture( 3, NULL);
	RenderFinal(lpD3DDev);
}
//-----------------------------------------------------------------------------
// Name: CleanRender()
//-----------------------------------------------------------------------------
void CleanRender(LPDIRECT3DDEVICE8 lpD3DDev)
{
	DWORD i;
	
	for( i=0 ; i<2 ; i++ ){
		RELEASE(pRenderSurface[i]);
		RELEASE(pRenderTexture[i]);
	}
	RELEASE(pBackbuffer);
	
	RELEASE(pFinalVB);
	RELEASE(pDropVB);
	RELEASE(pDropTexture);
}
