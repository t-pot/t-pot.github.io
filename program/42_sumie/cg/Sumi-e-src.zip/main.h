// ----------------------------------------------------------------------------
//
// main.h
// 
// Copyright (c) 2002 imagire takashi (imagire@nifty.com)
// All Rights Reserved.
//
// ----------------------------------------------------------------------------
#ifndef _MAIN_H
#define	_MAIN_H

#define	CAPTION			"Sumie Shader"
#define	WIDTH			512
#define	HEIGHT			512


#define RELEASE(o)	if (o){o->Release();o=NULL;}

#endif /* !_MAIN_H */
