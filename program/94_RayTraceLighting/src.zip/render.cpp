#include "stdafx.h"
#include "math.h"
#include "render.h"

namespace Render {

// �w�i�F
D3DXVECTOR3 BG_COLOR = D3DXVECTOR3(0.25f, 0.4f, 0.5f);

class CCamera
{
private:
	D3DXMATRIX  m_mView;
	D3DXMATRIX  m_mProj;
	D3DXMATRIX  m_mVP;
	D3DXMATRIX  m_mVP_Inv;
	D3DXMATRIX  m_mView_Inv;

	D3DXVECTOR3 m_vFrom;
	D3DXVECTOR3 m_vLookat;
	D3DXVECTOR3 m_vUp;

	float	m_fFovy;
	float	m_fAspect;
	float   m_fNear;
	float   m_fFar;

public:

	void Update();
	void SetFrom  (const D3DXVECTOR3 *p){m_vFrom  =*p;}
	void SetLookAt(const D3DXVECTOR3 *p){m_vLookat=*p;}
	void SetUp    (const D3DXVECTOR3 *p){m_vUp    =*p;}
	void SetFovY  (float val){m_fFovy   = val;}
	void SetAspect(float val){m_fAspect = val;}
	void SetNear  (float val){m_fNear   = val;}
	void SetFar   (float val){m_fFar    = val;}

	inline const D3DXMATRIX *GetViewInverse() const {return &m_mView_Inv;}
	inline const D3DXMATRIX *GetViewProjInverse() const {return &m_mVP_Inv;}
	inline void GetFrom (D3DXVECTOR3 *dest) const {*dest = m_vFrom;}
};

// ---------------------------------------------------------------------------
// �I�u�W�F�N�g
// ---------------------------------------------------------------------------
char s_data[4*RENDER_WIDTH*RENDER_HEIGHT];// ���z�t���[���o�b�t�@
CCamera camera;
CTriangle  room[12];	// ����
CTriangle  blocks[10];	// �Ⴂ��
CTriangle  blockt[10];	// ������
CSphere sphere;			// �Ⴂ�Ƃ���ɂ����
CSphere tphere;			// �����Ƃ���ɂ����

// ---------------------------------------------------------------------------
// ��
OBJ_DATA sphere_data[] = {
{// �������̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.01f, 0.05f, 0.02f },
		{0.01f, 0.05f, 0.02f },
		{0.10f, 0.10f, 0.10f },
		16.0f,
	},{{0,0,0},{0,0,0},{0,0,0}},{
		{185.5, 165+100,169},
		100.0f,
	}
},{// �傫���̂ɏ���Ă�ق�
	OBJ_TYPE_SPHERE,
	{
		{0.02f, 0.01f, 0.05f},
		{0.02f, 0.01f, 0.05f},
		{0.10f, 0.10f, 0.10f },
		8.0f,
	},{{0,0,0},{0,0,0},{0,0,0}},{
		{368.5, 330+100,351},
		100.0f,
	}
}};
// ---------------------------------------------------------------------------
// ����
OBJ_DATA room_data[12] = {
{// ���C�g�P
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f, 100.0f, 100.0f},
		{  0.0f,   0.0f,   0.0f},
		{  0.0f,   0.0f,   0.0f},
		0.0f,
	},{
		{213.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 227.0},
	}
},{// ���C�g�Q
	OBJ_TYPE_TRIANGLE,
	{
		{100.0f, 100.0f, 100.0f},
		{  0.0f,   0.0f,   0.0f},
		{  0.0f,   0.0f,   0.0f},
		0.0f,
	},{
		{343.0, 548.799f, 227.0},
		{213.0, 548.799f, 332.0},
		{343.0, 548.799f, 332.0},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.01f, 0.01f},
		{0.05f, 0.01f, 0.01f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{552.8f,   0.0f,   0.0f},
		{556.0f, 548.8f,   0.0f},
		{549.6f,   0.0f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.01f, 0.01f},
		{0.05f, 0.01f, 0.01f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f,   0.0f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �E�P
	OBJ_TYPE_TRIANGLE,
	{
		{0.01f, 0.01f, 0.05f},
		{0.01f, 0.01f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{0.0f,   0.0f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f,   0.0f},
	}

},{// �E�Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.01f, 0.01f, 0.05f},
		{0.01f, 0.01f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{0.0f, 548.8f,   0.0f},
		{0.0f,   0.0f, 559.2f},
		{0.0f, 548.8f, 559.2f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f,   0.0f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{  0.0f, 548.8f, 559.2f},
	}

},{// ���Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{549.6f,   0.0f, 559.2f},
		{556.0f, 548.8f, 559.2f},
	}

},{// �V��P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f, 548.8f,   0.0f},
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// �V��Q
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f, 548.8f, 559.2f},
		{556.0f, 548.8f, 559.2f},
		{556.0f, 548.8f,   0.0f},
	}

},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f, 0.0f,   0.0f},
		{552.8f, 0.0f,   0.0f},
		{  0.0f, 0.0f, 559.2f},
	}
},{// ���P
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{  0.0f, 0.0f, 559.2f},
		{552.8f, 0.0f,   0.0f},
		{549.6f, 0.0f, 559.2f},
	}
}};

// ---------------------------------------------------------------------------
// �Ⴂ��
OBJ_DATA Short_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{ 82.0f, 165.0f, 225.0f},
		{130.0f, 165.0f,  65.0f},
		{240.0f, 165.0f, 272.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{290.0, 165.0, 114.0},
		{240.0, 165.0, 272.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{290.0, 165.0, 114.0},
		{290.0,   0.0, 114.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{240.0, 165.0, 272.0},
		{290.0,   0.0, 114.0},
		{240.0,   0.0, 272.0},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{290.0,   0.0, 114.0},
		{290.0, 165.0, 114.0},
		{130.0,   0.0,  65.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{130.0,   0.0,  65.0},
		{290.0, 165.0, 114.0},
		{130.0, 165.0,  65.0},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0, 165.0,  65.0},
		{ 82.0, 165.0, 225.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{ 82.0,   0.0, 225.0},
		{130.0,   0.0,  65.0},
		{130.0, 165.0,  65.0},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0, 165.0, 225.0},
		{240.0, 165.0, 272.0},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{240.0,   0.0, 272.0},
		{ 82.0,   0.0, 225.0},
		{ 82.0, 165.0, 225.0},
	}
}};

// ---------------------------------------------------------------------------
// ������
OBJ_DATA Tall_block[] = {
{
	// ��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{314.0f, 330.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f, 330.0f, 406.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{423.0f,   0.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{423.0f, 330.0f, 247.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{423.0f, 330.0f, 247.0f},
		{472.0f,   0.0f, 406.0f},
		{472.0f, 330.0f, 406.0f},
	}
},{//�w��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{314.0f, 330.0f, 456.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{314.0f, 330.0f, 456.0f},
		{472.0f, 330.0f, 406.0f},
		{472.0f,   0.0f, 406.0f},
	}
},{//����
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f,   0.0f, 296.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{314.0f,   0.0f, 456.0f},
		{265.0f, 330.0f, 296.0f},
		{314.0f, 330.0f, 456.0f},
	}
},{//�O��
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{265.0f,   0.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{265.0f, 330.0f, 296.0f},
	}
},{
	OBJ_TYPE_TRIANGLE,
	{
		{0.05f, 0.05f, 0.05f},
		{0.05f, 0.05f, 0.05f},
		{0.00f, 0.00f, 0.00f},
		32.0f,
	},{
		{265.0f, 330.0f, 296.0f},
		{423.0f,   0.0f, 247.0f},
		{423.0f, 330.0f, 247.0f},
	}
}};

// ---------------------------------------------------------------------------
// �֐��錾
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y);


// ---------------------------------------------------------------------------
// �J�����N���X
// ---------------------------------------------------------------------------
void CCamera::Update()
{
    D3DXMatrixLookAtLH( &m_mView, &m_vFrom, &m_vLookat, &m_vUp );
    D3DXMatrixPerspectiveFovLH( &m_mProj, m_fFovy, m_fAspect, m_fNear, m_fFar );
	m_mVP = m_mView * m_mProj;

	D3DXMatrixInverse( &m_mView_Inv, NULL, &m_mView);
	D3DXMatrixInverse( &m_mVP_Inv, NULL, &m_mVP);
}
// ---------------------------------------------------------------------------
char *GetDataPointer()
{
	return s_data;
}
// ---------------------------------------------------------------------------
void Init()
{
	int i,j;

	// �t���[���o�b�t�@�̏�����
	for(j=0;j<RENDER_HEIGHT;j++){
	for(i=0;i<RENDER_WIDTH ;i++){
		s_data[4*(j*RENDER_WIDTH+i)+0]=(char)255;// R
		s_data[4*(j*RENDER_WIDTH+i)+1]=(char)(i*256/RENDER_WIDTH );// G
		s_data[4*(j*RENDER_WIDTH+i)+2]=(char)(j*256/RENDER_HEIGHT);// B
	}
	}
	
	// �J�����̐ݒ�
	camera.SetFrom  (&D3DXVECTOR3(278,273,-800));
	camera.SetLookAt(&D3DXVECTOR3(278,273,0));
	camera.SetUp    (&D3DXVECTOR3(0,1,0));
	camera.SetFovY  (D3DX_PI/4);
	camera.SetAspect(1.0f);
	camera.SetNear  (0.01f);
	camera.SetFar   (100.0f);
	camera.Update();

	// �I�u�W�F�N�g�̏�����
	sphere.Init(&sphere_data[0]);
	tphere.Init(&sphere_data[1]);
	for(i=0;i<12;i++){
		room[i].Init(&room_data[i]);
	}
	for(i=0;i<10;i++){
		blocks[i].Init(&Short_block[i]);
	}
	for(i=0;i<10;i++){
		blockt[i].Init(&Tall_block[i]);
	}
}
// ---------------------------------------------------------------------------
void Delete()
{
}
// ---------------------------------------------------------------------------
void Render()
{
	for(int j=0;j<RENDER_HEIGHT;j++){
	for(int i=0;i<RENDER_WIDTH ;i++){
		D3DXVECTOR3 col;
		GetColor(&col, ((float)i+0.5f)/(float)RENDER_WIDTH
					 , ((float)j+0.5f)/(float)RENDER_HEIGHT);
		s_data[4*(j*RENDER_WIDTH+i)+0]=(char)(255.9*min(1,col.x));// R
		s_data[4*(j*RENDER_WIDTH+i)+1]=(char)(255.9*min(1,col.y));// G
		s_data[4*(j*RENDER_WIDTH+i)+2]=(char)(255.9*min(1,col.z));// B
	}
	}
}

// ---------------------------------------------------------------------------
// ��{�I�u�W�F�N�g
// ---------------------------------------------------------------------------
void CObject::Init(OBJ_DATA *pData)
{
	m_type=pData->type;

	this->m_material = pData->material;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *CObject::GetColor(D3DXVECTOR3 *dest, float LN, float HN )
{
	*dest = *(D3DXVECTOR3*)&this->m_material.COLOR_AMB
		  + *(D3DXVECTOR3*)&this->m_material.COLOR_DIF * LN
		  + *(D3DXVECTOR3*)&this->m_material.COLOR_SPE * powf(HN, this->m_material.speq_power);

	return dest;
}
// ---------------------------------------------------------------------------
// ��
// ---------------------------------------------------------------------------
CSphere::CSphere()
{
}
// ---------------------------------------------------------------------------
void CSphere::Init(OBJ_DATA *pData)
{
	((CObject*)this)->Init(pData);

	this->center.x = pData->sphere.center[0];
	this->center.y = pData->sphere.center[1];
	this->center.z = pData->sphere.center[2];

	radius_sq = pData->sphere.radius;
	radius_sq *= radius_sq;
}
// ---------------------------------------------------------------------------
float CSphere::IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	FLOAT t, tp, tn;

	// �����Ƃ̔���

	D3DXVECTOR4 xc = (*x)-center;
	FLOAT xc2 = D3DXVec3Dot((D3DXVECTOR3 *)&xc, (D3DXVECTOR3 *)&xc);
	FLOAT vxc = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&xc);
	FLOAT D = sqrtf(vxc*vxc-xc2+radius_sq);
	
	if(D<0) return -INFINTY_DIST;

	tp = -vxc+D;
	tn = -vxc-D;

	if(tn<0){
		if(tp<0) return -INFINTY_DIST;
		t = tp;
	}else{
		t = tn;
	}

	*p = (*x)+t*(*v);
	*n = *p-center;
	D3DXVec3Normalize((D3DXVECTOR3*)n, (D3DXVECTOR3*)n);

	return t;
}

// ---------------------------------------------------------------------------
// �R�p�`
// ---------------------------------------------------------------------------
CTriangle::CTriangle()
{
}
// ---------------------------------------------------------------------------
void CTriangle::Init(OBJ_DATA *pData)
{
	((CObject*)this)->Init(pData);

	this->pos[0] = D3DXVECTOR4(	pData->triangle.x0[0],
								pData->triangle.x0[1],
								pData->triangle.x0[2],
								1.0f);
	this->pos[1] = D3DXVECTOR4(	pData->triangle.x1[0],
								pData->triangle.x1[1],
								pData->triangle.x1[2],
								1.0f);
	this->pos[2] = D3DXVECTOR4(	pData->triangle.x2[0],
								pData->triangle.x2[1],
								pData->triangle.x2[2],
								1.0f);

	// �@���x�N�g���̌v�Z
	D3DXVECTOR4 t0 = this->pos[1]-this->pos[0];
	D3DXVECTOR4 t1 = this->pos[2]-this->pos[0];
	D3DXVec3Cross((D3DXVECTOR3*)&normal, (D3DXVECTOR3*)&t1, (D3DXVECTOR3*)&t0);
	D3DXVec3Normalize((D3DXVECTOR3*)&normal, (D3DXVECTOR3*)&normal);
	normal.w = 0;
}
// ---------------------------------------------------------------------------
float CTriangle::IsAcross(D3DXVECTOR4 *n, D3DXVECTOR4 *p, const D3DXVECTOR4 *x, const D3DXVECTOR4 *v)
{
	FLOAT t;

	// �����Ƃ̔���
	D3DXVECTOR4 xp = this->pos[0]-(*x);

	FLOAT xpn = D3DXVec3Dot((D3DXVECTOR3 *)&xp, (D3DXVECTOR3 *)&normal);
	FLOAT vn  = D3DXVec3Dot((D3DXVECTOR3 *)v, (D3DXVECTOR3 *)&normal);
	
	if(-0.00001f<=vn)return -INFINTY_DIST;// �J�����O�Ɩ�������O��

	t = xpn/vn;
	
	if(t<0) return -INFINTY_DIST;// �������̃��C�͖���

	*p = (*x)+t*(*v);
	*n = normal;

	D3DXVECTOR4 d0, d1;
	D3DXVECTOR3 c;
	d0 = (*p)-this->pos[0];
	d1 = this->pos[1]-this->pos[0];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	d0 = (*p)-this->pos[1];
	d1 = this->pos[2]-this->pos[1];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	d0 = (*p)-this->pos[2];
	d1 = this->pos[0]-this->pos[2];
	D3DXVec3Cross(&c, (D3DXVECTOR3*)&d1, (D3DXVECTOR3*)&d0);
	if(D3DXVec3Dot(&c, (D3DXVECTOR3 *)&normal)>0)return -INFINTY_DIST;
	
	return t;
}


// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, D3DXVECTOR4 *x, D3DXVECTOR4 *v)
{
	D3DXVECTOR4 light_pos   = D3DXVECTOR4(278.f, 548.8f, 279.5f,1);// �����̈ʒu
	D3DXVECTOR3 light_color = D3DXVECTOR3( 10.f,   9.0f,   5.0f);  // �����̐F

	float ttmp;
	D3DXVECTOR4 ptmp;
	D3DXVECTOR4 ntmp;
	int i;
	
	float t = CObject::INFINTY_DIST;	// �ŋߐڃI�u�W�F�N�g�Ƃ̋���
	D3DXVECTOR4 p;						// �ŋߐړ_
	D3DXVECTOR4 n;						// �ŋߐړ_�ł̖@��
	CObject *pObj = NULL;				// �ŋߐڃI�u�W�F�N�g

	// ��ԋ߂��ɂ���I�u�W�F�N�g����������
	ttmp = sphere.IsAcross(&ntmp, &ptmp, x, v);
	if(0<=ttmp && ttmp<t){
		t = ttmp;
		n = ntmp;
		p = ptmp;
		pObj = &sphere;
	}
	ttmp = tphere.IsAcross(&ntmp, &ptmp, x, v);
	if(0<=ttmp && ttmp<t){
		t = ttmp;
		n = ntmp;
		p = ptmp;
		pObj = &tphere;
	}
	for(i = 0; i<12; i++){
		ttmp = room[i].IsAcross(&ntmp, &ptmp, x, v);
		if(0<=ttmp && ttmp<t){
			t = ttmp;
			n = ntmp;
			p = ptmp;
			pObj = &room[i];
		}
	}

	for(i = 0; i<10; i++){
		ttmp = blocks[i].IsAcross(&ntmp, &ptmp, x, v);
		if(0<=ttmp && ttmp<t){
			t = ttmp;
			n = ntmp;
			p = ptmp;
			pObj = &blocks[i];
		}
	}
	for(i = 0; i<10; i++){
		ttmp = blockt[i].IsAcross(&ntmp, &ptmp, x, v);
		if(0<=ttmp && ttmp<t){
			t = ttmp;
			n = ntmp;
			p = ptmp;
			pObj = &blockt[i];
		}
	}


	if( pObj ){
		// ������
		
		// �I�u�W�F�N�g�̐F��Phong�̋��ʔ��˂Ōv�Z����
		D3DXVECTOR4 l = light_pos-p;
		float L2 = D3DXVec3Dot((D3DXVECTOR3 *)&l, (D3DXVECTOR3 *)&l);
		D3DXVec3Normalize((D3DXVECTOR3 *)&l, (D3DXVECTOR3 *)&l);

		D3DXVECTOR3 dir, H;
		// �����̌v�Z
		camera.GetFrom(&dir);
		dir = dir - *(D3DXVECTOR3 *)&p;
		D3DXVec3Normalize(&dir, &dir);
		// �n�[�t�x�N�g��
		H = dir+*(D3DXVECTOR3 *)&l;
		D3DXVec3Normalize((D3DXVECTOR3 *)&H, (D3DXVECTOR3 *)&H);

		float LN = D3DXVec3Dot((D3DXVECTOR3 *)&l, (D3DXVECTOR3 *)&n);
		float HN = D3DXVec3Dot((D3DXVECTOR3 *)&H, (D3DXVECTOR3 *)&n);
		if(LN<0) LN=0;
		if(HN<0) HN=0;

		pObj->GetColor(dest, LN, HN);
		
		// �����̐F�̔��f
		dest->x *= light_color.x;
		dest->y *= light_color.y;
		dest->z *= light_color.z;
		
		// ���̋����̓K���ȕ␳
		*dest *= min(1.5f, 500000.0f/(10000.0f+L2)); // �����ɂ��␳
		*dest *= min(1, l.y+0.1f);					// ���̌�����cos�Ƃ̊֐��ɂ���
		
	}else{
		// �O��
		*dest = BG_COLOR;
	}


	return dest;
}
// ---------------------------------------------------------------------------
D3DXVECTOR3 *GetColor(D3DXVECTOR3 *dest, float x, float y)
{
	D3DXVECTOR4 ray_start_proj = D3DXVECTOR4(-2*x+1, -2*y+1, 0, 1);// �O���N���b�v��
	D3DXVECTOR4 ray_eye        = D3DXVECTOR4(0, 0, 0, 1);// �r���[��Ԃł̃J�����̈ʒu
	D3DXVECTOR4 ray_start;
	D3DXVECTOR4 ray_to;
	D3DXVECTOR4 ray_dir;
	D3DXMATRIX mInv;
	
	// ���_���ˉe��Ԃ��烏�[���h���W�ɕϊ�����
	D3DXVec4Transform( &ray_start, &ray_eye,        camera.GetViewInverse() );
	D3DXVec4Transform( &ray_to,    &ray_start_proj, camera.GetViewProjInverse() );
	D3DXVec4Scale( &ray_to,    &ray_to,    1.0f/ray_to.w   );// w=1 �̎ˉe��Ԃɗ��Ƃ�
	// �����̌v�Z
	ray_dir = ray_to - ray_start;
	D3DXVec4Normalize(&ray_dir, &ray_dir);
	
	// �F�v�Z
	return GetColor(dest, &ray_start, &ray_dir);
}

};// namespace Render
