//-------------------------------------------------------------
// File: main.cpp
//
// Desc: �ۉe
//-------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"
#include "main.h"

static const UINT MAP_SIZE = 256;

//-------------------------------------------------------------
// �O���[�o���ϐ�
//-------------------------------------------------------------
CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;


//-------------------------------------------------------------
// Name: WinMain()
// Desc: ���C���֐�
//-------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




//-------------------------------------------------------------
// Name: CMyD3DApplication()
// Desc: �A�v���P�[�V�����̃R���X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::CMyD3DApplication()
{
	m_pMeshBG					= new CD3DMesh();				

	m_pMapZ						= NULL;
	m_pIrradianceMap			= NULL;
	m_pIrradianceMapSurf		= NULL;
	m_pSubLightMap[0]			= NULL;
	m_pSubLightMap[1]			= NULL;
	m_pSubLightMapSurf[0]		= NULL;
	m_pSubLightMapSurf[1]		= NULL;
	m_pPosMap					= NULL;
	m_pPosMapSurf				= NULL;
	m_pDistMap					= NULL;
	m_pDistMapSurf				= NULL;
	m_bDistMap					= FALSE;

	m_pEffect					= NULL;
	m_pDecl						= NULL;
	m_hTechPos					= NULL;
	m_hTechDist					= NULL;
	m_hTechIrradiance			= NULL;
	m_hTechSubLight				= NULL;
	m_hTechFinal				= NULL;
	m_hmWVP						= NULL;
	m_hvDir						= NULL;
	m_htDecale					= NULL;
	m_htIrradiance				= NULL;
	m_htSubLight				= NULL;


	m_zoom						= 5.0f;
    m_fWorldRotX                = -0.26337099f;
	m_fWorldRotY                = 1.8705539f;
	m_LightDir					= D3DXVECTOR3( 0.8f, 0.6f,-0.0f);


	m_dwCreationWidth           = 500;
    m_dwCreationHeight          = 375;
    m_strWindowTitle            = TEXT( "main" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pFont                     = new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
    m_bLoadingApp               = TRUE;
    
	ZeroMemory( &m_UserInput, sizeof(m_UserInput) );
}




//-------------------------------------------------------------
// Name: ~CMyD3DApplication()
// Desc: �f�X�g���N�^
//-------------------------------------------------------------
CMyD3DApplication::~CMyD3DApplication()
{
}




//-------------------------------------------------------------
// Name: OneTimeSceneInit()
// Desc: ��x�����s��������
//		�E�B���h�E�̏�������IDirect3D9�̏������͏I����Ă܂��B
//		�����ALPDIRECT3DDEVICE9 �̏������͏I����Ă��܂���B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    // ���[�f�B���O���b�Z�[�W��\������
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}




//-------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: �������̎��ɌĂ΂�܂��B�K�v�Ȕ\�͂��`�F�b�N���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps
						, DWORD dwBehavior, D3DFORMAT Format )
{
    BOOL bCapsAcceptable = TRUE;

	UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
    // �s�N�Z���V�F�[�_�o�[�W�����`�F�b�N
    if( pCaps->PixelShaderVersion < D3DPS_VERSION(2,0) )
        bCapsAcceptable = FALSE;

    // ���_�V�F�[�_�o�[�W��������ʂ��\�t�g�E�F�A���_����
    if( pCaps->VertexShaderVersion < D3DVS_VERSION(1,1) )
        if( (dwBehavior & D3DCREATE_SOFTWARE_VERTEXPROCESSING ) == 0 )
            bCapsAcceptable = FALSE;

	return bCapsAcceptable;
}


//-------------------------------------------------------------
// Name: InitDeviceObjects()
// Desc: �f�o�C�X���������ꂽ��̏����������܂��B
//		�t���[���o�b�t�@�t�H�[�}�b�g��f�o�C�X�̎�ނ��ς����
//		��ɒʉ߂��܂��B
//		�����Ŋm�ۂ�����������DeleteDeviceObjects()�ŊJ�����܂�
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InitDeviceObjects()
{
    HRESULT hr;

	// �w�i���b�V���̓ǂݍ���
	if( FAILED( hr = m_pMeshBG->Create(m_pd3dDevice, "map.x" )))
		return DXTRACE_ERR( "Load Mesh", hr );
	m_pMeshBG->SetFVF( m_pd3dDevice, D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1 );
		
	// �V�F�[�_�̓ǂݍ���
	LPD3DXBUFFER pErr;
    if( FAILED( hr = D3DXCreateEffectFromFile(
						m_pd3dDevice, "hlsl.fx", NULL, NULL, 
						D3DXSHADER_DEBUG , NULL, &m_pEffect, &pErr ) ) ){
		MessageBox( NULL, (LPCTSTR)pErr->GetBufferPointer(), "ERROR", MB_OK);
		return DXTRACE_ERR( "CreateEffectFromFile", hr );
	}
	m_hTechPos	      = m_pEffect->GetTechniqueByName( "TPos" );
	m_hTechDist       = m_pEffect->GetTechniqueByName( "TDistance" );
	m_hTechIrradiance = m_pEffect->GetTechniqueByName( "TIrradiance" );
	m_hTechSubLight   = m_pEffect->GetTechniqueByName( "TSubLight" );
	m_hTechFinal      = m_pEffect->GetTechniqueByName( "TFinal" );

	m_hmWVP			= m_pEffect->GetParameterByName( NULL, "mWVP" );
	m_hvDir			= m_pEffect->GetParameterByName( NULL, "vLightDir" );
	m_htDecale		= m_pEffect->GetParameterByName( NULL, "TexDecale" );
	m_htIrradiance	= m_pEffect->GetParameterByName( NULL, "TexIrradiance" );
	m_htSubLight	= m_pEffect->GetParameterByName( NULL, "TexSubLight" );

	// ���_�錾�̃I�u�W�F�N�g�̐���(�n�`�p)
	D3DVERTEXELEMENT9 decl[] =
	{
		{0,  0, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
		{0, 12, D3DDECLTYPE_FLOAT3,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,	0},
		{0, 24, D3DDECLTYPE_FLOAT2,   D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
		D3DDECL_END()
	};
	if( FAILED( hr = m_pd3dDevice->CreateVertexDeclaration( decl, &m_pDecl )))
		return DXTRACE_ERR ("CreateVertexDeclaration", hr);

	// �t�H���g
    m_pFont->InitDeviceObjects( m_pd3dDevice );
    
	return S_OK;
}

//-------------------------------------------------------------
// Name: RestoreDeviceObjects()
// Desc: ��ʂ̃T�C�Y���ύX���ꂽ�����ɌĂ΂�܂��B
//		�m�ۂ�����������InvalidateDeviceObjects()�ŊJ�����܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
	m_pMeshBG->RestoreDeviceObjects(m_pd3dDevice);

	// �����_�����O�^�[�Q�b�g�[�x�̐���
	if (FAILED(m_pd3dDevice->CreateDepthStencilSurface(MAP_SIZE, MAP_SIZE, 
		D3DFMT_D16, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pMapZ, NULL)))
		return E_FAIL;
	// �Ǝ˃}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture( MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pIrradianceMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pIrradianceMap->GetSurfaceLevel(0, &m_pIrradianceMapSurf)))
		return E_FAIL;
	// �\�ʉ��U���}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pSubLightMap[0], NULL)))
		return E_FAIL;
	if (FAILED(m_pSubLightMap[0]->GetSurfaceLevel(0, &m_pSubLightMapSurf[0])))
		return E_FAIL;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pSubLightMap[1], NULL)))
		return E_FAIL;
	if (FAILED(m_pSubLightMap[1]->GetSurfaceLevel(0, &m_pSubLightMapSurf[1])))
		return E_FAIL;
	// �����}�b�v
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &m_pPosMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pPosMap->GetSurfaceLevel(0, &m_pPosMapSurf)))
		return E_FAIL;
	// �s�N�Z���Ԃ̋���
	m_bDistMap = FALSE;
	if (FAILED(m_pd3dDevice->CreateTexture(MAP_SIZE, MAP_SIZE, 1, 
		D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &m_pDistMap, NULL)))
		return E_FAIL;
	if (FAILED(m_pDistMap->GetSurfaceLevel(0, &m_pDistMapSurf)))
		return E_FAIL;


	// ��������Z�k�`������Ă݂�
	#define RS   m_pd3dDevice->SetRenderState
	#define SAMP m_pd3dDevice->SetSamplerState

    // �����_�����O��Ԃ̐ݒ�
    RS  ( D3DRS_ZENABLE,        TRUE );
	SAMP( 0, D3DSAMP_ADDRESSU,  D3DTADDRESS_CLAMP );
	SAMP( 0, D3DSAMP_ADDRESSV,  D3DTADDRESS_CLAMP );
    SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
    SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	// ���C�g�̐ݒ�
	D3DLIGHT9 light;
	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL,-m_LightDir.x,-m_LightDir.y,-m_LightDir.z );
	m_pd3dDevice->SetLight( 0, &light );
	m_pd3dDevice->LightEnable( 0, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );

    // ���[���h�s��
    D3DXMatrixIdentity( &m_mWorld );

    // �ˉe�s��̐ݒ�
    FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width )
				  / ((FLOAT)m_d3dsdBackBuffer.Height);
    D3DXMatrixPerspectiveFovLH( &m_mProj, D3DX_PI/4, fAspect
								, 1.0f, 100.0f );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_mProj );

	
	if( m_pEffect!=NULL ) m_pEffect->OnResetDevice();// �V�F�[�_

    m_pFont->RestoreDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: FrameMove()
// Desc: ���t���[���Ă΂�܂��B�A�j���̏����Ȃǂ��s���܂��B
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FrameMove()
{
	UpdateInput( &m_UserInput ); // ���̓f�[�^�̍X�V

	//---------------------------------------------------------
	// ���͂ɉ����č��W�n���X�V����
	//---------------------------------------------------------
	// ��]
    if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
        m_fWorldRotY += m_fElapsedTime;
    else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
        m_fWorldRotY -= m_fElapsedTime;

    if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
        m_fWorldRotX += m_fElapsedTime;
    else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
        m_fWorldRotX -= m_fElapsedTime;

	// �Y�[��
	if(m_UserInput.bZ && !m_UserInput.bX)
		m_zoom += 0.01f;
	else if(m_UserInput.bX && !m_UserInput.bZ)
		m_zoom -= 0.01f;

	//---------------------------------------------------------
	// �s��̍X�V
	//---------------------------------------------------------
	// ���[���h�̉�]
	D3DXMATRIX m, matRotX, matRotY;
    D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
    D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
    D3DXMatrixMultiply( &m_mCamera, &matRotY, &matRotX );

    // �r���[�s��
	D3DXVECTOR3 vEye    = D3DXVECTOR3( 0.0f, 0.0f, -m_zoom );
    D3DXVECTOR3 vLookat = D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
    D3DXVECTOR3 vUp     = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &m_mView, &vEye, &vLookat, &vUp );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &m_mView );


    return S_OK;
}




//-------------------------------------------------------------
// Name: UpdateInput()
// Desc: ���̓f�[�^���X�V����
//-------------------------------------------------------------
void CMyD3DApplication::UpdateInput( UserInput* pUserInput )
{
    pUserInput->bRotateUp    = ( m_bActive && (GetAsyncKeyState( VK_UP )    & 0x8000) == 0x8000 );
    pUserInput->bRotateDown  = ( m_bActive && (GetAsyncKeyState( VK_DOWN )  & 0x8000) == 0x8000 );
    pUserInput->bRotateLeft  = ( m_bActive && (GetAsyncKeyState( VK_LEFT )  & 0x8000) == 0x8000 );
    pUserInput->bRotateRight = ( m_bActive && (GetAsyncKeyState( VK_RIGHT ) & 0x8000) == 0x8000 );
	pUserInput->bZ = ( m_bActive && (GetAsyncKeyState( 'Z' ) & 0x8000) == 0x8000 );
	pUserInput->bX = ( m_bActive && (GetAsyncKeyState( 'X' ) & 0x8000) == 0x8000 );
}




//-------------------------------------------------------------
// Name: Render()
// Desc: ��ʂ�`�悷��.
//-------------------------------------------------------------
HRESULT CMyD3DApplication::Render()
{
	LPDIRECT3DSURFACE9 pOldBackBuffer, pOldZBuffer;
	D3DVIEWPORT9 oldViewport;
	D3DXMATRIX m, mL;
	D3DXVECTOR4 v;
	FLOAT ds = 0.5f/(FLOAT)MAP_SIZE;// �e�N�Z�����S�ړ��p
	FLOAT dt = 0.5f/(FLOAT)MAP_SIZE;

	static int id = 0;	// �\�ʉ��U���}�b�v�̂ǂ�����g����
	id ^= 1;

	// �ύX�p�r���[�|�[�g    x y   width   height  minz maxz
	D3DVIEWPORT9 viewport = {0,0, MAP_SIZE,MAP_SIZE,0.0f,1.0f};

	if( SUCCEEDED( m_pd3dDevice->BeginScene()))	// �`��̊J�n
    {
		if(m_pEffect != NULL)
		{
			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�̕ۑ�
			//-------------------------------------------------
			m_pd3dDevice->GetRenderTarget(0, &pOldBackBuffer);
			m_pd3dDevice->GetDepthStencilSurface(&pOldZBuffer);
			m_pd3dDevice->GetViewport(&oldViewport);

			if(!m_bDistMap){// �����}�b�v�̐���
				m_bDistMap = TRUE;
				//---------------------------------------------
				// �����}�b�v�̐���
				//---------------------------------------------
				m_pd3dDevice->SetRenderTarget(0, m_pPosMapSurf);
				m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);
				m_pd3dDevice->SetViewport(&viewport);

				// �����_�����O�^�[�Q�b�g�̃N���A
				m_pd3dDevice->Clear(0L, NULL,
								D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
								0x000000, 1.0f, 0L);

				m_pEffect->SetTechnique( m_hTechPos );
				m_pEffect->Begin( NULL, 0 );
				m_pEffect->Pass( 0 );
				m_pd3dDevice->SetVertexDeclaration( m_pDecl );

				m_pMeshBG->Render( m_pd3dDevice );

				m_pEffect->End();

				//---------------------------------------------
				// �����}�b�v�̐���
				//---------------------------------------------
				m_pd3dDevice->SetRenderTarget(0, m_pDistMapSurf);
				m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);
				m_pd3dDevice->SetViewport(&viewport);

				// �����_�����O�^�[�Q�b�g�̃N���A
				m_pd3dDevice->Clear(0L, NULL,
								D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
								0x000000, 1.0f, 0L);

				m_pEffect->SetTechnique( m_hTechDist );
				m_pEffect->Begin( NULL, 0 );
				m_pEffect->Pass( 0 );
				m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

				typedef struct {FLOAT p[3]; FLOAT tu, tv;} TVERTEX;

				TVERTEX Vertex[4] = {
					//x  y   z     tu    tv
					{-1,-1, 0.1f, 0.0f+ds, 1.0f+dt,},
					{ 1,-1, 0.1f, 1.0f+ds, 1.0f+dt,},
					{ 1, 1, 0.1f, 1.0f+ds, 0.0f+dt,},
					{-1, 1, 0.1f, 0.0f+ds, 0.0f+dt,},
				};
				m_pd3dDevice->SetTexture( 0, m_pPosMap );
				m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );

				m_pEffect->End();

				//---------------------------------------------
				// �\�ʉ��U���}�b�v�̃N���A
				//---------------------------------------------
				id = 0;
				for(int i=0; i<2; i++){
					m_pd3dDevice->SetRenderTarget(0, m_pSubLightMapSurf[i]);
					m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);
					m_pd3dDevice->SetViewport(&viewport);

					// �����_�����O�^�[�Q�b�g�̃N���A
					m_pd3dDevice->Clear(0L, NULL,
									D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
									0x000000, 1.0f, 0L);
				}
			}
			//---------------------------------------------
			// �Ǝ˃}�b�v�̐���
			//---------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pIrradianceMapSurf);
			m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);
			m_pd3dDevice->SetViewport(&viewport);

			// �����_�����O�^�[�Q�b�g�̃N���A
			m_pd3dDevice->Clear(0L, NULL,
							D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
							0x000000, 1.0f, 0L);

			m_pEffect->SetTechnique( m_hTechIrradiance );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );
			m_pd3dDevice->SetVertexDeclaration( m_pDecl );

			D3DXMatrixInverse( &m, NULL, &m_mCamera);
			D3DXVec3Transform( &v, &m_LightDir, &m );
			v.w = 0.1f;// ���F
			m_pEffect->SetVector( m_hvDir, &v );

			m_pMeshBG->Render( m_pd3dDevice );

			m_pEffect->End();

			//---------------------------------------------
			// �\�ʉ��U���}�b�v�̐���
			//---------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, m_pSubLightMapSurf[id]);
			m_pd3dDevice->SetDepthStencilSurface(m_pMapZ);
			m_pd3dDevice->SetViewport(&viewport);

			m_pEffect->SetTechnique( m_hTechSubLight );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );

			m_pEffect->SetTexture( m_htIrradiance, m_pIrradianceMap);
			m_pEffect->SetTexture( m_htSubLight, m_pSubLightMap[1-id]);
			m_pd3dDevice->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );

			typedef struct {FLOAT p[3]; FLOAT tu, tv;} TVERTEX;
			TVERTEX Vertex[4] = {
				//x  y   z     tu    tv
				{-1,-1, 0.1f, 0.0f+ds, 1.0f+dt,},
				{ 1,-1, 0.1f, 1.0f+ds, 1.0f+dt,},
				{ 1, 1, 0.1f, 1.0f+ds, 0.0f+dt,},
				{-1, 1, 0.1f, 0.0f+ds, 0.0f+dt,},
			};
			m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );

			m_pEffect->End();


			//-------------------------------------------------
			// �����_�����O�^�[�Q�b�g�����ɖ߂�
			//-------------------------------------------------
			m_pd3dDevice->SetRenderTarget(0, pOldBackBuffer);
			m_pd3dDevice->SetDepthStencilSurface(pOldZBuffer);
			m_pd3dDevice->SetViewport(&oldViewport);
			pOldBackBuffer->Release();
			pOldZBuffer->Release();

			// ��ʂ��N���A����
			m_pd3dDevice->Clear( 0L, NULL,
								D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
								0x4004080, 1.0f, 0L );
			
			// �G�t�F�N�g�̐ݒ�
			m_pEffect->SetTechnique( m_hTechFinal );
			m_pEffect->Begin( NULL, 0 );
			m_pEffect->Pass( 0 );
			m_pd3dDevice->SetVertexDeclaration( m_pDecl );

			m = m_mCamera * m_mView * m_mProj;
			m_pEffect->SetMatrix( m_hmWVP, &m );

			// �w�i�̕`��
			m_pMeshBG->Render( m_pd3dDevice );

			m_pEffect->End();
		}

#if 1 // �f�o�b�O�p�Ƀe�N�X�`����\������
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLOROP,    D3DTOP_SELECTARG1);
	m_pd3dDevice->SetTextureStageState(0,D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	m_pd3dDevice->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
	m_pd3dDevice->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
	m_pd3dDevice->SetVertexShader(NULL);
	m_pd3dDevice->SetPixelShader(0);
	for(DWORD loop = 0; loop < 2; loop++){
		const float scale = 64.0f;
		typedef struct {FLOAT p[4]; FLOAT tu, tv;} TVERTEX;

		TVERTEX Vertex[4] = {
			//       x        y   z rhw tu tv
			{(loop  )*scale,    0,0, 1, 0.0f+ds, 0.0f+dt,},
			{(loop+1)*scale,    0,0, 1, 1.0f+ds, 0.0f+dt,},
			{(loop+1)*scale,scale,0, 1, 1.0f+ds, 1.0f+dt,},
			{(loop  )*scale,scale,0, 1, 0.0f+ds, 1.0f+dt,},
		};
		switch(loop){
//		case 0: m_pd3dDevice->SetTexture( 0, m_pPosMap			); break;
//		case 1: m_pd3dDevice->SetTexture( 0, m_pDistMap			); break;
		case 0: m_pd3dDevice->SetTexture( 0, m_pIrradianceMap	); break;
		case 1: m_pd3dDevice->SetTexture( 0, m_pSubLightMap[0]	); break;
		}
		m_pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, Vertex, sizeof( TVERTEX ) );
	}
#endif      
		RenderText();				// �w���v���̕\��

        m_pd3dDevice->EndScene();	// �`��̏I��
    }
	
    return S_OK;
}




//-------------------------------------------------------------
// Name: RenderText()
// Desc: ��Ԃ�w���v����ʂɕ\������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::RenderText()
{
    D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
    TCHAR szMsg[MAX_PATH] = TEXT("");

    FLOAT fNextLine = 40.0f; 

    // ����@��p�����[�^��\������
    fNextLine = (FLOAT) m_d3dsdBackBuffer.Height; 
	sprintf( szMsg, "Zoom: %f", m_zoom );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("Use arrow keys to rotate object") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, TEXT("Press 'z' or 'x' to change zoom") );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    // �f�B�X�v���C�̏�Ԃ�\������
    lstrcpy( szMsg, m_strDeviceStats );
    fNextLine -= 20.0f;m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    lstrcpy( szMsg, m_strFrameStats );
    fNextLine -= 20.0f; m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
    
	return S_OK;
}




//-------------------------------------------------------------
// Name: MsgProc()
// Desc: WndProc ���I�[�o�[���C�h��������
//-------------------------------------------------------------
LRESULT CMyD3DApplication::MsgProc( HWND hWnd,
					UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // ���[�h��
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf(strMsg, TEXT("Loading... Please wait"));
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct,
						DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




//-------------------------------------------------------------
// Name: InvalidateDeviceObjects()
// Desc: RestoreDeviceObjects() �ō쐬�����I�u�W�F�N�g�̊J��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	// �����_�����O�^�[�Q�b�g
	SAFE_RELEASE(m_pIrradianceMapSurf);
	SAFE_RELEASE(m_pIrradianceMap);
	SAFE_RELEASE(m_pSubLightMapSurf[0]);
	SAFE_RELEASE(m_pSubLightMapSurf[1]);
	SAFE_RELEASE(m_pSubLightMap[0]);
	SAFE_RELEASE(m_pSubLightMap[1]);
	SAFE_RELEASE(m_pDistMapSurf);
	SAFE_RELEASE(m_pDistMap);
	SAFE_RELEASE(m_pPosMapSurf);
	SAFE_RELEASE(m_pPosMap);
	SAFE_RELEASE(m_pMapZ);
	m_bDistMap = FALSE;

    if(m_pEffect!=NULL) m_pEffect->OnLostDevice();	// �V�F�[�_

	m_pMeshBG->InvalidateDeviceObjects(); // ���b�V��
	
    m_pFont->InvalidateDeviceObjects();	// �t�H���g

    return S_OK;
}




//-------------------------------------------------------------
// Name: DeleteDeviceObjects()
// Desc: InitDeviceObjects() �ō쐬�����I�u�W�F�N�g���J������
//-------------------------------------------------------------
HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	m_pMeshBG->Destroy();

	SAFE_RELEASE( m_pDecl );		// ���_�錾
	SAFE_RELEASE( m_pEffect );		// �V�F�[�_

    m_pFont->DeleteDeviceObjects();	// �t�H���g

	return S_OK;
}




//-------------------------------------------------------------
// Name: FinalCleanup()
// Desc: �I�����钼���ɌĂ΂��
//-------------------------------------------------------------
HRESULT CMyD3DApplication::FinalCleanup()
{
	SAFE_DELETE( m_pMeshBG ); // ���b�V��

    SAFE_DELETE( m_pFont );	// �t�H���g

    return S_OK;
}




